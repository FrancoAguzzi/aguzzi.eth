module.exports = {
    plugins: [
        ['styled-components', { ssr: true, displayName: true, preprocess: false }],
        [
            'module-resolver',
            {
                root: ['.'],
                alias: {
                    '@api': './api',
                    '@settings': './settings',
                    '@components': './components',
                    '@interfaces': './interfaces',
                    '@features': './features',
                    '@sportech/pools-api': '../pools-api/src',
                },
            },
        ],
    ],
    presets: ['next/babel'],
};
