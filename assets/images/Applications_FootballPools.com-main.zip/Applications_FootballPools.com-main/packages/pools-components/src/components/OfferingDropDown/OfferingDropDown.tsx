import React from 'react';
import styled from 'styled-components';
import { Offerings, BetSlip, Offering } from '@sportech/pools-api';
import { OfferingDropDownListItem } from './OfferingDropDownListItem';

export interface OfferingDropDownProps {
    offers: Offerings;
    selectAmountAction: (id: number, offer: Offering) => void;
    setOfferingDropdownOpen: (val: boolean) => void;
    betslipCurrentSelection: BetSlip;
    setShowMore: (val: boolean) => void;
    setCurrentOffering: (val: number) => void;
}

export const OfferingDropDown = (props: OfferingDropDownProps): JSX.Element => {
    return (
        <React.Fragment>
            <StyledDropdown>
                <ul>
                    {props.offers.offerings.slice(3, props.offers.offerings.length).map((item, index) => (
                        <OfferingDropDownListItem
                            offer={item}
                            selectAmountAction={props.selectAmountAction}
                            key={index}
                            setShowMore={props.setShowMore}
                            setCurrentOffering={props.setCurrentOffering}
                            betslipCurrentSelection={props.betslipCurrentSelection}
                            setOfferingDropdownOpen={props.setOfferingDropdownOpen}
                        />
                    ))}
                </ul>
            </StyledDropdown>
            <DropdownOverlay
                onClick={(): void => {
                    props.setOfferingDropdownOpen(false);
                    props.setCurrentOffering(props.betslipCurrentSelection.priceID);
                }}
            />
        </React.Fragment>
    );
};

const DropdownOverlay = styled.div`
    position: absolute;
    width: 100vw;
    height: 100vw;
    top: 0;
    left: 0;

    z-index: 10;
`;

const StyledDropdown = styled.div`
    margin-top: 10px;
    position: relative;
    z-index: 11;
    height: 200px;
    overflow: scroll;
    width: 100%;
    ul {
        padding: 0 10px;
    }
    li {
        list-style: none;
        font-size: 16px;
        padding: 5px;
        cursor: pointer;
        display: flex;
        flex-wrap: wrap;

        button {
            flex: 1;
        }
    }

    hr {
        width: 95%;
    }
`;
