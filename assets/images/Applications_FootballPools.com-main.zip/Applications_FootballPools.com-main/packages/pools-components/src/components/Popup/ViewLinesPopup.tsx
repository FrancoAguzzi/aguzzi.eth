import React from 'react';
import { ViewMyLinesContent } from '../Styles/defaultPageStyles';
import { Offerings, Competition, toGameType, BetSlipSlice, Wager, BetSlip } from '@sportech/pools-api';
import { ViewLines, ViewLinesCurrent } from '../BetSlip/ViewLines/ViewLines';

interface ViewLinesPopupProps {
    offers: Offerings;
    competitions?: Competition[];
    gameType: keyof BetSlipSlice;
    nothda: boolean;
    wagers: Wager[];
    setViewLinesCurrent?: (viewLinesCurrent: ViewLinesCurrent) => void;
    viewLinesCurrent?: ViewLinesCurrent;
    canEdit?: boolean;
    betslip?: BetSlip;
    setShowWagerFixtures?: (showFixtures: boolean) => void;
    betslipItemSize?: string;
    ballColor?: string;
}

export const ViewLinesPopup = (props: ViewLinesPopupProps): JSX.Element => {
    return (
        <ViewMyLinesContent>
            <ViewLines
                competitions={props.competitions}
                offers={props.offers}
                gameType={toGameType(props.gameType)}
                nothda={props.nothda}
                wagers={props.wagers}
                isMobile
                setViewLinesCurrent={props.setViewLinesCurrent}
                viewLinesCurrent={props.viewLinesCurrent}
                canEdit={props.canEdit}
                betslip={props.betslip}
                setShowWagerFixtures={props.setShowWagerFixtures}
                betslipItemSize={props.betslipItemSize}
                ballColor={props.ballColor}
            />
        </ViewMyLinesContent>
    );
};
