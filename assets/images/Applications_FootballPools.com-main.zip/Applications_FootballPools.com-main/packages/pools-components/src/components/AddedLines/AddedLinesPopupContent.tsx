import React, { useRef, useEffect } from 'react';
import { BetSlip, Offerings } from '@sportech/pools-api';
import styled from 'styled-components';
import { BetSlipCircleList } from '../BetSlip/BetSlipCircleList/BetSlipCircleList';
import Button from '../Common/Button/Button';

interface AddedLinesPopupContentProps {
    betslipselection: Array<BetSlip>;
    offers: Offerings;
    currentBet: BetSlip;
    changeBet: any;
    openErrorPopup: any;
    closePopup: any;
    showHDA: boolean;
    handleCircleNumberClick: any;
    clearLine: any;
    showCountHeader?: boolean;
}

export const AddedLinesPopupContent = (props: AddedLinesPopupContentProps): JSX.Element => {
    const onLineClick = (item: BetSlip, index: number): void => {
        if (!item.current) {
            if (props.currentBet.pick === props.currentBet.numbers?.length || props.currentBet.numbers?.length === 0) {
                props.changeBet(index);
            } else {
                props.closePopup();
                props.openErrorPopup();
            }
        }
    };

    const editLineClick = (index: number): void => {
        props.changeBet(index);
        props.closePopup();
    };

    const removeLineClick = (index: number): void => {
        props.clearLine(index);
    };
    const yourLineItemRef = useRef<HTMLDivElement>(null);
    useEffect(() => {
        if (yourLineItemRef.current != null) {
            yourLineItemRef.current.scrollIntoView({
                behavior: 'smooth',
                block: 'center',
            });
        }
    });
    return (
        <AddedLinesContent>
            {props.betslipselection.map((item, index) => (
                <AddedLinesItem
                    ref={item.current ? yourLineItemRef : null}
                    isActive={item.current}
                    key={index}
                    onClick={() => {
                        onLineClick(item, index);
                    }}
                >
                    <h4>
                        {item.competitionId} {props.offers.offerings.find(x => x.id === item.priceID)?.description} £
                        {(item.price / 100).toFixed(2)}
                    </h4>
                    <ul style={{ padding: '0' }}>
                        <BetSlipCircleList
                            key={index}
                            selection={item.numbers}
                            displayId={props.showHDA}
                            row={0}
                            amount={item.pick}
                            handleOnClick={props.handleCircleNumberClick}
                            isCurrent={item.current}
                            ballColor="#363636"
                            showCountHeader={props.showCountHeader}
                        />
                    </ul>
                    <Button
                        rounded="0"
                        height="auto"
                        bgColor="#38d8ff"
                        textColor="#000"
                        hoverColor="#38D8FF"
                        hoverOpacity="1"
                        onClick={() => editLineClick(index)}
                    >
                        Edit
                    </Button>
                    <Button
                        rounded="0"
                        height="auto"
                        bgColor="#38d8ff"
                        textColor="#000"
                        hoverColor="#38D8FF"
                        hoverOpacity="1"
                        onClick={() => removeLineClick(index)}
                    >
                        Remove
                    </Button>
                </AddedLinesItem>
            ))}
        </AddedLinesContent>
    );
};

type AddedLinesItemProps = {
    isActive: boolean;
};

const AddedLinesContent = styled.div`
    color: white;
    padding: 10px;
    text-align: center;
    font-size: 16px;
    line-height: 24px;
    outline: 0;
    margin-top: 30px;

    p {
        font-weight: bold;
    }
`;

const AddedLinesItem = styled.div<AddedLinesItemProps>`
    width: 98%;
    padding: 1%;
    color: #fff;
    margin: 10px 0;
    text-align: left;

    ${props =>
        props.isActive &&
        `
        border: 2px solid #38d8ff;
    `}

    h4 {
        width: 100%;
        color: #000;
        margin-top: 0;
        padding-left: 10px;
    }
    button {
        font-size: 15px;
        font-weight: bold;
        box-shadow: 0 4px 5px 0 rgba(0, 0, 0, 0.75);
        line-height: 20px;
        margin: 10px 5px;
    }

    ul {
        padding: 5px 17px 5px 10px;
        width: 93%;
    }
`;
