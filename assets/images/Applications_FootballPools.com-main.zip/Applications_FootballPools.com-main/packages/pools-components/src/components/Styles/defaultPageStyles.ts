import styled from 'styled-components';
import { ExternalLink } from '../Common/ExternalLink/ExternalLink';
import { Button } from '../Common/Button/Button';
import { breakpoints } from '../../settings/breakpoints';

export const MenuDropdown = styled.ul`
    padding: 0;
    text-align: center;
    list-style: none;
    margin: 0;
    background: #f5f5f5;
    z-index: 15;
    position: relative;

    li {
        z-index: 15;
        a {
            text-decoration: none;
            display: block;
            padding: 10px 0;
            font-size: 1.3em;
            color: #383838;
            font-weight: bold;
        }
        hr {
            width: 90%;
            margin: 0 0 0 5%;
        }
    }
`;

type StyledHeaderProps = {
    isClassic?: boolean;
};

export const StyledHeader = styled.div<StyledHeaderProps>`
    position: relative;
    width: 100%;
    height: 200px;
    background: ${(props): string => props.theme.colours.gameMainColour};
    color: ${(props): string => props.theme.colours.gameMainColourText};
    text-align: center;
    font-size: 4em;
    padding: 0;
    margin: 0;
    display: flex;
    align-items: center;
    > img {
        width: 100%;
        height: 200px;
        object-fit: cover;
        object-position: left;
        ${breakpoints.below('sm')} {
            height: 60px;
        }
    }
    > p {
        position: absolute;
        ${breakpoints.below('lg')} {
            font-weight: 500;
        }
    }
    p {
        display: inline-block;
        margin: 5px 0;
        padding: 5px 0;
    }

    > p:first-of-type {
        left: 2%;
        top: calc(200px - 2.5em);
        ${breakpoints.below('lg')} {
            top: calc(90px - 3em);
        }
        ${breakpoints.below('sm')} {
            top: calc(56px - 3em);
        }
    }
    button {
        display: none;
    }

    ${breakpoints.below('lg')} {
        font-size: 2em;
        max-height: 90px;

        button {
            display: block;
            position: absolute;
            right: 5%;
            top: 55%;
            background: ${(props): string => props.theme.colours.gameMainColour};
        }

        svg {
            fill: ${(props): string => props.theme.colours.gameMainColourText};
            max-width: 26px;
            width: 26px;
            height: 26px;
        }
    }

    ${breakpoints.below('sm')} {
        max-height: 60px;
        font-size: 1.25em;

        button {
            top: 50%;
        }
    }

    ${props =>
        props.isClassic &&
        ` > p:last-of-type {
                right: 1%;
                top: calc(200px - 2.5em);
                @media (max-width: 1024px) {
                    left: 2%;
                    right: unset;
                    top: calc(126px - 3em);
                }
                @media (max-width: 600px) {
                    left: 2%;
                    right: unset;
                    top: calc(60px - 2em);
                }
            }`}
`;

export const StyledHeaderDesktop = styled.div`
    position: relative;
    width: 100%;
    background: ${props => props.theme.colours.gameMainColour};
    color: ${(props): string => props.theme.colours.gameMainColourText};
    height: 200px;
    text-align: center;
    font-size: 5em;
    padding: 0;
    margin: 0;
    > img {
        width: 100%;
        height: 200px;
    }
    > p {
        position: absolute;
        top: calc(200px - 3em);
    }

    ${breakpoints.below('sm')} {
        display: none;
    }
`;

export const StyledHeaderMobile = styled.div`
    width: 100%;
    background: ${props => props.theme.colours.gameMainColour};
    color: #fff;
    text-align: center;
    font-size: 1.5em;

    margin: 0;
    display: none;
    z-index: 1;
    position: relative;

    ${breakpoints.below('lg')} {
        display: block;
    }

    p {
        display: inline-block;
        margin: 5px 0;
        padding: 5px 0;
    }

    > p {
        position: absolute;
        font-weight: 500;
    }

    > p:first-of-type {
        left: 5%;
        top: calc(78px - 3em);
    }

    button {
        float: right;
        background: ${(props): string => props.theme.colours.gameMainColour};
    }
`;

export const StyledMain = styled.div`
    width: 100%;
    flex: 2;
    background: transparent;
    position: relative;

    ${breakpoints.below('lg')} {
        margin-right: 0px;
    }
`;

export const TitleStyle = styled.p`
    border-bottom: 1px solid #000;
    margin: 20px 0 0;
    color: #000;
    font-size: 16px;
    line-height: 1.2em;
`;
export const StyledSidebar = styled.div<{ background?: string }>`
    max-width: 335px;
    overflow-y: auto;
    background: ${(props): string => (props.background ? props.background : '#fff')};
    flex: 1;
    ${breakpoints.below('lg')} {
        display: none;
    }
`;

export type PageLinkButtonsContainerProps = {
    bgColor: string;
    textColor: string;
};

export const PageLinkButtonsContainer = styled.div<PageLinkButtonsContainerProps>`
    text-align: center;
    width: 100%;
    // background: ${props => props.theme.colours.gameMainColour};
    // padding: 10px 0;
    margin-bottom: 5px;
    font-weight: bold;
    background: ${(props): string => props.bgColor};
    cursor: pointer;
    a {
        color: ${(props): string => props.textColor};
        text-decoration: none;
        font-size: 1.2em;
        display: block;
        padding: 10px 0;
    }
`;

export const NavStyle = styled.div`
    padding: 0;
    margin: 0;

    width: 100%;
    display: flex;
    flex-direction: row;
`;

export const GameInfo = styled.div`
    display: inline-flex;
    flex-direction: column;
    width: 100%;
    justify-content: center;
    margin-top: 5px;
    text-align: center;
    display: inline-block;
    ${breakpoints.below('lg')} {
        flex-direction: row;
    }
`;

export const GameClosesText = styled.div`
    display: inline-block;
    color: #d32704;
    font-weight: bold;
`;

export const PopupText = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: left;
    align-items: left;
    text-align: left;

    p {
        margin: 0 0 15px 0;
    }
`;

export const StyledATag = styled(ExternalLink)`
    text-decoration: underline;
`;

export const StyledBetSlipMobile = styled.div`
    z-index: 2;
    display: flex;
    position: fixed;
    color: #fff;
    background: ${props => props.theme.colours.gameMainColour}; // #313131;
    height: auto;
    padding: 10px 5px;
    bottom: 0;
    left: 0;
    right: 0;
    justify-content: space-around;
    align-items: center;
    flex-wrap: wrap;

    ${breakpoints.above('lg')} {
        display: none;
    }
`;

export const StyledCurrentLineFloating = styled.div`
    z-index: 10;
    display: flex;
    position: fixed;
    color: #fff;
    background: ${props =>
        props.theme.colours.betslipListMobileBackgroundColour
            ? props.theme.colours.betslipListMobileBackgroundColour
            : '#313131'};
    height: auto;
    padding: 0 10px;
    bottom: 69px;
    left: 0;
    right: 0;
    justify-content: flex-start;
    align-items: center;
    flex-wrap: wrap;
    margin: 0;
    ${breakpoints.above('lg')} {
        display: none;
    }

    ul {
        padding: 5px 0;
        flex: unset;
        width: unset;
    }
`;

export const ErrorPopupText = styled.div`
    padding: 10px;
    text-align: center;
    font-size: 16px;
    line-height: 24px;
    outline: 0;

    p {
        font-weight: bold;
    }
    button {
        font-size: 15px;
        font-weight: bold;
        box-shadow: 0 4px 5px 0 rgba(0, 0, 0, 0.75);
        line-height: 20px;
        margin-top: 10px;
        width: 20%;
    }
`;

type StyledNavBarButtonsProps = {
    padding?: string;
};

export const StyledNavBarButtons = styled(Button)<StyledNavBarButtonsProps>`
    color: ${props => props.theme.colours.primaryFont};
    width: 25%;
    height: 60px;
    ${breakpoints.above('lg')} {
        display: flex;
        justify-content: center;
        align-items: center;
    }

    ${breakpoints.below('md')} {
        font-size: 0.75em;
        padding: ${(props): string => (props.padding ? props.padding : '0 14px')};
        height: 50px;
    }
    ${breakpoints.below('sm')} {
        font-size: 0.7em;
    }
    ${breakpoints.below('xxs')} {
        font-size: 0.6em;
    }
    position: relative;

    :not(:first-child)::before {
        content: '';
        height: 75%;
        width: 1px;

        position: absolute;
        left: 0;
        top: 12.5%;

        background-color: #fff;
    }

    img {
        width: 20px;
        ${breakpoints.above('lg')} {
            margin-right: 5px;
        }
    }
    :nth-child(3) {
        p {
            margin: 2px 0 0 0;
            ${breakpoints.below('xxs')} {
                margin: 3px 0 0 0;
            }
        }
    }

    p {
        margin: 1px 0 0 0;
    }
    ${breakpoints.below('lg')} {
        p:nth-of-type(2) {
            margin-top: -5px;
            line-height: 0;
        }
    }
`;

export const MillionText = styled.p`
    margin-right: 3px !important;
    font-weight: bold;
    ${breakpoints.below('lg')} {
        margin-top: -10px !important;
        line-height: 1.5em;
        font-size: 1.5em;
    }
    ${breakpoints.below('sm')} {
        font-size: 1.4em;
        line-height: 1.4em;
        margin-top: -5px !important;
    }

    ${breakpoints.below('xs')} {
        font-size: 1.2em;
        line-height: 1.2em;
        margin-top: 0px !important;
    }
    ${breakpoints.below('xxs')} {
        font-size: 1.2em;
        line-height: 1.2em;
        margin-top: 3px !important;
    }
`;

export const MillionTextFp = styled.div`
    margin-right: 3px !important;
    margin-top: -5px !important;
    font-weight: bold;
    font-size: 1.2em;
    ${breakpoints.below('lg')} {
        line-height: 1.2em;
        font-size: 1.2em;
    }
    ${breakpoints.below('md')} {
        line-height: 1em;
        font-size: 1em;
    }
    ${breakpoints.below('xs')} {
        font-size: 1em;
        line-height: 1em;
        margin-top: 0px !important;
    }
    ${breakpoints.below('xxs')} {
        /* font-size: 0.9em;
        line-height: 0.9em;
        margin-top: 3px !important; */
    }
`;
export const MillionLuckyDipText = styled.div`
    ${breakpoints.below('lg')} {
        line-height: 1em;
        font-size: 1em;
    }
    ${breakpoints.below('md')} {
        line-height: 0.8em;
        font-size: 0.8em;
    }
    /* ${breakpoints.below('xs')} {
        font-size: 1em;
        line-height: 1em;
        margin-top: 0px !important;
    } */
`;

export const StyledNavBarButtonsMobile = styled(Button)`
    position: relative;
    height: 60px;
    ${breakpoints.above('lg')} {
        display: none;
    }
    width: 25%;
    ${breakpoints.below('md')} {
        font-size: 0.75em;
        padding: 0 14px;
        height: 50px;
    }
    ${breakpoints.below('sm')} {
        font-size: 0.7em;
    }
    ${breakpoints.below('xxs')} {
        font-size: 0.6em;
    }

    :before {
        content: '';
        height: 75%;
        width: 1px;

        position: absolute;
        left: 0;
        top: 12.5%;

        background-color: #fff;
    }
    img {
        width: 20px;
    }

    p {
        margin: 1px 0 0 0;
    }
`;

export const ViewMyLinesContent = styled.div`
    color: #000;
    padding: 10px;
    text-align: center;
    font-size: 16px;
    line-height: 24px;
    outline: 0;
    margin-top: 30px;

    p {
        font-weight: bold;
    }
`;

export const PaymentPopupContent = styled.div`
    text-align: center;
`;

export const ClearContainer = styled.div<{ padding?: string }>`
    padding: ${props => props.padding || '0 5px'};
    display: flex;
    align-items: center;
    justify-content: center;
`;

export const MenuDropdownOverlay = styled.div`
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;

    z-index: 10;
    background: rgba(0, 0, 0, 0.5);
`;

export const ViewLinesOverlay = styled.div`
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;

    z-index: 10;
`;

type BannerTextProps = {
    textColor: string;
};

export const BannerText = styled.p<BannerTextProps>`
    color: ${(props): string => (props.textColor ? props.textColor : '#fff')};
`;

export const NotClassicBannerTextRight = styled.span`
    right: 5%;
    top: calc(200px - 2.5em);
    position: absolute;
    ${breakpoints.below('lg')} {
        left: 2%;
        right: unset;
        top: calc(100px - 2.2em);
    }

    ${breakpoints.below('sm')} {
        top: calc(60px - 2em);
    }
`;

export const BannerTextSmall = styled.p`
    font-size: 0.4em;
    white-space: wrap;
    font-weight: 900;
    margin: 0 !important;
    padding: 0 !important;
    line-height: 14px;
    width: 18px;

    ${breakpoints.above('lg')} {
        line-height: 25px;
    }
    ${breakpoints.below('sm')} {
        line-height: 8px;
        width: 10px;
    }
`;

export const ChevronText = styled.div`
    position: absolute;
    top: 20%;

    display: none;

    ${breakpoints.below('lg')} {
        display: block;
        right: 3%;
    }

    ${breakpoints.below('sm')} {
        font-size: 0.8em;
        right: 5%;
    }
`;

export const Container = styled.div`
    display: flex;
    flex: 1;
    overflow: auto;
    align-items: center;
    flex-wrap: nowrap;
    margin: 0;
    width: 100%;

    p {
        margin-left: 2%;
        margin-right: 2%;
    }
`;
