import React from 'react';
import styled from 'styled-components';
import { NumbersSelected } from '@sportech/pools-api';
import { breakpoints } from '../../../settings/breakpoints';
import { NumbersCardBall } from '../NumbersCardBall/NumbersCardBall';
import { testId } from '../../../utils/functionUtils';

export interface NumbersCardProps {
    number: number;
    action?: (id: number, type: string) => void;
    numbers?: NumbersSelected;
    bonusNumbers?: NumbersSelected;
    isResults: boolean;
    matchCardWidth?: string;
    useImage?: boolean;
    highlightBorderColour?: string;
    isClover?: boolean;
}

export const NumbersCard = (props: NumbersCardProps): JSX.Element => {
    return (
        <NumbersCardDiv matchCardWidth={props.matchCardWidth} {...testId(`Game_FixtureButton${props.number}`)}>
            {props.isResults ? <div>{props.number}</div> : <NumbersCardBall {...props} />}
        </NumbersCardDiv>
    );
};

type NumbersCardDivProps = {
    matchCardWidth?: string;
};

const NumbersCardDiv = styled.li<NumbersCardDivProps>`
    width: 80px;
    margin: 10px;
    font-size: 12px;
    ${breakpoints.below('sm')} {
        margin: 0.5% 5px;
        width: 45px;
    }
    ${breakpoints.below('xs')} {
        width: 42px;
    }
`;
