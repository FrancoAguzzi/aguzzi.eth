import React, { useContext } from 'react';
import styled, { ThemeContext } from 'styled-components';
import { BetSlip, Fixture } from '@sportech/pools-api';
import { MatchCard } from '../MatchCard/MatchCard';
import { HdaMatchCard } from '../HdaMatchCard/HdaMatchCard';
import { NumbersCard } from '../NumbersCard/NumbersCard';
import { breakpoints } from '../../../settings/breakpoints';
import { useMediaQuery } from 'react-responsive';

export type GameViewType = 'match' | 'numbers';

export interface GameSectionProps {
    betslipSelection?: BetSlip;
    action?: (id: number, type: string) => void;
    fixtures?: Array<Fixture>;
    isHda?: boolean;
    gameViewType: GameViewType;
    isViewLines: boolean;
    canEdit?: boolean;
    isClover?: boolean;
    background?: string;
    border?: string;
    borderRadius?: string;
    highlightBorderColour?: string;
    margin?: string;
    matchCardWidth?: string;
}
export const GameSection = (props: GameSectionProps): JSX.Element => {
    const themeContext = useContext(ThemeContext);

    const isMobile = useMediaQuery({
        query: `(max-width: ${themeContext.breakpoints.md}px )`,
    });
    return (
        <React.Fragment>
            {props.gameViewType === 'match' ? (
                <GameList margin={props.margin}>
                    {props.isHda
                        ? props.fixtures?.map(item => (
                              <HdaMatchCard
                                  key={item.id}
                                  action={props.action}
                                  matchId={item.id}
                                  number={item.number}
                                  isHda={props.isHda === true}
                                  homeTeam={item.homeTeamDisplay}
                                  awayTeam={item.awayTeamDisplay}
                                  numbers={
                                      props.betslipSelection && props.betslipSelection.numbers
                                          ? props.betslipSelection.numbers?.find(x => x?.Id === item.number)
                                          : undefined
                                  }
                                  isResults={false}
                                  isTwoColumn={false}
                              />
                          ))
                        : props.fixtures?.map(item => (
                              <MatchCard
                                  key={item.id}
                                  action={props.action}
                                  matchId={item.id}
                                  number={item.number}
                                  isHda={props.isHda === true}
                                  homeTeam={item.homeTeamDisplay}
                                  awayTeam={item.awayTeamDisplay}
                                  numbers={
                                      props.betslipSelection && props.betslipSelection.numbers
                                          ? props.betslipSelection.numbers?.find(x => x?.Id === item.number)
                                          : undefined
                                  }
                                  isResults={false}
                                  canEdit={props.canEdit}
                                  isTwoColumn
                                  isMobile={isMobile}
                                  matchCardWidth={props.matchCardWidth}
                              />
                          ))}
                    <EmptyMatchCard aria-hidden="true" />
                    <EmptyMatchCard aria-hidden="true" />
                </GameList>
            ) : (
                <NumbersGameList
                    background={props.background}
                    border={props.border}
                    borderRadius={props.borderRadius}
                    margin={props.margin}
                >
                    {props.fixtures?.map(item => (
                        <NumbersCard
                            key={item.id}
                            action={props.action}
                            number={item.number}
                            numbers={
                                props.betslipSelection && props.betslipSelection.numbers
                                    ? props.betslipSelection.numbers?.find(x => x?.Id === item.number)
                                    : undefined
                            }
                            isResults={false}
                            bonusNumbers={
                                props.betslipSelection && props.betslipSelection.bonusNumbers
                                    ? props.betslipSelection.bonusNumbers?.find(x => x?.Id === item.number)
                                    : undefined
                            }
                            useImage={props.isClover}
                            highlightBorderColour={props.highlightBorderColour}
                            isClover={props.isClover}
                        />
                    ))}
                    {/* used to align bottom row of flex-wrap with the rest of the rows */}
                    <EmptyNumbersCard aria-hidden="true" />
                    <EmptyNumbersCard aria-hidden="true" />
                    <EmptyNumbersCard aria-hidden="true" />
                    <EmptyNumbersCard aria-hidden="true" />
                    <EmptyNumbersCard aria-hidden="true" />
                    <EmptyNumbersCard aria-hidden="true" />
                    <EmptyNumbersCard aria-hidden="true" />
                    <EmptyNumbersCard aria-hidden="true" />
                    <EmptyNumbersCard aria-hidden="true" />
                </NumbersGameList>
            )}
        </React.Fragment>
    );
};

const GameList = styled.ul<{ margin?: string }>`
    list-style: none;
    padding-left: 0px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    margin: ${props => props.margin};

    > span {
        width: 100%;
        > span {
            width: 31%;
            margin: 0.5%;
            float: left;
            font-size: 12px;
        }
    }
`;

const NumbersGameList = styled.ul<{
    background?: string;
    border?: string;
    borderRadius?: string;
    margin?: string;
}>`
    display: flex;
    flex-wrap: wrap;
    list-style: none;
    justify-content: center;
    padding-left: 0px;
    width: 100%;
    background: ${props => props.background};
    border: ${props => props.border};
    border-radius: ${props => props.borderRadius};
    margin: ${props => props.margin};
`;

const EmptyMatchCard = styled.i`
    width: 32%;
    ${breakpoints.below('l')} {
        width: 48%;
    }
    margin: 0.2%;
    float: left;
    font-size: 10px;
    ${breakpoints.below('lg')} {
        width: 48%;
        font-size: 12px;
        margin: 0.5%;
    }
`;

const EmptyNumbersCard = styled.i`
    width: 80px;
    margin: 0.5% 10px;
    ${breakpoints.below('sm')} {
        margin: 0.5% 5px;
        width: 45px;
    }
    ${breakpoints.below('xs')} {
        width: 42px;
    }
`;
