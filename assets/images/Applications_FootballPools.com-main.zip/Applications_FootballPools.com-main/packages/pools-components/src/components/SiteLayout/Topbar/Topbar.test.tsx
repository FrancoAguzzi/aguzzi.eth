import React from 'react';
import { renderWithTheme } from '../../../testing/renderWithTheme';
import Topbar from './Topbar';

// jest.mock('../../../settings/breakpoints');

describe('Topbar', () => {
    it('should render without error', () => {
        const { container } = renderWithTheme(<Topbar urls={[{ label: 'test', url: 'https://test.com' }]} />);
        expect(container).toMatchSnapshot();
    });
});
