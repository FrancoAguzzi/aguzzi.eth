import styled from 'styled-components';
import { breakpoints } from '../../../settings/breakpoints';

export interface ToggleButtonProps {
    active?: boolean;
    toggleStyles?: {
        background?: string;
        activeBackground?: string;
    };
}

export const ToggleButton = styled.label<ToggleButtonProps>`
    margin-right: 5px;
    outline: 0;
    display: inline-block;
    width: 45px;
    height: 22px;
    position: relative;
    cursor: pointer;
    user-select: none;
    background: ${props =>
        props.active
            ? props.toggleStyles?.activeBackground
                ? props.toggleStyles.activeBackground
                : props.theme.colours.gameMainColour
            : props.toggleStyles?.background
            ? props.toggleStyles.background
            : '#d8d8d8'};
    border-radius: 2em;
    padding: 2px;
    transition: left 0.4s ease;

    ${breakpoints.below('lg')} {
        width: 30px;
        height: 15px;
        margin-left: 0;
        margin-top: -7px;
    }

    &:after,
    &:before {
        position: relative;
        content: '';
        width: 50%;
        height: 100%;
    }
    &:before {
        display: none;
    }
    &:after {
        display: block;
        left: ${(props): string => (props.active ? '50%' : '0')};
        border-radius: 50%;
        background: #fff;
        transition: left 0.2s ease;
    }
`;

export default ToggleButton;
