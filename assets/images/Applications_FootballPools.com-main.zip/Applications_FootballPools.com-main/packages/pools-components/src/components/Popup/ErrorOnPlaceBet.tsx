import React, { FunctionComponent } from 'react';
import { useDispatch } from 'react-redux';
import { ErrorPopupText } from '../Styles/defaultPageStyles';
import { Button } from '../Common/Button/Button';
import { closePopup } from '../../state/popupsSlice';

export const ErrorOnPlaceBet: FunctionComponent = () => {
    const dispatch = useDispatch();

    return (
        <ErrorPopupText>
            <p>
                There was a problem with placing your bet. If you are playing with a bonus, this is due to the wager
                being greater than the bonus value. Please play the exact game for which you have received the bonus,
                and to the exact value of that bonus.
            </p>
            <Button
                bgColor="#38d8ff"
                textColor="black"
                height="auto"
                padding="8px 10px"
                rounded="4px"
                hoverColor="#38D8FF"
                onClick={() => dispatch(closePopup('error_on_place_bet'))}
            >
                OK
            </Button>
        </ErrorPopupText>
    );
};
