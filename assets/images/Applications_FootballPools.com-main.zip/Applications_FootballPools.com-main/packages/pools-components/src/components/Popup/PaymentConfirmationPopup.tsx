import React from 'react';
import { PaymentPopupContent } from '../Styles/defaultPageStyles';

interface PaymentConfirmationPopupProps {
    customer?: any;
}

export const PaymentConfirmationPopup = ({ customer }: PaymentConfirmationPopupProps): JSX.Element => {
    return (
        <PaymentPopupContent>
            <p>You&apos;re now in the game!</p>
            <p>Your remaining balance is:</p>

            <p>£{customer.userdata?.cashBalance?.toFixed(2)}</p>
        </PaymentPopupContent>
    );
};
