import React from 'react';
import styled from 'styled-components';
import { breakpoints } from '../../../settings/breakpoints';

interface NavBarProps {
    path?: string;
    user?: any;
}

const Styledatag = styled.a`
    font-size: 16px;
    font-weight: 700;
    padding: 0 10px;
    text-decoration: none;
    display: inline-block;
    color: #000;
    margin-right: 5px;
    &:active {
        color: #000;
        background: #38d8ff;
    }
    &:hover {
        color: #000;
        background: #fff;
        text-decoration: none;
    }
`;
export const NavBar = ({ user }: NavBarProps): JSX.Element => {
    return (
        <Styleddiv>
            <LeftHandSide>
                {/* <Link prefetch={false} href='/classicpools' passHref> */}
                <Styledatag>CLASSIC POOLS</Styledatag>
                {/* </Link> */}
                {/* <Link prefetch={false} href='/goalrush' passHref> */}
                <Styledatag>GOAL RUSH 8</Styledatag>
                {/* </Link> */}
                {/* <Link prefetch={false} href='/premier6' passHref> */}
                <Styledatag>SOCCER 6</Styledatag>
                {/* </Link> */}
                {/* <Link prefetch={false} href='/premier10' passHref> */}
                <Styledatag>PREMIER 10</Styledatag>
                {/* </Link> */}
                {/* <Link prefetch={false} href='/jackpot12' passHref> */}
                <Styledatag>JACKPOT 12</Styledatag>
                {/* </Link> */}
                {/* <Link prefetch={false} href='/luckyclover' passHref> */}
                <Styledatag>LUCKY CLOVER</Styledatag>
                {/* </Link> */}
            </LeftHandSide>
            <RightHandSide>
                {/* <Link href={getHref('results')} passHref> */}
                <Styledatag>Results</Styledatag>
                {/* </Link> */}
                {user && user != null && (
                    // <Link href={getHref('history', router)} passHref>
                    <Styledatag>BET HISTORY</Styledatag>
                    // </Link>
                )}
            </RightHandSide>
        </Styleddiv>
    );
};

const Styleddiv = styled.div`
    line-height: 40px;
    text-transform: uppercase;
    background: #38d8ff;
    ${breakpoints.below('lg')} {
        display: none;
    }
    display: flex;
`;

const RightHandSide = styled.div`
    display: flex;
    justify-content: flex-end;
    flex: 1;
`;

const LeftHandSide = styled.div`
    display: flex;
    justify-content: flex-start;
    flex: 2;
`;
