import React from 'react';
import { render, act, fireEvent, waitFor } from '@testing-library/react';
import 'jest-styled-components';
import { ToggleButton } from './ToggleButton';

const mockFn = jest.fn();
jest.mock('../../../settings/breakpoints');

describe('ToggleButton', () => {
    it('should render', async () => {
        const { container } = render(<ToggleButton onClick={mockFn}>ToggleButton</ToggleButton>);

        await waitFor(() => expect(container).toMatchSnapshot());
    });

    it('should execute a function on click', () => {
        const { getByText } = render(<ToggleButton onClick={mockFn}>ToggleButton</ToggleButton>);

        act(() => {
            fireEvent.click(getByText(/ToggleButton/i));
        });

        expect(mockFn).toHaveBeenCalled();
    });
});
