import React from 'react';
import styled from 'styled-components';
import { BetSlip, Competition } from '@sportech/pools-api';
import { RemoveGameName } from '../../../utils/functionUtils';

export interface CompetitionSelectorProps {
    competitions: Competition[];
    currentCompetition: number;
    ChangeCompetitions: (id: number, desc: string) => void;
    BetSlipSelection: Array<BetSlip>;
    openErrorOnBetslipLinePopup: () => void;
    margin?: string;
    isCurved?: boolean;
    height?: string;
}

export interface CompetitionsStyleProps {
    length?: number;
    active?: boolean;
    offset?: number;
}

export const CompetitionSelector = (props: CompetitionSelectorProps): JSX.Element => {
    const BetslipCurrentSelection = props.BetSlipSelection.filter(x => x.current)[0];
    const currentSelectedIndex: number = props.competitions.findIndex(x => props.currentCompetition === x.id);
    const calculatedoffset: number = currentSelectedIndex * -130 + 10;
    return (
        <ContainerStyle isCurved={props.isCurved} height={props.height}>
            <LeftArrowButtonStyle
                onClick={(): void => {
                    const index = props.competitions.findIndex(x => props.currentCompetition === x.id);
                    if (index > 0) {
                        if (
                            BetslipCurrentSelection.pick === BetslipCurrentSelection.numbers?.length ||
                            BetslipCurrentSelection.numbers?.length === 0
                        ) {
                            props.ChangeCompetitions(
                                props.competitions[index - 1].id,
                                props.competitions[index - 1].description,
                            );
                        } else {
                            props.openErrorOnBetslipLinePopup();
                        }
                    }
                }}
                isCurved={props.isCurved}
            />
            <ScrollStyle>
                <CompetitionsStyle length={props.competitions.length} offset={calculatedoffset}>
                    {props.competitions.map(item => (
                        <ComButtonStyle
                            onClick={(): void => {
                                if (props.currentCompetition !== item.id) {
                                    if (
                                        BetslipCurrentSelection.pick === BetslipCurrentSelection.numbers?.length ||
                                        BetslipCurrentSelection.numbers?.length === 0
                                    ) {
                                        props.ChangeCompetitions(item.id, item.description);
                                    } else {
                                        props.openErrorOnBetslipLinePopup();
                                    }
                                }
                            }}
                            active={props.currentCompetition === item.id}
                            key={item.id}
                        >
                            {RemoveGameName(item.description)}
                        </ComButtonStyle>
                    ))}
                </CompetitionsStyle>
            </ScrollStyle>
            <RightArrowButtonStyle
                onClick={(): void => {
                    const index = props.competitions.findIndex(x => props.currentCompetition === x.id);
                    if (index < props.competitions.length - 1) {
                        if (
                            BetslipCurrentSelection.pick === BetslipCurrentSelection.numbers?.length ||
                            BetslipCurrentSelection.numbers?.length === 0
                        ) {
                            props.ChangeCompetitions(
                                props.competitions[index + 1].id,
                                props.competitions[index + 1].description,
                            );
                        } else {
                            props.openErrorOnBetslipLinePopup();
                        }
                    }
                }}
                isCurved={props.isCurved}
            />
        </ContainerStyle>
    );
};

const ContainerStyle = styled.div<{
    margin?: string;
    isCurved?: boolean;
    height?: string;
}>`
    margin: ${props => props.margin};
    display: flex;
    justify-content: space-between;
    overflow-x: hidden;
    height: ${props => props.height || '55px'};
    background: ${props => props.theme.colours.gameSecondaryColour || '#eaeaea'};
    flex: 2;
    border-radius: ${props => (props.isCurved ? '25px' : undefined)};
`;

const ScrollStyle = styled.div`
    overflow-x: visible;
    margin: 0 5px;
    width: 100%;
    position: relative;
`;

const CompetitionsStyle = styled.div<CompetitionsStyleProps>`
    white-space: nowrap;
    position: absolute;
    left: 100%;
    transition: left 0.5s ease-in-out;
    left: ${props => (props.offset ? `calc((50% - 70px) + ${props.offset}px)` : 'calc(50% + -50px)')};
    bottom: 0;
`;

const LeftArrowButtonStyle = styled.button<{ isCurved?: boolean }>`
    cursor: pointer;
    width: 30px;
    background: ${props => props.theme.colours.gameMainColour};
    border: none;
    border-radius: ${props => (props.isCurved ? '25px 0 0 25px' : undefined)};
    flex-shrink: 0;
    z-index: 4;
    &::after {
        content: '';
        border-style: solid;
        font-size: 0;
        margin-top: 3px;
        display: inline-block;
        border-width: 9px 10px 9px 0;
        border-color: transparent #fff transparent transparent;
    }
`;

const RightArrowButtonStyle = styled.button<{ isCurved?: boolean }>`
    cursor: pointer;
    width: 30px;
    background: ${props => props.theme.colours.gameMainColour};
    border: none;
    border-radius: ${props => (props.isCurved ? '0 25px 25px 0' : undefined)};
    flex-shrink: 0;
    z-index: 4;
    &::after {
        content: '';
        border-style: solid;
        font-size: 0;
        margin-top: 3px;
        display: inline-block;
        border-width: 9px 0 9px 10px;
        border-color: transparent transparent transparent #fff;
    }
`;

const ComButtonStyle = styled.button<CompetitionsStyleProps>`
    display: inline-block;
    min-width: 120px;
    max-width: 200px;

    height: 50px;
    padding: 8px 17px 17px;
    font-size: 17.5px;
    line-height: 40px;
    border: none;
    border-left: ${props => `3px solid ${props.theme.colours.gameSecondaryColour || '#fff'}`};
    border-right: ${props => `3px solid ${props.theme.colours.gameSecondaryColour || '#fff'}`};
    border-radius: 10px 10px 0 0;
    font-weight: 500;
    cursor: pointer;
    background: ${props => (props.active ? '#fff' : '#EDEDED')};
    color: ${props => (props.active ? '#222222' : '#222222')};
    /* box-shadow: ${props => (props.active ? '2px 2px 0 0 #c0c0c0' : '')}; */
    outline: 0;
    font-weight: bold;
`;
