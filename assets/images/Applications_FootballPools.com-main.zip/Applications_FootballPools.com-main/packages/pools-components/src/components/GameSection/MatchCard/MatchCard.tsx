import React from 'react';
import styled from 'styled-components';
import { MatchCardTeams } from '../MatchCardTeams/MatchCardTeams';
import { breakpoints } from '../../../settings/breakpoints';
import { GameType, NumbersSelected, Scores } from '@sportech/pools-api';
import { MatchCardResults } from '../../Results/ResultsSection/MatchCardResults';

export interface MatchCardProps {
    homeTeam: string;
    awayTeam: string;
    number: number;
    matchId: number;
    isHda: boolean;
    action?: (id: number, type: string) => void;
    numbers?: NumbersSelected | undefined;
    isResults: boolean;
    score?: Scores;
    points?: number;
    matchCardWidth?: string;
    gameType?: GameType;
    canEdit?: boolean;
    isTwoColumn?: boolean;
    isMobile?: boolean;
}

export const MatchCard = (props: MatchCardProps): JSX.Element => {
    return (
        <MatchCardDiv
            isResults={props.isResults}
            matchCardWidth={props.matchCardWidth}
            isTwoColumn={props.isTwoColumn}
            isMobile={props.isMobile}
        >
            {props.isResults ? <MatchCardResults {...props} /> : <MatchCardTeams {...props} />}
        </MatchCardDiv>
    );
};

type MatchCardDivProps = {
    matchCardWidth?: string;
    isResults?: boolean;
    isTwoColumn?: boolean;
    isMobile?: boolean;
};

const MatchCardDiv = styled.li<MatchCardDivProps>`
    width: ${props => (props.matchCardWidth ? props.matchCardWidth : '32%')};
    ${breakpoints.below('l')} {
        width: 48%;
    }
    ${breakpoints.below('lg')} {
        margin: 0.5%;
    }
    ${breakpoints.below('md')} {
        width: 48%;
    }
    font-size: 10px;
    margin: 0.6%;
    float: left;
`;
