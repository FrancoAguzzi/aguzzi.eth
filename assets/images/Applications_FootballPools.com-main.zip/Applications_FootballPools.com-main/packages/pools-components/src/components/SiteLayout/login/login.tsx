import React from 'react';
import styled from 'styled-components';
import { breakpoints } from '../../../settings/breakpoints';
import { ExternalLink } from '../../Common/ExternalLink/ExternalLink';

interface LoginProps {
    Account?: () => void;
    UserData?: any;
    isLoading?: boolean;
    UserLoading?: boolean;
    User?: any;
    registerUrl?: string;
    depositUrl?: string;
    accountUrl?: string;
    inboxUrl?: string;
    isMobileOrTablet: boolean;
    mailCount: number;
}

const Login = ({ ...props }: LoginProps): JSX.Element => {
    return (
        <StyledRight>
            {!props.UserLoading &&
                (props.User ? (
                    <BalanceWrapper>
                        {props.User != null && (
                            <AccountName target="_self" href={props.accountUrl}>
                                {props.User.Name}
                            </AccountName>
                        )}
                        <BalanceContainer>
                            <SmallBalance>Balance: </SmallBalance>
                            {!props.isLoading && <Balance>£{props.UserData?.cashBalance?.toFixed(2)}</Balance>}
                        </BalanceContainer>
                        {!props.isMobileOrTablet && (
                            <MailContainer>
                                <Styledatag target="_self" href={props.inboxUrl}>
                                    <img src="/Mail.svg" alt="mail icon" />
                                    {props.mailCount !== undefined && props.mailCount > 0 && (
                                        <RedDot>
                                            {props.mailCount <= 9 ? (
                                                <RedSpotText>{props.mailCount}</RedSpotText>
                                            ) : (
                                                <RedSpotTextNinePlus>9+</RedSpotTextNinePlus>
                                            )}
                                        </RedDot>
                                    )}
                                </Styledatag>
                            </MailContainer>
                        )}

                        <PersonIcon onClick={props.Account}>
                            <SportsIcon>
                                <path d="M16.978,12.344c1.011,-1.088 1.633,-2.566 1.633,-4.122c0,-3.422 -2.8,-6.222 -6.222,-6.222c-3.422,0 -6.222,2.8 -6.222,6.222c0,3.422 2.8,6.222 6.222,6.222c1.244,0 2.333,-0.388 3.267,-0.933c3.422,1.245 5.677,4.356 5.988,7.933l-18.588,0c0.233,-2.411 1.322,-4.666 3.188,-6.3c0.312,-0.311 0.389,-0.777 0.078,-1.088c-0.311,-0.312 -0.778,-0.389 -1.089,-0.078c-2.411,2.1 -3.733,5.055 -3.733,8.244c0,0.467 0.311,0.778 0.778,0.778l20.222,0c0.467,0 0.778,-0.311 0.778,-0.778c0,-4.278 -2.489,-8.089 -6.3,-9.878ZM7.722,8.222c0,-2.566 2.1,-4.666 4.667,-4.666c2.567,0 4.667,2.1 4.667,4.666c0,2.567 -2.1,4.667 -4.667,4.667c-2.567,0 -4.667,-2.1 -4.667,-4.667Z" />
                            </SportsIcon>
                        </PersonIcon>
                        {props.depositUrl && (
                            <StyledButtonDeposit>
                                <a href={props.depositUrl}>DEPOSIT</a>
                            </StyledButtonDeposit>
                        )}
                        <StyledButtonLogOut>
                            <a href="/api/logout">LOG OUT</a>
                        </StyledButtonLogOut>
                    </BalanceWrapper>
                ) : (
                    <React.Fragment>
                        {props.registerUrl && (
                            <StyledButton>
                                <a href={props.registerUrl}>SIGN UP</a>
                            </StyledButton>
                        )}
                        <StyledButton>
                            <a href="/api/login">LOG IN</a>
                        </StyledButton>
                    </React.Fragment>
                ))}
        </StyledRight>
    );
};

export default Login;

const StyledButton = styled.button`
    font-size: 14px;
    font-weight: 700;
    -webkit-font-smoothing: antialiased;
    border: 1px solid transparent;
    color: #000000;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    border-radius: 3px;
    margin: 4px 1px;
    background: #38d8ff;
    height: 35px;
    width: 80px;
    text-transform: none;
    overflow: visible;
    white-space: nowrap;
    overflow: hidden;
    padding: unset;

    a {
        color: #000;
        text-transform: none;
        text-decoration: none;
        display: block;
        height: 100%;

        display: flex;
        align-items: center;
        justify-content: center;
    }
    &:hover {
    }
`;

const StyledButtonDeposit = styled(StyledButton)`
    background: #00cc08;
    color: #000;
    ${breakpoints.below('lg')} {
        display: none;
    }
`;
const StyledButtonLogOut = styled(StyledButton)`
    background: #000;
    a {
        color: #949494;
    }
    ${breakpoints.below('lg')} {
        display: none;
    }
`;
const StyledRight = styled.div`
    display: flex;
    -webkit-box-pack: end;
    justify-content: flex-end;
`;

const BalanceWrapper = styled.div`
    display: flex;
    align-items: center;
`;

const AccountName = styled(ExternalLink)`
    margin-top: 1px;
    color: #fff;
    margin-right: 20px;
    text-decoration: none;
    font-size: 18px;
    font-weight: 700;
    &:hover {
        text-decoration: underline;
        color: #38d8ff;
    }
    ${breakpoints.below('lg')} {
        display: none;
    }
`;

const BalanceContainer = styled.ul`
    display: block;
    list-style-type: none;
    text-align: center;
`;

const SmallBalance = styled.li`
    margin-right: 18px;
    font-size: 12px;
    font-weight: 500;
    color: #fff;
    ${breakpoints.below('lg')} {
        display: none;
    }
`;

const Balance = styled.li`
    font-size: 18px;
    font-weight: 700;
    color: #fff;
    margin-right: 20px;
    ${breakpoints.below('lg')} {
        margin-right: 0;
    }
    ${breakpoints.below('xs')} {
        font-size: 14px;
    }
`;

const PersonIcon = styled.div`
    position: relative;
`;

const SportsIcon = styled.svg`
    display: none;
    width: 25px;
    height: 25px;
    fill: #38d8ff;
    margin: 0 10px 5px;
    ${breakpoints.below('lg')} {
        display: block;
    }
`;

const Styledatag = styled(ExternalLink)`
    color: white;
    text-decoration: none;
`;

const MailContainer = styled.div`
    position: relative;
    display: inline-block;
    width: 34px;
    height: 34px;
    margin-right: 14px;

    img {
        margin: 0;
        padding: 0;
    }
`;

const RedDot = styled.div`
    position: absolute;
    background-color: red;
    width: 16px;
    height: 16px;
    top: 0px;
    right: -6px;
    border-radius: 8px;
`;

const RedSpotText = styled.div`
    position: absolute;
    top: -1px;
    left: 5.5px;
    font-size: 13px;
    color: #fff;
`;

const RedSpotTextNinePlus = styled.div`
    position: absolute;
    top: -1px;
    left: 4px;
    font-size: 13px;
`;
