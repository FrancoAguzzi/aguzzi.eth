import React from 'react';
import 'jest-styled-components';
import { HdaButton } from './HdaButton';
import { renderWithTheme } from '../../../testing/renderWithTheme';

describe('HdaButton', () => {
    it('should render', () => {
        const { container } = renderWithTheme(<HdaButton>home</HdaButton>);

        expect(container).toMatchSnapshot();
    });

    it('should render Active', () => {
        const { container } = renderWithTheme(<HdaButton active>home</HdaButton>);

        expect(container).toMatchSnapshot();
    });
});
