import React from 'react';
import styled from 'styled-components';

const Container = styled.div<{ backgroundColour?: string }>`
    width: 100%;
    text-align: center;
    background: ${props => (props.backgroundColour ? props.backgroundColour : props.theme.colours.gameMainColour)};
    color: #fff;
`;

const Content = styled.div`
    padding: 10px;
    text-align: initial;
    font-size: 14px;
    ul {
        padding: 0 15px;
        li {
            margin-top: 5px;
        }
    }
    a {
        color: #fff;
    }
`;

interface TermsPanelProps {
    content?: string;
    backgroundColour?: string;
    children?: JSX.Element;
}

export const TermsPanel = ({ content, backgroundColour, children }: TermsPanelProps): JSX.Element => {
    // WARNING: this is some dirty stuff.
    return (
        <Container backgroundColour={backgroundColour}>
            {content && (
                <Content
                    dangerouslySetInnerHTML={{
                        __html: content,
                    }}
                />
            )}
            {children}
        </Container>
    );
};
