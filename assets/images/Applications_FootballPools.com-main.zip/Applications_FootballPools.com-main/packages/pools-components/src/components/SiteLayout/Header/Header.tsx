import React, { forwardRef } from 'react';
import styled from 'styled-components';
import Login from '../login/login';
import { breakpoints } from '../../../settings/breakpoints';
// import { Customer } from '@interfaces/FSB/Customer';

interface HeaderProps {
    SideMenu?: () => void;
    Account?: () => void;
    UserData?: any;
    isLoading?: boolean;
    User?: null;
    UserLoading?: boolean;
    isMobileOrTablet: boolean;
    mailCount: number;
}
const Header = forwardRef<HTMLDivElement, HeaderProps>((props: HeaderProps, ref) => {
    return (
        <Styleheader ref={ref}>
            <BurgerIcon onClick={props.SideMenu}>
                <BurgerLine />
                <BurgerLine />
                <BurgerLine />
            </BurgerIcon>
            <Styleatag>
                <StyleaImg
                    src="https://uat-assets.thepools.com/the-pools.svg"
                    width="250"
                    height="50"
                    alt="the pools icon"
                />
            </Styleatag>
            <Login {...props} />
        </Styleheader>
    );
});

Header.displayName = 'Header';

export default Header;

const Styleheader = styled.div`
    margin: 0 auto;
    max-width: 1316px;
    display: flex;
    flex-flow: row nowrap;
    justify-content: space-between;
    align-items: center;
    height: 100%;
    width: 100%;
    background: #363636;

    ${breakpoints.below('lg')} {
        position: sticky;
        top: 0;
        z-index: 100; /* this is optional and should be different for every project */
    }
`;

const Styleatag = styled.a`
    max-width: 1316px;
    color: #fff;
    height: 90px;
    ${breakpoints.below('lg')} {
        height: unset;
    }
`;

const StyleaImg = styled.img`
    box-sizing: border-box;
    padding: 0;
    margin: 0;
    margin-top: 8%;
    ${breakpoints.below('lg')} {
        width: 150px;
        margin-top: 1%;
    }
    ${breakpoints.below('sm')} {
        width: 130px;
        margin-top: 1%;
    }
    ${breakpoints.below('xs')} {
        width: 110px;
        margin-top: 1%;
    }
`;

const BurgerIcon = styled.div`
    display: none;
    ${breakpoints.below('lg')} {
        display: block;
        height: 22px;
        cursor: pointer;
        margin: 6px 5% 0 3%;
    }

    ${breakpoints.below('xs')} {
        display: block;
        height: 22px;
        cursor: pointer;
        margin: 6px 10px 0 3px;
    }
`;
const BurgerLine = styled.div`
    width: 13px;
    height: 2px;
    background-color: white;
    margin: 2px 0;
    border-radius: 1px;
`;
