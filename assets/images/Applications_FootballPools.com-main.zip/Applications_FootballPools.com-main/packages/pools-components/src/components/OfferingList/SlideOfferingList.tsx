import React, { useContext, useRef, useEffect } from 'react';
import MediaQuery from 'react-responsive';
import styled, { ThemeContext } from 'styled-components';
// eslint-disable-next-line import/named
import { Offerings, BetSlip, Offering } from '@sportech/pools-api';
import { Button } from '../Common/Button/Button';

export interface OfferingListProps {
    showMoreValue: boolean;
    setShowMore: (val: boolean) => void;
    offerings: Offerings;
    currentOfferingId: number;
    setCurrentOfferingId: (val: number) => void;
    selectAmount: (id: number, amount: Offering) => void;
    currentSlip: BetSlip;
    isHda: boolean;
    isClover?: boolean;
    showCost?: boolean;
}

export const SlideOfferingList = (props: OfferingListProps): JSX.Element => {
    const themeContext = useContext(ThemeContext);
    const w = (props.offerings.offerings.length * 100) / 100;
    const offeringButtonWidth = `${w < 25 ? 25 : w}%`;

    const scrollToRef = useRef<HTMLLIElement>(null);
    useEffect(() => {
        if (scrollToRef.current) {
            scrollToRef.current.scrollIntoView(false);
        }
    }, [scrollToRef]);

    const getCostLabel = (offer: Offering): string => {
        let cost = offer.pricePerEntry;
        if (
            props.currentSlip &&
            props.currentSlip.priceID === offer.id &&
            offer.bonusId &&
            offer.bonusId > 0 &&
            offer.bonusPricePerEntry &&
            offer.bonusPricePerEntry > 0 &&
            props.currentSlip.bonusNumbers &&
            props.currentSlip.bonusNumbers.length > 0 &&
            props.currentSlip.bonusNumbers.length === offer.bonusMaximumSelections
        ) {
            cost = offer.pricePerEntry + offer.bonusPricePerEntry;
        }
        const ret = `£${(cost / 100).toFixed(2)}`;
        return ret;
    };

    return (
        <StyledListDivoffering isClover={props.isClover as boolean}>
            <StyledListUloffering>
                {props.offerings.offerings.map((item, index) => (
                    <StyledListlioffering
                        key={`OfferingButton_${index}`}
                        ref={props.currentOfferingId === item.id ? scrollToRef : null}
                    >
                        <StyledOfferingButton
                            isActiveLine={props.currentOfferingId === item.id}
                            onClick={(): void => {
                                props.selectAmount(props.currentSlip?.competitionId as number, item);
                                props.setCurrentOfferingId(item.id);
                            }}
                            bgColor={
                                props.currentOfferingId === item.id ? themeContext.colours.gameMainColour : '#EAEAEA'
                            }
                            height="40px"
                            padding="5px"
                            width={offeringButtonWidth.toString()}
                            rounded="0"
                            key={index}
                            textColor={props.currentOfferingId === item.id ? '#fff' : '#000'}
                            hoverColor={props.currentOfferingId === item.id ? '00108B' : '#5c5c5c'}
                            hoverOpacity={props.currentOfferingId === item.id ? '1' : '0.8'}
                        >
                            <MediaQuery maxWidth={1024}>
                                <p>
                                    Pick {item.maximumSelections}
                                    {props.showCost && (
                                        <React.Fragment>
                                            <br />
                                            {getCostLabel(item)}
                                        </React.Fragment>
                                    )}
                                </p>
                            </MediaQuery>
                            <MediaQuery minWidth={1025}>
                                <p>
                                    Pick {item.maximumSelections}
                                    {props.isHda && props.showCost && ` £${(item.pricePerEntry / 100).toFixed(2)}`}
                                </p>
                            </MediaQuery>
                        </StyledOfferingButton>
                    </StyledListlioffering>
                ))}
            </StyledListUloffering>
        </StyledListDivoffering>
    );
};

type StyledListDivofferingProps = {
    isClover: boolean;
};

const StyledListDivoffering = styled.div<StyledListDivofferingProps>`
    display: flex;
    flex-direction: row;
    /* overflow: scroll; */
`;
type StyledOfferingButtonProps = {
    isActiveLine?: boolean;
};
const StyledOfferingButton = styled(Button)<StyledOfferingButtonProps>`
    position: relative;
    img {
        width: 15px;
        position: absolute;
        top: 50%;
        left: 52%;
        transform: translate(-50%, -50%);
    }
    ${props =>
        props.isActiveLine &&
        ` position: relative;
    &:last-of-type:after {
        left: 4%;
    }
    :after {
        content: '';
        position: absolute;
        left: 0;
        right: 0;
        margin: 0 auto;
        width: 0;
        height: 0;
        top: 40px;
        border-top: 10px solid ${props.theme.colours.gameMainColour};
        border-left: 10px solid transparent;
        border-right: 10px solid transparent;
    }
    `}
`;

const StyledListUloffering = styled.ul`
    display: flex;
    list-style-type: none;
    padding: 0;
    margin: 0;
    height: 66px;
    width: 100%;
    background: #fff;
    overflow-x: scroll;
    overflow-y: hidden;

    // Chrome, Edge, Opera, Safari:
    ::-webkit-scrollbar {
        height: 5px;
        width: 5px;
        background: ${props => props.theme.colours.scrollTrackBackground};
    }
    ::-webkit-scrollbar-thumb {
        height: 5px;
        border-radius: 4px;
        background-color: ${props => props.theme.colours.scrollBarBackground};
    }

    // Firefox:
    scrollbar-color: ${props =>
        `${props.theme.colours.scrollBarBackground} ${props.theme.colours.scrollTrackBackground}`}; // bar, track
    scrollbar-width: thin;
`;

const StyledListlioffering = styled.li`
    // float: left;
    font-size: 0.9em;
    line-height: 1em;
    min-width: 100px;
    cursor: default;
    width: 100%;
    background: #fff;
    display: flex;
    flex-wrap: wrap;
    p {
        margin: 0;
    }

    a {
        position: relative;
        display: block;
        background: #0117ae;
        border: 2px solid transparent;
        border-radius: 4px;
        color: #fff;
        font-weight: 500;
        text-align: center;
        padding: 0.35em 0;
        overflow: hidden;
        text-decoration: none;
    }

    &.active a {
        background: $solidCyan;
        color: $solidBlack;
        border-color: $solidCyan;
    }
    &:hover > a {
        color: #000000;
        background: #fff;
        text-decoration: none;
        cursor: pointer;
    }
`;
