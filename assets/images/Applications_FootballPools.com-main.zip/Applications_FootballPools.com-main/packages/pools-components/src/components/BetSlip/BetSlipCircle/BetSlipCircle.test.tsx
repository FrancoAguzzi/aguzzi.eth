import React from 'react';
import { BetSlipCircle } from './BetSlipCircle';
import 'jest-styled-components';
import { renderWithRedux } from '../../../testing/renderWithRedux';
import { withTheme } from '../../../testing/renderWithTheme';
import { RootState } from '../../../state/rootReducer';

describe('BetSlipCircle', () => {
    it('should render with text', () => {
        const { container } = renderWithRedux(withTheme(<BetSlipCircle selected="D" />), {} as RootState);

        expect(container).toMatchSnapshot();
    });
});
