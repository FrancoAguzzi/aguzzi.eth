import React from 'react';
import { fireEvent, act } from '@testing-library/react';
import 'jest-styled-components';
import { Button } from './Button';
import { renderWithTheme } from '../../../testing/renderWithTheme';

const mockFn = jest.fn();

describe('Button', () => {
    it('should render with text', () => {
        const { container } = renderWithTheme(<Button onClick={mockFn}>Button</Button>);

        expect(container).toMatchSnapshot();
    });

    it('should execute a function on click', () => {
        const { getByText } = renderWithTheme(<Button onClick={mockFn}>Button</Button>);

        act(() => {
            fireEvent.click(getByText(/Button/i));
        });

        expect(mockFn).toHaveBeenCalled();
    });
});
