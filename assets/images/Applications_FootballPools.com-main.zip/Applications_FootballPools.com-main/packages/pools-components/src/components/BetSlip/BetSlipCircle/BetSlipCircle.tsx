import { GameType } from '@sportech/pools-api';
import React from 'react';
import styled, { keyframes } from 'styled-components';
import { breakpoints } from '../../../settings/breakpoints';

export interface BetSlipCircleProps {
    selected?: string | number;
    selectedId?: number | undefined;
    isCurrentSelectedLine?: boolean;
    handleOnClick?: (id: number, displayId: string) => void;
    ballColor?: string;
    displayId?: boolean;
    isMobileBetslip?: boolean;
    'data-testid'?: string;
    size?: string;
    borderColor?: string;
    header?: string;
    selectionsFontStyle?: 'normal' | 'italic';
    selectionsFontColour?: string;
    game?: GameType;
    accountHistoryStyle?: boolean;
    points?: number;
    children?: JSX.Element;
}

export const BetSlipCircle = ({ 'data-testid': testId, ...props }: BetSlipCircleProps): JSX.Element => {
    return (
        <ListItem>
            {props.header && <BetSelectionHeader>{props.header}</BetSelectionHeader>}
            <BetSelection
                onClick={(): void => {
                    if (props.isCurrentSelectedLine && props.selected && props?.handleOnClick !== undefined) {
                        if (props.handleOnClick) {
                            props.handleOnClick(
                                props.selectedId as number,
                                props.displayId ? 'D' : (props.selected as string),
                            );
                        }
                    }
                }}
                isCurrentSelectedLine={props.isCurrentSelectedLine}
                ballColor={props.ballColor}
                MultiLetter={typeof props.selected === 'string' && props.selected.length > 1}
                size={props.size}
                data-testid={testId}
                borderColor={props.borderColor}
                fontStyle={props.selectionsFontStyle}
                selectionsFontColour={props.selectionsFontColour}
                game={props.game}
                accountHistoryStyle={props.accountHistoryStyle}
                points={props.points}
            >
                {props.children ? props.children : props.selected}
            </BetSelection>
        </ListItem>
    );
};

type StyledListItemProps = {
    isCurrentSelectedLine?: boolean;
    ballColor?: string;
    MultiLetter?: boolean;
    size?: string;
    borderColor?: string;
    fontStyle?: 'normal' | 'italic';
    selectionsFontColour?: string;
    game?: GameType;
    accountHistoryStyle?: boolean;
    points?: number;
};

const fadeIn = keyframes`
    from {
        /* transform: scale(.25); */
        opacity: 0;
    }

    to {
        /* transform: scale(1); */
        opacity: 1;
    }
`;

const fadeOut = keyframes`
    from {
        opacity: 0;
    }

    to {
        opacity: 1;
    }
`;

const ListItem = styled.li`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
`;

const BetSelectionHeader = styled.div`
    color: ${props => props.theme.colours.primaryFont};
    font-size: 10px;
    line-height: 14px;
`;

const BetSelection = styled.div<StyledListItemProps>`
    display: flex;
    margin: auto;
    text-align: center;
    border-radius: 5px;
    padding: 0;
    font-weight: bold;
    border: 1px solid #707070;
    width: ${(props): string => (props.size ? props.size : props.MultiLetter ? '35px' : '20px')};
    height: ${props => (props.size ? props.size : '20px')};
    line-height: 24px;
    font-size: 14px;
    font-style: ${props => props.fontStyle};
    display: flex;
    align-items: center;
    justify-content: center;

    ${breakpoints.below('lg')} {
        min-width: 30px;
        min-height: 30px;
        font-size: 16px;
    }
    ${breakpoints.below('sm')} {
        min-width: 26px;
        min-height: 26px;
        font-size: 14px;
    }

    &:not(:empty) {
        &.blank-ball {
            border-color: #fff;
            color: ${(props): string => (props.selectionsFontColour ? props.selectionsFontColour : '#fff')};
            cursor: default;
        }
    }

    &:not(:empty) {
        background: ${(props): string => {
            if (props.accountHistoryStyle) {
                if (props.game === 'classic-pools') {
                    switch (props.points) {
                        case 3:
                            return '#4CA40C';
                        case 2:
                            return '#112093';
                        case 1:
                            return '#E02B20';
                        default:
                            return '#fff';
                    }
                } else {
                    switch (props.points) {
                        case 1:
                            return '#4CA40C';
                        case 0:
                            return '#E02B20';
                        default:
                            return '#fff';
                    }
                }
            } else {
                return props.ballColor && props.isCurrentSelectedLine
                    ? props.ballColor
                    : props.isCurrentSelectedLine
                    ? props.theme.colours.betslipItemSelectedColour
                    : props.theme.colours.betslipItemColour;
            }
        }};
        color: ${props => {
            if (props.accountHistoryStyle) {
                return (props.game === 'classic-pools' && props.points) || props.points !== undefined
                    ? '#fff'
                    : '#707070';
            } else {
                return props.selectionsFontColour
                    ? props.selectionsFontColour
                    : props.isCurrentSelectedLine
                    ? props.theme.colours.betslipItemSelectedFontColour
                    : props.theme.colours.betslipItemSelectedFontColour;
            }
        }};
        border: ${(props): string => {
            if (props.accountHistoryStyle) {
                if (props.game === 'classic-pools') {
                    switch (props.points) {
                        case 3:
                            return '1px solid #4CA40C';
                        case 2:
                            return '1px solid #112093';
                        case 1:
                            return '1px solid #E02B20';
                        default:
                            return '1px solid #707070';
                    }
                } else {
                    switch (props.points) {
                        case 1:
                            return '#4CA40C';
                        case 0:
                            return '#E02B20';
                        default:
                            return '#707070';
                    }
                }
            } else {
                return `1px solid ${
                    props.borderColor
                        ? props.borderColor
                        : props.ballColor && props.isCurrentSelectedLine
                        ? props.ballColor
                        : props.isCurrentSelectedLine
                        ? props.theme.colours.betslipItemSelectedColour
                        : props.theme.colours.betslipItemColour
                }`;
            }
        }};

        cursor: ${(props): string => (props.isCurrentSelectedLine ? 'pointer' : 'default')};

        animation: ${props => (props.isCurrentSelectedLine ? fadeIn : fadeOut)} 0.5s ease;
        transition: visibility 0.5s ease;
    }

    &:empty {
        animation: ${props => (props.isCurrentSelectedLine ? fadeOut : fadeIn)} 0.5s ease;
        transition: visibility 0.5s ease;
    }
`;
