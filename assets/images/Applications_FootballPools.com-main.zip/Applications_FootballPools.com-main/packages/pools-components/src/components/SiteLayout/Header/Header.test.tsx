import React from 'react';
import 'jest-styled-components';
import { renderWithTheme } from '../../../testing/renderWithTheme';
import Header from './Header';

describe('Header', () => {
    it('should render without error', () => {
        const { container } = renderWithTheme(<Header isMobileOrTablet={false} mailCount={0} />);
        expect(container).toMatchSnapshot();
    });
});
