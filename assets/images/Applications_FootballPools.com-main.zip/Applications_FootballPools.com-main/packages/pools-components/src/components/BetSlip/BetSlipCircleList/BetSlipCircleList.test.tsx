import React from 'react';
import { BetSlipCircleList } from './BetSlipCircleList';
import 'jest-styled-components';
import { renderWithTheme } from '../../../testing/renderWithTheme';

describe('BetSlipCircleList', () => {
    it('should render List', () => {
        const { container } = renderWithTheme(<BetSlipCircleList amount={10} row={0} />);

        expect(container).toMatchSnapshot();
    });
});
