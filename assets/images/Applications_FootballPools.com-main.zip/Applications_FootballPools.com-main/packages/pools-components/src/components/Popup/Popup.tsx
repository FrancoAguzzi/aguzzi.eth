import React, { ReactElement, PropsWithChildren, cloneElement } from 'react';
import styled, { css, keyframes } from 'styled-components';
import ReactJSPopup from 'reactjs-popup';
import { RootState } from '../../state/rootReducer';
import { Button } from '../Common/Button/Button';
import { Loader } from '../Loader/Loader';
import { PopupState, openPopup, closePopup, addPopup, getPopup } from '../../state/popupsSlice';
import { connect } from 'react-redux';
import { breakpoints } from '../../settings/breakpoints';
import { PopupPosition } from 'reactjs-popup/dist/types';

export interface PopupProps {
    trigger?: ReactElement;
    title?: string;
    popupStyles: {
        maxWidth?: string;
        maxHeight?: string;
        padding?: string;
        rounded?: boolean;
        overflow?: string;
        width?: string;
        height?: string;
        margin?: string;
        mobileMargin?: string;
        mobileHeight?: string;
        mobileWidth?: string;
        headerStyles: {
            textAlign?: string;
            color?: string;
            padding?: string;
            fontSize?: string;
            position?: string;
            bgColor?: string;
            rounded?: boolean;
            width?: string;
        };
        crossStyles?: {
            top?: string;
            right?: string;
            iconImg?: string;
        };
        backgroundImage?: string;
        backgroundColour?: string;
        position?: PopupPosition | PopupPosition[];
    };
    withCloseButton?: boolean;
    popupName: string;
    closeOnDocumentClick?: boolean;
    closeOnEscape?: boolean;
    handleOnCloseClicked?(): boolean;
}

interface PopupStyleProps {
    maxWidth?: string;
    maxHeight?: string;
    padding?: string;
    rounded?: boolean;
    overflow?: string;
    width?: string;
    height?: string;
    margin?: string;
    mobileMargin?: string;
    mobileHeight?: string;
    mobileWidth?: string;
    backgroundImage?: string;
    backgroundColour?: string;
}

interface PopupHeaderProps {
    textAlign?: string;
    color?: string;
    padding?: string;
    fontSize?: string;
    position?: string;
    bgColor?: string;
    rounded?: boolean;
    width?: string;
}

interface PopupCrossProps {
    right?: string;
    top?: string;
    iconImg?: string;
}

const Container = styled(ReactJSPopup)<PopupStyleProps>`
    &-overlay {
        background-color: rgba(0, 0, 0, 0.5);
    }
    &-content {
        height: ${(props): string => (props.height ? props.height : 'auto')};
        background-color: ${props => (props.backgroundColour ? props.backgroundColour : '#fff !important')};
        color: #000;
        border-color: #363636 !important;
        border-radius: ${(props): string => (props.rounded ? '20px' : '0')};
        max-height: ${(props): string => (props.maxHeight ? props.maxHeight : '90vh')};
        max-width: ${(props): string => (props.maxWidth ? props.maxWidth : 'auto')};
        padding: ${(props): string => (props.padding ? props.padding : '20px 55px !important')};
        font-size: 14px !important;
        overflow: ${(props): string => (props.overflow ? props.overflow : 'hidden')};
        width: ${(props): string => (props.width ? props.width : '100% !important')};
        background-image: ${(props): string => (props.backgroundImage ? props.backgroundImage : '')};
        margin: ${(props): string => (props.margin ? props.margin : 'auto')};
        ${breakpoints.below('lg')} {
            width: ${(props): string => (props.mobileWidth ? props.mobileWidth : '100% !important')};
            max-width: ${(props): string => (props.maxWidth ? props.maxWidth : '')};
            ${(props): string | undefined => props.mobileHeight && `height: {props.mobileHeight}`};
            margin: ${(props): string => (props.mobileMargin ? props.mobileMargin : 'auto 3% !important')};
            border: none !important;
        }
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;

        // Chrome, Edge, Opera, Safari:
        ::-webkit-scrollbar {
            display: none;
            /* height: 5px;
            width: 5px;
            background: ${props => props.theme.colours.scrollTrackBackground}; */
        }
        ::-webkit-scrollbar-thumb {
            display: none;
            /* height: 5px;
            border-radius: 4px;
            background-color: ${props => props.theme.colours.scrollBarBackground}; */
        }

        // Firefox:
        scrollbar-color: ${props =>
            `${props.theme.colours.scrollBarBackground} ${props.theme.colours.scrollTrackBackground}`}; // bar, track
        scrollbar-width: none;
    }
`;

const PopupHeader = styled.h2<PopupHeaderProps>`
    color: ${(props): string => (props.color ? props.color : '#000')};
    font-size: ${(props): string => (props.fontSize ? props.fontSize : '2.3em')};
    padding: ${(props): string => (props.padding ? props.padding : '0.5em 0')};
    margin: 0;
    text-align: ${(props): string => (props.textAlign ? props.textAlign : 'left')};
    position: ${(props): string => (props.position ? props.position : 'relative')};
    background-color: ${(props): string => (props.bgColor ? props.bgColor : '#fff')};
    max-width: inherit;
    border-top-right-radius: ${(props): string => (props.rounded ? '20px' : '0')};
    border-top-left-radius: ${(props): string => (props.rounded ? '20px' : '0')};
    z-index: 1000;

    ${breakpoints.below('lg')} {
        width: ${(props): string | undefined => props.width};
    }
`;

const CloseButton = styled(Button)<PopupCrossProps>`
    background-color: transparent;
    color: black;
    position: fixed;
    &:hover {
        background: none;
    }
`;

const FixedWrapper = styled.div<PopupCrossProps>`
    position: absolute;
    right: ${(props): string => (props.right ? props.right : '60px')};
    top: ${(props): string => (props.top ? props.top : '0px')};
    z-index: 1001;
`;

export const PopupComponent = ({
    action,
    withCloseButton,
    children,
    openPopup,
    closePopup,
    addPopup,
    trigger,
    popupName,
    addToStore,
    title,
    handleOnCloseClicked,
    ...props
}: Props): JSX.Element => {
    if (addToStore) {
        addPopup({ name: popupName, action: action });
    }
    let triggerToUse = trigger;
    if (trigger && !trigger.props.onClick) {
        triggerToUse = cloneElement(trigger, {
            onClick: () => openPopup(popupName),
        });
    }

    const onCloseClicked = (): void => {
        let close = true;
        if (handleOnCloseClicked) {
            close = handleOnCloseClicked();
        }
        if (close) {
            closePopup(popupName);
        }
    };

    return (
        <React.Fragment>
            {triggerToUse}
            <Container
                backgroundColour={props.popupStyles.backgroundColour}
                backgroundImage={props.popupStyles.backgroundImage}
                maxWidth={props.popupStyles.maxWidth}
                maxHeight={props.popupStyles.maxHeight}
                rounded={props.popupStyles.rounded}
                padding={props.popupStyles.padding}
                overflow={props.popupStyles.overflow}
                width={props.popupStyles.width}
                height={props.popupStyles.height}
                margin={props.popupStyles.margin}
                mobileWidth={props.popupStyles.mobileWidth}
                mobileMargin={props.popupStyles.mobileMargin}
                {...props}
                open={action !== 'close'}
                onClose={onCloseClicked}
                lockScroll
                position={props.popupStyles.position}
            >
                <React.Fragment>
                    {title && (
                        <PopupHeader
                            textAlign={props.popupStyles.headerStyles.textAlign}
                            color={props.popupStyles.headerStyles.color}
                            padding={props.popupStyles.headerStyles.padding}
                            fontSize={props.popupStyles.headerStyles.fontSize}
                            position={props.popupStyles.headerStyles.position}
                            bgColor={props.popupStyles.headerStyles.bgColor}
                            rounded={props.popupStyles.rounded}
                            width={props.popupStyles.headerStyles.width}
                        >
                            {title}
                        </PopupHeader>
                    )}
                    <Loader isLoading={action === 'loading'} />
                    {withCloseButton && (
                        <FixedWrapper
                            top={props.popupStyles.crossStyles ? props.popupStyles.crossStyles.top : 'auto'}
                            right={props.popupStyles.crossStyles ? props.popupStyles.crossStyles.right : 'auto'}
                        >
                            <CloseButton title="close" onClick={() => closePopup(popupName)} type="button">
                                {props.popupStyles.crossStyles && props.popupStyles.crossStyles.iconImg ? (
                                    <img src={props.popupStyles.crossStyles.iconImg} alt="close icon" />
                                ) : (
                                    <img src="/close.png" alt="close icon" />
                                )}
                            </CloseButton>
                        </FixedWrapper>
                    )}
                    {children}
                </React.Fragment>
            </Container>
        </React.Fragment>
    );
};

const growUpKeyframes = keyframes`
    0% {
      transform: scaleY(0)
    }
    100% {
      transform: scaleY(1)
    }
  `;

const animation = () =>
    css`
        ${growUpKeyframes};
    `;

// TODO: change to use useSelector / dispatch
const mapStatesToProps = (state: RootState, ownProps: PopupProps): PopupState =>
    getPopup(state.popups, ownProps.popupName);

const mapDispatchToProps = {
    openPopup,
    closePopup,
    addPopup,
};

export type Props = ReturnType<typeof mapStatesToProps> & typeof mapDispatchToProps & PropsWithChildren<PopupProps>;

export const Popup = connect(mapStatesToProps, mapDispatchToProps)(PopupComponent);

export const SlideUpAnimatedPopup = styled(Popup)<PopupProps>`
    &-content {
        animation: ${animation} 0.7s ease-in-out forwards !important;
        -webkit-animation: 0.7s ${animation} ease-in-out forwards !important;
        transform-origin: bottom center !important;
    }
`;
