import React from 'react';
import styled from 'styled-components';
import { NumbersSelected } from '@sportech/pools-api';
import { breakpoints } from '../../../settings/breakpoints';

export interface NumbersCardBallProps {
    number: number;
    action?: (id: number, type: string) => void;
    numbers?: NumbersSelected | undefined;
    bonusNumbers?: NumbersSelected | undefined;
    useImage?: boolean;
    highlightBorderColour?: string;
    correctNumber?: boolean;
    isClover?: boolean;
}

export interface NumbersCardBallStyleProps {
    numbers?: NumbersSelected | undefined;
    bonusNumbers?: NumbersSelected | undefined;
    useImage?: boolean;
    highlightBorderColour?: string;
    correctNumber?: boolean;
    isClover?: boolean;
}

export const NumbersCardBall = (props: NumbersCardBallProps): JSX.Element => {
    return (
        <NumbersCardDiv
            numbers={props.numbers}
            bonusNumbers={props.bonusNumbers}
            useImage={props.useImage}
            highlightBorderColour={props.highlightBorderColour}
            onClick={(): void => {
                if (props.action !== undefined) {
                    props.action(props.number, 'D');
                }
            }}
            correctNumber={props.correctNumber !== undefined ? props.correctNumber : true}
            isClover={props.isClover}
        >
            {props.useImage &&
                (props.numbers ? (
                    <NumbersImageDiv>
                        <BallImage src="/greenball.png" alt="greenball icon" />
                    </NumbersImageDiv>
                ) : props.bonusNumbers ? (
                    <NumbersImageDiv>
                        <BallImage src="/goldenball.png" alt="goldenball icon" />
                    </NumbersImageDiv>
                ) : (
                    <div />
                ))}

            <NumberDiv numbers={props.numbers} bonusNumbers={props.bonusNumbers} useImage={props.useImage}>
                {props.number}
            </NumberDiv>
        </NumbersCardDiv>
    );
};

const NumbersCardDiv = styled.div<NumbersCardBallStyleProps>`
    display: flex;
    background: #ffffff;
    -webkit-box-align: center;
    align-items: center;
    border: ${props => (props.numbers || props.bonusNumbers ? '1px solid transparent' : '1px solid #959595')};
    background: ${props =>
        !props.useImage && (props.numbers || props.bonusNumbers)
            ? props.theme.colours.gameButtonSelectedBackground
            : 'none'};
    border-radius: ${props => (props.isClover ? '45px' : '10px')};
    /* border-radius: 10px; */
    /* border-radius: 45px; */
    height: 80px;
    -webkit-box-pack: center;
    justify-content: center;
    width: 80px;
    margin: 5px;
    ${breakpoints.below('sm')} {
        width: 45px;
        height: 45px;
        margin: 5px 0;
    }
    ${breakpoints.below('xs')} {
        width: 42px;
    }
    cursor: pointer;
    opacity: ${props => (props.correctNumber ? '100%' : '35%')};
    transition: ${props => (!props.useImage ? 'background-color 0.5s ease' : '')};
    ${breakpoints.above('lg')} {
        &:hover {
            cursor: pointer;
            border: ${props =>
                `2px solid ${props.highlightBorderColour || props.theme.colours.gameButtonSelectedBackground}`};
        }
    }
`;

const NumberDiv = styled.div<NumbersCardBallStyleProps>`
    line-height: inherit;
    text-align: center;
    color: ${(props): string =>
        props.numbers || props.bonusNumbers ? (props.useImage ? '#000000' : '#fff') : '#959595'};
    background: transparent;
    position: relative;
    font-size: 2em;
    font-weight: bold;
`;

const NumbersImageDiv = styled.div<NumbersCardBallStyleProps>`
    display: flex;
    position: absolute;
    align-items: center;
    height: 80px;
    justify-content: center;
    width: 80px;
    ${breakpoints.below('sm')} {
        width: 50px;
        height: 50px;
    }
`;

const BallImage = styled.img`
    width: 80px;
    height: 80px;
    ${breakpoints.below('sm')} {
        width: 50px;
        height: 50px;
    }
`;
