import React from 'react';
import styled from 'styled-components';
import { breakpoints } from '../../../settings/breakpoints';
import { ExternalLink } from '../../Common/ExternalLink/ExternalLink';

interface SideMenuProps {
    open?: boolean;
    topLinks: Link[];
    centreLinks: Link[];
    bottomLinks: Link[];
    SideMenu?: () => void;
    isMobileOrTablet: boolean;
    distanceBetweenHeaderAndTopOfWindow: number;
}

interface Link {
    href: string;
    label: string;
    target?: string;
    image?: {
        src: string;
        width?: string;
    };
}

const SideMenu = ({ topLinks, centreLinks, bottomLinks, ...props }: SideMenuProps): JSX.Element => {
    const Clicked = (): void => {
        if (props.SideMenu !== undefined) {
            props.SideMenu();
        }
    };
    return (
        <SideMenuStyle
            distanceBetweenHeaderAndTopOfWindow={props.distanceBetweenHeaderAndTopOfWindow}
            open={props.open}
        >
            <Content>
                <Items>
                    {topLinks &&
                        topLinks.length > 0 &&
                        topLinks.map((link, index) => (
                            <Links key={`TopLink_${index}`} href={link.href} target={link.target}>
                                {link.label}
                                {link.image && <Img src={link.image.src} width={link.image.width} />}
                            </Links>
                        ))}
                </Items>
                <Items>
                    {centreLinks &&
                        centreLinks.length > 0 &&
                        centreLinks.map((link, index) => (
                            <LinkInternal key={`CentreLink_${index}`} href={link.href} target={link.target}>
                                {link.label}
                                {link.image && <Img src={link.image.src} width={link.image.width} />}
                            </LinkInternal>
                        ))}
                </Items>
                <Items>
                    {bottomLinks &&
                        bottomLinks.length > 0 &&
                        bottomLinks.map((link, index) => (
                            <Links key={`BottomLink_${index}`} href={link.href} target={link.target}>
                                {link.label}
                                {link.image && <Img src={link.image.src} width={link.image.width} />}
                            </Links>
                        ))}
                </Items>
            </Content>
            {props.open && props.isMobileOrTablet && (
                <SideMenuStyleOverlay onTouchMoveCapture={Clicked} onClick={Clicked} />
            )}
        </SideMenuStyle>
    );
};

export default SideMenu;

const SideMenuStyle = styled.div<{ distanceBetweenHeaderAndTopOfWindow: number; open?: boolean }>`
    padding-left: env(safe-area-inset-left);
    height: 100%;
    width: auto;
    position: fixed;
    z-index: 1000;
    top: 0;
    left: 0;
    margin-top: ${(props): string => props.distanceBetweenHeaderAndTopOfWindow + 50 + 'px'};
    padding-bottom: 50px;
    transform: ${(props): string => (props.open ? 'translateX(0)' : 'translateX(-100%)')};
    transition: 0.5s;
    font-size: 0.75em;
    background: #363636;
    overflow-x: hidden;
    white-space: nowrap;
    text-overflow: clip;
    display: none;
    ${breakpoints.below('lg')} {
        display: block;
    }
`;

const SideMenuStyleOverlay = styled.div`
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;

    z-index: 15;
    background: rgba(0, 0, 0, 0.5);
`;

const Content = styled.div`
    color: #fff;
    padding: 0 1.166em;
    padding-bottom: 4.666em;
`;

const Items = styled.div`
    font-size: 16px;
    &:not(:first-child) {
        margin-top: 1.166em;
    }
`;
const LinkInternal = styled.a`
    display: block;
    border-bottom: 1px #3d3d3d solid;
    padding: 7px 0;
    text-decoration: none;
    color: inherit;
    &:hover {
        background: #3d3d3d;
        color: #38d8ff;
    }
`;

const Links = styled(ExternalLink)`
    display: block;
    border-bottom: 1px #3d3d3d solid;
    padding: 7px 0;
    text-decoration: none;
    color: inherit;
    &:hover {
        background: #3d3d3d;
        color: #38d8ff;
    }
`;

const Img = styled.img<{ width?: string }>`
    width: ${props => (props.width ? props.width : '65px')};
`;
