import styled from 'styled-components';

export const popupStyles = {
    width: '25% !important',
    padding: '20px 55px !important',
    rounded: true,
    headerStyles: {
        textAlign: 'left',
    },
    crossStyles: {
        top: '5px',
        right: '60px',
    },
};

export const errorPopupStyles = {
    width: '30% !important',
    padding: '0 !important',
    rounded: true,
    headerStyles: {
        color: '#000',
        textAlign: 'center',
        fontSize: '1,5em',
        padding: '0.5em',
    },
    crossStyles: {
        top: '-11px',
        right: '60px',
    },
};

export const paymentPopupStyles = {
    width: '400px !important',
    padding: '0 !important',
    rounded: true,
    headerStyles: {
        color: '#000',
        textAlign: 'center',
        fontSize: '1,5em',
        padding: '0.5em',
    },
    crossStyles: {
        top: '-13px',
        right: '60px',
    },
};

export const ViewMyLinesPopupStyle = {
    maxWidth: '100vw',
    maxHeight: '100vh',
    padding: '0 !important',
    rounded: false,
    overflow: 'scroll',
    width: '100vw',
    height: '100vh',
    mobileMargin: '0 !important',
    mobileHeight: '100% !important',
    headerStyles: {
        color: '#000',
        textAlign: 'center',
        fontSize: '1.5em',
        padding: '0.5em 0',
        position: 'fixed',
        bgColor: '#fff',
        width: '100%',
    },
    crossStyles: {
        top: '-12px',
        right: '60px',
    },
};

export const PopupStickyFooter = styled.div`
    position: fixed;
    bottom: 0px;
    background: #fff;
    max-width: inherit;
    width: 100%;
    height: 160px;
    padding: 0.4em 0;
    text-align: center;
    left: 50%;
    transform: translate(-50%, 0%);

    button {
        font-size: 15px;
        font-weight: bold;
        line-height: 20px;
        margin: 10px 5px;
    }
    p {
        margin: 0;
        font-size: 15px;
        font-weight: bold;
    }
`;

export const addedLinesPopupStyle = {
    maxWidth: '100vw',
    maxHeight: '100vh',
    padding: '0 10px !important',
    rounded: false,
    overflow: 'scroll',
    height: '100vh',
    width: '100vw',
    mobileMargin: '0 !important',
    mobileHeight: '100% !important',
    headerStyles: {
        color: '#000',
        textAlign: 'center',
        fontSize: '1,5em',
        padding: '0.5em 0',
        position: 'fixed',
        width: '100%',
    },
    crossStyles: {
        top: '-11px',
    },
};
