import React, { useContext } from 'react';
import { Popup, SlideUpAnimatedPopup } from './Popup';
import {
    errorPopupStyles,
    paymentPopupStyles,
    addedLinesPopupStyle,
    popupStyles,
    ViewMyLinesPopupStyle,
} from '../Styles/popupStyles';
import { ErrorOnBetSlipChangePopup } from './ErrorOnBetSlipChangePopup';
import {
    BetSlip,
    BetSlipSlice,
    Offerings,
    Competition,
    CompetitionWagers,
    Wager,
    toGameType,
} from '@sportech/pools-api';
// import { PaymentPopup } from './PaymentPopup';
import { AddedLinesPopup } from './AddedLinesPopup';
import { ClassicPoolsHowToPlayPopup } from './HowToPlay/ClassicPoolsHowToPlayPopup';
import { ViewLinesPopup } from './ViewLinesPopup';
import { GoalRushHowToPlayPopup } from './HowToPlay/GoalRushHowToPlayPopup';
import { Premier6HowToPlayPopup } from './HowToPlay/Premier6HowToPlayPopup';
import { Premier10HowToPlayPopup } from './HowToPlay/Premier10HowToPlayPopup';
import { PaymentConfirmationPopup } from './PaymentConfirmationPopup';
import { useMediaQuery } from 'react-responsive';
import { Jackpot12HowToPlayPopup } from './HowToPlay/Jackpot12HowToPlayPopup';
import { LuckyCloverHowToPlayPopup } from './HowToPlay/LuckyCloverHowToPlayPopup';
import { ErrorOnPlaceBet } from './ErrorOnPlaceBet';
import { ThemeContext } from 'styled-components';
import { ViewLinesCurrent } from '../BetSlip/ViewLines/ViewLines';

interface PopupsContainerProps {
    currentSlip: BetSlip;
    betslipselection: Array<BetSlip>;
    GameType: keyof BetSlipSlice;
    offers: Offerings;
    showHDA: boolean;
    ChangeCurrentBets: (index: number) => void;
    addedLines: BetSlip[];
    competitions: Competition[];
    ClearLine: (index?: number, isCurrent?: boolean) => void;
    viewLinesWager: Wager[];
    pressPlay: () => void;
    hasCreatedWagersReponse: boolean;
    createdWagersResponse: CompetitionWagers[];
    viewLinesBetslip?: BetSlip;
    setViewLinesCurrent?: (viewLinesCurrent: ViewLinesCurrent) => void;
    viewLinesCurrent?: ViewLinesCurrent;
    canEdit?: boolean;
    handleViewLinesBetslipCircleClick?: (id: number, type: string) => void;
    isClover: boolean;
    setShowWagers?: (showWagers: boolean) => void;
    setShowWagerFixtures?: (showFixtures: boolean) => void;
    showWagerFixtures?: boolean;
    betslipItemSize?: string;
    ballColor?: string;
    viewLinesOffers?: Offerings;
    showAddedLinesBackButton?: boolean;
    showAddedLinesPlayButton?: boolean;
    showAddedLinesCost?: boolean;
    showAddedLinesCount?: boolean;
    showAddedLinesPerLineCount?: boolean;
    minimumCost?: number;
    showAddedLinesCountHeader?: boolean;
    addedLinesSelectionsFontStyle?: 'normal' | 'italic';
    setManualBetSwitching?: (manualSwitch: boolean) => void;
    playNowColour?: string;
}

export const PopupsContainer = ({
    currentSlip,
    betslipselection,
    GameType,
    offers,
    showHDA,
    ChangeCurrentBets,
    addedLines,
    competitions,
    ClearLine,
    viewLinesWager,
    pressPlay,
    viewLinesBetslip,
    setViewLinesCurrent,
    viewLinesCurrent,
    canEdit,
    isClover,
    setShowWagers,
    setShowWagerFixtures,
    showWagerFixtures,
    betslipItemSize,
    ballColor,
    viewLinesOffers,
    showAddedLinesBackButton,
    showAddedLinesPlayButton,
    showAddedLinesCost,
    showAddedLinesCount,
    minimumCost,
    showAddedLinesCountHeader,
    addedLinesSelectionsFontStyle,
    showAddedLinesPerLineCount,
    setManualBetSwitching,
    playNowColour,
}: PopupsContainerProps): JSX.Element => {
    const themeContext = useContext(ThemeContext);
    const isMobileOrTablet = useMediaQuery({
        query: `(max-width: ${themeContext.breakpoints.lg}px )`,
    });
    return (
        <React.Fragment>
            <Popup
                title="ERROR"
                popupStyles={errorPopupStyles}
                withCloseButton
                popupName="error_on_change_betslip_line"
                closeOnDocumentClick
                closeOnEscape
            >
                <ErrorOnBetSlipChangePopup currentSlip={currentSlip as BetSlip} />
            </Popup>
            <Popup
                title="ERROR"
                popupStyles={errorPopupStyles}
                withCloseButton
                popupName="error_on_place_bet"
                closeOnDocumentClick
                closeOnEscape
            >
                <ErrorOnPlaceBet />
            </Popup>
            {/* {hasCreatedWagersReponse && (
                <Popup
                    title={'Place Bet'}
                    popupStyles={paymentPopupStyles}
                    withCloseButton={true}
                    popupName={'payment'}
                    closeOnDocumentClick={true}
                    closeOnEscape={true}
                >
                    <PaymentPopup
                        gameType={GameType}
                        createdWagersResponse={createdWagersResponse}
                        betslipselection={betslipselection}
                        isHDA={showHDA}
                        isClover={isClover}
                    />
                </Popup>
            )} */}

            <Popup
                title="Congratulations"
                popupStyles={paymentPopupStyles}
                withCloseButton
                popupName="payment_confirmation"
                closeOnDocumentClick
                closeOnEscape
            >
                <PaymentConfirmationPopup />
            </Popup>
            {isMobileOrTablet && (
                <React.Fragment>
                    <SlideUpAnimatedPopup
                        popupStyles={addedLinesPopupStyle}
                        withCloseButton
                        title="Your Selections"
                        popupName="added_lines"
                        closeOnEscape
                        closeOnDocumentClick
                    >
                        <AddedLinesPopup
                            betslipselection={betslipselection}
                            offers={offers}
                            currentBet={betslipselection.filter(x => x.current)[0]}
                            showHDA={showHDA}
                            clearLine={ClearLine}
                            changeBet={ChangeCurrentBets}
                            addedLines={addedLines}
                            pressPlay={pressPlay}
                            isClover={isClover}
                            game={toGameType(GameType)}
                            showBackButton={showAddedLinesBackButton}
                            showPlayButton={showAddedLinesPlayButton}
                            showCost={showAddedLinesCost}
                            showLinesCount={showAddedLinesCount}
                            minimumCost={minimumCost}
                            showCountHeader={showAddedLinesCountHeader}
                            selectionsFontStyle={addedLinesSelectionsFontStyle}
                            showPerLineCount={showAddedLinesPerLineCount}
                            setManualBetSwitching={setManualBetSwitching}
                            playNowColour={playNowColour}
                        />
                    </SlideUpAnimatedPopup>
                    <Popup
                        popupStyles={ViewMyLinesPopupStyle}
                        title="Your Lines"
                        popupName="your_placed_lines"
                        withCloseButton
                        handleOnCloseClicked={() => {
                            if (!showWagerFixtures) {
                                if (setShowWagers) {
                                    setShowWagers(false);
                                }
                                if (setViewLinesCurrent) {
                                    setViewLinesCurrent({
                                        id: 0,
                                        competitionId: 0,
                                    });
                                }
                            }
                            return true;
                        }}
                    >
                        <ViewLinesPopup
                            competitions={competitions}
                            offers={viewLinesOffers || offers}
                            gameType={GameType}
                            nothda={!showHDA}
                            wagers={viewLinesWager}
                            canEdit={canEdit}
                            viewLinesCurrent={viewLinesCurrent}
                            setViewLinesCurrent={setViewLinesCurrent}
                            betslip={viewLinesBetslip}
                            setShowWagerFixtures={setShowWagerFixtures}
                            betslipItemSize={betslipItemSize}
                            ballColor={ballColor}
                        />
                    </Popup>
                </React.Fragment>
            )}

            <Popup
                title="How to Play Classic Pools"
                popupStyles={popupStyles}
                withCloseButton
                popupName="how_to_play_ClassicPools"
                closeOnEscape
                closeOnDocumentClick
            >
                <ClassicPoolsHowToPlayPopup />
            </Popup>

            <Popup
                title="How to Play Goal Rush 8"
                popupStyles={popupStyles}
                withCloseButton
                popupName="how_to_play_GoalRush8"
                closeOnEscape
                closeOnDocumentClick
            >
                <GoalRushHowToPlayPopup />
            </Popup>

            <Popup
                title="How to Play Soccer 6"
                popupStyles={popupStyles}
                withCloseButton
                popupName="how_to_play_Premier6"
                closeOnEscape
                closeOnDocumentClick
            >
                <Premier6HowToPlayPopup />
            </Popup>

            <Popup
                title="How to Play Lucky Clover"
                popupStyles={popupStyles}
                withCloseButton
                popupName="how_to_play_LuckyClover"
                closeOnEscape
                closeOnDocumentClick
            >
                <LuckyCloverHowToPlayPopup />
            </Popup>

            <Popup
                title="How to Play Premier 10"
                popupStyles={popupStyles}
                withCloseButton
                popupName="how_to_play_Premier10"
                closeOnEscape
                closeOnDocumentClick
            >
                <Premier10HowToPlayPopup />
            </Popup>
            <Popup
                title="How to Play Jackpot 12"
                popupStyles={popupStyles}
                withCloseButton
                popupName="how_to_play_Jackpot12"
                closeOnEscape
                closeOnDocumentClick
            >
                <Jackpot12HowToPlayPopup />
            </Popup>
        </React.Fragment>
    );
};
