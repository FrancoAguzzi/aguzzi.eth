import React from 'react';

type AnchorAttributes = JSX.IntrinsicElements['a'];
export const ExternalLink = (props: AnchorAttributes): JSX.Element => (
    <a target={props.target || '_blank'} rel="noopener noreferrer" {...props} />
);
