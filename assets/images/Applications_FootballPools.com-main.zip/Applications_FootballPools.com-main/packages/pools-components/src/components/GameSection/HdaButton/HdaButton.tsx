import { ButtonHTMLAttributes } from 'react';
import styled from 'styled-components';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    active?: boolean;
    bgcolor?: string;
    isResults?: boolean;
}

export const HdaButton = styled.button<ButtonProps>`
    border: ${props => `1px solid ${props.theme.colours.primaryFont}`};
    outline: 0;
    display: inline-block;

    text-align: center;
    vertical-align: middle;
    text-shadow: 0 1px 5px rgba(0, 0, 0, 0.15);
    user-select: none;
    text-shadow: none;
    border-radius: 5px;
    flex: 1;
    margin-right: 5px;
    text-transform: uppercase;
    padding: 0.7em 1.09em;
    max-width: 30%;
    font: 400 17.3333px;
    font-weight: bold;
    background: ${props =>
        props.active === true ? (props.bgcolor ? props.bgcolor : props.theme.colours.gameMainColour) : '#fff'};
    color: ${(props): string => (props.active === true ? 'white' : props.theme.colours.primaryFont)};
    ${props =>
        !props.active &&
        !props.isResults &&
        `
        &:hover {
        // background-color: #7fa2f5;
        cursor: pointer;
    }
    `}
`;
// //color: #fff!important;
