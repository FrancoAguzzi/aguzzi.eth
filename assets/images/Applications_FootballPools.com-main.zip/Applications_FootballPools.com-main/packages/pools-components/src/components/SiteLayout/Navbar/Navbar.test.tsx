import React from 'react';
import 'jest-styled-components';
import { renderWithTheme } from '../../../testing/renderWithTheme';
import { NavBar } from './Navbar';

describe('Topbar', () => {
    it('should render without error', () => {
        const { container } = renderWithTheme(<NavBar path="/" />);
        expect(container).toMatchSnapshot();
    });
});
