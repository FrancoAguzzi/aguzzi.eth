import React from 'react';
import styled from 'styled-components';
import { breakpoints } from '../../../settings/breakpoints';
import { MatchCardProps } from '../MatchCard/MatchCard';
import { HdaButton } from '../HdaButton/HdaButton';
import { ResultsHdaMatchCard } from '../../Results/ResultsSection/ResultsHdaMatchCard';

export const HdaMatchCard = (props: MatchCardProps): JSX.Element => {
    return (
        <MatchCardDiv matchCardWidth={props.matchCardWidth}>
            {props.isResults ? (
                <ResultsHdaMatchCard {...props} />
            ) : (
                <React.Fragment>
                    <MatchCardDivs>
                        <NumberDiv>{props.number}</NumberDiv>
                        <TeamsDiv>
                            <Rowone>
                                <HomeDiv>{props.homeTeam}</HomeDiv>
                                <VsDiv>V</VsDiv>
                                <AwayDiv>{props.awayTeam}</AwayDiv>
                            </Rowone>
                            <Rowtwo>
                                <MatchCardbuttonDiv>
                                    <HdaButton
                                        onClick={(): void => {
                                            if (props.action !== undefined) {
                                                props.action(props.number, 'H');
                                            }
                                        }}
                                        active={props.numbers?.selections.includes('H')}
                                    >
                                        Home
                                    </HdaButton>
                                    <HdaButton
                                        onClick={(): void => {
                                            if (props.action !== undefined) {
                                                props.action(props.number, 'D');
                                            }
                                        }}
                                        active={props.numbers?.selections.includes('D')}
                                    >
                                        Draw
                                    </HdaButton>
                                    <HdaButton
                                        onClick={(): void => {
                                            if (props.action !== undefined) {
                                                props.action(props.number, 'A');
                                            }
                                        }}
                                        active={props.numbers?.selections.includes('A')}
                                    >
                                        Away
                                    </HdaButton>
                                </MatchCardbuttonDiv>
                            </Rowtwo>
                        </TeamsDiv>
                    </MatchCardDivs>
                </React.Fragment>
            )}
        </MatchCardDiv>
    );
};

type MatchCardDivProps = {
    matchCardWidth?: string;
};

const MatchCardDiv = styled.li<MatchCardDivProps>`
    width: ${(props): string => (props.matchCardWidth ? props.matchCardWidth : '48%')};
    margin: 0.5%;
    float: left;
    font-size: 12px;
    border: 1px solid transparent;
    height: 70px;
    ${breakpoints.below('md')} {
        width: 96%;
    }
`;

const MatchCardbuttonDiv = styled.div`
    display: flex;
    overflow: hidden;
    text-align: center;
    justify-content: center;
`;
const MatchCardDivs = styled.div`
    color: #011fb3;
    display: flex;
    height: 70px !important;
    width: 100%;

    height: 42px;
    line-height: 42px;

    position: relative;
    z-index: 1;

    background: ${props => props.theme.colours.matchCardBackground || '#fff'};
    border: ${props => `1px solid ${props.theme.colours.matchCardBorder}`};
    color: ${props => props.theme.colours.primaryFont};
`;

const NumberDiv = styled.div`
    width: 50px;
    line-height: inherit;
    text-align: center;
    color: ${props => props.theme.colours.primaryFont};
    position: relative;
    font-size: 30px;
    margin-left: 3px;
    height: 70px;
    display: flex;
    justify-content: center;
    align-items: center;

    :after {
        content: '';
        height: 75%;
        width: 1px;

        position: absolute;
        right: 0;
        top: 12.5%;

        background-color: #000; //
    }

    ${breakpoints.below('md')} {
        width: 18%;
        max-width: 80px;
    }
`;

const TeamsDiv = styled.div`
    display: flex;
    flex-direction: column;
    width: 100%;
    justify-content: center;
    height: 70px;
    border-radius: 5px;

    ${breakpoints.below('xs')} {
        width: 82%;
    }
`;

const HomeDiv = styled.div`
    flex: 1;
    font-weight: 600;
    width: 40%;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    text-align: right;
    font-size: 15px;
`;

const VsDiv = styled.div`
    width: 1.5em;
    text-align: center;
    font-weight: 600;
    font-size: 0.8em;
    color: ${props => props.theme.colours.primaryFont};
    font-size: 15px;
`;
const AwayDiv = styled.div`
    font-weight: 600;
    width: 40%;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    flex: 1;
    font-size: 15px;
`;

const Rowone = styled.div`
    flex: 1;
    display: flex;
    flex-direction: row;
    max-height: 30px;
    align-items: center;
`;

const Rowtwo = styled.div`
    flex: 1;
`;
