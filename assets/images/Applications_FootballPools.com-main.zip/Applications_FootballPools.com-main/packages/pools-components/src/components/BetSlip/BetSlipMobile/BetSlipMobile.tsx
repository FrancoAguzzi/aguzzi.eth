import React, { useEffect, useContext } from 'react';
import styled, { ThemeContext } from 'styled-components';

import { Button } from '../../Common/Button/Button';
import { BetSlip, Offering, Offerings } from '@sportech/pools-api';
import { breakpoints } from '../../../settings/breakpoints';
import { getTotalPrice, testId } from '../../../utils/functionUtils';
import '../../../utils/extensionMethods';

export interface BetSlipMobileProps {
    betslipselection: Array<BetSlip>;
    SelectAmountAction: (id: number, amount: Offering) => void;
    ClearLine: () => void;
    AddLine: () => void;
    ChangeBet: (index: number) => void;
    offers: Offerings;
    ShowHDA?: boolean;
    setCurrentOfferingId: (val: number) => void;
    currentOfferingId: number;
    setShowMore: (val: boolean) => void;
    showMoreValue: boolean;
    addedLines: BetSlip[];
    pressPlay: () => void;
    user?: any;
    openAddLinesPopup: () => void;
    canAddMultipleLines?: boolean;
    isViewLines?: boolean;
    canEdit?: boolean;
    fixtureCountLabel?: string;
    showFixtureCount?: boolean;
    isClover: boolean;
}

export const BetSlipMobile = (props: BetSlipMobileProps): JSX.Element => {
    const lines = props.addedLines.length;
    const totalPricenumber = getTotalPrice(props.ShowHDA as boolean, props.isClover, props.betslipselection);
    const totalPrice = totalPricenumber.toLocaleStringCash();

    const currentBet = props.betslipselection.filter(x => x.current)[0];
    const themeContext = useContext(ThemeContext);

    const updateCurrentOfferingId = (item: BetSlip): void => {
        props.setCurrentOfferingId(item.priceID);
        props.setShowMore(false);
    };

    useEffect(() => {
        updateCurrentOfferingId(currentBet);
    }, [props.betslipselection]);

    return (
        <MobileBetslipContainer>
            {props.isViewLines && props.canEdit && (
                <MobileBetSlipItem>
                    <Button
                        height="auto"
                        width="100px"
                        bgColor={themeContext.colours.buttonCancel ? themeContext.colours.buttonCancel : '#009A29'}
                        textColor="#fff"
                        padding="1em 0.75em"
                        disabled={props.betslipselection?.filter(x => x.pick === x.numbers?.length).length <= 0}
                        onClick={props.pressPlay}
                        disabledBackgroundColour={themeContext.colours.betslipMobileButtonDisabled}
                        {...testId('BetSlipMobile_CancelButton')}
                    >
                        Save
                    </Button>
                </MobileBetSlipItem>
            )}
            {props.canAddMultipleLines && (
                <MobileBetSlipItem>
                    <Button
                        height="auto"
                        bgColor={themeContext.colours.gameMainColour}
                        textColor="#fff"
                        padding="1em 0.75em"
                        disabled={props.addedLines.length === 0}
                        onClick={props.openAddLinesPopup}
                        {...testId('BetSlipMobile_OpenAddLinePopupButton')}
                    >
                        {lines > 1 ? `${lines} Lines Added ` : `${lines} Line Added `} £{totalPrice}
                    </Button>
                </MobileBetSlipItem>
            )}
            {props.showFixtureCount && (
                <MobileBetSlipItem>
                    <FixtureCountContainer>
                        {props.fixtureCountLabel && <FixtureCountText>{props.fixtureCountLabel}</FixtureCountText>}
                        {currentBet.numbers?.length}/{currentBet.pick}
                    </FixtureCountContainer>
                </MobileBetSlipItem>
            )}
            {props.canAddMultipleLines && (
                <MobileBetSlipItem>
                    <Button
                        height="auto"
                        bgColor="#38d8ff"
                        textColor="#000"
                        padding="1em 0.75em"
                        onClick={(): void => {
                            props.AddLine();
                        }}
                        disabled={!currentBet || currentBet.pick !== currentBet.numbers?.length}
                        {...testId('BetSlipMobile_AddLineButton')}
                    >
                        Add a Line
                    </Button>
                </MobileBetSlipItem>
            )}
            <MobileBetSlipItem>
                <BetSlipButton
                    height="auto"
                    width="100px"
                    bgColor={themeContext.colours.buttonConfirm ? themeContext.colours.buttonConfirm : '#009A29'}
                    textColor="#fff"
                    padding="1em 0.75em"
                    disabled={props.betslipselection?.filter(x => x.pick === x.numbers?.length).length <= 0}
                    onClick={props.pressPlay}
                    disabledBackgroundColour={themeContext.colours.betslipMobileButtonDisabled}
                    {...testId('BetSlipMobile_PlayButton')}
                >
                    Play
                </BetSlipButton>
            </MobileBetSlipItem>
        </MobileBetslipContainer>
    );
};

const MobileBetslipContainer = styled.div`
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    padding: 10px 5px;
    width: 95%;
`;

const MobileBetSlipItem = styled.div`
    flex-basis: 0 1 auto;
`;

const FixtureCountContainer = styled.div`
    display: flex;
    flex-direction: column;
`;
const FixtureCountText = styled.p`
    font-size: 0.6rem;
`;

const BetSlipButton = styled(Button)`
    border-radius: 24px;
    width: 250px;
    &:disabled {
        background: ${props => props.theme.colours.betslipMobileButtonDisabled};
        transition: background-color 0.5s ease;
    }
    &:enabled {
        transition: background-color 0.5s ease;
    }
    ${breakpoints.below('sm')} {
        width: 150px;
    }
`;
