import React from 'react';
import 'jest-styled-components';
import { DateTimeFormatter } from './DateTimeFormatter';
import { renderWithTheme } from '../../../testing/renderWithTheme';

describe('DateTimeFormatter', () => {
    it('should render with text', () => {
        const { container } = renderWithTheme(
            <DateTimeFormatter format="Do MMM YYYY" input="Mon Jul 20 2020 10:51:21 GMT+0100 (British Summer Time)" />,
        );

        expect(container).toMatchSnapshot();
    });
});
