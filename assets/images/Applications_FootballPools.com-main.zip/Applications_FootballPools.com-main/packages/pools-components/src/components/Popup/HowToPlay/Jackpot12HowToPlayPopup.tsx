import React, { FunctionComponent } from 'react';
import { useDispatch } from 'react-redux';
import { PopupText, StyledATag } from '../../Styles/defaultPageStyles';
import { AppDispatch } from '../../../state/rootReducer';
import { closePopup } from '../../../state/popupsSlice';

export const Jackpot12HowToPlayPopup: FunctionComponent = () => {
    const dispatch: AppDispatch = useDispatch<AppDispatch>();
    return (
        <PopupText>
            <p>
                <strong>Win big money from as little as 50p!</strong>
                <br />
                <br />
                Simply select the outcomes of the 12 selected matches for your chance to win. This will give you a
                single line in the pool - you&apos;ll see this on the right hand side of your screen. You can increase
                your chances of winning by selecting more than one outcome in each match - this will give you more lines
                in the pool. Once all the matches have been completed, anyone with 12 correct results will win the pool,
                or a share of the pool if there are multiple winners. The pool size shown is before expenses and
                commissions.
            </p>
            <StyledATag
                onClick={() => dispatch(closePopup('how_to_play_Jackpot12'))}
                target="_self"
                href="/content/Jackpot-12-Game-Rules"
            >
                View Game Terms & Conditions
            </StyledATag>
        </PopupText>
    );
};
