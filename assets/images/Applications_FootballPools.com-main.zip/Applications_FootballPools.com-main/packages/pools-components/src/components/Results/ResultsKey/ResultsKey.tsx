import React from 'react';
import styled from 'styled-components';
import { breakpoints } from '../../../settings/breakpoints';
import { GameType } from '@sportech/pools-api';

type ResultKeyPointsProps = {
    bgColor: string;
    isNotStarted?: boolean;
};

type ResultsKeyContainerProps = {
    isSmall: boolean;
};

const ResultsKeyContainer = styled.div<ResultsKeyContainerProps>`
    padding: ${(props): string => (props.isSmall ? '0 0 0 15px' : '10px 33px 6px 10px')};
    display: flex;
    flex-wrap: wrap;
    ${breakpoints.below('sm')} {
        font-size: 12px;
    }
    > span {
        font-size: 13px;
        line-height: 40px;
        margin-right: 13px;

        ${breakpoints.below('sm')} {
            font-size: 12px;
        }
    }
    ${props =>
        !props.isSmall
            ? `> span:not(:first-child)::before {
        position: relative;
        right: 4%;
        color: #a4a4a4;
    }`
            : `> span::before {
        position: relative;
        right: 4%;
        color: #a4a4a4;
    }`}
`;

const ResultsKeyPoint = styled.span<ResultKeyPointsProps>`
    &::before {
        content: '';
        top: ${(props): string => (props.isNotStarted ? '7%' : '5%')};
        width: ${(props): string => (props.isNotStarted ? '0.8em' : '1em')};
        height: ${(props): string => (props.isNotStarted ? '0.8em' : '1em')};
        display: inline-block;
        border-radius: 1em;
        background-color: ${(props): string => props.bgColor};
        border: ${(props): string => (props.isNotStarted ? '2px solid #c2d3d7' : '')};
    }
`;

type ResultsKeyVoidAndPoolsPanelProps = {
    content: string;
};

const ResultsKeyVoidAndPoolsPanel = styled.span<ResultsKeyVoidAndPoolsPanelProps>`
    &::before {
        content: '${(props): string => props.content}';
        font-weight: 600;
    }
`;

const ResultsKeyInProgress = styled.span`
    &::before {
        top: 8%;
        height: 16px;
        width: 16px;
        content: url('/clock-o.png');
        opacity: 1;
    }
`;

export interface ResultsKeyProps {
    isSmall?: boolean;
    GameType?: GameType;
}

export const ResultsKey = (props: ResultsKeyProps): JSX.Element => {
    return (
        <ResultsKeyContainer isSmall={props.isSmall ? props.isSmall : false}>
            {!props.isSmall && <span>Results Key:</span>}
            {props.GameType === 'classic-pools' ? (
                <React.Fragment>
                    <ResultsKeyPoint bgColor="green">3 points</ResultsKeyPoint>
                    <ResultsKeyPoint bgColor="#272188">2 points</ResultsKeyPoint>
                    <ResultsKeyPoint bgColor="#ff2b2b">1 point</ResultsKeyPoint>
                </React.Fragment>
            ) : (
                <React.Fragment>
                    <ResultsKeyPoint bgColor="Green">1 point</ResultsKeyPoint>
                    <ResultsKeyPoint bgColor="Red">0 points</ResultsKeyPoint>
                </React.Fragment>
            )}
            {props.isSmall && (
                <ResultsKeyPoint isNotStarted bgColor="#fff">
                    Not Started
                </ResultsKeyPoint>
            )}
            {!props.isSmall && (
                <React.Fragment>
                    <ResultsKeyVoidAndPoolsPanel content="VOID">2pts</ResultsKeyVoidAndPoolsPanel>
                    <ResultsKeyInProgress>In progress</ResultsKeyInProgress>
                    <ResultsKeyVoidAndPoolsPanel content="P-P">Pools Panel</ResultsKeyVoidAndPoolsPanel>
                </React.Fragment>
            )}
        </ResultsKeyContainer>
    );
};

export const ResultsKeyBig = (props: ResultsKeyProps): JSX.Element => {
    return (
        <React.Fragment>
            {props.GameType ? (
                props.GameType === 'classic-pools' ? (
                    <ResultsKeyBigContainer>
                        <span>
                            <ColoredSpan bgColor="green">GREEN</ColoredSpan>
                            <br />3 points
                        </span>
                        <span>
                            <ColoredSpan bgColor="blue">BLUE</ColoredSpan>
                            <br />2 points
                        </span>
                        <span>
                            <ColoredSpan bgColor="red">RED</ColoredSpan>
                            <br />1 point
                        </span>
                        <span>
                            <ResultsKeyVoidAndPoolsPanel content="VOID" />
                            <br />2 points
                        </span>
                        <span>
                            <ResultsKeyInProgress />
                            <br />
                            In Progress
                        </span>
                        <span>
                            <ResultsKeyVoidAndPoolsPanel content="P-P" />
                            <br />
                            Pools Panel
                        </span>
                    </ResultsKeyBigContainer>
                ) : (
                    <ResultsKeyBigContainer>
                        <span>
                            <ColoredSpan bgColor="green">GREEN</ColoredSpan>
                            <br />1 point
                        </span>
                        <span>
                            <ColoredSpan bgColor="red">RED</ColoredSpan>
                            <br />
                            No point
                        </span>
                        <span>
                            <ResultsKeyVoidAndPoolsPanel content="VOID" />
                            <br />1 points
                        </span>
                        <span>
                            <ResultsKeyInProgress />
                            <br />
                            In Progress
                        </span>
                    </ResultsKeyBigContainer>
                )
            ) : (
                <React.Fragment />
            )}
        </React.Fragment>
    );
};

const ResultsKeyBigContainer = styled.div`
    padding: 15px 5px 5px 5px;
    display: flex;
    flex-wrap: wrap;
    height: 50px;
    ${breakpoints.below('sm')} {
        font-size: 12px;
    }
    > span {
        > span {
            font-size: 15px;
        }
        line-height: 20px;
        flex: 1 1 14%;
        font-size: 13px;
        margin-right: 5px;
        text-align: center;
        ${breakpoints.below('sm')} {
            > span {
                font-size: 13px;
            }
            font-size: 12px;
        }
    }
`;

const ColoredSpan = styled.span<ResultKeyPointsProps>`
    color: ${(props): string => props.bgColor};
`;
