import React from 'react';
import styled from 'styled-components';
import { GameType, Scores } from '@sportech/pools-api';
import { breakpoints } from '../../../settings/breakpoints';

export interface MatchCardResultsProps {
    homeTeam: string;
    awayTeam: string;
    number: number;
    matchId: number;
    score?: Scores;
    points?: number;
    gameType?: GameType;
}

export interface NumberStyleProps {
    color?: string;
    textColor?: string;
    numbers?: number;
    points?: number;
}

export const MatchCardResults = (props: MatchCardResultsProps): JSX.Element => {
    const getColor = (points: number | undefined, textColor = false): string => {
        let color: string;
        let Textcolor: string;
        if (props.gameType === 'goal-rush') {
            switch (points) {
                case 1:
                    color = '#4ca40c';
                    Textcolor = '#fff';
                    break;
                default:
                    color = '#cf1d02';
                    Textcolor = '#fff';
            }
        } else if (props.gameType === 'classic-pools') {
            switch (points) {
                case 1:
                    color = '#ff2b2b';
                    Textcolor = '#fff';
                    break;
                case 2:
                    color = '#272188';
                    Textcolor = '#fff';
                    break;
                case 3:
                    color = 'green';
                    Textcolor = '#fff';
                    break;
                default:
                    color = '#dbdbdb';
                    Textcolor = 'black';
            }
        } else {
            color = '';
            Textcolor = 'black';
        }

        if (textColor) {
            return Textcolor;
        }

        return color;
    };

    return (
        <React.Fragment>
            <MatchCardDiv
                points={props.points}
                numbers={props.number}
                color={getColor(props.points)}
                textColor={getColor(props.points, true)}
            >
                <NumberDiv
                    numbers={props.number}
                    color={getColor(props.points)}
                    points={props.points}
                    textColor={getColor(props.points, true)}
                >
                    {props.number}
                </NumberDiv>
                <TeamsDiv>
                    <HomeDiv>{props.homeTeam}</HomeDiv>
                    <VsDiv points={props.points} textColor={getColor(props.points, true)}>
                        {props.score?.fullTime != null
                            ? `${props.score.fullTime.home} - ${props.score.fullTime.away}`
                            : props.score?.isVoid
                            ? 'VOID'
                            : props.score?.poolsPanel
                            ? 'P - P'
                            : 'vs'}
                    </VsDiv>
                    <AwayDiv>{props.awayTeam}</AwayDiv>
                </TeamsDiv>
            </MatchCardDiv>
        </React.Fragment>
    );
};

const MatchCardDiv = styled.div<NumberStyleProps>`
    color: #011fb3;
    background-color: #fff;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;

    height: 42px;
    line-height: 42px;
    border: ${props => (props.color === '#fff' || props.color === '' ? '1px solid #000' : '0px solid transparent')};

    border-radius: 5px;
    position: relative;
    z-index: 1;
    background: ${(props): string => (props.color ? props.color : '#fff')};
    color: ${(props): string => (props.textColor ? props.textColor : '#000')};

    &:before {
        content: '';
        display: block;
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        right: 0;
        z-index: -1;
        border-radius: 5px;
        transition: all 0.5s;
    }
    &:after {
        background: ${(props): string => (props.color ? props.color : '#fff')};
        content: '';
        display: block;
        position: absolute;
        left: 0px;
        top: 0px;
        bottom: 0px;
        right: 0px;
        z-index: -1;
        border-radius: 5px;
        transition: all 0.5s;
    }
`;

const NumberDiv = styled.div<NumberStyleProps>`
    width: 50px;
    line-height: inherit;
    text-align: center;
    color: ${(props): string => (props.textColor ? props.textColor : '#000')};
    background: transparent;
    position: relative;
    font-size: 16px;
    margin-left: 3px;

    :after {
        content: '';
        height: 75%;
        width: 1px;

        position: absolute;
        right: 0;
        top: 12.5%;

        background-color: ${props => (props.textColor ? props.textColor : '#000')};
    }
    ${breakpoints.below('lg')} {
        width: 20%;
        margin-left: 0;
    }
`;

const TeamsDiv = styled.div`
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 0 2px;
    overflow: hidden;
    width: 0;
`;

const HomeDiv = styled.div`
    text-align: right;
    -webkit-box-flex: 2;
    -webkit-flex: 2;
    -ms-flex: 2;
    flex: 2;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    font-weight: 600;
`;

const VsDiv = styled.div<NumberStyleProps>`
    width: 1.5em;
    text-align: center;
    font-weight: 400;
    font-size: 1.2em;
    color: ${(props): string => (props.textColor ? props.textColor : '#000')};
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;

    ${breakpoints.below('lg')} {
        padding: 0 1px;
    }
`;
const AwayDiv = styled.div`
    -webkit-box-flex: 2;
    -webkit-flex: 2;
    -ms-flex: 2;
    flex: 2;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    font-weight: 600;
`;
