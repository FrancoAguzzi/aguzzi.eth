import React from 'react';
import styled from 'styled-components';
import { CompetitionWagers } from '@sportech/pools-api';
import { ArrowButton } from '../../Common/ArrowButton/ArrowButton';

export interface ResultsWagerLineSelectorProps {
    comp: CompetitionWagers;
    changeLine: any;
    currentActiveWagerLineNumber: number;
    handleScrollContainerLeftChange: any;
    scrollContainerLeftValue: number;
}

export const ResultsWagerLineSelector = (props: ResultsWagerLineSelectorProps): JSX.Element => {
    const moreThanFiveWagers = props.comp.wagers.length > 5;
    const numberOfWagers = props.comp.wagers.length;
    const nextClick = (): void => {
        const newLeftValue = props.scrollContainerLeftValue - 141;
        const maxLeftValue = (numberOfWagers - 5) * 141;

        if (moreThanFiveWagers && newLeftValue >= -maxLeftValue) {
            props.handleScrollContainerLeftChange(newLeftValue);
        }
    };

    const previousClick = (): void => {
        const newLeftValue = props.scrollContainerLeftValue + 141;

        if (moreThanFiveWagers && newLeftValue <= 0) {
            props.handleScrollContainerLeftChange(newLeftValue);
        }
    };
    return (
        <LineContainer>
            <React.Fragment>
                {moreThanFiveWagers && (
                    <ArrowButton isFacingLeft color="#fff" backgroundColor="#38d8ff" onClick={previousClick} />
                )}

                <ScrollContainer>
                    <LineList left={props.scrollContainerLeftValue}>
                        {props.comp.wagers.map((wager, index) => (
                            <StyledP
                                color={index + 1 === props.currentActiveWagerLineNumber ? '#fff' : 'grey'}
                                key={index}
                                onClick={() => props.changeLine(index + 1)}
                            >
                                LINE {index + 1}
                            </StyledP>
                        ))}
                    </LineList>
                </ScrollContainer>
                {moreThanFiveWagers && (
                    <ArrowButton isFacingLeft={false} color="#fff" backgroundColor="#38d8ff" onClick={nextClick} />
                )}
            </React.Fragment>
        </LineContainer>
    );
};

type PProps = {
    color: string;
};

const StyledP = styled.p<PProps>`
    color: ${props => (props.color ? props.color : 'grey')};
    cursor: pointer;
    font-weight: bolder;
    font-size: 1.2em;
    flex: 0 0 141px;
    text-align: center;
    display: inline-block;
    padding: 18px 10px;
    margin: 0;
`;

const ScrollContainer = styled.div`
    overflow: hidden;
    width: 100%;
    height: 64px;
    margin: 0 5px;
    line-height: 32px;
`;

const LineContainer = styled.div`
    display: flex;
    justify-content: space-between;
    background-color: #38d8ff;
    /* color will be white when line is selected */
    color: #fff;
    align-items: center;
    flex-flow: row nowrap;
    margin-top: 10px;
`;

type LineListProps = {
    left: number;
};

const LineList = styled.div<LineListProps>`
    display: flex;
    font-weight: 900;
    text-align: center;
    transition: 0.5s ease-in-out;
    position: relative;
    left: ${props => props.left}px;
`;
