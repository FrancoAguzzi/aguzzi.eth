import React from 'react';
import styled from 'styled-components';
import { Dividend } from '@sportech/pools-api';
import Link from 'next/link';
import { Button } from '../Common/Button/Button';
import '../../utils/extensionMethods';

interface PrizeBreakdownProps {
    Dividends: Dividend[];
}

export const PrizeBreakdown = (props: PrizeBreakdownProps): JSX.Element => {
    return (
        <PrizeBreakdownContainer>
            <div className="header">Prize Breakdown</div>
            <Breakdown>
                <Row>
                    <span>Points</span>
                    <span> Prize money</span>
                </Row>
                {props.Dividends.map((dividend, index) => (
                    <Row key={index}>
                        <span>{dividend.level}</span>
                        <span>£{(dividend.amount / 100).toLocaleStringCash()}</span>
                    </Row>
                ))}
            </Breakdown>
            <Link href="/">
                <StyledPlayClassicButton height="auto">PLAY CLASSIC POOLS</StyledPlayClassicButton>
            </Link>
        </PrizeBreakdownContainer>
    );
};

const PrizeBreakdownContainer = styled.div`
    font-weight: bold;
    line-height: 40px;
    width: 100%;
    background: #edeeee;
    height: fit-content;

    .header {
        background: #363636;
        color: #fff;
        padding: 5px 10px;
        font-size: 19px;
    }
`;

const Breakdown = styled.div`
    display: flex;
    flex-direction: column;
    padding: 0 5px;

    div:first-child {
        font-weight: 400;
    }
`;

const Row = styled.div`
    display: flex;
    flex-flow: row nowrap;
    border-bottom: 0.5px solid #252525;
    margin: 5px 0;
    font-size: 14px;

    span {
        display: flex;
        flex: 1;
        justify-content: center;
    }
`;

const StyledPlayClassicButton = styled(Button)`
    border: none;
    background: #38d8ff;
    color: #000;
    padding: 10px;
    border-radius: 4px;
    line-height: 20px;
    font-size: 13px;
    width: 52%;
    margin: 45px 15px 20px;
    font-weight: 700;
`;
