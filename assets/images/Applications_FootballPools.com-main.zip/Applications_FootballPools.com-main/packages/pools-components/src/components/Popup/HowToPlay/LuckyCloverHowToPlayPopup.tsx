import React, { FunctionComponent } from 'react';
import { useDispatch } from 'react-redux';
import { PopupText, StyledATag } from '../../Styles/defaultPageStyles';
import { AppDispatch } from '../../../state/rootReducer';
import { closePopup } from '../../../state/popupsSlice';

export const LuckyCloverHowToPlayPopup: FunctionComponent = () => {
    const dispatch: AppDispatch = useDispatch<AppDispatch>();

    return (
        <PopupText>
            <div>
                <p>
                    Match all 6 numbers and you could win a cool &pound;1 MILLION!* Plus, there&rsquo;s guaranteed
                    prizes up to &pound;65,000!
                </p>
                <p>
                    It&rsquo;s just &pound;1.50 per draw so it&rsquo;s cheaper than the UK National Lottery and with
                    just 47 balls to choose from you&rsquo;ve got a greater chance of winning!
                </p>
                <p>
                    Simply select your chosen plan for a guaranteed prize, pick your numbers then select additional
                    bonus number(s) for the chance to win up to &pound;1 Million:
                </p>
                <div>
                    <ul>
                        <li>
                            Play pick 5 and match 5 to win a guaranteed &pound;65,000 &ndash; add 1 bonus number to win
                            up to &pound;1 Million!
                        </li>
                        <li>
                            Play pick 4 and match 4 to win a guaranteed &pound;4,800 &ndash; add 2 bonus numbers to win
                            up to &pound;1 Million!
                        </li>
                        <li>
                            Play pick 3 and match 3 to win a guaranteed &pound;800** &ndash; add 3 bonus numbers to win
                            up to &pound;1 Million!
                        </li>
                        <li>
                            Play pick 2 and match 2 to win a guaranteed &pound;55 &ndash; add 4 bonus numbers to win up
                            to &pound;1 Million!
                        </li>
                    </ul>
                </div>
                <p>
                    *Lucky Clover, brought to you by The Football Pools is based on the first 6 numbers drawn in the
                    main Irish National Lotto draws which take place every Saturday and Wednesday. Winnings for
                    guaranteed prizes exclude bonus numbers. In the event of more than 1 winner with 6 correct numbers
                    the &pound;1 Million prize will be shared.
                </p>
            </div>
            <StyledATag
                onClick={() => dispatch(closePopup('how_to_play_LuckyClover'))}
                target="_self"
                href="/content/lucky-clover-Game-Rules"
            >
                View Game Terms & Conditions
            </StyledATag>
        </PopupText>
    );
};
