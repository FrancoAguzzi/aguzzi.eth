import React from 'react';
import { BetSlipItem } from './BetSlipItem';
import { BetSlip, Competition, Offerings } from '@sportech/pools-api';
import { renderWithRedux } from '../../../testing/renderWithRedux';
import { RootState } from '../../../state/rootReducer';
import { withTheme } from '../../../testing/renderWithTheme';
import { testId } from '../../../utils/functionUtils';

const mockBetslip: BetSlip = {
    competitionId: 1234,
    competitionName: 'test comp',
    pick: 10,
    current: true,
    price: 100,
    priceID: 5,
    highestRow: 1,
    numbers: [
        {
            Id: 1,
            rows: 1,
            selections: [],
        },
        {
            Id: 2,
            rows: 1,
            selections: [],
        },
        {
            Id: 3,
            rows: 1,
            selections: [],
        },
        {
            Id: 4,
            rows: 1,
            selections: [],
        },
        {
            Id: 5,
            rows: 1,
            selections: [],
        },
        {
            Id: 6,
            rows: 1,
            selections: [],
        },
        {
            Id: 7,
            rows: 1,
            selections: [],
        },
        {
            Id: 8,
            rows: 1,
            selections: [],
        },
        {
            Id: 9,
            rows: 1,
            selections: [],
        },
        {
            Id: 10,
            rows: 1,
            selections: [],
        },
    ],
    bonusNumbers: [],
    bonusPick: 0,
    bonusPrice: 0,
    bonusPriceId: 0,
};

const mockOffers: Offerings = {
    defaultOffering: {
        id: 5,
        pricePerEntry: 100,
        description: 'test offer',
        maximumSelections: 10,
    },
    offerings: [],
    gameType: { subscription: true, oneOff: false },
};

const mockCompetition: Competition = {
    id: 1234,
    description: 'test comp',
    number: 1234,
    datumDate: '',
    datumDateWithBuffer: '',
    fixtures: [],
    poolSize: { type: '', value: 0 },
    state: '',
};

describe('BetSlipItem', () => {
    it('should render List', () => {
        const { container } = renderWithRedux(
            withTheme(
                <BetSlipItem
                    betslipselection={mockBetslip}
                    SelectAmountAction={jest.fn()}
                    ClearLine={jest.fn()}
                    AddLine={jest.fn()}
                    ChangeBet={jest.fn()}
                    betslipCurrentSelection={mockBetslip}
                    offers={mockOffers}
                    moreThanOneLine={false}
                    handleCircleNumberClick={jest.fn()}
                    setCurrentOfferingId={jest.fn()}
                    setShowMore={jest.fn()}
                    showMoreValue={false}
                    currentOfferingId={5}
                    isClover={false}
                    competition={mockCompetition}
                    {...testId(`Game_BetslipItem0`)}
                />,
            ),
            {} as RootState,
        );

        expect(container).toMatchSnapshot();
    });
});
