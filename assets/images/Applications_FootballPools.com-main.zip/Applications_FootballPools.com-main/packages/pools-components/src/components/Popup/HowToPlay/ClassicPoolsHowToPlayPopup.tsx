import React, { FunctionComponent } from 'react';
import { useDispatch } from 'react-redux';
import { PopupText, StyledATag } from '../../Styles/defaultPageStyles';
import { AppDispatch } from '../../../state/rootReducer';
import { closePopup } from '../../../state/popupsSlice';

export const ClassicPoolsHowToPlayPopup: FunctionComponent = () => {
    const dispatch: AppDispatch = useDispatch<AppDispatch>();
    return (
        <PopupText>
            <p>
                Simply choose 10 matches from the list of 49 you think will result in a score draw - points will be
                awarded for your best 8 selections
            </p>
            <p>
                <strong>
                    <span>3 points</span>
                </strong>
                <span> For a Score Draw (1-1 or higher)</span>
            </p>
            <p>
                <strong>
                    <span>2 points</span>
                </strong>
                <span> For a No-Score Draw(0-0)</span>
            </p>
            <p>
                <strong>
                    <span>1 points</span>
                </strong>
                <span> Home or Away Win</span>
            </p>
            <p> The more points you get, the greater your chance of winning a cash prize will be!</p>
            <p>
                The top prize is a MASSIVE £3 Million, find out all about it{' '}
                <StyledATag
                    onClick={() => dispatch(closePopup('how_to_play_ClassicPools'))}
                    target="_self"
                    href="/content/win-3-million-on-classic-pools"
                >
                    here
                </StyledATag>
                .
            </p>
            <StyledATag
                onClick={() => dispatch(closePopup('how_to_play_ClassicPools'))}
                target="_self"
                href="/content/classic-pools-game-rules"
            >
                View Game Terms & Conditions
            </StyledATag>
        </PopupText>
    );
};
