import React from 'react';
import styled from 'styled-components';
import { FixtureResult, GameType, NumbersSelected } from '@sportech/pools-api';
import { BetSlipCircle } from '../BetSlipCircle/BetSlipCircle';
import { getHdaResult, testId } from '../../../utils/functionUtils';

export interface BetSlipCircleListProps {
    selection?: Array<NumbersSelected>;
    winningNumbers?: number[];
    amount: number;
    row: number;
    displayId?: boolean;
    isCurrent?: boolean;
    handleOnClick?: (id: number, displayId: string) => void;
    ballColor?: string;
    isMobileBetslip?: boolean;
    isClover?: boolean;
    betslipItemSize?: string;
    showCountHeader?: boolean;
    selectionsFontStyle?: 'normal' | 'italic';
    selectionsFontColour?: string;
    accountHistoryStyle?: boolean;
    game?: GameType;
    fixtureResults?: FixtureResult[];
    isHda?: boolean;
    ballMargin?: string;
}

export const BetSlipCircleList = (props: BetSlipCircleListProps): JSX.Element => {
    return (
        <>
            <StyledListItem
                isClover={props.isClover}
                isBetslipMobile={props.isMobileBetslip}
                ballMargin={props.ballMargin}
            >
                {Array.from(Array(props.amount), (e, i) => {
                    const selection = props.selection && props.selection[i] ? props.selection[i] : undefined;
                    const fixtureResult =
                        props.fixtureResults && selection
                            ? props.fixtureResults.find(f => f.number === selection.Id)
                            : undefined;

                    const hdaResult = fixtureResult && props.isHda ? getHdaResult(fixtureResult) : undefined;
                    const hdaSelection = selection?.selections.toString().toLocaleUpperCase();
                    const points = props.isHda
                        ? hdaSelection && hdaResult
                            ? hdaSelection.includes(hdaResult)
                                ? 1
                                : 0
                            : undefined
                        : props.isClover
                        ? selection && props.winningNumbers
                            ? props.winningNumbers.includes(selection.Id)
                                ? 1
                                : 0
                            : undefined
                        : fixtureResult
                        ? fixtureResult.points
                        : undefined;
                    return (
                        <BetSlipCircle
                            key={`Circle${i}`}
                            selected={
                                props.selection && props.selection[i]
                                    ? props.displayId
                                        ? props.selection[i].Id
                                        : props.selection[i].selections[props.row]?.toLocaleUpperCase()
                                    : ''
                            }
                            displayId={props.displayId}
                            selectedId={props.selection && props.selection[i] ? props.selection[i].Id : 0}
                            isCurrentSelectedLine={props.isCurrent}
                            handleOnClick={props.handleOnClick}
                            ballColor={props.ballColor}
                            isMobileBetslip={props.isMobileBetslip}
                            size={props.betslipItemSize}
                            header={props.showCountHeader ? (i + 1).toString() : undefined}
                            selectionsFontStyle={props.selectionsFontStyle}
                            {...testId(`Game_BetslipCircle${props.row}_${i}`)}
                            selectionsFontColour={props.selectionsFontColour}
                            game={props.game}
                            accountHistoryStyle={props.accountHistoryStyle}
                            points={points}
                        />
                    );
                })}
            </StyledListItem>
        </>
    );
};

type StyledListItemProps = {
    isBetslipMobile?: boolean;
    isClover?: boolean;
    ballMargin?: string;
};

const StyledListItem = styled.ul<StyledListItemProps>`
    overflow: auto;
    flex-wrap: nowrap;
    padding: 0 0 0 0;

    display: flex;
    margin: 0em 0;
    ${props =>
        props.isBetslipMobile &&
        `
        overflow: auto;
        flex-wrap: nowrap;
        margin: 0;
    `}
    flex: unset;
    width: unset;
    list-style-type: none;

    li {
        margin: ${props => (props.ballMargin ? props.ballMargin : '3px 1px')};
    }
`;
