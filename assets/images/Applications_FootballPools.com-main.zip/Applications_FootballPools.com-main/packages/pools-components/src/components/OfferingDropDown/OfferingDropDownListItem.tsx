import React, { useState } from 'react';
import styled from 'styled-components';
import { BetSlip, Offering, Response } from '@sportech/pools-api';
import { Button } from '../Common/Button/Button';
import { ChevronFigures } from '../Figures/ChevronFigures';

export interface OfferingDropDownListItemProps {
    offer: Offering;
    selectAmountAction: (id: number, offer: Offering) => void;
    setOfferingDropdownOpen: (val: boolean) => void;
    betslipCurrentSelection: BetSlip;
    setShowMore: (val: boolean) => void;
    setCurrentOffering: (val: number) => void;
    getOfferingDescription?: (id: number) => Response<string>;
}
export const OfferingDropDownListItem = (props: OfferingDropDownListItemProps): JSX.Element => {
    const [accordianOpen, setAccordianOpen] = useState(false);
    const [offeringDescription, setOfferingDescription] = useState<Response<string> | undefined>(undefined);
    // const [runQuery, { called, loading, data }] = useLazyQuery(QUERY);
    // const getOfferingDescription = (): void => {
    //     runQuery({
    //         variables: { idFilter: buildIdFilter(props.offer.id) },
    //     });
    // };

    return (
        <React.Fragment>
            <li>
                <StyledOfferingDesc
                    onClick={(): void => {
                        props.selectAmountAction(props.betslipCurrentSelection.competitionId, props.offer);
                        props.setShowMore(true);
                        props.setOfferingDropdownOpen(false);
                        props.setCurrentOffering(props.offer.id);
                    }}
                >
                    {props.offer.description}
                </StyledOfferingDesc>
                <Button
                    height="10px"
                    bgColor="#F5F5F5"
                    textColor="#000"
                    // padding={'0.25em 1.25em'}
                    onClick={(): void => {
                        setOfferingDescription(
                            props.getOfferingDescription
                                ? props.getOfferingDescription(props.offer.id)
                                : {
                                      data: `Pick ${props.offer.description}`,
                                      isLoading: false,
                                  },
                        );
                        setAccordianOpen(accordianOpen => !accordianOpen);
                    }}
                    noHover
                >
                    <ChevronFigures width="20px" height="20px" rotation={accordianOpen ? '180' : '0'} />
                </Button>

                {accordianOpen && (
                    <StyledOfferingMoreDetails>
                        {offeringDescription !== undefined && offeringDescription.data ? (
                            offeringDescription.data
                        ) : (
                            <p>loading</p>
                        )}
                    </StyledOfferingMoreDetails>
                )}
            </li>
            <hr />
        </React.Fragment>
    );
};

const StyledOfferingDesc = styled.p`
    display: inline-block;
    width: 80%;
    margin: 0;
    flex: 7;
`;

const StyledOfferingMoreDetails = styled.p`
    width: 100%;
    padding: 20px 10px 5px 10px;
    cursor: default;
`;
