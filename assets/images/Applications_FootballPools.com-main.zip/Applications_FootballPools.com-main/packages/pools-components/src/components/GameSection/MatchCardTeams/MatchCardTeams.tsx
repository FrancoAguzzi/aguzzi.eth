import React from 'react';
import styled from 'styled-components';
import { NumbersSelected } from '@sportech/pools-api';
import { breakpoints } from '../../../settings/breakpoints';
import { testId } from '../../../utils/functionUtils';

export interface MatchCardTeamsProps {
    homeTeam: string;
    awayTeam: string;
    number: number;
    action?: (id: number, type: string) => void;
    matchId: number;
    numbers?: NumbersSelected | undefined;
    canEdit?: boolean;
    isTwoColumn?: boolean;
    isMobile?: boolean;
}

export interface MatchCardTeamsStyleProps {
    numbers?: NumbersSelected | undefined;
    canEdit: boolean;
    isTwoColumn?: boolean;
    ismobile?: boolean;
}

export const MatchCardTeams = (props: MatchCardTeamsProps): JSX.Element => {
    return (
        <MatchCardDiv
            numbers={props.numbers}
            canEdit={props.canEdit || false}
            onClick={(): void => {
                if (props.canEdit && props.action !== undefined) {
                    props.action(props.number, 'D');
                }
            }}
            {...testId(`Game_FixtureButton${props.number}`)}
        >
            <NumberDiv canEdit={props.canEdit || false} numbers={props.numbers} isTwoColumn={props.isTwoColumn}>
                {props.number}
            </NumberDiv>
            <DividerDiv numbers={props.numbers} />

            <TeamsDiv numbers={props.numbers} isTwoColumn>
                <HomeDiv>{props.homeTeam}</HomeDiv>
                <AwayDiv>{props.awayTeam}</AwayDiv>
            </TeamsDiv>
        </MatchCardDiv>
    );
};

const MatchCardDiv = styled.div<MatchCardTeamsStyleProps>`
    color: ${props => props.theme.colours.gameButtonFont};
    display: flex;
    padding: 1px;
    height: 40px;
    line-height: 40px;
    font-size: 14px;
    background: ${props => (props.numbers ? props.theme.colours.gameButtonSelectedBackground : '#fff')};
    border: ${props =>
        props.numbers
            ? `1px solid ${props.theme.colours.gameButtonSelectedBackground}`
            : `1px solid ${props.theme.colours.gameButtonFont}`};
    border-radius: 6px;
    font-weight: ${props => (props.numbers ? `700` : `400`)};
    ${breakpoints.below('sm')} {
        font-size: 12px;
        height: 35px;
        line-height: 35px;
    }
    z-index: 1;
    ${breakpoints.above('lg')} {
        &:hover {
            cursor: pointer;
            border: ${props => `2px solid ${props.theme.colours.gameButtonSelectedBackground}`};
            padding: 0;
        }
    }
    transition: background-color 0.5s ease;
`;

const NumberDiv = styled.div<MatchCardTeamsStyleProps>`
    width: 40px;
    height: 40px;
    line-height: inherit;
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    font-size: 18px;
    margin-left: 3px;
    margin-right: 2px;
    color: ${props => (props.numbers ? '#fff' : '#000')};

    border-radius: 8px;

    ${breakpoints.below('sm')} {
        height: 32px;
        line-height: 32px;
    }

    ${breakpoints.above('lg')} {
        width: 39px;
        height: 39px;
    }
    transition: background-color 0.5s ease;
`;

const TeamsDiv = styled.div<{
    numbers?: NumbersSelected;
    isTwoColumn: boolean;
}>`
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    padding: ${props => (props.isTwoColumn ? '0 10px' : '')};
    flex-direction: column;
    color: ${props => (props.numbers ? '#fff' : '#000')};
    border-radius: 8px;
    ${breakpoints.below('lg')} {
        width: 63%;
    }
    overflow: hidden;
    transition: background-color 0.5s ease;
`;

const HomeDiv = styled.div`
    flex: 1;
    height: 20px;
    margin-top: -10px;
    width: 100%;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
`;

const AwayDiv = styled.div`
    flex: 1;
    height: 20px;
    margin-top: -10px;
    width: 100%;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
`;

const DividerDiv = styled.div<{
    numbers?: NumbersSelected;
}>`
    height: 22px;
    margin: auto;
    width: 1px;
    background: ${props => (props.numbers ? '#fff' : '#000')};
`;
