import React from 'react';
import { DateTimeFormatter } from '../../Common/DateTimeFormatter/DateTimeFormatter';
import styled from 'styled-components';

const Container = styled.div`
    display: flex;
    flex-direction: column;
`;

const CompetitionInfoContainer = styled.div`
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    background: #c8c8c8;
    padding: 5px;
`;
const CompetitionDescription = styled.div`
    font-weight: bold;
`;
const CompetitionDate = styled.div``;

const BetsTypeDescriptionContainer = styled.div`
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    background: ${props => props.theme.colours.gameMainColour};
    color: ${props => props.theme.colours.gameMainColourText};
    padding: 5px;
`;

const ViewLinesItemInfoContainer = styled.div`
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    background: #e6e6e6;
    padding: 5px;
`;
const ViewLinesItemDescription = styled.div``;
const ViewLinesItemCost = styled.div``;

interface ViewLinesItemInfoProps {
    competitionDescription?: string;
    competitionDate?: string;
    viewLinesItemDescription?: string;
    viewLinesItemCost?: string;
    betsTypeDescription?: string;
}

export const ViewLinesItemInfo = ({
    competitionDescription,
    competitionDate,
    viewLinesItemDescription,
    viewLinesItemCost,
    betsTypeDescription,
}: ViewLinesItemInfoProps): JSX.Element => {
    return (
        <Container>
            {(competitionDescription || competitionDate) && (
                <CompetitionInfoContainer>
                    {competitionDescription && (
                        <CompetitionDescription>{competitionDescription}</CompetitionDescription>
                    )}
                    {competitionDate && (
                        <CompetitionDate>
                            <DateTimeFormatter input={competitionDate} format="DD-MM-YYYY HH:mm" />
                        </CompetitionDate>
                    )}
                </CompetitionInfoContainer>
            )}
            {betsTypeDescription && <BetsTypeDescriptionContainer>{betsTypeDescription}</BetsTypeDescriptionContainer>}
            <ViewLinesItemInfoContainer>
                {viewLinesItemDescription && (
                    <ViewLinesItemDescription>{viewLinesItemDescription}</ViewLinesItemDescription>
                )}
                {viewLinesItemCost && <ViewLinesItemCost>{viewLinesItemCost}</ViewLinesItemCost>}
            </ViewLinesItemInfoContainer>
        </Container>
    );
};
