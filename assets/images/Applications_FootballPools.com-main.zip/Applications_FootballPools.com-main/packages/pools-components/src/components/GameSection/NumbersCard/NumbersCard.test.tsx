import React from 'react';
import 'jest-styled-components';
import { renderWithTheme } from '../../../testing/renderWithTheme';
import { NumbersCard } from './NumbersCard';

// jest.mock('@settings/breakpoints');

describe('Numbers Card', () => {
    it('should match snapshot', () => {
        const { container } = renderWithTheme(<NumbersCard number={1} isResults={false} />);

        expect(container).toMatchSnapshot();
    });
});
