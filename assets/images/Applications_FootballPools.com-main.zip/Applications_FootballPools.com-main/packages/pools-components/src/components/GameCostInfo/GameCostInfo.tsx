import React, { useLayoutEffect, useState } from 'react';
import styled from 'styled-components';
import Tooltip from 'reactjs-popup';

const Container = styled.div`
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    font-weight: bold;
    color: #120f0e;
    width: 100%;
`;
const PriceContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    margin: 10px 0;
`;
const HeaderText = styled.div`
    font-size: 14px;
`;
const PriceText = styled.div`
    font-size: 22px;
`;
const StyledTooltip = styled(Tooltip)`
    &-overlay {
        background-color: rgba(0, 0, 0, 0.5) !important;
    }
    &-content {
        background-color: #fff !important;
        border-radius: 5px 5px 0 5px;
        max-width: 100% !important;
        padding: 1rem !important;
    }
`;

const StyledImg = styled.img`
    height: 15px;
    margin-left: 5px;
`;

export interface GameCostInfoProps {
    perDrawCost?: string;
    perMonthCost?: string;
    perMonthTooltipContent?: JSX.Element;
    tooltipProps?: {
        lockScroll?: boolean;
    };
    perDrawCostText?: string;
    perMonthCostText?: string;
}

export const GameCostInfo = ({
    perDrawCost,
    perMonthCost,
    perMonthTooltipContent,
    tooltipProps,
    perDrawCostText,
    perMonthCostText,
}: GameCostInfoProps): JSX.Element => {
    const [isTooltipOpen, setIsTooltipOpen] = useState<boolean>(false);
    const lockScroll = () => {
        document.getElementsByTagName('body')[0].style.overflow = 'hidden';
    };
    const resetScroll = () => {
        document.getElementsByTagName('body')[0].style.overflow = 'auto';
    };
    /**
     * This is required as the lockScroll prop on reactjs-popup only
     * works when modal is set to true.
     * For tooltips we must lock the scroll manually:
     */
    useLayoutEffect(() => {
        if (tooltipProps && tooltipProps.lockScroll) {
            if (isTooltipOpen) {
                lockScroll();
            } else {
                resetScroll();
            }
        }
    }, [isTooltipOpen]);
    const getTrigger = (isOpen: boolean): JSX.Element => {
        setIsTooltipOpen(isOpen);
        return <StyledImg src="/input-question-mark.svg" alt="question mark icon" role="switch" />;
    };
    return (
        <Container>
            {perDrawCost && (
                <PriceContainer>
                    <HeaderText>{perDrawCostText || 'COST PER GAME'}</HeaderText>
                    <PriceText>{perDrawCost}</PriceText>
                </PriceContainer>
            )}
            {perMonthCost && (
                <PriceContainer>
                    <HeaderText>{perMonthCostText || 'MAX COST A MONTH'}</HeaderText>
                    <PriceText>
                        {perMonthCost}
                        {perMonthTooltipContent && (
                            <StyledTooltip
                                trigger={getTrigger}
                                position="top right"
                                // on={['hover', 'focus', 'click']}
                                {...tooltipProps}
                            >
                                {perMonthTooltipContent}
                            </StyledTooltip>
                        )}
                    </PriceText>
                </PriceContainer>
            )}
        </Container>
    );
};
