import React from 'react';
import styled from 'styled-components';
import { breakpoints } from '../../../settings/breakpoints';
import { ExternalLink } from '../../Common/ExternalLink/ExternalLink';

interface TopbarProps {
    urls: TopbarUrlProps[];
}

interface TopbarUrlProps {
    label: string;
    url: string;
    image?: string;
}

const Topbar = ({ urls }: TopbarProps): JSX.Element => (
    <div>
        <StyledContent>
            <Styledulist>
                {urls &&
                    urls.map((value, index) => (
                        <Styledlist key={index}>
                            <Styledatag target="_self" href={value.url}>
                                {value.image ? <Styledimg src={value.image} /> : value.label}
                            </Styledatag>
                        </Styledlist>
                    ))}
            </Styledulist>
        </StyledContent>
    </div>
);

export default Topbar;

const Styledlist = styled.li`
    -webkit-border-top-left-radius: 0px;
    -moz-border-radius-topleft: 0px;
    border-top-left-radius: 0px;
    -webkit-border-top-right-radius: 0px;
    -moz-border-radius-topright: 0px;
    border-top-right-radius: 0px;
    height: auto;
    margin-top: 10px;
    padding: 5px 7px;
    font-size: 13px;
    margin-right: -5px;
    font-weight: 700;
    display: inline-block;
    position: relative;
    margin-left: 5px;
    text-transform: uppercase;
    vertical-align: middle;
    &:first-child {
        margin-left: 0;
    }
    &:nth-last-child(3) {
        float: right;
    }
    &:nth-last-child(2) {
        float: right;
    }
    &:nth-last-child(1) {
        float: right;
    }

    &:nth-last-child(4) {
        padding: 1px 7px;
    }
`;

const Styledulist = styled.ul`
    margin: 0;
    padding: 0;
    list-style: none;
`;

const Styledatag = styled(ExternalLink)`
    color: white;
    text-decoration: none;
`;

const StyledContent = styled.div`
    max-width: 1316px;
    margin: 0 auto;
    font-family: Arial, Helvetica Neue, Helvetica, sans-serif;
    ${breakpoints.below('lg')} {
        display: none;
    }
`;

const Styledimg = styled.img`
    height: 27px;
    width: 84px;
`;
