import React from 'react';
import 'jest-styled-components';
import { ViewLinesItemInfo } from './ViewLinesItemInfo';
import { renderWithTheme } from '../../../testing/renderWithTheme';

describe('ViewLinesItemInfo', () => {
    it('should render with text', () => {
        const { container } = renderWithTheme(<ViewLinesItemInfo />);

        expect(container).toMatchSnapshot();
    });
});
