import React, { useEffect, useContext } from 'react';
import styled, { ThemeContext } from 'styled-components';

import { Button } from '../Common/Button/Button';
import { BetSlip, Offering, Offerings } from '@sportech/pools-api';
import { breakpoints } from '../../settings/breakpoints';
import { getTotalPrice, isPlayEnabled, testId } from '../../utils/functionUtils';
import '../../utils/extensionMethods';
import { MillionLuckyDipText, MillionTextFp } from '../Styles/defaultPageStyles';

export interface GameActionButtonsProps {
    betslipselection: Array<BetSlip>;
    SelectAmountAction: (id: number, amount: Offering) => void;
    ClearLine: () => void;
    AddLine: () => void;
    ChangeBet: (index: number) => void;
    offers: Offerings;
    ShowHDA?: boolean;
    setCurrentOfferingId: (val: number) => void;
    currentOfferingId: number;
    setShowMore: (val: boolean) => void;
    showMoreValue: boolean;
    addedLines: BetSlip[];
    pressPlay: () => void;
    user?: any;
    openAddLinesPopup: () => void;
    isViewLines?: boolean;
    canEdit?: boolean;
    fixtureCountLabel?: string;
    onClickLuckyDip?: () => void;
    onClickLuckyDipBonus?: () => void;
    onClickHowToPlay?: () => void;
    onClickViewLines?: () => void;
    isClover: boolean;
    showLuckyDipButton?: boolean;
    showLuckyDipBonusButton?: boolean;
    showAddLinesButton?: boolean;
    showAddedLinesButton?: boolean;
    showCompetitionSelector?: boolean;
    isMobileOrTablet?: boolean;
    isViewLinesButtonEnabled?: boolean;
    competitionSelectorElement?: JSX.Element;
    maximumLines?: number;
    minimumCost?: number;
    howToPlayButtonText?: string;
    showHowToPlayButton?: boolean;
    playNowColour?: string;
}

export const GameActionButtons = (props: GameActionButtonsProps): JSX.Element => {
    const totalPricenumber = getTotalPrice(props.ShowHDA as boolean, props.isClover, props.betslipselection);
    const totalPrice = totalPricenumber.toLocaleStringCash();

    const currentBet = props.betslipselection.filter(x => x.current)[0];

    const themeContext = useContext(ThemeContext);

    const updateCurrentOfferingId = (item: BetSlip): void => {
        if (item && item.priceID) {
            props.setCurrentOfferingId(item.priceID);
            props.setShowMore(false);
        }
    };

    useEffect(() => {
        updateCurrentOfferingId(currentBet);
    }, [props.betslipselection]);

    return (
        <GameActionButtonsContainer>
            {props.showLuckyDipButton && (
                <ActionItem>
                    <ActionButton
                        height="auto"
                        width="100px"
                        bgColor="#1A90FF"
                        textColor="#fff"
                        padding="1em 0.75em"
                        onClick={props.onClickLuckyDip}
                        disabledBackgroundColour={themeContext.colours.betslipMobileButtonDisabled}
                        {...testId('BetSlip_LuckyDip')}
                    >
                        LUCKY DIP
                    </ActionButton>
                </ActionItem>
            )}

            {props.showLuckyDipBonusButton && (
                <ActionItem>
                    <ActionButton
                        height="auto"
                        width="100px"
                        bgColor="#e0ac00"
                        textColor="#000"
                        padding="1em 0.75em"
                        onClick={props.onClickLuckyDipBonus}
                        disabledBackgroundColour={themeContext.colours.betslipMobileButtonDisabled}
                        {...testId('BetSlip_LuckyDipBonus')}
                    >
                        <MillionTextFp>£1 MILLION</MillionTextFp>
                        <MillionLuckyDipText>LUCKY DIP</MillionLuckyDipText>
                    </ActionButton>
                </ActionItem>
            )}
            {props.showHowToPlayButton && (
                <ActionItem>
                    <ActionButton
                        height="auto"
                        width="100px"
                        bgColor="#000D68"
                        textColor="#fff"
                        padding="1em 0.75em"
                        onClick={props.onClickHowToPlay}
                        disabledBackgroundColour={themeContext.colours.betslipMobileButtonDisabled}
                        {...testId('BetSlip_HowToPlay')}
                    >
                        {typeof props.howToPlayButtonText !== 'undefined' ? props.howToPlayButtonText : `HOW TO PLAY`}
                    </ActionButton>
                </ActionItem>
            )}

            {props.user && props.user.isLoggedIn && (
                <ActionItemMobileOnly>
                    <ActionButton
                        height="auto"
                        width="100px"
                        bgColor="#FD0000"
                        textColor="#fff"
                        padding="1em 0.75em"
                        onClick={props.onClickViewLines}
                        disabledBackgroundColour={themeContext.colours.betslipMobileButtonDisabled}
                        {...testId('BetSlipMobile_ViewLines')}
                        disabled={!props.isViewLinesButtonEnabled}
                    >
                        VIEW LINES
                    </ActionButton>
                </ActionItemMobileOnly>
            )}
            {props.showAddLinesButton && (
                <ActionItem>
                    <ActionButton
                        height="auto"
                        bgColor="#38d8ff"
                        textColor="#fff"
                        padding="1em 0.75em"
                        onClick={(): void => {
                            props.AddLine();
                        }}
                        disabledBackgroundColour={themeContext.colours.betslipMobileButtonDisabled}
                        disabled={
                            !currentBet ||
                            (currentBet.pick !== currentBet.numbers?.length &&
                                (!props.maximumLines || props.addedLines.length + 1 <= props.maximumLines))
                        }
                        {...testId('BetSlipMobile_AddLineButton')}
                    >
                        ADD LINE
                    </ActionButton>
                </ActionItem>
            )}
            {props.showAddedLinesButton && (
                <ActionItemMobileOnly>
                    <ActionButton
                        height="auto"
                        bgColor={themeContext.colours.gameMainColour}
                        textColor="#fff"
                        padding="1em 0.75em"
                        disabled={props.addedLines.length === 0}
                        onClick={props.openAddLinesPopup}
                        {...testId('BetSlipMobile_OpenAddLinePopupButton')}
                    >
                        {props.addedLines.length > 1
                            ? `${props.addedLines.length} LINES ADDED `
                            : `${props.addedLines.length} LINE ADDED `}{' '}
                        £{totalPrice}
                    </ActionButton>
                </ActionItemMobileOnly>
            )}

            <ActionItemMobileOnly>
                <PlayNowActionButton
                    height="auto"
                    width="100px"
                    bgColor={
                        props.playNowColour
                            ? props.playNowColour
                            : themeContext.colours.buttonConfirm
                            ? themeContext.colours.buttonConfirm
                            : '#009A29'
                    }
                    textColor="#fff"
                    padding="1em 0.75em"
                    disabled={!isPlayEnabled(props.betslipselection, props.offers, props.minimumCost, totalPricenumber)}
                    onClick={props.pressPlay}
                    disabledBackgroundColour={themeContext.colours.betslipMobileButtonDisabled}
                    {...testId('BetSlipMobile_PlayButton')}
                    disablePulse={props.playNowColour !== undefined}
                >
                    PLAY NOW
                </PlayNowActionButton>
            </ActionItemMobileOnly>

            {props.showCompetitionSelector && props.competitionSelectorElement && (
                <React.Fragment>{props.competitionSelectorElement}</React.Fragment>
            )}
        </GameActionButtonsContainer>
    );
};

const GameActionButtonsContainer = styled.div`
    display: flex;
    flex-direction: row;
    justify-content: center;
    padding: 10px 5px;
    width: 100%;
    ${breakpoints.below('lg')} {
        justify-content: space-around;
    }
`;

const ActionItem = styled.div`
    width: 24%;
    height: 52px;
    margin: 0 10px;
    ${breakpoints.below('sm')} {
        height: 42px;
    }
    ${breakpoints.below('lg')} {
        margin: auto;
    }
`;

const ActionItemMobileOnly = styled(ActionItem)`
    display: none;
    ${breakpoints.below('lg')} {
        display: block;
    }
`;

const ActionButton = styled(Button)`
    border-radius: 25px;
    font-size: 14px;
    font-weight: bold;
    width: 100%;
    height: 100%;
    &:disabled {
        background: ${props => props.theme.colours.betslipMobileButtonDisabled};
        transition: background-color 0.5s ease;
    }
    &:enabled {
        transition: background-color 0.5s ease;
    }
    ${breakpoints.below('sm')} {
        font-size: 12px;
    }
    ${breakpoints.below('xs')} {
        font-size: 9px;
    }
`;

const PlayNowActionButton = styled(ActionButton)<{ disablePulse?: boolean }>`
    ${props =>
        !props.disablePulse &&
        `@keyframes pulse {
        0% {
            box-shadow: 0 0 0 0 rgba(0, 195, 8, 0.4);
        }
        70% {
            box-shadow: 0 0 0 10px rgba(0, 195, 8, 0);
        }
        100% {
            box-shadow: 0 0 0 0 rgba(0, 195, 8, 0);
        }
    }
    &:enabled {
        box-shadow: 0 0 0 rgba(0, 195, 8, 0.4);
        animation: pulse 2s infinite;
    }`}
`;
