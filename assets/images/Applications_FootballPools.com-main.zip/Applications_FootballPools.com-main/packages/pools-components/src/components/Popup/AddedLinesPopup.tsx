import React, { useEffect, useRef } from 'react';
import { useDispatch } from 'react-redux';
import styled from 'styled-components';
import { BetSlip, GameType, Offerings } from '@sportech/pools-api';
import { AppDispatch } from '../../state/rootReducer';
import { closePopup } from '../../state/popupsSlice';
import { Button } from '../Common/Button/Button';
import { getTotalLines, getTotalPrice, isPlayEnabled, RemoveGameName } from '../../utils/functionUtils';
import '../../utils/extensionMethods';
import { BetSelections } from '../BetSlip/BetSelections/BetSelections';

interface AddedLinesPopupProps {
    betslipselection: Array<BetSlip>;
    offers: Offerings;
    currentBet: BetSlip;
    changeBet: (index: number) => void;
    showHDA: boolean;
    clearLine: (index?: number, isCurrent?: boolean) => void;
    addedLines: BetSlip[];
    pressPlay: () => void;
    handleCircleNumberClick?: (id: number, type: string) => void;
    isClover: boolean;
    game: GameType;
    showBackButton?: boolean;
    showPlayButton?: boolean;
    showCost?: boolean;
    showLinesCount?: boolean;
    minimumCost?: number;
    showCountHeader?: boolean;
    selectionsFontStyle?: 'normal' | 'italic';
    selectionsMargin?: string;
    showPerLineCount?: boolean;
    setManualBetSwitching?: (manualSwitch: boolean) => void;
    playNowColour?: string;
}

export const AddedLinesPopup = (props: AddedLinesPopupProps): JSX.Element => {
    const dispatch: AppDispatch = useDispatch<AppDispatch>();
    const editLineClick = (index: number): void => {
        const currentLineIndex = props.addedLines?.findIndex(b => b.current);
        const isCurrent = currentLineIndex === index || currentLineIndex < 0;
        if (props.setManualBetSwitching && isCurrent) {
            props.setManualBetSwitching(true);
        }
        if (props.currentBet.pick !== props.currentBet.numbers?.length) {
            props.clearLine();
        }
        props.changeBet(index);
        dispatch(closePopup('added_lines'));
    };

    const removeLineClick = (index: number): void => {
        const currentLineIndex = props.addedLines?.findIndex(b => b.current);
        const isCurrent = currentLineIndex === index || currentLineIndex < 0;
        if (props.setManualBetSwitching && isCurrent) {
            props.setManualBetSwitching(true);
        }
        if (props.betslipselection.filter(x => !x.current).length <= 1) {
            props.clearLine(index, isCurrent);
            dispatch(closePopup('added_lines'));
        } else {
            props.clearLine(index, isCurrent);
        }
    };

    const betSlipScrollRef = useRef<HTMLDivElement>(null);
    const childBetSlipItemRef = useRef<HTMLLIElement>(null);
    const scrollToCurrentLine = (): void => {
        setTimeout(() => {
            if (childBetSlipItemRef.current !== null) {
                childBetSlipItemRef.current.scrollIntoView({
                    behavior: 'smooth',
                    block: 'nearest',
                });
            } else if (betSlipScrollRef.current !== null) {
                betSlipScrollRef.current.scrollTop = betSlipScrollRef.current.scrollHeight;
            }
        }, 100);
    };
    useEffect(() => {
        scrollToCurrentLine();
    }, [props.betslipselection]);

    const totalPricenumber = getTotalPrice(props.showHDA, props.isClover, props.betslipselection);
    const totalPrice = totalPricenumber.toLocaleStringCash();

    const getLinePrice = (line: BetSlip): string => {
        const ret = getTotalPrice(
            props.showHDA,
            props.isClover,
            props.betslipselection.filter(it => it === line),
        ).toLocaleStringCash();
        return ret;
    };

    const getTotalLinesForItem = (bet: BetSlip): number => {
        const lines = getTotalLines(props.showHDA, [bet]);
        return lines;
    };

    return (
        <React.Fragment>
            <AddedLinesContent ref={betSlipScrollRef}>
                {props.addedLines.map((item, index) => (
                    <AddedLinesItem key={index} ref={item === props.currentBet ? childBetSlipItemRef : null}>
                        <AddedLineHeader>
                            {/* {RemoveGameName(
                                props.offers.offerings.find(
                                    (x) => x.id === item.priceID,
                                )?.description,
                            )}{' '}
                            <br /> */}
                            <AddedLineHeaderItem>{RemoveGameName(item.competitionName)}</AddedLineHeaderItem>
                            {props.showPerLineCount && <LineCountSection count={getTotalLinesForItem(item)} />}
                        </AddedLineHeader>
                        <Container isClover={props.isClover}>
                            <BetSelections
                                key={index}
                                bet={item}
                                game={props.game}
                                displayId={!props.showHDA}
                                isCurrentSelectedLine={item.current}
                                handleOnClick={props.handleCircleNumberClick}
                                hideBonusIfEmpty
                                showCountHeader={props.showCountHeader}
                                selectionsFontStyle={props.selectionsFontStyle}
                                selectionsMargin={props.selectionsMargin}
                            />
                        </Container>
                        <AddedLineBottomRow>
                            <AddedLineBottomRowButton onClick={(): void => editLineClick(index)}>
                                Edit
                            </AddedLineBottomRowButton>
                            <AddedLineBottomRowButton
                                onClick={() => {
                                    removeLineClick(index);
                                }}
                            >
                                Remove
                            </AddedLineBottomRowButton>
                            <CostLabel>{`Cost: ${item.price === 0 ? 'Free' : `£${getLinePrice(item)}`} `}</CostLabel>
                        </AddedLineBottomRow>
                    </AddedLinesItem>
                ))}
            </AddedLinesContent>

            <StickyFooter>
                {props.showLinesCount && <p>Total Lines: {props.addedLines.length}</p>}
                {props.showCost && <p>Total Cost: £{totalPrice}</p>}
                <ButtonsContainer>
                    {props.showBackButton && (
                        <Button
                            height="40px"
                            bgColor="#e02b20"
                            textColor="#fff"
                            width="70%"
                            onClick={(): void => {
                                dispatch(closePopup('added_lines'));
                            }}
                            rounded="25px"
                        >
                            BACK
                        </Button>
                    )}
                    {props.showPlayButton && (
                        <Button
                            height="40px"
                            bgColor={props.playNowColour ? props.playNowColour : '#68d338'}
                            textColor="#fff"
                            width="70%"
                            disabled={
                                !isPlayEnabled(
                                    props.betslipselection,
                                    props.offers,
                                    props.minimumCost,
                                    totalPricenumber,
                                )
                            }
                            onClick={(): void => {
                                props.pressPlay();
                                dispatch(closePopup('added_lines'));
                            }}
                            rounded="25px"
                        >
                            PLAY NOW
                        </Button>
                    )}
                </ButtonsContainer>
            </StickyFooter>
        </React.Fragment>
    );
};

interface LineCountSectionProps {
    count?: number;
}
const LineCountSection = ({ count }: LineCountSectionProps) => {
    return <AddedLineHeaderItem>{`${count} ${count && count > 1 ? 'Lines' : 'Line'}`}</AddedLineHeaderItem>;
};

const AddedLinesContent = styled.div`
    color: white;
    padding: 10px 0 10px 0;
    text-align: center;
    font-size: 16px;
    line-height: 24px;
    outline: 0;
    margin-top: 30px;
    width: 100%;
    overflow-y: scroll;
    max-height: 75vh;

    p {
        font-weight: bold;
    }
`;

const AddedLineBottomRow = styled.div`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    border-bottom: ${props => `1px solid ${props.theme.colours.primaryFont}`};
`;

const AddedLineHeader = styled.div`
    background: ${props => props.theme.colours.gameMainColour};
    color: #fff;
    margin: 5px 0 0 0;
    padding: 0 5px;
    width: 100%;
    font-weight: bold;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
`;
const AddedLineHeaderItem = styled.h4`
    margin: 0;
`;

const CostLabel = styled.div`
    color: ${props => props.theme.colours.primaryFont};
`;
const AddedLineBottomRowButton = styled.div`
    color: ${props => props.theme.colours.primaryFont};
    cursor: pointer;
    flex: 1;
`;

type ContainerProps = {
    isClover: boolean;
};

const Container = styled.div<ContainerProps>`
    display: flex;
    flex: 1;

    flex-direction: ${props => (props.isClover ? 'row' : 'column')};

    p {
        margin-left: 5px;
        margin-right: 5px;
    }
`;

interface AddedLineItemProps {
    index: number;
    bet: BetSlip;
    game: GameType;
    isHda?: boolean;
    showPerLineCount?: boolean;
    totalLinesForBet?: number;
    totalCostForBet?: string;
    showCountHeader?: boolean;
    selectionsFontStyle?: 'normal' | 'italic';
    selectionsMargin?: string;
    onClickEditLine?: (index: number) => void;
    onClickRemoveLine?: (index: number) => void;
    handleCircleNumberClick?: (id: number, type: string) => void;
}
export const AddedLineItem = ({
    index,
    bet,
    game,
    isHda,
    showPerLineCount,
    totalLinesForBet,
    totalCostForBet,
    showCountHeader,
    selectionsFontStyle,
    selectionsMargin,
    onClickEditLine,
    onClickRemoveLine,
    handleCircleNumberClick,
}: AddedLineItemProps) => {
    return (
        <AddedLinesItem key={index}>
            <AddedLineHeader>
                <AddedLineHeaderItem>{RemoveGameName(bet.competitionName)}</AddedLineHeaderItem>
                {showPerLineCount && <LineCountSection count={totalLinesForBet} />}
            </AddedLineHeader>
            <Container isClover={game === 'lucky-clover'}>
                <BetSelections
                    key={index}
                    bet={bet}
                    game={game}
                    displayId={!isHda}
                    isCurrentSelectedLine={bet.current}
                    handleOnClick={handleCircleNumberClick}
                    hideBonusIfEmpty
                    showCountHeader={showCountHeader}
                    selectionsFontStyle={selectionsFontStyle}
                    selectionsMargin={selectionsMargin}
                />
            </Container>
            <AddedLineBottomRow>
                <AddedLineBottomRowButton
                    onClick={(): void => {
                        if (onClickEditLine) {
                            onClickEditLine(index);
                        }
                    }}
                >
                    Edit
                </AddedLineBottomRowButton>
                <AddedLineBottomRowButton
                    onClick={() => {
                        if (onClickRemoveLine) {
                            onClickRemoveLine(index);
                        }
                    }}
                >
                    Remove
                </AddedLineBottomRowButton>
                <CostLabel>{`Cost: ${totalCostForBet}`}</CostLabel>
            </AddedLineBottomRow>
        </AddedLinesItem>
    );
};

const AddedLinesItem = styled.li`
    width: 100%;
    padding: 0;
    color: #fff;
    margin: 5px 0 5px 0;
    text-align: left;

    a {
        font-size: 15px;
        font-weight: bold;
        line-height: 20px;
    }

    ul {
        padding: 0;
        margin: 10px 0;
        flex: unset;
        width: unset;
    }

    p {
        color: #000;
    }
`;

const ButtonsContainer = styled.div`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    width: 100%;
`;

const StickyFooter = styled.div`
    position: fixed;
    bottom: 0px;
    background: #fff;
    max-width: inherit;
    width: 100%;
    padding: 0.4em 0;
    text-align: center;
    left: 50%;
    transform: translate(-50%, 0%);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: end;

    button {
        font-size: 15px;
        font-weight: bold;
        line-height: 20px;
        margin: 10px 5px;
    }
    p {
        margin: 0;
        font-size: 15px;
        font-weight: bold;
        color: ${props => props.theme.colours.gameMainColour};
    }
`;
