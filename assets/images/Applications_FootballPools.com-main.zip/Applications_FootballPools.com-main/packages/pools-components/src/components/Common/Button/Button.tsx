import React from 'react';
import { breakpoints } from '../../../settings/breakpoints';
import styled from 'styled-components';

export interface ButtonProps {
    rounded?: string;
    bgColor?: string;
    hoverColor?: string;
    hoverTextColor?: string;
    hoverOpacity?: string;
    hoverBorder?: string;
    textColor?: string;
    fontWeight?: string;
    width?: string;
    margin?: string;
    height?: string;
    padding?: string;
    noHover?: boolean;
    cursor?: string;
    disabledBackgroundColour?: string;
    fontSize?: string;
    disabledOpacity?: string;
    border?: string;
}

export const Button = (props: any): JSX.Element => <StyledButton {...props} />;

const StyledButton = styled.button<ButtonProps>`
    background: ${(props): string => (props.bgColor ? props.bgColor : '#363636')};
    color: ${(props): string =>
        props.textColor ? props.textColor : props.theme.colours.primaryFont ? props.theme.colours.primaryFont : '#fff'};
    padding: ${(props): string => (props.padding ? props.padding : '0.5em 1.25em;')};
    font-size: ${props => (props.fontSize ? props.fontSize : 'inherit')};
    font-weight: ${(props): string => (props.fontWeight ? props.fontWeight : 'inherit')};
    border: ${props => (props.border ? props.border : 'none')};
    border-radius: ${(props): string => (props.rounded ? props.rounded : '8px')};
    cursor: ${(props): string => (props.cursor ? props.cursor : 'pointer')};
    width: ${(props): string => (props.width ? props.width : '')};
    font-family: ${props =>
        props.theme.fonts?.primaryFontFamily ? props.theme.fonts.primaryFontFamily : '"Barlow Condensed", sans-serif'};
    ${breakpoints.above('lg')} {
        ${props =>
            props.noHover !== true &&
            ` &:hover {
        background:  ${props.hoverColor ? props.hoverColor : '#cccccc'};
        opacity: ${props.hoverOpacity ? props.hoverOpacity : '0.9'};
        color: ${props.hoverTextColor ? props.hoverTextColor : ''};
        border: ${props.hoverBorder ? props.hoverBorder : 'none'};
    }`}
    }

    &:disabled {
        background: ${(props): string => (props.disabledBackgroundColour ? props.disabledBackgroundColour : '#d3d3d3')};
        opacity: ${props => props.disabledOpacity};
    }

    height: ${(props): string => (props.height ? props.height : '70px')};
    display: inline-block;
    flex-grow: 1;
    margin: ${(props): string => (props.margin ? props.margin : '')};
    &:focus {
        outline: none;
        box-shadow: none;
    }
`;

export default Button;
