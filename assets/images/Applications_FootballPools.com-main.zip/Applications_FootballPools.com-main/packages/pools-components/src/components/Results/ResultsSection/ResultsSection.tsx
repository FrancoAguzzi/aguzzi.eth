import React, { useState } from 'react';
import styled from 'styled-components';
import { FixtureResult, GameType, NumbersSelected, Offering } from '@sportech/pools-api';
import { MatchCard } from '../../GameSection/MatchCard/MatchCard';
import { ArrowButton } from '../../Common/ArrowButton/ArrowButton';
import { HdaMatchCard } from '../../GameSection/HdaMatchCard/HdaMatchCard';
import { breakpoints } from '../../../settings/breakpoints';

export interface ResultSectionProps {
    action?: () => void;
    fixtures: Array<FixtureResult>;
    IsHda?: boolean;
    matchCardWidth?: string;
    Accordion?: boolean;
    LineNumber?: number;
    offerings?: Offering;
    GameType?: GameType;
    Wager?: NumbersSelected[];
    points?: number;
}

export const ResultSection = (props: ResultSectionProps): JSX.Element => {
    const [isWagerItemExpanded, setExpandWagerItem] = useState(false);
    const classicPoolsPlansToShowPointsFor = [5, 10, 12];
    return props.Accordion ? (
        <StyledWagerItem
            onClick={(): void => {
                setExpandWagerItem(!isWagerItemExpanded);
            }}
        >
            <p>
                Line {props.LineNumber} : {props.offerings?.description}
                {((props.GameType === 'classic-pools' &&
                    classicPoolsPlansToShowPointsFor.includes(props.offerings?.id as number)) ||
                    props.GameType !== 'classic-pools') &&
                    `: ${props.points} Points`}
            </p>
            <StyledArrowButton
                isWagerExpanded={isWagerItemExpanded}
                isFacingLeft={false}
                color="#c1c1c1"
                backgroundColor="#F5F5F5"
            />
            {isWagerItemExpanded && (
                <GameList>
                    {props.fixtures.map(item =>
                        props.IsHda === true ? (
                            <HdaMatchCard
                                key={item.id}
                                // gameType={props.GameType}
                                action={props.action}
                                matchId={item.id}
                                number={item.number}
                                isHda
                                homeTeam={item.homeTeamDisplay}
                                awayTeam={item.awayTeamDisplay}
                                isResults
                                numbers={props.Wager?.find(x => x.Id === item.number)}
                                score={item.scores}
                                points={item.points}
                                matchCardWidth={props.matchCardWidth}
                                canEdit={false}
                            />
                        ) : (
                            <MatchCard
                                key={item.id}
                                gameType={props.GameType}
                                action={props.action}
                                matchId={item.id}
                                number={item.number}
                                isHda={false}
                                homeTeam={item.homeTeamDisplay}
                                awayTeam={item.awayTeamDisplay}
                                isResults
                                score={item.scores}
                                points={item.points}
                                matchCardWidth={props.matchCardWidth}
                                canEdit={false}
                            />
                        ),
                    )}
                    <EmptyMatchCard matchCardWidth={props.matchCardWidth} aria-hidden="true" />
                    <EmptyMatchCard matchCardWidth={props.matchCardWidth} aria-hidden="true" />
                </GameList>
            )}
        </StyledWagerItem>
    ) : (
        <GameList>
            {props.fixtures.map(item =>
                props.IsHda === true ? (
                    <HdaMatchCard
                        key={item.id}
                        action={props.action}
                        matchId={item.id}
                        number={item.number}
                        isHda
                        homeTeam={item.homeTeamDisplay}
                        awayTeam={item.awayTeamDisplay}
                        isResults
                        numbers={props.Wager?.find(x => x.Id === item.number)}
                        score={item.scores}
                        points={item.points}
                        matchCardWidth={props.matchCardWidth}
                        canEdit={false}
                    />
                ) : (
                    <MatchCard
                        key={item.id}
                        action={props.action}
                        matchId={item.id}
                        gameType={props.GameType}
                        number={item.number}
                        isHda={false}
                        homeTeam={item.homeTeamDisplay}
                        awayTeam={item.awayTeamDisplay}
                        isResults
                        score={item.scores}
                        points={item.points}
                        matchCardWidth={props.matchCardWidth}
                        canEdit={false}
                    />
                ),
            )}
            <EmptyMatchCard matchCardWidth={props.matchCardWidth} aria-hidden="true" />
            <EmptyMatchCard matchCardWidth={props.matchCardWidth} aria-hidden="true" />
        </GameList>
    );
};

const GameList = styled.ul`
    list-style: none;
    padding: 0px 5px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    width: 100%;

    ${breakpoints.below('lg')} {
        padding: 0;
    }
`;

const StyledWagerItem = styled.li`
    display: flex;
    flex-flow: wrap;
    justify-content: space-between;
    border-top: 1px solid #333;
    p {
        flex: 1 1 25%;
        padding-left: 10px;
    }
`;

type StyledArrowProps = {
    isWagerExpanded: boolean;
};

const StyledArrowButton = styled(ArrowButton)<StyledArrowProps>`
    ${props =>
        props.isWagerExpanded &&
        ` transform: rotate(90deg);
    margin-top: 10px;
    `}
    transition: transform 0.15s linear;
`;

type EmptyMatchCardProps = {
    matchCardWidth: string | undefined;
};

const EmptyMatchCard = styled.i<EmptyMatchCardProps>`
    width: ${(props): string => (props.matchCardWidth ? props.matchCardWidth : '31%')};
    margin: 0.5%;
    float: left;
    font-size: 13px;
    ${breakpoints.below('lg')} {
        width: 48%;
        font-size: 12px;
    }
`;
