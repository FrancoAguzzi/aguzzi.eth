import React from 'react';
import styled from 'styled-components';
import { useForm } from 'react-hook-form';
import { ConfirmWagers, GameType } from '@sportech/pools-api';

export interface DirectDebitFormProps {
    accountNumber: string;
    sortCode: string;
}

export interface DirectDebitFormInputProps {
    game: GameType;
    onSubmitForm: (details: ConfirmWagers, game: GameType) => void;
}

// interface DirectDebitFormInputStyleProps {}

const Container = styled.div`
    flex: 1;
`;
const FormContainer = styled.form`
    flex: 1;
    flex-direction: column;
`;

const Row1 = styled.div`
    margin-bottom: 5px;
`;

const Row2 = styled.div`
    margin-bottom: 5px;
`;
const Row3 = styled.div``;

export const DirectDebitForm = ({ game, onSubmitForm }: DirectDebitFormInputProps): JSX.Element => {
    const { register, handleSubmit, errors } = useForm<DirectDebitFormProps>();

    const onSubmit = handleSubmit(data => {
        // console.log(data);
        const confirmData: ConfirmWagers = {
            directDebitDetails: {
                accountNumber: data.accountNumber,
                sortCode: data.sortCode,
            },
        };
        onSubmitForm(confirmData, game);
    });

    return (
        <Container>
            <FormContainer onSubmit={onSubmit}>
                <Row1>
                    <label>SORT CODE</label>
                    <input
                        name="sortCode"
                        data-wc-ignore="true"
                        ref={register({
                            required: {
                                value: true,
                                message: 'This is required',
                            },
                            pattern: { value: /[0-9]{6}/, message: '' },
                        })}
                    />
                    {errors.sortCode && 'Must be 6 numbers'}
                </Row1>
                <Row2>
                    <label>BANK ACCOUNT NUMBER</label>
                    <input
                        name="accountNumber"
                        data-wc-ignore="true"
                        ref={register({
                            required: {
                                value: true,
                                message: 'This is required',
                            },
                            pattern: { value: /[0-9]{8}/, message: '' },
                        })}
                    />
                    {errors.accountNumber && 'Must be 8 numbers'}
                </Row2>

                <Row3>
                    <input type="submit" />
                </Row3>
            </FormContainer>
        </Container>
    );
};
