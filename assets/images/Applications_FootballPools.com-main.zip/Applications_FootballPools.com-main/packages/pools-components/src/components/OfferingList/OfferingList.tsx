import React, { useContext, useState } from 'react';
import MediaQuery from 'react-responsive';
import styled, { ThemeContext } from 'styled-components';
import { Offerings, BetSlip, Offering } from '@sportech/pools-api';
import { OfferingDropDown } from '../OfferingDropDown/OfferingDropDown';
import { Button } from '../Common/Button/Button';
import { ChevronFigures } from '../Figures/ChevronFigures';

export interface OfferingListProps {
    showMoreValue: boolean;
    setShowMore: (val: boolean) => void;
    offerings: Offerings;
    currentOfferingId: number;
    setCurrentOfferingId: (val: number) => void;
    selectAmount: (id: number, amount: Offering) => void;
    currentSlip: BetSlip;
    isHda: boolean;
    isClover?: boolean;
}

export const OfferingList = (props: OfferingListProps): JSX.Element => {
    const [offeringDropDownOpen, setOfferingDropdownOpen] = useState(false);
    const themeContext = useContext(ThemeContext);

    const slicedOfferings = props.isClover
        ? props.offerings.offerings
              .slice(0, 4)
              .sort((offering, offering2) => offering2.maximumSelections - offering.maximumSelections)
        : props.offerings.offerings.slice(0, 3);
    const offeringButtonWidth = props.isClover ? '25%' : props.offerings.offerings.length === 1 ? '100%' : '30%';
    return (
        <StyledListDivoffering isClover={props.isClover as boolean}>
            <StyledListUloffering>
                <StyledListlioffering>
                    {!props.showMoreValue ? (
                        <React.Fragment>
                            {slicedOfferings.map((item, index) => (
                                <StyledOfferingButton
                                    isActiveLine={props.currentOfferingId === item.id}
                                    onClick={(): void => {
                                        props.selectAmount(props.currentSlip?.competitionId as number, item);
                                        props.setCurrentOfferingId(item.id);
                                    }}
                                    bgColor={
                                        props.currentOfferingId === item.id
                                            ? themeContext.colours.gameMainColour
                                            : '#EAEAEA'
                                    }
                                    height="40px"
                                    padding="5px"
                                    width={offeringButtonWidth}
                                    rounded="0"
                                    key={index}
                                    textColor={props.currentOfferingId === item.id ? '#fff' : '#000'}
                                    hoverColor={props.currentOfferingId === item.id ? '00108B' : '#5c5c5c'}
                                    hoverOpacity={props.currentOfferingId === item.id ? '1' : '0.8'}
                                >
                                    <MediaQuery maxWidth={1024}>
                                        <p>
                                            Pick {item.maximumSelections} £{(item.pricePerEntry / 100).toFixed(2)}
                                        </p>
                                    </MediaQuery>
                                    <MediaQuery minWidth={1025}>
                                        <p>
                                            Pick {item.maximumSelections}
                                            {props.isHda && ` £${(item.pricePerEntry / 100).toFixed(2)}`}
                                        </p>
                                    </MediaQuery>
                                </StyledOfferingButton>
                            ))}
                        </React.Fragment>
                    ) : (
                        <React.Fragment>
                            <StyledOfferingButton
                                isActiveLine={false}
                                onClick={(): void => {
                                    props.setShowMore(false);
                                    props.selectAmount(
                                        props.currentSlip?.competitionId as number,
                                        props.offerings.defaultOffering,
                                    );
                                    props.setCurrentOfferingId(props.offerings.defaultOffering.id);
                                }}
                                bgColor="#EAEAEA"
                                height="40px"
                                padding="5px"
                                width="10%"
                                rounded="0"
                                textColor="#000"
                                hoverColor="#5c5c5c"
                                hoverOpacity="0.8"
                            >
                                <ChevronFigures height="50%" rotation="90" />
                            </StyledOfferingButton>
                            <StyledOfferingButton
                                isActiveLine={props.currentOfferingId === (props.currentSlip?.priceID as number)}
                                onClick={(): void => {
                                    props.selectAmount(
                                        props.currentSlip?.competitionId as number,
                                        props.offerings.offerings.find(
                                            x => x.id === (props.currentSlip?.priceID as number),
                                        ) as Offering,
                                    );
                                    props.setCurrentOfferingId(props.currentSlip?.priceID);
                                }}
                                bgColor={
                                    props.currentOfferingId === props.currentSlip?.priceID
                                        ? themeContext.colours.gameMainColour
                                        : '#EAEAEA'
                                }
                                height="40px"
                                padding="5px"
                                width="80%"
                                rounded="0"
                                textColor={props.currentOfferingId === props.currentSlip?.priceID ? '#fff' : '#000'}
                                hoverColor={
                                    props.currentOfferingId === props.currentSlip?.priceID ? '00108B' : '#5c5c5c'
                                }
                                hoverOpacity={props.currentOfferingId === props.currentSlip?.priceID ? '1' : '0.8'}
                            >
                                <MediaQuery maxWidth={1024}>
                                    <p>
                                        {
                                            props.offerings.offerings.find(x => x.id === props.currentSlip?.priceID)
                                                ?.description
                                        }{' '}
                                        £
                                        {(
                                            (props.offerings.offerings.find(x => x.id === props.currentSlip?.priceID)
                                                ?.pricePerEntry as number) / 100
                                        ).toFixed(2)}
                                    </p>
                                </MediaQuery>
                                <MediaQuery minWidth={1025}>
                                    <p>
                                        {
                                            props.offerings.offerings.find(x => x.id === props.currentSlip?.priceID)
                                                ?.description
                                        }{' '}
                                        £
                                        {(
                                            (props.offerings.offerings.find(x => x.id === props.currentSlip?.priceID)
                                                ?.pricePerEntry as number) / 100
                                        ).toFixed(2)}
                                    </p>
                                </MediaQuery>
                            </StyledOfferingButton>
                        </React.Fragment>
                    )}
                    {props.offerings.offerings.length > 3 && !props.isClover ? (
                        <React.Fragment>
                            <StyledOfferingButton
                                onClick={(): void => {
                                    setOfferingDropdownOpen(offeringDropDownOpen => !offeringDropDownOpen);
                                    props.setCurrentOfferingId(-1);
                                }}
                                height="40px"
                                padding="0px"
                                width="10%"
                                rounded="0"
                                textColor={props.currentOfferingId === -1 ? '#fff' : '#000'}
                                bgColor={
                                    props.currentOfferingId === -1 ? themeContext.colours.gameMainColour : '#EAEAEA'
                                }
                                isActiveLine={props.currentOfferingId === -1}
                                hoverColor={props.currentOfferingId === -1 ? '00108B' : '#5c5c5c'}
                                hoverOpacity={props.currentOfferingId === -1 ? '1' : '0.8'}
                            >
                                {props.currentOfferingId === -1 ? (
                                    <img src="/white-plus.svg" alt="white plus icon" />
                                ) : (
                                    <img src="/plus.svg" alt="plus icon" />
                                )}
                            </StyledOfferingButton>
                            {offeringDropDownOpen && (
                                <React.Fragment>
                                    <OfferingDropDown
                                        offers={props.offerings}
                                        betslipCurrentSelection={props.currentSlip as BetSlip}
                                        selectAmountAction={props.selectAmount}
                                        setCurrentOffering={props.setCurrentOfferingId}
                                        setOfferingDropdownOpen={setOfferingDropdownOpen}
                                        setShowMore={props.setShowMore}
                                    />
                                    <OfferingDropdownOverlay
                                        onClick={(): void => {
                                            setOfferingDropdownOpen(false);
                                            props.setCurrentOfferingId(props.currentSlip?.priceID);
                                        }}
                                    />
                                </React.Fragment>
                            )}
                        </React.Fragment>
                    ) : (
                        <React.Fragment />
                    )}
                </StyledListlioffering>
            </StyledListUloffering>
        </StyledListDivoffering>
    );
};

const OfferingDropdownOverlay = styled.div`
    position: absolute;
    width: 100vw;
    height: 100vh;
    top: 0;
    left: 0;

    z-index: 10;
`;

type StyledListDivofferingProps = {
    isClover: boolean;
};

const StyledListDivoffering = styled.div<StyledListDivofferingProps>`
    display: flex;
    flex-direction: row;
    padding: 0 0 10px 0;

    margin-top: ${props => (props.isClover ? '5px' : '0px')};
`;
type StyledOfferingButtonProps = {
    isActiveLine?: boolean;
};
const StyledOfferingButton = styled(Button)<StyledOfferingButtonProps>`
    position: relative;
    img {
        width: 15px;
        position: absolute;
        top: 50%;
        left: 52%;
        transform: translate(-50%, -50%);
    }
    ${props =>
        props.isActiveLine &&
        ` position: relative;
    &:last-of-type:after {
        left: 4%;
    }
    :after {
        content: '';
        position: absolute;
        left: 0;
        right: 0;
        margin: 0 auto;
        width: 0;
        height: 0;
        top: 40px;
        border-top: 10px solid ${props.theme.colours.gameMainColour};
        border-left: 10px solid transparent;
        border-right: 10px solid transparent;
    }
    `}
`;

const StyledListUloffering = styled.ul`
    display: flex;
    list-style-type: none;
    padding: 0;
    margin: 0;
    width: 100%;
`;

const StyledListlioffering = styled.li`
    // float: left;
    font-size: 0.9em;
    line-height: 1em;
    cursor: default;
    width: 100%;
    background: #f5f5f5;
    display: flex;
    flex-wrap: wrap;
    p {
        margin: 0;
    }

    a {
        position: relative;
        display: block;
        background: #0117ae;
        border: 2px solid transparent;
        border-radius: 4px;
        color: #fff;
        font-weight: 500;
        text-align: center;
        padding: 0.35em 0;
        overflow: hidden;
        text-decoration: none;
    }

    &.active a {
        background: $solidCyan;
        color: $solidBlack;
        border-color: $solidCyan;
    }
    &:hover > a {
        color: #000000;
        background: #fff;
        text-decoration: none;
        cursor: pointer;
    }
`;
