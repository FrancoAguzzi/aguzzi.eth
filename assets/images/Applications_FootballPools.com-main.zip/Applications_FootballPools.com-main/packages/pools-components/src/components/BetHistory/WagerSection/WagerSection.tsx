import React from 'react';
import styled from 'styled-components';
import {
    Offering,
    CompetitionResults,
    CompetitionDividends,
    GameType,
    CompetitionWagers,
    Wager,
} from '@sportech/pools-api';
import { WagerItem } from '../Wager/WagerItem';
import { groupBy } from '../../../utils/functionUtils';

interface WagerSectionProps {
    wagers: CompetitionWagers[];
    offerings: Offering[];
    competitions: CompetitionResults;
    dividends: CompetitionDividends;
    isAllBets: boolean;
    fromDate: Date;
    toDate: Date;
    GameName: GameType;
}

export const WagerSection = (props: WagerSectionProps): JSX.Element => {
    const openComps = props.competitions
        .filter(x => x.state !== 'completed')
        .map(comp => {
            return comp.id;
        });
    const openBets = props.wagers?.filter(x => openComps.includes(x.competitionId));

    const wagerComps = props.isAllBets ? props.wagers : openBets;

    const wagersArray: Wager[] = [];

    if (wagerComps) {
        wagerComps.map(competition =>
            competition.wagers.map(wager => {
                wager.competitionId = competition.competitionId;
                wagersArray.push(wager);
            }),
        );
    }

    wagersArray.sort((a, b) => (b.wagerId as number) - (a.wagerId as number));
    const noBetsText = props.isAllBets ? 'No bets within selected date range' : 'No open bets';
    let numberOfWagers = 0;
    const WagersGroupByCreatedAt = groupBy(wagersArray, wagers => wagers.createdAt);
    return (
        <WagerList>
            <WagerListHeader>
                <p>Date</p>
                <p>Stake</p>
                <p>Result</p>
            </WagerListHeader>
            <React.Fragment>
                {props.isAllBets
                    ? Array.from((WagersGroupByCreatedAt.values() as unknown) as Wager[][]).map((wager, index) => {
                          const filteredWagers = ((wager as unknown) as Wager[])?.filter(
                              x =>
                                  new Date(x.createdAt as string) >= props.fromDate &&
                                  new Date(x.createdAt as string) <= props.toDate,
                          );

                          numberOfWagers += filteredWagers.length;
                          return (
                              <WagerItem
                                  GameName={props.GameName}
                                  wager={filteredWagers}
                                  key={index}
                                  offering={props.offerings}
                                  comp={props.competitions}
                                  dividends={props.dividends}
                              />
                          );
                      })
                    : Array.from((WagersGroupByCreatedAt.values() as unknown) as Wager[][]).map((wager, index) => {
                          const wagers = (wager as unknown) as Wager[];
                          numberOfWagers += wagers.length;
                          return (
                              <WagerItem
                                  GameName={props.GameName}
                                  wager={wagers}
                                  key={index}
                                  offering={props.offerings}
                                  comp={props.competitions}
                                  dividends={props.dividends}
                              />
                          );
                      })}
            </React.Fragment>
            {numberOfWagers === 0 && <NoBetText>{noBetsText}</NoBetText>}
        </WagerList>
    );
};

const WagerList = styled.ul`
    list-style: none;
    padding: 0;
    margin-top: 0;
`;

const WagerListHeader = styled.ul`
    list-style: none;
    display: flex;
    padding: 0 0 0 30px;
    background: #363637;
    color: #fff;

    p {
        flex: 1 1 33%;
    }
`;

const NoBetText = styled.p`
    text-align: center;
    background: lightgrey;
    margin: 0;
    padding: 30px 0;
`;
