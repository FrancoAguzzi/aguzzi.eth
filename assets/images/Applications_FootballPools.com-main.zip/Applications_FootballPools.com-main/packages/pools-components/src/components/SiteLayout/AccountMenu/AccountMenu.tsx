import React from 'react';
import styled from 'styled-components';
import { breakpoints } from '../../../settings/breakpoints';

interface SideMenuProps {
    open?: boolean;
    user?: null;
    userBalance?: number;
    links?: Link[];
    isMobileOrTablet: boolean;
    distanceBetweenHeaderAndTopOfWindow: number;
    mailCount: number;
    name?: string;
    account: () => void;
}

interface Link {
    href: string;
    label: string;
    target?: string;
}

const AccountMenu = (props: SideMenuProps): JSX.Element => {
    return (
        <SideMenuStyle {...props}>
            <SideMenuHeader>
                {props.name && <div>{props.name}</div>}
                <div>
                    Balance:
                    <div>
                        £{props.userBalance != null && <React.Fragment>{props.userBalance.toFixed(2)}</React.Fragment>}
                    </div>
                </div>
            </SideMenuHeader>
            <Content>
                {props.links &&
                    props.links.map((link, index) => (
                        <a key={`Links_${index}`} href={link.href} target={link.target}>
                            {link.label}
                        </a>
                    ))}
            </Content>
            {props.open && props.isMobileOrTablet && (
                <SideMenuStyleOverlay
                    onTouchMoveCapture={() => {
                        if (props.account) {
                            props.account();
                        }
                    }}
                    onClick={() => {
                        if (props.account) {
                            props.account();
                        }
                    }}
                />
            )}
        </SideMenuStyle>
    );
};

export default AccountMenu;

const SideMenuStyle = styled.div<SideMenuProps>`
    padding-left: env(safe-area-inset-left);
    height: 100%;
    width: 100%;
    max-width: 260px;
    position: fixed;
    z-index: 1000;
    top: 0;
    right: 0;
    margin-top: ${(props): string => props.distanceBetweenHeaderAndTopOfWindow + 50 + 'px'};
    padding-bottom: 50px;
    transform: ${(props): string => (props.open ? 'translateX(0)' : 'translateX(+100%)')};
    transition: 0.5s;
    font-size: 0.75em;
    background: #363636;
    overflow-x: hidden;
    white-space: nowrap;
    text-overflow: clip;
    display: none;
    ${breakpoints.below('lg')} {
        display: block;
    }
`;

const SideMenuStyleOverlay = styled.div`
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;

    z-index: 10;
    background: rgba(0, 0, 0, 0.5);
`;

const SideMenuHeader = styled.div`
    background: #363636;
    padding: 0 14px;

    > :first-child {
        color: #38d8ff;
        height: 50px;
        font-size: 16px;
        line-height: 50px;
        font-weight: 700;
    }
    > :last-child {
        color: #fff;
        margin-top: 7px;
        font-size: 12px;
        font-weight: 400;

        > :first-child {
            font-weight: 700;
            color: #38d8ff;
            font-size: 16px;
            margin-top: 1px;
            padding: 0;
        }
    }
`;

const Content = styled.div`
    padding: 7px 7px 42px;
    background: #363636;
    color: #fff;

    > a {
        border-bottom: 0.7px solid #fff;
        border-bottom: 1px solid #fff;
        display: block;
        text-decoration: none;
        color: #fff;
        border-bottom: 1px solid #3d3d3d;
        padding: 7px;
        font-size: 14px;
    }
    > a:last-child {
        width: 96%;
        height: 40px;
        display: block;
        color: #949494;
        background: #000000;
        border-radius: 3px;
        font-size: 14px;
        text-transform: uppercase;
        text-decoration: none;
        text-align: center;
        line-height: 40px;
        margin-top: 14px;
    }
`;
