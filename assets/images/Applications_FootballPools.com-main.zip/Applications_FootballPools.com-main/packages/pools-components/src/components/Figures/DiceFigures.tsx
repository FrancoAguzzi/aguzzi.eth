import React from 'react';
import styled from 'styled-components';

export interface DiceFiguresProps {
    flip?: boolean;
    colour?: string;
    backgroundColour?: string;
}

export const DiceFigures = (props: DiceFiguresProps): JSX.Element => {
    return (
        <DiceStyle {...props}>
            <DotsStyle colour={props.colour} />
        </DiceStyle>
    );
};

const DiceStyle = styled.figure<DiceFiguresProps>`
    background-color: ${props => props.backgroundColour};
    position: relative;
    display: inline-block;
    border: ${props => `1px solid ${props.colour ? props.colour : '#000'}`};
    border-radius: 3px;
    width: 1em;
    height: 1em;
    vertical-align: middle;
    box-sizing: content-box;
    font-size: 1.6em;
    transform-origin: 50% 50%;
    transform: ${(props): string => (props.flip ? 'rotate(-45deg)' : 'rotate(45deg)')};
    border-color: ${props => (props.colour ? props.colour : '#000')};
    margin-top: 0px;
    margin-bottom: 4px;
    &.anti-clockwise {
        transform: rotate(-45deg);
    }
    margin-right: 4px;
    margin-left: 1px;

    &:last-child {
        margin-top: 15px;
        @media (max-width: $gridMD) {
            margin-top: 12px;
        }
    }

    &:before,
    &:after {
        background: ${props => (props.colour ? props.colour : '#000')};
        content: '';
        position: absolute;
        margin-left: -0.1em;
        margin-top: -0.1em;
        width: 0.2em;
        height: 0.2em;
        border-radius: 50%;
    }

    &:before {
        left: 0.2em;
        top: 0.2em;
    }

    &:after {
        left: 0.2em;
        bottom: 0.1em;
    }
`;

const DotsStyle = styled.figure<{ colour?: string }>`
    left: 0.5em;
    top: 0.5em;
    background: ${props => (props.colour ? props.colour : '#000')};
    content: '';
    position: absolute;
    margin-left: -0.1em;
    margin-top: -0.1em;
    width: 0.2em;
    height: 0.2em;
    border-radius: 50%;
    &:before,
    &:after {
        background: ${props => (props.colour ? props.colour : '#000')};
        content: '';
        position: absolute;
        margin-left: -0.1em;
        margin-top: -0.1em;
        width: 0.2em;
        height: 0.2em;
        border-radius: 50%;
    }

    &:before {
        left: 0.4em;
        top: -0.2em;
    }

    &:after {
        left: 0.4em;
        bottom: -0.3em;
    }
`;
