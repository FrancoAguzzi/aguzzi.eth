import React, { FunctionComponent } from 'react';
import { useDispatch } from 'react-redux';
import { PopupText, StyledATag } from '../../Styles/defaultPageStyles';
import { AppDispatch } from '../../../state/rootReducer';
import { closePopup } from '../../../state/popupsSlice';

export const GoalRushHowToPlayPopup: FunctionComponent = () => {
    const dispatch: AppDispatch = useDispatch<AppDispatch>();
    return (
        <PopupText>
            <p>
                <strong>
                    <span>Win up to £1 Million with Both Teams to Score!</span>
                </strong>
                Simply select 8 fixtures from the list of 35 you think both teams will score in, and if your selections
                are the first 8 matches on the coupon where both teams score, you&#39;ll win all or a share of our £1
                Million Top Prize! Not only that, but if both teams score at any time in all 8 of your selected matches,
                you&#39;ll win a cash prize! Only got 7 right? Don&#39;t worry, you&#39;ll still win a consolation
                prize. For full info on our £1 Million Top Prize can be found{' '}
                <StyledATag target="_self" href="/content/win-1-million-on-goal-rush">
                    here
                </StyledATag>
                .
            </p>
            <StyledATag
                onClick={() => dispatch(closePopup('how_to_play_GoalRush8'))}
                target="_self"
                href="/content/goal-rush-game-rules"
            >
                View Game Terms & Conditions
            </StyledATag>
        </PopupText>
    );
};
