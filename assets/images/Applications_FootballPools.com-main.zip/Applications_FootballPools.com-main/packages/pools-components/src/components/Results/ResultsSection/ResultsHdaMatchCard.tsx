import React from 'react';
import styled from 'styled-components';
import { breakpoints } from '../../../settings/breakpoints';
import { HdaButton } from '../../GameSection/HdaButton/HdaButton';
import { MatchCardProps } from '../../GameSection/MatchCard/MatchCard';

enum WinTypeEnum {
    HomeWIN,
    AwayWIN,
    Draw,
    NotSet,
}
export interface NumberStyleProps {
    color?: string;
    textColor?: string;
    numbers?: number;
    points?: number;
}

export const ResultsHdaMatchCard = (props: MatchCardProps): JSX.Element => {
    let Score: WinTypeEnum = WinTypeEnum.NotSet;
    if (props.score?.fullTime != null) {
        if (props.score.fullTime.home > props.score.fullTime.away) {
            Score = WinTypeEnum.HomeWIN;
        } else if (props.score.fullTime.home > props.score.fullTime.away) {
            Score = WinTypeEnum.AwayWIN;
        } else {
            Score = WinTypeEnum.Draw;
        }
    }
    return (
        <React.Fragment>
            <MatchCardDivs>
                <NumberDiv>{props.number}</NumberDiv>
                <TeamsDiv>
                    <Rowone>
                        <HomeDiv>{props.homeTeam}</HomeDiv>
                        <VsDiv textColor="black">
                            {props.score?.fullTime != null
                                ? `${props.score.fullTime.home} - ${props.score.fullTime.away}`
                                : props.score?.isVoid
                                ? 'VOID'
                                : props.score?.poolsPanel
                                ? 'P - P'
                                : 'vs'}
                        </VsDiv>
                        <AwayDiv>{props.awayTeam}</AwayDiv>
                    </Rowone>
                    <Rowtwo>
                        <MatchCardbuttonDiv>
                            <HdaButton
                                active={props.numbers?.selections.includes('H')}
                                bgcolor={Score === WinTypeEnum.HomeWIN ? 'Green' : 'Red'}
                                isResults
                            >
                                Home
                            </HdaButton>
                            <HdaButton
                                active={props.numbers?.selections.includes('D')}
                                bgcolor={Score === WinTypeEnum.Draw ? 'Green' : 'Red'}
                                isResults
                            >
                                Draw
                            </HdaButton>
                            <HdaButton
                                active={props.numbers?.selections.includes('A')}
                                bgcolor={Score === WinTypeEnum.AwayWIN ? 'Green' : 'Red'}
                                isResults
                            >
                                Away
                            </HdaButton>
                        </MatchCardbuttonDiv>
                    </Rowtwo>
                </TeamsDiv>
            </MatchCardDivs>
        </React.Fragment>
    );
};

const MatchCardbuttonDiv = styled.div`
    display: flex;
    background: #fff;
    overflow: hidden;
    text-align: center;
    justify-content: center;
`;
const MatchCardDivs = styled.div`
    color: #000;
    background-color: #fff;
    display: flex;

    width: 100%;
    border-radius: 5px;
    position: relative;
    z-index: 1;
`;

const NumberDiv = styled.div`
    width: 50px;
    line-height: inherit;
    text-align: center;
    color: #000;
    background: #fff;
    position: relative;
    font-size: 30px;
    margin-left: 3px;
    height: 70px;
    display: flex;
    justify-content: center;
    align-items: center;

    :after {
        content: '';
        height: 75%;
        width: 1px;

        position: absolute;
        right: 0;
        top: 12.5%;

        background-color: #000; //
    }

    ${breakpoints.below('lg')} {
        width: 20%;
    }
`;

const TeamsDiv = styled.div`
    flex: 1;
    display: flex;
    align-items: center;
    padding: 0 10px;
    flex-direction: row;
    flex-direction: column;
    width: 100%;
    justify-content: center;
    height: 70px;
    background: #fff;
    border-radius: 5px;
`;

const HomeDiv = styled.div`
    flex: 1;
    font-weight: 600;
    width: 40%;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    text-align: right;
    font-size: 15px;
`;

const VsDiv = styled.div<NumberStyleProps>`
    width: 1.5em;
    text-align: center;
    font-weight: 600;
    font-size: 1.2em;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
    color: ${(props): string => (props.textColor ? props.textColor : '#000')};
`;
const AwayDiv = styled.div`
    flex: 1;
    font-weight: 600;
    width: 40%;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    font-size: 15px;
`;

const Rowone = styled.div`
    flex: 1;
    display: flex;
    flex-direction: row;
    max-height: 30px;
    align-items: center;
    width: 100%;
`;

const Rowtwo = styled.div`
    flex: 1;
    width: 100%;
`;
