import React, { useContext, useEffect } from 'react';
import getConfig from 'next/config';
import styled, { ThemeContext } from 'styled-components';
import { Competition, GameType, Offerings, Offering, Wager, BetSlip } from '@sportech/pools-api';
import { breakpoints } from '../../../settings/breakpoints';
import {
    getCompetitionFromId,
    getIdFromWager,
    getWagersSortedByCompetition,
    isCurrentViewLines,
} from '../../../utils/functionUtils';

import { ViewLinesItem } from './ViewLinesItem';

const { publicRuntimeConfig } = getConfig();

const editLCSelections = publicRuntimeConfig.EDIT_LC_SELECTIONS === 'true';

export interface ViewLinesCurrent {
    id: number;
    competitionId?: number;
}

export interface ViewLinesProps {
    offers: Offerings;
    competitions?: Competition[];
    gameType: GameType;
    wagers?: Wager[];
    setViewLinesCurrent?: (viewLinesCurrent: ViewLinesCurrent) => void;
    viewLinesCurrent?: ViewLinesCurrent;
    nothda: boolean;
    isMobile?: boolean;
    canEdit?: boolean;
    handleCircleNumberClick?: (id: number, type: string) => void;
    betslip?: BetSlip;
    ClearLine?: () => void;
    setShowWagerFixtures?: (showFixtures: boolean) => void;
    betslipItemSize?: string;
    ballColor?: string;
    handleOnClickManageLinesInfo?: () => void;
}

export const ViewLines = (props: ViewLinesProps): JSX.Element => {
    const themeContext = useContext(ThemeContext);
    useEffect(() => {
        if (
            props.wagers !== undefined &&
            props.wagers !== null &&
            props.wagers.length > 0 &&
            props.viewLinesCurrent?.id === 0 &&
            // (!props.isMobile || props.canEdit) &&
            props.setViewLinesCurrent !== undefined
        ) {
            const wagersWithDetails = getWagersSortedByCompetition(props.gameType, props.wagers, props.competitions);
            const id = getIdFromWager(wagersWithDetails[0].wager);
            if (id > 0) {
                props.setViewLinesCurrent({
                    id,
                    competitionId: wagersWithDetails[0].wager.competitionId,
                });
            }
        }
    });

    const handleViewLineItemClick = (id: number, competitionId?: number): void => {
        if (
            props.setViewLinesCurrent !== undefined &&
            props.viewLinesCurrent &&
            (props.viewLinesCurrent.id !== id ||
                (competitionId && props.viewLinesCurrent.competitionId !== competitionId))
        ) {
            props.setViewLinesCurrent({ id, competitionId });
        }
    };

    const wagersWithDetails: {
        wager: Wager;
        betsTypeDescription?: string;
        showCompetitionInfo?: boolean;
    }[] = getWagersSortedByCompetition(props.gameType, props.wagers, props.competitions);
    const hasSubscriptionWagers = wagersWithDetails.some(
        w => w.wager.paymentType !== 'wallet' && w.wager.paymentType !== 'ot_card',
    );

    return (
        <React.Fragment>
            {hasSubscriptionWagers && props.handleOnClickManageLinesInfo && (
                <HowToManageYourLinesContainer onClick={props.handleOnClickManageLinesInfo}>
                    How to manage your lines
                    <HowToManageYourLinesIcon src="/input-question-mark.svg" alt="question mark icon" />
                </HowToManageYourLinesContainer>
            )}
            {wagersWithDetails && wagersWithDetails.length > 0 ? (
                wagersWithDetails.map((item, index) => (
                    <div key={'WagerList' + index}>
                        <div key={'WagerSection' + index}>
                            <StyledViewLineItemContainer
                                isActiveViewLine={isCurrentViewLines(
                                    item.wager,
                                    props.competitions,
                                    props.viewLinesCurrent,
                                )}
                                isActiveColor={themeContext.colours.gameMainColour}
                                onClick={(): void => {
                                    // if (!props.isMobile || props.canEdit) {
                                    handleViewLineItemClick(getIdFromWager(item.wager), item.wager.competitionId);
                                    // }
                                }}
                            >
                                <ViewLinesItem
                                    wager={item.wager}
                                    competition={
                                        getCompetitionFromId(
                                            item.wager.competitionId,
                                            props.competitions,
                                        ) as Competition
                                    }
                                    offering={
                                        props.offers.offerings.find(x => x.id === item.wager.offeringId) as Offering
                                    }
                                    index={index}
                                    nothda={props.nothda}
                                    handleCircleNumberClick={props.canEdit ? props.handleCircleNumberClick : undefined}
                                    isCurrent={isCurrentViewLines(
                                        item.wager,
                                        props.competitions,
                                        props.viewLinesCurrent,
                                    )}
                                    amount={
                                        isCurrentViewLines(item.wager, props.competitions, props.viewLinesCurrent)
                                            ? props.betslip?.pick
                                            : undefined
                                    }
                                    canEdit={props.canEdit}
                                    ClearLine={
                                        !props.isMobile && (props.gameType !== 'lucky-clover' || editLCSelections)
                                            ? props.ClearLine
                                            : undefined
                                    }
                                    isClover={props.gameType === 'lucky-clover'}
                                    setShowWagerFixtures={props.setShowWagerFixtures}
                                    betslipItemSize={props.betslipItemSize}
                                    ballColor={props.ballColor}
                                    game={props.gameType}
                                    showCompetitionInfo={item.showCompetitionInfo}
                                    betsTypeDescription={item.betsTypeDescription}
                                />
                            </StyledViewLineItemContainer>
                        </div>
                    </div>
                ))
            ) : (
                <p>No lines for competitions starting within the next 8 days</p>
            )}
        </React.Fragment>
    );
};
type StyledViewLineItemContainerProps = {
    isActiveViewLine: boolean;
    isActiveColor: string;
};
const StyledViewLineItemContainer = styled.div<StyledViewLineItemContainerProps>`
    ${breakpoints.above('lg')} {
        cursor: pointer;
    }
    // margin-bottom: 10px;
    ${props =>
        props.isActiveViewLine &&
        `
        border: 2px solid ${props.isActiveColor};
    `}
`;

const HowToManageYourLinesContainer = styled.div`
    display: flex;
    flex-direction: row;
    justify-content: flex-end;
    text-decoration: underline;
    cursor: pointer;
    padding: 5px;
`;
const HowToManageYourLinesIcon = styled.img`
    padding-left: 5px;
`;
