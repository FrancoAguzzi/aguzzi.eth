import React, { useState } from 'react';
import styled from 'styled-components';
import { CompetitionResult } from '@sportech/pools-api';
// eslint-disable-next-line import/default
import dayjs from 'dayjs';

export interface ResultsCompetitionSelectorProps {
    competitions: CompetitionResult[];
    CurrentCompetition: CompetitionResult;
    ChangeCompetitions: (id: number) => void;
    user: null;
}

export const ResultsCompetitionSelector = (props: ResultsCompetitionSelectorProps): JSX.Element => {
    const [isOpen, setIsOpen] = useState(false);
    const SelectOption = (event: number): void => {
        setIsOpen(false);
        props.ChangeCompetitions(event);
    };
    return (
        <DropDownContainer>
            <DropDownHeader
                onClick={(): void => {
                    setIsOpen(!isOpen);
                }}
            >
                <span>
                    {props.CurrentCompetition.description} -{' '}
                    {dayjs(props.CurrentCompetition.datumDate).format('DD/MM/YYYY HH:mm')}
                </span>
                <FloatRightDiv>
                    <img src="/date_range_white.svg" alt="date range icon" />
                </FloatRightDiv>
            </DropDownHeader>
            {isOpen && (
                <DropDownListContainer>
                    <DropDownList>
                        {props.competitions.map((comp, index) => (
                            <ListItem
                                onClick={(): void => {
                                    SelectOption(comp.id);
                                }}
                                key={index}
                                value={comp.id}
                            >
                                {comp.description} - {dayjs(comp.datumDate).format('DD/MM/YYYY HH:mm')}
                            </ListItem>
                        ))}
                    </DropDownList>
                </DropDownListContainer>
            )}
        </DropDownContainer>
    );
};

const DropDownContainer = styled.div`
    padding-top: 10px;
    background: white;
`;

const DropDownHeader = styled.div`
    padding: 0.4em 0 0.4em 0;
    font-weight: 500;
    font-size: 1.3rem;
    color: #fff;
    background: ${(props): string => props.theme.colours.gameMainColour};
    width: 100%;
    cursor: pointer;
    > span {
        margin-right: -30px;
    }
`;
const FloatRightDiv = styled.div`
    float: right;

    img {
        padding-right: 10px;
    }
`;

const DropDownListContainer = styled.div`
    position: relative;
`;

const DropDownList = styled.div`
    position: absolute;
    z-index: 300;
    padding: 0;
    margin: 0;
    height: 200px;
    overflow: scroll;
    background: #eaeaea;
    box-sizing: border-box;
    color: #000;
    font-size: 1.3rem;
    font-weight: 500;
    width: 100%;
    &:first-child {
        padding-top: 0.8em;
    }
`;

const ListItem = styled.li`
    list-style: none;
    margin-bottom: 0.8em;
    cursor: pointer;
`;
