import React from 'react';
import { useDispatch } from 'react-redux';
import { BetSlip } from '@sportech/pools-api';
import { ErrorPopupText } from '../Styles/defaultPageStyles';
import { Button } from '../Common/Button/Button';
import { closePopup } from '../../state/popupsSlice';

interface ErrorOnBetSlipChangePopupProps {
    currentSlip: BetSlip;
}
export const ErrorOnBetSlipChangePopup = (props: ErrorOnBetSlipChangePopupProps): JSX.Element => {
    const dispatch = useDispatch();

    return (
        <ErrorPopupText>
            <p>A minimum of {props.currentSlip?.pick} selections need to be added to enter</p>
            <Button
                bgColor="#38d8ff"
                textColor="black"
                height="auto"
                padding="8px 10px"
                rounded="4px"
                hoverColor="#38D8FF"
                onClick={() => dispatch(closePopup('error_on_change_betslip_line'))}
            >
                OK
            </Button>
        </ErrorPopupText>
    );
};
