import React from 'react';

import dayjs from '../../../libs/dayjs';
export interface DateTimeFormatterProps {
    format: string;
    input?: Date | string;
}

export const DateTimeFormatter = (props: DateTimeFormatterProps): JSX.Element => {
    return <React.Fragment>{dayjs(props.input).format(props.format)}</React.Fragment>;
};
