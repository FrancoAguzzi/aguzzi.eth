import React from 'react';
import { DiceFigures } from './DiceFigures';
import { render } from '@testing-library/react';

describe('DiceFigures', () => {
    it('should render', () => {
        const { container } = render(<DiceFigures />);

        expect(container).toMatchSnapshot();
    });

    it('should render Flipped', () => {
        const { container } = render(<DiceFigures flip />);

        expect(container).toMatchSnapshot();
    });
});
