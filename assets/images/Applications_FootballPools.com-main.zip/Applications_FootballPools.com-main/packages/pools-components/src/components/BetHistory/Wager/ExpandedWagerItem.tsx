import React from 'react';
import { ResultsKey } from '../../Results/ResultsKey/ResultsKey';
import { DateTimeFormatter } from '../../Common/DateTimeFormatter/DateTimeFormatter';
import { BetSlipCircle } from '../../BetSlip/BetSlipCircle/BetSlipCircle';
import { ResultSection } from '../../Results/ResultsSection/ResultsSection';
import styled from 'styled-components';
import { CompetitionResult, Offering, Dividends, Wager, NumbersSelected, GameType } from '@sportech/pools-api';
import {
    ConvertStringToArray,
    getPoints,
    getWinningPoints,
    isHDA,
    getGameCategory,
} from '../../../utils/functionUtils';

export interface ExpandedWagerItemProps {
    wager: Wager;
    offering: Offering;
    comp: CompetitionResult;
    dividends: Dividends;
    result: string;
    showFixtures: boolean;
    setShowFixtures: (val: boolean) => void;
    GameName: GameType;
    isFirstWager?: boolean;
    hasMulitpleWagers?: boolean;
}

export const ExpandedWagerItem = (props: ExpandedWagerItemProps): JSX.Element => {
    const IsHDA = isHDA(getGameCategory(props.GameName));
    const wagerSelection = ConvertStringToArray(props.wager.selections as string, !IsHDA);
    const wagerSelectionFixtures = props.comp?.fixtures?.filter(x => wagerSelection?.find(c => c.Id === x.number));
    const pointsTotal = getPoints(wagerSelectionFixtures, IsHDA, props.GameName === 'classic-pools', wagerSelection);
    const winningPoints = getWinningPoints(props.dividends);
    const winStatus =
        props.comp !== undefined
            ? props.comp.state === 'completed' && pointsTotal !== undefined && pointsTotal >= winningPoints
                ? 'Won'
                : props.comp.state === 'completed' && pointsTotal !== undefined && winningPoints > pointsTotal
                ? 'Lost'
                : 'Pending'
            : '-';
    const numbersFixturesPText = props.showFixtures ? 'Fixtures' : 'Numbers';
    const numbersFixturesViewText = props.showFixtures ? 'View Numbers' : 'View Fixtures';
    const PointsColor = (Numbers: NumbersSelected): string => {
        if (props.comp === undefined) {
            return '#fff';
        }
        const match = props.comp.fixtures.find(x => x.number === Numbers.Id);
        if (match === undefined) {
            return '#fff';
        }
        if (IsHDA) {
            if (
                match.scores.fullTime !== undefined &&
                Numbers.selections.includes('H') &&
                match.scores.fullTime.home > match.scores.fullTime.away
            ) {
                return 'green';
            } else if (
                match.scores.fullTime !== undefined &&
                Numbers.selections.includes('A') &&
                match.scores.fullTime.home < match.scores.fullTime.away
            ) {
                return 'green';
            } else if (
                match.scores.fullTime !== undefined &&
                Numbers.selections.includes('D') &&
                match.scores.fullTime.home === match.scores.fullTime.away
            ) {
                return 'green';
            }
        } else if (props.GameName === 'classic-pools') {
            if (match.points === 3) {
                return 'green';
            } else if (match.points === 2) {
                return '#272188';
            } else if (match.points === 1) {
                return '#ff2b2b';
            }
        } else if (props.GameName === 'goal-rush') {
            if (match.points === 1) {
                return 'green';
            } else if (match.points === 0) {
                return 'red';
            }
        }

        return '#fff';
    };
    return (
        <ExpandedWager>
            {props.isFirstWager && (
                <StyledResultsKey>
                    <ResultsKey GameType={props.GameName} isSmall />
                </StyledResultsKey>
            )}
            {props.hasMulitpleWagers && props.isFirstWager && (
                <Row3>
                    <Row3Item>
                        <p>
                            {`${numbersFixturesPText} `}
                            {props.comp !== undefined ? (
                                <StyledAUnderline
                                    onClick={e => {
                                        props.setShowFixtures(!props.showFixtures);
                                        e.stopPropagation();
                                    }}
                                >
                                    {numbersFixturesViewText}
                                </StyledAUnderline>
                            ) : (
                                <React.Fragment />
                            )}
                        </p>
                    </Row3Item>
                </Row3>
            )}
            <Row2>
                <StyledExpandedWagerItem>
                    {props.isFirstWager && (
                        <strong>
                            <p>Plan</p>
                        </strong>
                    )}
                    <p>{props.offering.description}</p>
                </StyledExpandedWagerItem>
                <StyledExpandedWagerItem>
                    {props.isFirstWager && (
                        <strong>
                            <p>Date</p>
                        </strong>
                    )}
                    <p>
                        {props.comp !== undefined ? (
                            <DateTimeFormatter format="dd/MM/yyyy HH:mm" input={props.comp?.datumDate} />
                        ) : (
                            <React.Fragment>-</React.Fragment>
                        )}
                    </p>
                </StyledExpandedWagerItem>
                <StyledExpandedWagerItem>
                    {props.isFirstWager && (
                        <strong>
                            <p>Points</p>
                        </strong>
                    )}
                    <p>{props.comp !== undefined ? pointsTotal : '-'}</p>
                </StyledExpandedWagerItem>
                <StyledExpandedWagerItem>
                    {props.isFirstWager && (
                        <strong>
                            <p>Result</p>
                        </strong>
                    )}
                    <p>{props.result}</p>
                </StyledExpandedWagerItem>
                <StyledExpandedWagerItem>
                    {props.isFirstWager && (
                        <strong>
                            <p>Status</p>
                        </strong>
                    )}
                    <p>{winStatus}</p>
                </StyledExpandedWagerItem>
            </Row2>
            {!props.hasMulitpleWagers && (
                <Row3>
                    <Row3Item>
                        <p>
                            {`${numbersFixturesPText} `}
                            {props.comp !== undefined ? (
                                <StyledAUnderline
                                    onClick={e => {
                                        props.setShowFixtures(!props.showFixtures);
                                        e.stopPropagation();
                                    }}
                                >
                                    {numbersFixturesViewText}
                                </StyledAUnderline>
                            ) : (
                                <></>
                            )}
                        </p>
                    </Row3Item>
                </Row3>
            )}
            {!props.showFixtures && (
                <NumbersContainer>
                    <SelectionsNumberContainer>
                        {wagerSelection.map((fixture, index) => (
                            <BetSlipCircle
                                key={index}
                                selected={IsHDA ? fixture.selections.join('') : fixture.Id}
                                ballColor={PointsColor(fixture)}
                            />
                        ))}
                    </SelectionsNumberContainer>
                </NumbersContainer>
            )}
            {props.showFixtures && (
                <ResultSection
                    GameType={props.GameName}
                    IsHda={IsHDA}
                    fixtures={wagerSelectionFixtures}
                    matchCardWidth="48%"
                    Wager={wagerSelection}
                />
            )}
        </ExpandedWager>
    );
};

const ExpandedWager = styled.div`
    display: flex;
    flex-wrap: wrap;
    width: 100%;
    padding-bottom: 5px;
    justify-content: center;
    font-size: 0.8em;
`;

const StyledExpandedWagerItem = styled.div`
    display: flex;
    flex: 1 1;
    flex-flow: column;
    align-items: center;

    p {
        margin: 2px 0;
    }
`;

const StyledResultsKey = styled.div`
    display: flex;
    flex: 1 1 100%;
    justify-content: center;
`;

const Row2 = styled.div`
    display: flex;
    flex: 1 1 100%;
`;

const Row3 = styled.div`
    display: flex;
    flex: 1 1 100%;
    justify-content: center;
`;

const Row3Item = styled.div`
    display: flex;
`;

const StyledAUnderline = styled.a`
    text-decoration: underline;
    cursor: pointer;
`;

const NumbersContainer = styled.div`
    padding: 0 10px;
`;

const SelectionsNumberContainer = styled.ul`
    display: flex;
    flex: 1 1 100%;
    flex-wrap: wrap;
    padding: 0;
`;
