import React, { useEffect, useState } from 'react';
import styled from 'styled-components';

const Container = styled.div<{ colour?: string }>`
    display: flex;
    flex-direction: column;
    justify-content: center;
    text-align: center;
    font-weight: bold;
    color: ${props => props.colour || '#3c3c3c'};
    p {
        margin: 5px;
    }
`;
const CountContainer = styled.div`
    display: flex;
    flex-direction: row;
    justify-content: center;
`;
const CountItemContainer = styled.div`
    display: flex;
    flex-direction: column;
    font-size: 30px;
`;
const HeaderText = styled.p<{ fontSize?: string }>`
    font-size: ${props => props.fontSize || '20px'};
`;
const CountDurationText = styled.p`
    font-size: 16px;
`;

export interface CountdownProps {
    target?: Date | string;
    headerText?: string;
    includeSeconds?: boolean;
    tickMs?: number;
    styles?: {
        fontColour?: string;
        headerTextSize?: string;
    };
}

export interface Count {
    days: string;
    hours: string;
    minutes: string;
    seconds: string;
}

export const getCountdown = (endDate?: Date | string): Count => {
    const end = !endDate ? new Date() : typeof endDate === 'string' ? new Date(endDate) : endDate;
    const now = new Date().getTime();

    const diff = end.getTime() - now;

    const days = Math.max(Math.floor(diff / (1000 * 60 * 60 * 24)), 0);
    const hours = Math.max(Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)), 0);
    const minutes = Math.max(Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)), 0);
    const seconds = Math.max(Math.floor((diff % (1000 * 60)) / 1000), 0);

    return {
        days: days < 10 ? `0${days}` : days.toString(),
        hours: hours < 10 ? `0${hours}` : hours.toString(),
        minutes: minutes < 10 ? `0${minutes}` : minutes.toString(),
        seconds: seconds < 10 ? `0${seconds}` : seconds.toString(),
    };
};

export const Countdown = ({ target, headerText, includeSeconds, tickMs, styles }: CountdownProps): JSX.Element => {
    const [count, setCount] = useState<Count>(getCountdown(target));
    useEffect(() => {
        const interval = setInterval(() => {
            setCount(getCountdown(target));
        }, tickMs || 1000);
        return () => clearInterval(interval);
    }, [count]);
    if (!target) {
        return <React.Fragment />;
    }
    return (
        <Container colour={styles?.fontColour}>
            <HeaderText fontSize={styles?.headerTextSize}>{headerText}</HeaderText>
            <CountContainer>
                {parseInt(count.days) > 0 && (
                    <React.Fragment>
                        <CountItemContainer>
                            {count.days}
                            <CountDurationText>DAYS</CountDurationText>
                        </CountItemContainer>
                        <CountItemContainer>:</CountItemContainer>
                    </React.Fragment>
                )}
                <CountItemContainer>
                    {count.hours}
                    <CountDurationText>HOURS</CountDurationText>
                </CountItemContainer>
                <CountItemContainer>:</CountItemContainer>
                <CountItemContainer>
                    {count.minutes}
                    <CountDurationText>MINS</CountDurationText>
                </CountItemContainer>
                {includeSeconds && (
                    <React.Fragment>
                        <CountItemContainer>:</CountItemContainer>
                        <CountItemContainer>
                            {count.seconds}
                            <CountDurationText>SECS</CountDurationText>
                        </CountItemContainer>
                    </React.Fragment>
                )}
            </CountContainer>
        </Container>
    );
};
