import React from 'react';
import styled from 'styled-components';
import { ExternalLink } from '@components/Common/ExternalLink/ExternalLink';
import getConfig from 'next/config';
import { breakpoints } from '@settings/breakpoints';

const { publicRuntimeConfig } = getConfig();

const FSBUrl = (path: string): string => publicRuntimeConfig.FSB_SITE_URL + path;

const TopTabs: React.FC = () => (
    <StyledTopTabsContainer>
        <StyledTopTabsItem>
            <Styledatag target="_self" href={FSBUrl('sportsbook')}>
                <img src="/sportsbook.svg" alt="sportsbook icon" />
                SPORTSBOOK
            </Styledatag>
        </StyledTopTabsItem>
        <StyledTopTabsItem>
            <Styledatag target="_self" href={FSBUrl('casino')}>
                <img src="/casino.svg" alt="casino icon" />
                CASINO
            </Styledatag>
        </StyledTopTabsItem>
        <StyledTopTabsItem isActive>
            <Styledatag>
                <img src="/poolsgames.svg" alt="poolsgames icon" />
                POOLS GAMES
            </Styledatag>
        </StyledTopTabsItem>
    </StyledTopTabsContainer>
);

export default TopTabs;

const Styledatag = styled(ExternalLink)`
    text-decoration: none;
`;

const StyledTopTabsContainer = styled.div`
    display: flex;
    align-items: center;
    justify-content: center;
`;

type StyledTobTabsItemProps = {
    isActive?: boolean;
};

const StyledTopTabsItem = styled.div<StyledTobTabsItemProps>`
    flex: 1;
    background-color: ${(props): string => (props.isActive ? 'rgb(54, 54, 54)' : '#212121')};
    font-size: 1em;
    font-family: 'Barlow Condensed Regular', sans-serif;
    font-weight: bold;
    display: flex;
    justify-content: center;

    ${breakpoints.below('sm')} {
        font-size: 0.7em;
    }

    ${breakpoints.below('xs')} {
        font-size: 0.5em;
    }

    a {
        color: ${(props): string => (props.isActive ? '#38D8FF' : '#fff')};
        display: flex;
        align-items: center;
        justify-content: center;
        width: 100%;
        padding: 3% 0;
    }

    img {
        max-width: 20px;
        height: 20px;
        margin-right: 5px;
    }
`;
