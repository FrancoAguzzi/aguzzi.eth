import React, { useState } from 'react';
import styled from 'styled-components';
import MediaQuery from 'react-responsive';
import { Fixture, Competition, Offering, Wager, GameType } from '@sportech/pools-api';
import {
    ConvertStringToArray,
    convertWagerToBetSlipSelection,
    getIdFromWager,
    RemoveGameName,
    replaceGameName,
} from '../../../utils/functionUtils';
import { GameSection } from '../../GameSection/GameSection/GameSection';
import { useDispatch } from 'react-redux';
import { closePopup } from '../../../state/popupsSlice';
import { BetSelections } from '../BetSelections/BetSelections';
import { ViewLinesItemInfo } from './ViewLinesItemInfo';

interface ViewLinesItemProps {
    wager: Wager;
    competition: Competition;
    offering: Offering;
    index: number;
    nothda: boolean;
    handleCircleNumberClick?: (id: number, type: string) => void;
    isCurrent?: boolean;
    amount?: number;
    canEdit?: boolean;
    ClearLine?: () => void;
    isClover?: boolean;
    setShowWagerFixtures?: (showFixtures: boolean) => void;
    betslipItemSize?: string;
    ballColor?: string;
    game: GameType;
    showCost?: boolean;
    showCompetitionInfo?: boolean;
    betsTypeDescription?: string;
}

export const ViewLinesItem = (props: ViewLinesItemProps): JSX.Element => {
    const [showFixtures, setShowFixtures] = useState(false);
    const numbersFixturesViewText = showFixtures ? 'View Numbers' : 'View Fixtures';
    const dispatch = useDispatch();

    const onShowFixturesClick = (): void => {
        if (props.canEdit) {
            if (props.setShowWagerFixtures) {
                props.setShowWagerFixtures(true);
            }
            dispatch(closePopup('your_placed_lines'));
        } else {
            setShowFixtures(!showFixtures);
        }
    };

    const bet = convertWagerToBetSlipSelection(
        props.competition,
        props.offering,
        props.wager,
        ConvertStringToArray(props.wager.selections as string, props.nothda),
        props.wager.bonusSelections ? ConvertStringToArray(props.wager.bonusSelections as string, props.nothda) : [],
    );

    const costText =
        props.wager.paidCost && props.wager.paidCost > 0
            ? `£${((props.wager.paidCost as number) / 100).toLocaleStringCash()}`
            : 'Free';

    const itemDescription =
        props.wager.bonusSelections && props.wager.bonusSelections.length > 0
            ? `${props.offering.description} with £1M upgrade`
            : replaceGameName(props.offering.description);

    return (
        <React.Fragment>
            <ViewLinesItemInfo
                key={getIdFromWager(props.wager)}
                competitionDescription={
                    props.showCompetitionInfo ? RemoveGameName(props.competition.description) : undefined
                }
                competitionDate={props.showCompetitionInfo ? props.competition.datumDateWithBuffer : undefined}
                viewLinesItemCost={costText}
                viewLinesItemDescription={itemDescription}
                betsTypeDescription={props.betsTypeDescription}
            />

            {!showFixtures && (
                <NumberList key={'NumberList' + props.index}>
                    <Container>
                        <BetSelections
                            bet={bet}
                            game={props.game}
                            displayId={props.nothda}
                            handleOnClick={
                                props.wager.paymentType !== 'wallet' && props.wager.paymentType !== 'ot_card'
                                    ? props.handleCircleNumberClick
                                    : undefined
                            }
                            selectionsColour={props.ballColor}
                            bonusSelectionsColour="#e0ac00"
                            isCurrentSelectedLine={props.isCurrent}
                            handleOnClickClear={
                                props.wager.paymentType !== 'wallet' && props.wager.paymentType !== 'ot_card'
                                    ? props.ClearLine
                                    : undefined
                            }
                            betslipItemSize={props.betslipItemSize}
                            row={0}
                            hideBonusIfEmpty
                        />
                    </Container>
                    {ConvertStringToArray(props.wager.selections as string, props.nothda).reduce(
                        (maxId, item) => Math.max(maxId, item.rows),
                        0,
                    ) >= 2 ? (
                        <Container>
                            <BetSelections
                                bet={bet}
                                game={props.game}
                                displayId={props.nothda}
                                handleOnClick={
                                    props.wager.paymentType !== 'wallet' && props.wager.paymentType !== 'ot_card'
                                        ? props.handleCircleNumberClick
                                        : undefined
                                }
                                selectionsColour={props.ballColor}
                                bonusSelectionsColour="#e0ac00"
                                isCurrentSelectedLine={props.isCurrent}
                                handleOnClickClear={
                                    props.wager.paymentType !== 'wallet' && props.wager.paymentType !== 'ot_card'
                                        ? props.ClearLine
                                        : undefined
                                }
                                betslipItemSize={props.betslipItemSize}
                                row={1}
                                hideBonusIfEmpty
                            />
                        </Container>
                    ) : (
                        <React.Fragment />
                    )}
                    {ConvertStringToArray(props.wager.selections as string, props.nothda).reduce(
                        (maxId, item) => Math.max(maxId, item.rows),
                        0,
                    ) >= 3 ? (
                        <Container>
                            <BetSelections
                                bet={bet}
                                game={props.game}
                                displayId={props.nothda}
                                handleOnClick={
                                    props.wager.paymentType !== 'wallet' && props.wager.paymentType !== 'ot_card'
                                        ? props.handleCircleNumberClick
                                        : undefined
                                }
                                selectionsColour={props.ballColor}
                                bonusSelectionsColour="#e0ac00"
                                isCurrentSelectedLine={props.isCurrent}
                                handleOnClickClear={
                                    props.wager.paymentType !== 'wallet' && props.wager.paymentType !== 'ot_card'
                                        ? props.ClearLine
                                        : undefined
                                }
                                betslipItemSize={props.betslipItemSize}
                                row={2}
                                hideBonusIfEmpty
                            />
                        </Container>
                    ) : (
                        <React.Fragment />
                    )}
                </NumberList>
            )}
            <MediaQuery maxWidth={1270}>
                {showFixtures && (
                    <GameSection
                        isHda={!props.nothda}
                        fixtures={[
                            ...(props.competition?.fixtures.filter(x =>
                                ConvertStringToArray(props.wager.selections as string, props.nothda).find(
                                    s => s.Id === x.number,
                                ),
                            ) as Fixture[]),
                            ...(props.competition?.fixtures.filter(x =>
                                ConvertStringToArray(props.wager.bonusSelections as string, props.nothda).find(
                                    s => s.Id === x.number,
                                ),
                            ) as Fixture[]),
                        ]}
                        betslipSelection={convertWagerToBetSlipSelection(
                            props.competition,
                            props.offering,
                            props.wager,
                            ConvertStringToArray(props.wager.selections as string, props.nothda),
                            props.wager.bonusSelections
                                ? ConvertStringToArray(props.wager.bonusSelections as string, props.nothda)
                                : [],
                        )}
                        gameViewType={props.isClover ? 'numbers' : 'match'}
                        isViewLines
                        isClover={props.isClover}
                    />
                )}
                {!props.isClover && (
                    <ViewFixturesButtonContainer>
                        <StyledAUnderline onClick={onShowFixturesClick}>{numbersFixturesViewText}</StyledAUnderline>
                    </ViewFixturesButtonContainer>
                )}
            </MediaQuery>
        </React.Fragment>
    );
};

const NumberList = styled.div`
    padding: 5px 0 5px 10px;
    /* background: #eaeaea !important; */
    display: inline-block;
    width: 96.5%;
`;

const StyledAUnderline = styled.a`
    text-decoration: underline;
    cursor: pointer;
    text-align: center;
`;

const ViewFixturesButtonContainer = styled.div`
    text-align: center;
    background: #eaeaea;
    padding-bottom: 5px;
`;

const Container = styled.div`
    display: flex;
    flex: 1;
    overflow: auto;
    align-items: center;
    flex-wrap: nowrap;
    margin: 0;
    width: 100%;

    p {
        margin-left: 2%;
        margin-right: 2%;
    }
`;
