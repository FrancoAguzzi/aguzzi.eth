import React, { FunctionComponent } from 'react';
import { useDispatch } from 'react-redux';
import { PopupText, StyledATag } from '../../Styles/defaultPageStyles';
import { AppDispatch } from '../../../state/rootReducer';
import { closePopup } from '../../../state/popupsSlice';

export const Premier10HowToPlayPopup: FunctionComponent = () => {
    const dispatch: AppDispatch = useDispatch<AppDispatch>();
    return (
        <PopupText>
            <p>
                <strong>Pick Home, Draw or Away on 10 matches to win big</strong>
                <br />
                <br />
                <strong>We&#39;ve paid on average £18,000 for 10 correct results in 2017!</strong>
                <br />
                <br />
                Simply pick Home, Draw or Away on all 10 matches. This will give you a single line in the pool -
                you&#39;ll see this on the right hand side in your bet slip. You can increase your chances of winning by
                selecting more than one outcome in each match. This will give you more than one line, which will cost
                more - but you can adjust your stake in the betslip. Once all matches have been played, whoever gets all
                10 results correct wins the pool, or a share of the pool if there are multiple winners! You&#39;ll also
                win money if you get 9 correct - on average in 2017, we&#39;ve paid £400 to players with 9 correct
                results! The pool size shown is before expenses and commissions.
            </p>
            <StyledATag
                onClick={() => dispatch(closePopup('how_to_play_Premier10'))}
                target="_self"
                href="/content/Premier-10-Game-Rules"
            >
                View Game Terms & Conditions
            </StyledATag>
        </PopupText>
    );
};
