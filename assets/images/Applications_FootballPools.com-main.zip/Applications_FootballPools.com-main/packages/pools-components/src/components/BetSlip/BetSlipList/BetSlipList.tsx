import React, { useRef, useEffect } from 'react';
import styled, { useTheme } from 'styled-components';
import {
    BetSlip,
    BetSlipSlice,
    Competition,
    Offerings,
    Offering,
    Wager,
    Response,
    toGameType,
} from '@sportech/pools-api';
import { Button } from '../../Common/Button/Button';
import BetSlipItem from '../BetSlipItem/BetSlipItem';
import { ViewLines, ViewLinesCurrent } from '../ViewLines/ViewLines';
import { testId, getTotalPrice, isPlayEnabled, replaceGameName } from '../../../utils/functionUtils';
import '../../../utils/extensionMethods';
import { Countdown } from '../../Countdown/Countdown';
import { GameCostInfo } from '../../GameCostInfo/GameCostInfo';
import { TermsPanel } from '../TermsPanel/TermsPanel';

export interface BetSlipListProps {
    betslipselection: Array<BetSlip>;
    SelectAmountAction: (id: number, amount: Offering) => void;
    ClearLine: (index?: number | undefined) => void;
    AddLine: () => void;
    ChangeBet: (index: number) => void;
    offers: Offerings;
    ShowHDA?: boolean;
    gameType: keyof BetSlipSlice;
    handleCircleNumberClick: (id: number, type: string) => void;
    setCurrentOfferingId: (val: number) => void;
    setShowMore: (val: boolean) => void;
    currentOfferingId: number;
    showMoreValue: boolean;
    user: any;
    depositUrl?: string;
    gameTermsUrl?: string;
    customerReq?: Response<{ cashBalance: number }>;
    competitions: Competition[];
    showWagers: boolean;
    setShowWagers: (val: boolean) => void;
    wagers?: Wager[];
    setViewLinesCurrent: (viewLinesCurrent: ViewLinesCurrent) => void;
    viewLinesCurrent: ViewLinesCurrent;
    pressPlay: () => void;
    canEdit?: boolean;
    viewLinesBetslip?: BetSlip;
    showAddLinesButton?: boolean;
    showOfferingList?: boolean;
    isClover: boolean;
    setShowWagerFixtures?: (showFixtures: boolean) => void;
    showClearInBetslipCircle?: boolean;
    betslipItemSize?: string;
    maxCostPerMonth?: string;
    termsContent?: string;
    termsBackgroundColour?: string;
    ballColor?: string;
    handleOnClickManageLinesInfo?: () => void;
    perMonthTooltipContent?: JSX.Element;
    viewLinesOffers?: Offerings;
    openPopupTermsAndConditions?: () => void;
    perDrawCostText?: string;
    perMonthCostText?: string;
    perDrawCost?: string;
    addLineButtonPosition?: 'perLine' | 'adjacentPlay' | 'afterLines';
    betslipItemLabelling?: 'perLine' | 'header';
    showTotalLinesLabel?: boolean;
    borderType?: 'split' | 'whole';
    maximumLines?: number;
    showCostPerLine?: boolean;
    clearIconSrc?: string;
    showTermsAndConditionsLink?: boolean;
    minimumCost?: number;
    showBetslipCountHeader?: boolean;
    countdownHeaderText?: string;
    minimumStakeText?: string;
    selectionFontColour?: string;
    playNowColour?: string;
}

export const BetSlipList = ({ gameType, wagers, user, ...props }: BetSlipListProps): JSX.Element => {
    const lines = props.betslipselection?.filter(x => x.pick === x.numbers?.length).length;
    const totalPricenumber = getTotalPrice(
        props.ShowHDA as boolean,
        props.isClover,
        props.betslipselection,
        'pounds',
        props.offers.offerings,
    );
    const totalPrice = props.perDrawCost || totalPricenumber.toLocaleStringCash();

    const betslipCurrentSelection = props.betslipselection.find(x => x.current);

    const currentCompetition = props.competitions.find(c => c.id === betslipCurrentSelection?.competitionId);

    const childBetSlipItemRef = useRef<HTMLDivElement>(null);
    const scrollToCurrentLine = (): void => {
        if (childBetSlipItemRef.current != null) {
            childBetSlipItemRef.current.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
            });
        }
    };
    useEffect(() => {
        scrollToCurrentLine();
    }, [props.betslipselection.length]);

    const theme = useTheme();

    return (
        <React.Fragment>
            <TabContainer>
                <ButtonTab
                    onClick={(): void => props.setShowWagers(false)}
                    rounded={user ? '10px 0px 0px 0px' : '10px 10px 0px 0px'}
                    width={user ? '50%' : '100%'}
                    textColor={props.showWagers ? '#fff' : theme.colours.betslipItemSelectedColour}
                    fontWeight="bold"
                    bgColor={props.showWagers ? '#FD0000' : '#fff'}
                    hoverColor={props.showWagers ? '#FD0000' : '#fff'}
                    hoverOpacity="0.5"
                    noHover={user == null}
                    cursor="default"
                    {...testId(`Game_BuyNewLinesButton`)}
                >
                    BUY LINES
                </ButtonTab>
                {user != null && user.isLoggedIn && (
                    <ButtonTab
                        onClick={(): void => {
                            props.setShowWagers(true);
                        }}
                        rounded="0px 10px 0px 0px"
                        width="50%"
                        textColor={props.showWagers ? theme.colours.betslipItemSelectedColour : '#fff'}
                        fontWeight="bold"
                        bgColor={props.showWagers ? '#fff' : '#FD0000'}
                        hoverColor={props.showWagers ? '#fff' : '#FD0000'}
                        hoverOpacity="0.5"
                        {...testId(`Game_ViewLinesButton`)}
                        disabled={!wagers || wagers.length <= 0}
                    >
                        VIEW LINES
                    </ButtonTab>
                )}
            </TabContainer>
            <BetslipContainer borderType={props.borderType}>
                <LinesPanelContainer borderType={props.borderType}>
                    <StyledListScroll showAddLinesButton={props.showAddLinesButton && !props.showWagers}>
                        {!props.showWagers && (
                            <React.Fragment>
                                {props.betslipItemLabelling === 'header' && (
                                    <BetslipHeader4>
                                        {replaceGameName(
                                            props.competitions.find(
                                                c =>
                                                    props.betslipselection &&
                                                    props.betslipselection.length > 0 &&
                                                    props.betslipselection[0].competitionId === c.id,
                                            )?.description,
                                        )}
                                    </BetslipHeader4>
                                )}
                                {props.betslipselection.map((item, index) => (
                                    <BetSlipItem
                                        backgroundColour={index % 2 === 0}
                                        ref={childBetSlipItemRef}
                                        ChangeBet={(): void => props.ChangeBet(index)}
                                        showCountHeader={props.showBetslipCountHeader}
                                        SelectAmountAction={props.SelectAmountAction}
                                        ClearLine={props.ClearLine}
                                        AddLine={props.AddLine}
                                        key={index}
                                        ShowHDA={props.ShowHDA}
                                        offers={props.offers}
                                        betslipselection={item}
                                        betslipCurrentSelection={betslipCurrentSelection as BetSlip}
                                        moreThanOneLine={props.betslipselection.length > 1}
                                        handleCircleNumberClick={props.handleCircleNumberClick}
                                        setCurrentOfferingId={props.setCurrentOfferingId}
                                        currentOfferingId={props.currentOfferingId}
                                        setShowMore={props.setShowMore}
                                        showMoreValue={props.showMoreValue}
                                        showAddLinesButton={props.showAddLinesButton}
                                        showOfferingList={props.showOfferingList}
                                        {...testId(`Game_BetslipItem${index}`)}
                                        isClover={props.isClover}
                                        competition={
                                            props.competitions.find(
                                                x => x.id === betslipCurrentSelection?.competitionId,
                                            ) as Competition
                                        }
                                        showClearInBetslipCircle={props.showClearInBetslipCircle}
                                        betslipItemSize={props.betslipItemSize}
                                        ballColor={props.ballColor}
                                        betslipItemLabelling={props.betslipItemLabelling}
                                        showCostPerLine={props.showCostPerLine}
                                        clearIconSrc={props.clearIconSrc}
                                        selectionsFontColour={props.selectionFontColour}
                                    />
                                ))}
                            </React.Fragment>
                        )}
                        {props.showWagers && (
                            <ViewLines
                                competitions={props.competitions}
                                offers={props.viewLinesOffers || props.offers}
                                gameType={toGameType(gameType)}
                                wagers={wagers}
                                setViewLinesCurrent={props.setViewLinesCurrent}
                                viewLinesCurrent={props.viewLinesCurrent}
                                nothda={!props.ShowHDA}
                                handleCircleNumberClick={props.handleCircleNumberClick}
                                canEdit={props.canEdit}
                                betslip={props.viewLinesBetslip}
                                ClearLine={props.ClearLine}
                                setShowWagerFixtures={props.setShowWagerFixtures}
                                betslipItemSize={props.betslipItemSize}
                                ballColor={props.ballColor}
                                handleOnClickManageLinesInfo={props.handleOnClickManageLinesInfo}
                            />
                        )}
                    </StyledListScroll>
                    {!props.showWagers && (
                        <LinesPanelBottomContainer>
                            <LinesCostContainer>
                                {props.showAddLinesButton && props.showTotalLinesLabel && (
                                    <TotalLines>Total Lines: {lines}</TotalLines>
                                )}
                            </LinesCostContainer>

                            {props.showAddLinesButton && props.addLineButtonPosition === 'afterLines' && (
                                <Play width="90%">
                                    <Button
                                        disabled={Boolean(
                                            betslipCurrentSelection?.pick !==
                                                betslipCurrentSelection?.numbers?.length ||
                                                (props.maximumLines && lines >= props.maximumLines),
                                        )}
                                        onClick={props.AddLine}
                                        width="100%"
                                        height="50px"
                                        bgColor="#f88702"
                                        hoverColor="#f88702"
                                        hoverOpacity="0.5"
                                        padding="0.75em 1.25em"
                                        textColor="#fff"
                                        fontWeight="bold"
                                        rounded="25px"
                                        {...testId(`Game_AddLineButton`)}
                                    >
                                        ADD A LINE +
                                    </Button>
                                </Play>
                            )}
                        </LinesPanelBottomContainer>
                    )}
                </LinesPanelContainer>
                {!props.showWagers && (
                    <React.Fragment>
                        <BuyLines borderType={props.borderType}>
                            <GameCostInfo
                                perDrawCost={`£${totalPrice}`}
                                perMonthCost={props.maxCostPerMonth}
                                perMonthTooltipContent={props.perMonthTooltipContent}
                                tooltipProps={{
                                    lockScroll: true,
                                }}
                                perDrawCostText={props.perDrawCostText}
                                perMonthCostText={props.perMonthCostText}
                            />

                            <Play
                                width={
                                    props.showAddLinesButton && props.addLineButtonPosition === 'adjacentPlay'
                                        ? '95%'
                                        : '90%'
                                }
                            >
                                {props.showAddLinesButton && props.addLineButtonPosition === 'adjacentPlay' && (
                                    <Button
                                        disabled={
                                            betslipCurrentSelection?.pick !== betslipCurrentSelection?.numbers?.length
                                        }
                                        onClick={props.AddLine}
                                        width="100%"
                                        height="50px"
                                        bgColor="#f88702"
                                        hoverColor="#f88702"
                                        hoverOpacity="0.5"
                                        padding="0.75em 1.25em"
                                        textColor="#fff"
                                        fontWeight="bold"
                                        rounded="25px"
                                        {...testId(`Game_AddLineButton`)}
                                    >
                                        ADD LINE +
                                    </Button>
                                )}
                                <PlayNowButton
                                    disabled={
                                        !isPlayEnabled(
                                            props.betslipselection,
                                            props.offers,
                                            props.minimumCost,
                                            totalPricenumber,
                                        )
                                    }
                                    onClick={props.pressPlay}
                                    width="100%"
                                    height="50px"
                                    bgColor={props.playNowColour ? props.playNowColour : '#68D338'}
                                    hoverColor={props.playNowColour ? props.playNowColour : '#68D338'}
                                    hoverOpacity="0.5"
                                    padding="0.75em 1.25em"
                                    textColor="#fff"
                                    fontWeight="bold"
                                    rounded="25px"
                                    disablePulse={props.playNowColour !== undefined}
                                    {...testId(`Game_PlayButton`)}
                                >
                                    PLAY NOW
                                </PlayNowButton>
                            </Play>

                            {props.minimumStakeText && (
                                <MinStakeContainer>
                                    <MinStake>{props.minimumStakeText}</MinStake>
                                </MinStakeContainer>
                            )}

                            <Countdown
                                target={currentCompetition?.datumDateWithBuffer}
                                includeSeconds
                                headerText={props.countdownHeaderText}
                            />
                            <TermsPanel content={props.termsContent} backgroundColour={props.termsBackgroundColour}>
                                {props.showTermsAndConditionsLink ? (
                                    <StyledTermsAndConditionsLink termsBackgroundColour={props.termsBackgroundColour}>
                                        <StyledLink onClick={props.openPopupTermsAndConditions}>
                                            Terms and Conditions
                                        </StyledLink>
                                    </StyledTermsAndConditionsLink>
                                ) : undefined}
                            </TermsPanel>
                        </BuyLines>
                    </React.Fragment>
                )}
            </BetslipContainer>
        </React.Fragment>
    );
};

const TabContainer = styled.div`
    margin: 10px 10px 0 10px;
    border: 1px solid #000;
    border-radius: 10px 10px 0 0;
    height: 40px;
`;

const ButtonTab = styled(Button)`
    height: 100%;
`;

const BetslipContainer = styled.div<{ borderType?: 'split' | 'whole' }>`
    margin: ${props => (props.borderType === 'whole' ? '0 10px' : undefined)};
    border: ${props => (props.borderType === 'whole' ? '1px solid #000' : undefined)};
    border-top: 0;
    background: #fff;
`;

const LinesPanelContainer = styled.div<{ borderType?: 'split' | 'whole' }>`
    margin: ${props => (props.borderType === 'split' ? '0 10px 10px 10px' : undefined)};
    border: ${props => (props.borderType === 'split' ? '1px solid #000' : undefined)};
    border-top: none;
`;
const LinesPanelBottomContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin-bottom: 10px;
`;

const MinStakeContainer = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 40px;
    margin: 10px;
`;

const MinStake = styled.h6`
    font-size: 16px;
`;

const StyledListScroll = styled.div<{ showAddLinesButton?: boolean }>`
    max-height: ${props => (props.showAddLinesButton ? '300px' : 'calc(90vh)')};
    overflow-y: scroll;
    overflow-x: hidden;

    // Chrome, Edge, Opera, Safari:
    ::-webkit-scrollbar {
        height: 5px;
        width: 5px;
        background: ${props => props.theme.colours.scrollTrackBackground};
    }
    ::-webkit-scrollbar-thumb {
        height: 5px;
        border-radius: 4px;
        background-color: ${props => props.theme.colours.scrollBarBackground};
    }

    // Firefox:
    scrollbar-color: ${props =>
        `${props.theme.colours.scrollBarBackground} ${props.theme.colours.scrollTrackBackground}`}; // bar, track
    scrollbar-width: thin;

    /* min-height: ${props => (props.showAddLinesButton ? '210px' : '')}; */
`;

const BuyLines = styled.div<{ borderType?: 'split' | 'whole' }>`
    display: flex;
    flex-direction: column;
    align-items: center;
    color: #000;
    margin: 0 10px 10px 10px;
    border: 1px solid #000;
    margin: ${props => (props.borderType === 'split' ? '0 10px 10px 10px' : '0')};
    border: ${props => (props.borderType === 'split' ? '1px solid #000' : 'none')};
`;

const LinesCostContainer = styled.div`
    display: flex;
    flex-direction: row;
    text-align: center;
    font-size: 14px;
    font-weight: 500;
    margin: 0 10px 10px;
`;

// const TooltipContainer = styled.div`
//     font-size: 0.75rem;
//     margin: 10px;
//     padding: 10px;
//     background: #fff;
//     border: 2px solid #000;
// `;

const TotalLines = styled.div`
    cursor: default;
    margin: 10px 0;
    font-size: 0.9em;
    float: left;
`;

const Play = styled.div<{ width?: string }>`
    display: flex;
    flex-direction: row;
    width: ${props => props.width};
`;

const PlayNowButton = styled(Button)<{ disablePulse?: boolean }>`
    ${props =>
        !props.disablePulse &&
        `@keyframes pulse {
        0% {
            box-shadow: 0 0 0 0 rgba(0, 195, 8, 0.4);
        }
        70% {
            box-shadow: 0 0 0 10px rgba(0, 195, 8, 0);
        }
        100% {
            box-shadow: 0 0 0 0 rgba(0, 195, 8, 0);
        }
    }
    &:enabled {
        box-shadow: 0 0 0 rgba(0, 195, 8, 0.4);
        animation: pulse 2s infinite;
    }`}
`;

const StyledTermsAndConditionsLink = styled.div<{
    termsBackgroundColour?: string;
}>`
    width: 100%;
    padding-bottom: 10px;
    text-align: end;
    background: ${props =>
        props.termsBackgroundColour ? props.termsBackgroundColour : props.theme.colours.gameMainColour};
`;

const StyledLink = styled.a`
    cursor: pointer;
    text-decoration: underline;
    margin: 10px;
    font-size: 12px;
    text-align: end;
    color: #fff;
    :hover {
        text-decoration: none;
    }
`;

const BetslipHeader4 = styled.h4`
    box-sizing: border-box;
    line-height: 1.1;
    margin-top: 10px;
    margin-bottom: 10px;
    font-size: 14px;
    font-weight: bold;
    color: ${props => props.theme.colours.primaryFont}; // #707070;
    cursor: inherit;
    padding-left: 10px;
`;
