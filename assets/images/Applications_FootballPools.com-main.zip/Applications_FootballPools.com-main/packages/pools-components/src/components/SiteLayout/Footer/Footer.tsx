import React from 'react';
import styled from 'styled-components';

import { ExternalLink } from '../../Common/ExternalLink/ExternalLink';
import { theme } from '../../../settings/theme';
import { breakpoints } from '../../../settings/breakpoints';

const Container = styled.footer`
    margin: 20px 0 0 0;
    padding: 20px 0;
    font-size: 0.813rem;
    background-color: ${theme.colours.footerBackground};
    height: 8rem;
    font-weight: 500;
    -webkit-font-smoothing: antialiased;
    padding-bottom: 96px;
    -moz-osx-font-smoothing: grayscale;
    max-width: 1316px;
    margin: 0 auto;

    ${breakpoints.below('lg')} {
        padding-bottom: 300px;
        text-align: center;
    }

    ${breakpoints.below('sm')} {
        padding-bottom: 365px;
    }
    ${breakpoints.below('xs')} {
        padding-bottom: 425px;
    }
`;

const Section = styled.div`
    display: block;
    justify-content: center;
    flex-wrap: wrap;
    color: #fff;
    align-items: baseline;

    ${breakpoints.below('lg')} {
        align-items: center;
    }

    ${Container} > &:nth-child(1) {
        margin: 20px 10px 5px 10px;
    }
    ${Container} > &:nth-child(2) {
        margin: -35px 10px 20px 10px;

        ${breakpoints.above('lg')} {
            float: right;
        }

        ${breakpoints.below('lg')} {
            margin: 0 !important;
        }

        ${breakpoints.below('sm')} {
            padding-bottom: 15px;
        }
    }
    ${Container} > &:nth-child(3) {
        display: -ms-grid;
        display: grid;
        justify-content: flex-start;
        margin-left: 10px;
    }
    ${Container} > &:nth-child(4) {
        float: right;
        width: 60%;
        padding-left: 60px;
        text-align: right;
        font-size: 0.7em;
        margin: 0px 10px 0px 0px;
        -webkit-box-pack: start;
        -ms-flex-pack: start;
        justify-content: flex-start;
        margin-top: -96px;
        color: #fff;
        line-height: 16px;

        ${breakpoints.below('lg')} {
            width: 50%;
        }
    }
    ${Container} > &:nth-child(5) {
        margin-left: 10px;
        float: right;
        margin-top: 10px;
        margin-bottom: 40px;
    }
    color: ${theme.colours.footerNote};
`;

type ImageProps = { small?: boolean };
const Image = styled.img<ImageProps>`
    height: ${({ small }) => (small ? 20 : 30)}px;
    width: auto;

    margin: 0 2.5px;
`;

const RedExternalLink = styled(ExternalLink)`
    text-decoration: none;
    color: #d32703;

    &:hover {
        text-decoration: underline;
    }
`;

const AgeLimitLink = styled(ExternalLink)`
    display: inline-block;
    border: 3px solid red;
    background: #fff;
    color: #000;
    font-weight: 700;
    font-size: 12px;
    text-align: center;
    width: 30px;
    height: 30px;
    line-height: 23px;
    border-radius: 50%;
    margin-left: 8px;
    text-decoration: none;
`;

const FooterLink = styled(ExternalLink)`
    color: #fff;
    text-decoration: none;
`;

const FooterIcons = styled(Image as any)`
    height: 35px !important;
    width: 100px !important;
    margin-right: 10px;
    margin-top: -10px;

    ${Section} > &:nth-child(1) {
        margin-bottom: 4px;
    }
    ${Section} > &:nth-child(2) {
        margin-top: 6px;
    }
    ${Section} > &:nth-child(3) {
        margin-right: -15px;
        margin-bottom: 2px;
    }
    ${Section} > &:nth-child(4) {
        margin-right: -30px;
        margin-bottom: 2px;
        padding-top: 15px;
    }
`;

const GamIcons = styled(Image as any)`
    height: 25px !important;
`;

interface FooterLink {
    href: string;
    label: string;
}

interface FooterProps {
    footerLinks?: FooterLink[];
}

const Footer = ({ footerLinks }: FooterProps): JSX.Element => (
    <Container>
        <Section>
            <FooterIcons src="https://uat-assets.thepools.com/footer/payment_visa.svg" alt="visa icon" />
            <FooterIcons
                src="https://uat-assets.thepools.com/footer/payment_visa_electron.svg"
                alt="visa electron icon"
            />
            <FooterIcons src="https://uat-assets.thepools.com/footer/payment_mastercard.svg" alt="mastercard icon" />
            <FooterIcons src="https://uat-assets.thepools.com/footer/payment_maestro.svg" alt="maestro icon" />
        </Section>
        <Section>
            <AgeLimitLink href="https://uat-assets.thepools.com/responsible-gaming/">18+</AgeLimitLink>
            <ExternalLink href="http://www.begambleaware.org">
                <GamIcons alt="gambleAware" src="https://uat-assets.thepools.com/footer/gambleAware.png" />
            </ExternalLink>
            <ExternalLink href="http://www.gamblingcommission.gov.uk">
                <GamIcons
                    alt="gamblingcommission"
                    src="https://uat-assets.thepools.com/footer/Gambling-Commission-logo-transparent.png"
                />
            </ExternalLink>
            <ExternalLink href="http://www.ibas-uk.com">
                <GamIcons alt="ibas" src="https://uat-assets.thepools.com/footer/ibas_logo.png" />
            </ExternalLink>
            <ExternalLink href="https://www.gamstop.co.uk/">
                <GamIcons alt="gamstop" src="https://uat-assets.thepools.com/footer/gamstop.png" />
            </ExternalLink>
        </Section>
        <Section>
            {footerLinks &&
                footerLinks.length > 0 &&
                footerLinks.map((link, index) => (
                    <FooterLink key={`FooterLink_${index}`} href={link.href}>
                        {link.label}
                    </FooterLink>
                ))}
        </Section>

        <Section>
            &copy; The Football Pools Limited is a limited company registered in England and Wales with registered
            number 10573569 and
            <br />
            VAT registered number 420 0342 65. Our registered office is at Walton House, 55 Charnock Road, Liverpool,
            England, L67 1AA.
            <br />
            The Football Pools Limited is licensed and regulated by the{' '}
            <RedExternalLink href="https://secure.gamblingcommission.gov.uk/PublicRegister/Search/Detail/48272">
                Gambling Commission
            </RedExternalLink>
            <br />
            (licence numbers: 000-048272-R-326339-003 and 000-048272-N-326340-003)
        </Section>
    </Container>
);

export default Footer;
