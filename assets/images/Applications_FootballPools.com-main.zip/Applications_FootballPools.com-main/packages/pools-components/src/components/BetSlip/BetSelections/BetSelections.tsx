import { BetSlip, GameType } from '@sportech/pools-api';
import getConfig from 'next/config';
import React from 'react';
import styled from 'styled-components';
import { BetSlipCircleList } from '../BetSlipCircleList/BetSlipCircleList';
import { ClearContainer } from '../../Styles/defaultPageStyles';
import { BetSlipCircle } from '../BetSlipCircle/BetSlipCircle';
import { testId } from '../../../utils/functionUtils';
import { breakpoints } from '../../../settings/breakpoints';

const { publicRuntimeConfig } = getConfig();

const editLCSelections = publicRuntimeConfig.EDIT_LC_SELECTIONS === 'true';

export const Container = styled.div`
    display: flex;
    flex-direction: row;
    width: 100%;
`;

export const BetSelectionsContainer = styled.div<{ justifyContent?: string }>`
    display: flex;
    flex: 1;
    overflow: auto;
    align-items: center;
    flex-wrap: nowrap;
    margin: 0;
    width: 100%;
    justify-content: ${props => props.justifyContent};

    p {
        margin-left: 2%;
        margin-right: 2%;
    }
`;

const BetslipBonusText = styled.p`
    color: ${props => props.theme.colours.primaryFont};
    ${breakpoints.below('sm')} {
        font-size: 0.7em;
    }
`;

const PriceContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    /* margin: 10px 0; */
    padding: 0 0 0 5px;
    color: ${props => props.theme.colours.primaryFont};
`;
const HeaderText = styled.div`
    font-size: 8px;
    ${breakpoints.below('sm')} {
        font-size: 0.5em;
    }
`;
const PriceText = styled.div`
    font-size: 16px;
    ${breakpoints.below('sm')} {
        font-size: 0.7em;
    }
`;

const BetLinesContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
`;

export interface BetSelectionsProps {
    bet: BetSlip | undefined;
    game: GameType;
    displayId: boolean;
    handleOnClick?: (id: number, displayId: string) => void;
    selectionsColour?: string;
    bonusSelectionsColour?: string;
    betslipItemSize?: string;
    justifyContent?: string;
    isCurrentSelectedLine?: boolean;
    handleOnClickClear?: (index?: number, isCurrent?: boolean) => void;
    bonusText?: string;
    row?: number;
    hideBonusIfEmpty?: boolean;
    perDrawCost?: string;
    clearIconSrc?: string;
    showCountHeader?: boolean;
    selectionsFontStyle?: 'normal' | 'italic';
    selectionsFontColour?: string;
    selectionsMargin?: string;
}

export const BetSelections = ({
    bet,
    game,
    displayId,
    handleOnClick,
    selectionsColour,
    bonusSelectionsColour,
    betslipItemSize,
    justifyContent,
    isCurrentSelectedLine,
    handleOnClickClear,
    bonusText,
    row,
    hideBonusIfEmpty,
    perDrawCost,
    clearIconSrc,
    showCountHeader,
    selectionsFontStyle,
    selectionsFontColour,
    selectionsMargin,
}: BetSelectionsProps): JSX.Element => {
    const isClover = game === 'lucky-clover';
    const showBonus =
        isClover && (!hideBonusIfEmpty || (bet && bet.bonusNumbers && bet.bonusNumbers.length > 0) || editLCSelections);
    return (
        <Container>
            {perDrawCost && (
                <PriceContainer>
                    <HeaderText>PER GAME</HeaderText>
                    <PriceText>{perDrawCost}</PriceText>
                </PriceContainer>
            )}

            <BetLinesContainer>
                <BetSelectionsContainer justifyContent={justifyContent}>
                    <BetSlipCircleList
                        selection={bet?.numbers}
                        displayId={displayId}
                        row={row || 0}
                        amount={bet?.pick || 0}
                        handleOnClick={handleOnClick}
                        isCurrent={isCurrentSelectedLine}
                        isMobileBetslip
                        ballColor={selectionsColour}
                        isClover={isClover}
                        betslipItemSize={betslipItemSize}
                        showCountHeader={showCountHeader}
                        selectionsFontStyle={selectionsFontStyle}
                        selectionsFontColour={selectionsFontColour}
                        ballMargin={selectionsMargin}
                    />
                    {showBonus && (
                        <React.Fragment>
                            <BetslipBonusText>{bonusText || 'Bonus'}</BetslipBonusText>
                            <BetSlipCircleList
                                selection={bet?.bonusNumbers}
                                displayId
                                row={row || 2}
                                amount={bet?.bonusPick || 0}
                                isCurrent={isCurrentSelectedLine}
                                handleOnClick={handleOnClick}
                                isClover={isClover}
                                ballColor={bonusSelectionsColour}
                                betslipItemSize={betslipItemSize}
                                selectionsFontStyle={selectionsFontStyle}
                                selectionsFontColour={selectionsFontColour}
                                ballMargin={selectionsMargin}
                            />
                        </React.Fragment>
                    )}
                </BetSelectionsContainer>
                {bet && bet.highestRow && bet.highestRow >= 2 ? (
                    <BetSelectionsContainer>
                        <BetSlipCircleList
                            selection={bet.numbers}
                            displayId={displayId}
                            row={1}
                            amount={bet.pick}
                            handleOnClick={handleOnClick}
                            ballColor={selectionsColour}
                            isCurrent={isCurrentSelectedLine}
                            betslipItemSize={betslipItemSize}
                            selectionsFontStyle={selectionsFontStyle}
                            selectionsFontColour={selectionsFontColour}
                            ballMargin={selectionsMargin}
                        />
                    </BetSelectionsContainer>
                ) : (
                    <React.Fragment />
                )}
                {bet && bet.highestRow && bet.highestRow >= 3 ? (
                    <BetSelectionsContainer>
                        <BetSlipCircleList
                            selection={bet.numbers}
                            displayId={displayId}
                            row={2}
                            amount={bet.pick}
                            handleOnClick={handleOnClick}
                            ballColor={selectionsColour}
                            isCurrent={isCurrentSelectedLine}
                            betslipItemSize={betslipItemSize}
                            selectionsFontStyle={selectionsFontStyle}
                            selectionsFontColour={selectionsFontColour}
                            ballMargin={selectionsMargin}
                        />
                    </BetSelectionsContainer>
                ) : (
                    <React.Fragment />
                )}
            </BetLinesContainer>
            {handleOnClickClear && (
                <ClearContainer>
                    <BetSlipCircle
                        isCurrentSelectedLine={isCurrentSelectedLine}
                        {...testId(`Game_BetslipClearButton`)}
                        ballColor="#fff"
                        borderColor="#707070"
                        size={betslipItemSize}
                    >
                        <img
                            onClick={(): void => handleOnClickClear(undefined, isCurrentSelectedLine)}
                            src={clearIconSrc || '/bin.png'}
                            alt="Clear Selections Button"
                        />
                    </BetSlipCircle>
                </ClearContainer>
            )}
        </Container>
    );
};
