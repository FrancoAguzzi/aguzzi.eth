import React, { useContext, forwardRef, useEffect } from 'react';
import styled, { ThemeContext } from 'styled-components';
import { Button } from '../../Common/Button/Button';
import { BetSlipCircleList } from '../BetSlipCircleList/BetSlipCircleList';
import { Offerings, BetSlip, Offering, Competition } from '@sportech/pools-api';

import { SlideOfferingList } from '../../OfferingList/SlideOfferingList';
import { useDispatch } from 'react-redux';
import { openPopup } from '../../../state/popupsSlice';
import { testId, RemoveGameName, getTotalPrice } from '../../../utils/functionUtils';
import { BetSlipCircle } from '../BetSlipCircle/BetSlipCircle';
import '../../../utils/extensionMethods';

export interface BetSlipItemProps {
    betslipselection: BetSlip;
    SelectAmountAction: (id: number, amount: Offering) => void;
    ClearLine: () => void;
    AddLine: () => void;
    ChangeBet: () => void;
    offers: Offerings;
    ShowHDA?: boolean;
    betslipCurrentSelection: BetSlip;
    moreThanOneLine: boolean;
    handleCircleNumberClick: (id: number, displayId: string) => void;
    setCurrentOfferingId: (val: number) => void;
    setShowMore: (val: boolean) => void;
    showMoreValue: boolean;
    currentOfferingId: number;
    showAddLinesButton?: boolean;
    showOfferingList?: boolean;
    'data-testid'?: string;
    isClover: boolean;
    competition: Competition;
    showClearInBetslipCircle?: boolean;
    betslipItemSize?: string;
    ballColor?: string;
    addLineButtonPosition?: 'perLine' | 'adjacentPlay' | 'afterLines';
    betslipItemLabelling?: 'perLine' | 'header';
    showCostPerLine?: boolean;
    clearIconSrc?: string;
    showCountHeader?: boolean;
    backgroundColour?: boolean;
    selectionsFontColour?: string;
    selectionsMargin?: string;
}

export const BetSlipItem = forwardRef<HTMLDivElement, BetSlipItemProps>(
    ({ 'data-testid': testIdValue, ...props }: BetSlipItemProps, ref): JSX.Element => {
        const dispatch = useDispatch();
        const themeContext = useContext(ThemeContext);

        const updateCurrentOfferingId = (item: BetSlip): void => {
            props.setCurrentOfferingId(item.priceID);
            props.setShowMore(false);
        };

        const totalPricenumber = getTotalPrice(props.ShowHDA || false, props.isClover, [props.betslipselection]);
        const totalPriceStr =
            totalPricenumber > 0
                ? `£${totalPricenumber.toLocaleStringCash()}`
                : props.currentOfferingId && props.offers && props.offers.offerings && props.offers.offerings.length > 0
                ? '£' +
                  (
                      (props.offers.offerings.find(o => o.id === props.currentOfferingId)?.pricePerEntry || 0) / 100
                  )?.toLocaleStringCash()
                : undefined;

        useEffect(() => {
            updateCurrentOfferingId(props.betslipCurrentSelection);
        }, [props.betslipselection]);
        return (
            <React.Fragment>
                <StyledListItem
                    ref={props.betslipselection.current ? ref : null}
                    onClick={(): void => {
                        if (!props.betslipselection.current) {
                            if (
                                props.betslipCurrentSelection.pick === props.betslipCurrentSelection.numbers?.length ||
                                props.betslipCurrentSelection.numbers?.length === 0
                            ) {
                                props.ChangeBet();
                            } else {
                                dispatch(openPopup('error_on_change_betslip_line'));
                            }
                        }
                    }}
                    isCurrent={props.betslipselection.current}
                    data-testid={testIdValue}
                    backgroundColour={props.backgroundColour}
                >
                    {props.showOfferingList && props.betslipselection.current && (
                        <SlideOfferingList
                            setShowMore={props.setShowMore}
                            showMoreValue={props.showMoreValue}
                            setCurrentOfferingId={props.setCurrentOfferingId}
                            currentOfferingId={props.currentOfferingId}
                            offerings={props.offers}
                            currentSlip={props.betslipCurrentSelection}
                            selectAmount={props.SelectAmountAction}
                            isClover={props.isClover}
                            isHda={props.ShowHDA as boolean}
                            showCost={false}
                        />
                    )}
                    {!props.isClover && props.betslipItemLabelling === 'perLine' && (
                        <StyledDescAndClearContainer>
                            <StyledListh4>
                                {!props.showAddLinesButton &&
                                    RemoveGameName(
                                        props.offers.offerings.find(x => x.id === props.betslipselection.priceID)
                                            ?.description,
                                    )?.toLocaleUpperCase()}{' '}
                                {props.showAddLinesButton && (
                                    <React.Fragment>
                                        {RemoveGameName(props.betslipselection?.competitionName)}
                                    </React.Fragment>
                                )}
                            </StyledListh4>
                            {props.showCostPerLine && totalPriceStr && (
                                <StyledCostPerLine>{totalPriceStr}</StyledCostPerLine>
                            )}
                        </StyledDescAndClearContainer>
                    )}
                    <StyledNumberedList isClover={props.isClover}>
                        <BetSelectionsLinesContainer>
                            <Container>
                                <BetSlipCircleList
                                    selection={props.betslipselection.numbers}
                                    displayId={!props.ShowHDA}
                                    row={0}
                                    amount={props.betslipselection.pick}
                                    handleOnClick={props.handleCircleNumberClick}
                                    isCurrent={props.betslipselection.current}
                                    isClover={props.isClover}
                                    ballColor={props.ballColor}
                                    betslipItemSize={props.betslipItemSize}
                                    showCountHeader={props.showCountHeader}
                                    selectionsFontColour={props.selectionsFontColour}
                                />
                                {props.isClover && (
                                    <React.Fragment>
                                        <p>Bonus</p>
                                        <BetSlipCircleList
                                            selection={props.betslipselection.bonusNumbers}
                                            displayId={!props.ShowHDA}
                                            row={2}
                                            amount={props.betslipselection.bonusPick}
                                            handleOnClick={props.handleCircleNumberClick}
                                            isCurrent={props.betslipselection.current}
                                            isClover={props.isClover}
                                            ballColor="#E0AC00"
                                            betslipItemSize={props.betslipItemSize}
                                        />
                                    </React.Fragment>
                                )}
                            </Container>
                            {props.betslipselection.highestRow && props.betslipselection.highestRow >= 2 ? (
                                <Container>
                                    <BetSlipCircleList
                                        selection={props.betslipselection.numbers}
                                        displayId={!props.ShowHDA}
                                        row={1}
                                        amount={props.betslipselection.pick}
                                        handleOnClick={props.handleCircleNumberClick}
                                        ballColor={props.ballColor}
                                        isCurrent={props.betslipselection.current}
                                        betslipItemSize={props.betslipItemSize}
                                        selectionsFontColour={props.selectionsFontColour}
                                    />
                                </Container>
                            ) : (
                                <React.Fragment />
                            )}
                            {props.betslipselection.highestRow && props.betslipselection.highestRow >= 3 ? (
                                <Container>
                                    <BetSlipCircleList
                                        selection={props.betslipselection.numbers}
                                        displayId={!props.ShowHDA}
                                        row={2}
                                        amount={props.betslipselection.pick}
                                        handleOnClick={props.handleCircleNumberClick}
                                        ballColor={props.ballColor}
                                        isCurrent={props.betslipselection.current}
                                        betslipItemSize={props.betslipItemSize}
                                        selectionsFontColour={props.selectionsFontColour}
                                    />
                                </Container>
                            ) : (
                                <React.Fragment />
                            )}
                        </BetSelectionsLinesContainer>
                        <ClearContainer>
                            {props.betslipselection.current &&
                                (props.showClearInBetslipCircle ? (
                                    <BetSlipCircle
                                        isCurrentSelectedLine={props.betslipselection.current}
                                        size={props.betslipItemSize}
                                        {...testId(
                                            `Game_BetslipClearButton${testIdValue?.replace('Game_BetslipItem', '')}`,
                                        )}
                                        ballColor="#fff"
                                        borderColor="#707070"
                                    >
                                        <img
                                            onClick={(): void => props.ClearLine()}
                                            src={props.clearIconSrc || '/bin.png'}
                                            alt="Clear Selections Button"
                                        />
                                    </BetSlipCircle>
                                ) : (
                                    <StyledListClear
                                        onClick={props.ClearLine}
                                        {...testId(
                                            `Game_BetslipClearButton${testIdValue?.replace('Game_BetslipItem', '')}`,
                                        )}
                                    >
                                        <img src={props.clearIconSrc || '/bin.png'} alt="Clear Selections Button" />
                                    </StyledListClear>
                                ))}
                        </ClearContainer>
                    </StyledNumberedList>

                    {props.betslipselection.current &&
                        props.showAddLinesButton &&
                        props.addLineButtonPosition === 'perLine' && (
                            <DivButtonContainer>
                                <Button
                                    onClick={(): void => {
                                        props.AddLine();
                                    }}
                                    disabled={props.betslipselection.pick !== props.betslipselection.numbers?.length}
                                    bgColor={themeContext.colours.gameMainColour}
                                    width="100%"
                                    height="auto"
                                    padding="0.75em 1em"
                                    textColor="#fff"
                                    {...testId('Game_AddLineButton')}
                                >
                                    ADD LINE
                                </Button>
                            </DivButtonContainer>
                        )}
                </StyledListItem>
            </React.Fragment>
        );
    },
);

type StyledListItemProps = {
    isCurrent: boolean;
    backgroundColour?: boolean;
};

const Container = styled.div`
    display: flex;
    flex: 1;
    overflow: auto;
    align-items: center;
    flex-wrap: nowrap;
    margin: 0;
    width: 100%;

    p {
        margin-left: 2%;
        margin-right: 2%;
    }
    @media (max-width: 1375px) {
        li {
            width: 22px;
            height: 22px;
        }
    }
`;

const ClearContainer = styled.div<{ padding?: string }>`
    padding: ${props => props.padding || '5px'};
    display: flex;
    align-items: center;
    justify-content: center;
    @media (max-width: 1375px) {
        li {
            width: 22px;
            height: 22px;
            img {
                width: 14px;
                height: 18px;
            }
        }
    }
    align-self: flex-start;
`;

const StyledListItem = styled.div<StyledListItemProps>`
    margin-bottom: 5px;
    cursor: ${(props): string => (props.isCurrent ? 'default' : 'pointer')};
    padding: 0;
    width: 100%;
    background-color: ${props => (props.backgroundColour ? '#E6E9F3' : '#fff')};
`;

const StyledDescAndClearContainer = styled.div`
    color: ${props => (props.theme.colours.primaryFont ? props.theme.colours.primaryFont : '#fff')};
    h4 {
        width: 65%;
        display: inline-block;
        font-weight: normal;
        font-size: 16px;
    }

    a {
        margin: 10px 10px 10px 0;
        display: inline-block;
    }

    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
`;

const StyledCostPerLine = styled.div`
    font-size: 16px;
    padding-right: 10px;
`;

const StyledListClear = styled.a`
    display: block;
    font-size: 0.85em;
    line-height: 1em;
    text-align: right;
    cursor: pointer;
    float: right;
    &:hover {
        text-decoration: none;
    }

    img {
        height: 16px;
        width: 16px;
    }
`;
const StyledListh4 = styled.h4`
    box-sizing: border-box;
    line-height: 1.1;
    margin-top: 10px;
    margin-bottom: 10px;
    font-size: 14px;
    font-weight: bold;
    color: ${props => props.theme.colours.primaryFont}; // #707070;
    cursor: inherit;
    padding-left: 10px;
`;

type StyledNumberedListProps = {
    isClover: boolean;
};

const StyledNumberedList = styled.div<StyledNumberedListProps>`
    display: flex;
    justify-content: flex-start;
    align-items: center;
    flex-direction: row; // ${props => (props.isClover ? 'row' : 'column')};
    flex: 1;
    margin: 0 0 0 3px;
    padding-bottom: 5px;
`;

const BetSelectionsLinesContainer = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
    width: 100%;
    flex: 1;
`;

const DivButtonContainer = styled.div`
    display: inline-block;
    width: 95%;
    margin: 10px 2.5%;
`;

BetSlipItem.displayName = 'BetSlipItem';

export default BetSlipItem;
