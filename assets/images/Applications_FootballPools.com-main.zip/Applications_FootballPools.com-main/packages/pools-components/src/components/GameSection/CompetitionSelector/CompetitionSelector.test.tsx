import React from 'react';
import { CompetitionSelector } from './CompetitionSelector';
import { BetSlipSlice, Competition } from '@sportech/pools-api';
import { renderWithTheme } from '../../../testing/renderWithTheme';

const ChangeCompetitions = jest.fn();
const openErrorOnBetslipLinePopup = jest.fn();

const betslip: BetSlipSlice = {
    ClassicPools: [],
    Premier6: [],
    GoalRush8: [],
    Premier10: [],
    Jackpot12: [],
    LuckyClover: [],
};
describe('CompetitionSelector', () => {
    it('should render', async () => {
        const competitions: Competition[] = [
            {
                datumDate: new Date().toISOString(),
                datumDateWithBuffer: new Date().toISOString(),
                description: 'test',
                fixtures: [],
                id: 1234,
                number: 12,
                poolSize: { type: '', value: 0 },
                state: 'Selling',
            },
        ];
        betslip.ClassicPools.push({
            current: true,
            competitionId: 1234,
            pick: 10,
            price: 100,
            priceID: 5,
            bonusPick: 0,
            bonusPrice: 0,
            bonusPriceId: 0,
            bonusNumbers: [],
        });
        const { container } = renderWithTheme(
            <CompetitionSelector
                currentCompetition={1234}
                competitions={competitions}
                ChangeCompetitions={ChangeCompetitions}
                BetSlipSelection={betslip.ClassicPools}
                openErrorOnBetslipLinePopup={openErrorOnBetslipLinePopup}
            />,
        );

        expect(container).toMatchSnapshot();
    });
});
