import {
    BetSlip,
    Competition,
    Dividends,
    FixtureResult,
    GameType,
    NumbersSelected,
    Offering,
    Offerings,
    Wager,
} from '@sportech/pools-api';
import { ViewLinesCurrent } from '../components/BetSlip/ViewLines/ViewLines';
import { goalRushTheme, Jackpot12theme, LuckyClovertheme, Prem10theme, Premier6theme, theme } from '../settings/theme';

export const convertNumbersSelectedToString = (numbers: NumbersSelected[], isHda?: boolean): string => {
    let ret = '';
    if (!isHda) {
        if (numbers != null && numbers.length > 0) {
            for (let i = 0; i < numbers.length; i++) {
                if (numbers[i].Id < 10) {
                    ret += `0${numbers[i].Id}`;
                } else {
                    ret += numbers[i].Id;
                }
            }
        }
    } else {
        if (numbers != null && numbers.length > 0) {
            for (let i = 0; i < numbers.length; i++) {
                ret += `${numbers[i].selections.join('')},`;
            }
            ret = ret.slice(0, -1).toLocaleLowerCase();
        }
    }
    return ret;
};

export const convertNumbersSelectedToArray = (numbers: NumbersSelected[], isHda?: boolean): string[] => {
    const ret: string[] = [];
    if (!isHda) {
        if (numbers != null && numbers.length > 0) {
            for (let i = 0; i < numbers.length; i++) {
                ret.push(numbers[i].Id.toString());
            }
        }
    } else if (numbers && numbers.length > 0) {
        for (let i = 0; i < numbers.length; i++) {
            ret.push(numbers[i].selections.join('').toString().toLocaleLowerCase());
        }
    }
    return ret;
};

export const ConvertStringToArray = (list: string | string[], nothda: boolean): NumbersSelected[] => {
    const ret: NumbersSelected[] = [];

    let stringArray: string[] = [];
    if (typeof list === 'string') {
        if (!nothda) {
            stringArray = list.split(',');
        }
    } else {
        stringArray = list;
    }

    if (stringArray && stringArray.length > 0) {
        stringArray.forEach((x, i) => {
            if (!nothda) {
                ret.push({
                    Id: i + 1,
                    rows: x.length,
                    selections: x.toUpperCase().split(''),
                });
            } else {
                ret.push({
                    Id: parseInt(x),
                    rows: 1,
                    selections: ['D'],
                });
            }
        });
    }

    return ret;
};

export const getTotalPrice = (
    isHDA: boolean,
    isClover: boolean,
    linesList: BetSlip[],
    format?: 'pence' | 'pounds',
    offers?: Offering[],
): number => {
    let price = 0;
    const divisor = format && format === 'pence' ? 1 : 100;
    if (isHDA) {
        linesList.forEach(element => {
            const current =
                element.numbers?.reduce((sum, num) => {
                    return sum * num.selections.length;
                }, 1) || 0;
            if (element.pick === element.numbers?.length) {
                price += current * element.price;
            }
        });
        price = price / divisor;
    } else {
        const linesToInclude =
            offers && isClover
                ? linesList.filter(l => {
                      const offerForLine = offers.find(o => o.id === l.priceID);
                      if (offerForLine) {
                          return offerForLine.mustIncludeBonus
                              ? l.pick === l.numbers?.length && l.bonusPick === l.bonusNumbers?.length
                              : l.pick === l.numbers?.length;
                      }
                      return true;
                  })
                : linesList;

        price = isClover
            ? linesToInclude?.filter(x => x.pick === x.numbers?.length).reduce((a, b) => a + (b.price || 0), 0) /
                  divisor +
              linesToInclude
                  ?.filter(x => x.pick === x.numbers?.length && x.bonusPick === x.bonusNumbers?.length)
                  .reduce((a, b) => a + (b.bonusPrice || 0), 0) /
                  divisor
            : linesToInclude?.filter(x => x.pick === x.numbers?.length).reduce((a, b) => a + (b.price || 0), 0) /
              divisor;
    }
    return price;
};

export const getTotalLines = (isHDA: boolean, linesList: BetSlip[]): number => {
    let lines = linesList?.filter(x => x.pick === x.numbers?.length).length;
    if (isHDA) {
        lines = 0;
        linesList.forEach(element => {
            const current =
                element.numbers?.reduce((sum, num) => {
                    return sum * num.selections.length;
                }, 1) || 0;
            if (element.pick === element.numbers?.length) {
                lines += current;
            }
        });
    }
    return lines;
};

export function isString(value: unknown): value is string {
    return typeof value === 'string';
}

export function toGameName<T>(appGameType: string): T {
    let ret = 'ClassicPools';
    switch (appGameType) {
        case 'classic-pools': {
            ret = 'ClassicPools';
            break;
        }
        case 'goal-rush': {
            ret = 'GoalRush8';
            break;
        }
        case 'jackpot-12': {
            ret = 'Jackpot12';
            break;
        }
        case 'premier-10': {
            ret = 'Premier10';
            break;
        }
        case 'premier-6': {
            ret = 'Premier6';
            break;
        }
        case 'lucky-clover': {
            ret = 'LuckyClover';
            break;
        }
    }
    return (ret as unknown) as T;
}

export function toGameTypeToPretty(appGameType: GameType): string {
    let ret = 'ClassicPools';
    switch (appGameType) {
        case 'classic-pools': {
            ret = 'Classic Pools';
            break;
        }
        case 'goal-rush': {
            ret = 'Goal Rush 8';
            break;
        }
        case 'jackpot-12': {
            ret = 'Jackpot 12';
            break;
        }
        case 'premier-10': {
            ret = 'Premier 10';
            break;
        }
        case 'premier-6': {
            ret = 'Premier 6';
            break;
        }
        case 'lucky-clover': {
            ret = 'Lucky Clover';
            break;
        }
    }
    return ret;
}

export const getGameTypesWithThemes = (): {
    gameType: GameType;
    gameThemeMainColor: string;
    gameThemMainTextColor: string;
}[] => {
    return [
        {
            gameType: 'classic-pools',
            gameThemeMainColor: theme.colours.gameMainColour,
            gameThemMainTextColor: theme.colours.gameMainColourText,
        },
        {
            gameType: 'goal-rush',
            gameThemeMainColor: goalRushTheme.colours.gameMainColour,
            gameThemMainTextColor: goalRushTheme.colours.gameMainColourText,
        },
        {
            gameType: 'premier-6',
            gameThemeMainColor: Premier6theme.colours.gameMainColour,
            gameThemMainTextColor: Premier6theme.colours.gameMainColourText,
        },
        {
            gameType: 'premier-10',
            gameThemeMainColor: Prem10theme.colours.gameMainColour,
            gameThemMainTextColor: Prem10theme.colours.gameMainColourText,
        },
        {
            gameType: 'jackpot-12',
            gameThemeMainColor: Jackpot12theme.colours.gameMainColour,
            gameThemMainTextColor: Jackpot12theme.colours.gameMainColourText,
        },
        {
            gameType: 'lucky-clover',
            gameThemeMainColor: LuckyClovertheme.colours.gameMainColour,
            gameThemMainTextColor: LuckyClovertheme.colours.gameMainColourText,
        },
    ];
};

export const getAfterFlexWrapMaxWidth = (
    numberOfColumns: number,
    widthOfOtherFlexItems: number,
    numberOfFlexItems: number,
): string => {
    return (numberOfColumns - (numberOfFlexItems % numberOfColumns)) * widthOfOtherFlexItems + '%';
};

export const convertWagerToBetSlipSelection = (
    currentComp: Competition,
    currentOffering: Offering,
    currentWager: Wager,
    currentWagerSelectionArray: NumbersSelected[],
    currentWagerBonusSelectionArray: NumbersSelected[],
): BetSlip | undefined => {
    let ret: BetSlip | undefined;
    if (currentWager !== undefined && currentComp !== undefined && currentOffering !== undefined) {
        ret = {
            competitionId: currentComp?.id as number,
            competitionName: currentComp?.description,
            pick: currentOffering?.maximumSelections as number,
            bonusPick: currentOffering?.bonusMaximumSelections as number,
            current: true,
            price: currentOffering?.pricePerEntry as number,
            bonusPrice: currentOffering?.bonusPricePerEntry as number,
            priceID: currentOffering?.id as number,
            bonusPriceId: currentOffering?.bonusId as number,
            numbers: currentWagerSelectionArray,
            bonusNumbers: currentWagerBonusSelectionArray,
        };
    }
    return ret;
};

export const RemoveGameName = (prams: string | undefined): string | undefined => {
    return prams
        ?.replace('Soccer 6', '')
        .replace('Soccer6', '')
        .replace('Goal Rush 8', '')
        .replace('GoalRush8', '')
        .replace('Premier 10', '')
        .replace('Premier10', '')
        .replace('Jackpot 12', '')
        .replace('Jackpot12', '');
};

export const replaceGameName = (params: string | undefined): string | undefined => {
    return params
        ?.replace('Soccer 6', 'Premier 6')
        .replace('Soccer6', 'Premier6')
        .replace('Goal Rush 8', 'Goal Rush')
        .replace('GoalRush8', 'GoalRush')
        .replace('Jackpot 12', 'Premier 12')
        .replace('Jackpot12', 'Premier12');
};

export const getIdFromWager = (wager?: Wager): number => {
    if (wager) {
        return wager.wagerId ? (wager.wagerId as number) : (wager.lineId as number);
    }
    return -1;
};

export const testId = (value: string): { 'data-testid': string } => {
    return { 'data-testid': value };
};

// export const getHref = (page: string, router?: NextRouter): string => {
//     if (router == undefined) {
//         router = useRouter();
//     }

//     return `/${page}${
//         router.asPath !== '/'
//             ? router.asPath.replace(/\/results|\/history|\/leaderboards/gi, '')
//             : ''
//     }`;
// };

export const groupBy = <K, V>(list: Array<V>, keyGetter: (input: V) => K): Map<K, Array<V>> => {
    const map = new Map<K, Array<V>>();
    list.forEach(item => {
        const key = keyGetter(item);
        const collection = map.get(key);
        if (!collection) {
            map.set(key, [item]);
        } else {
            collection.push(item);
        }
    });
    return map;
};

export const getPoints = (
    fixtures: FixtureResult[],
    ishda: boolean,
    isClassic: boolean,
    wager?: NumbersSelected[],
): number | undefined => {
    if (fixtures === undefined) {
        return;
    }
    let pointsTotal = 0;
    if (ishda) {
        pointsTotal = 0;
        fixtures.forEach(w => {
            if (w.scores?.fullTime !== null && w.scores?.fullTime !== undefined) {
                const currentWager = wager?.find(x => x.Id === w.number);
                if (currentWager !== undefined) {
                    if (w.scores.fullTime.home > w.scores.fullTime.away) {
                        if (currentWager?.selections.includes('H')) {
                            pointsTotal++;
                        }
                    } else if (w.scores.fullTime.home < w.scores.fullTime.away) {
                        if (currentWager?.selections.includes('A')) {
                            pointsTotal++;
                        }
                    } else {
                        if (currentWager?.selections.includes('D') && !w.scores.isVoid) {
                            pointsTotal++;
                        }
                    }
                }
                if (w.scores?.isVoid) {
                    pointsTotal++;
                }
            }
        });
        return pointsTotal;
    } else {
        const wagerPointsArray = isClassic
            ? fixtures
                  .map(fixture => {
                      return fixture.points;
                  })
                  .sort((num1, num2) => num2 - num1)
                  .slice(0, 8)
            : fixtures
                  .map(fixture => {
                      return fixture.points;
                  })
                  .sort((num1, num2) => num1 - num2);
        return wagerPointsArray.reduce((total, item) => (item ? total + item : total), 0);
    }
};

export const getHdaResult = (fixture: FixtureResult): string | undefined => {
    if (!fixture?.scores?.fullTime) {
        return;
    }
    const { home, away } = fixture.scores.fullTime;
    if (home > away) {
        return 'H';
    } else if (home < away) {
        return 'A';
    } else {
        return 'D';
    }
};

export const getWinningPoints = (dividends: Dividends): number | false => {
    return (
        dividends &&
        dividends.dividends.length > 0 &&
        dividends.dividends.filter(x => x.level !== 0).sort((a, b) => a.level - b.level)[0].level
    );
};

export const getCompetitionIdLuckyClover = (pickNumber: number, compIds: { [key: string]: number }): number => {
    let ret = compIds[41];
    switch (pickNumber) {
        case 6: {
            ret = compIds[44];
            break;
        }
        case 5: {
            break;
        }
        case 4: {
            ret = compIds[40];
            break;
        }
        case 3: {
            ret = compIds[39];
            break;
        }
        case 2: {
            ret = compIds[38];
            break;
        }
    }
    return ret;
};

export type GameCategory = 'singles' | 'hda' | 'clover';

export const getGameCategory = (gameName: GameType): GameCategory => {
    let ret: GameCategory = 'singles';
    switch (gameName) {
        case 'classic-pools': {
            ret = 'singles';
            break;
        }
        case 'goal-rush': {
            ret = 'singles';
            break;
        }
        case 'jackpot-12': {
            ret = 'hda';
            break;
        }
        case 'premier-10': {
            ret = 'hda';
            break;
        }
        case 'premier-6': {
            ret = 'hda';
            break;
        }
        case 'lucky-clover': {
            ret = 'clover';
            break;
        }
        default: {
            ret = 'singles';
        }
    }

    return ret;
};

export const isCPorGR = (typeOfGame: GameCategory): boolean => {
    return typeOfGame === 'singles';
};

export const isClover = (typeOfGame: GameCategory): boolean => {
    return typeOfGame === 'clover';
};

export const isHDA = (typeOfGame: GameCategory): boolean => {
    return typeOfGame === 'hda';
};

export const isNumbers = (typeOfGame: GameCategory): boolean => {
    return isClover(typeOfGame) || isCPorGR(typeOfGame);
};

export const classicPoolsPlansToShowPointsFor = [5, 10, 12];

/**
 * Get a competition from a competition id.
 * Checks competitionIds dictionary for clover competitions.
 * @param id
 * @param competitions
 */
export const getCompetitionFromId = (id?: number, competitions?: Competition[]): Competition | undefined => {
    let ret: Competition | undefined;
    if (id && competitions) {
        ret = competitions.find(c => c.id === id);
        if (!ret && competitions.some(c => c.competitionIds)) {
            for (let i = 0; i < competitions.length; i++) {
                const competition = competitions[i];
                if (competition.competitionIds) {
                    const index = Object.keys(competition.competitionIds).findIndex(
                        k => competition.competitionIds && competition.competitionIds[k] === id,
                    );
                    if (index > -1) {
                        ret = competition;
                        break;
                    }
                }
            }
        }
    }
    return ret;
};

export const isCurrentViewLines = (
    wager: Wager,
    competitions?: Competition[],
    viewLinesCurrent?: ViewLinesCurrent,
): boolean => {
    let ret = getIdFromWager(wager) === viewLinesCurrent?.id;
    if (ret && wager.competitionId && viewLinesCurrent?.competitionId) {
        // ret =
        //     getCompetitionFromId(wager.competitionId, competitions)?.id ===
        //     viewLinesCurrent?.competitionId;
        ret = wager.competitionId === viewLinesCurrent.competitionId;
    }
    return ret;
};

export const getWagersSortedByCompetition = (
    game: GameType,
    wagers?: Wager[],
    competitions?: Competition[],
): {
    wager: Wager;
    betsTypeDescription?: string;
    showCompetitionInfo?: boolean;
}[] => {
    // Sort wagers by competition:

    const competitionsByDate = competitions?.sort((a, b) => {
        return new Date(a.datumDateWithBuffer).getTime() - new Date(b.datumDateWithBuffer).getTime();
    });

    const ret: {
        wager: Wager;
        betsTypeDescription?: string;
        showCompetitionInfo?: boolean;
    }[] = [];
    competitionsByDate?.forEach(c => {
        const wagersForCompetition = wagers?.filter(w => getCompetitionFromId(w.competitionId, [c])?.id === c.id);
        const walletWagers = wagersForCompetition?.filter(
            w => w.paymentType === 'wallet' || w.paymentType === 'ot_card',
        );
        const subscriptionWagers = wagersForCompetition?.filter(
            w => w.paymentType !== 'wallet' && w.paymentType !== 'ot_card',
        );
        const orderedWagers: Wager[] = [];
        if (walletWagers && walletWagers.length > 0) {
            orderedWagers.push(...walletWagers);
        }
        if (subscriptionWagers && subscriptionWagers.length > 0) {
            orderedWagers.push(...subscriptionWagers);
        }
        let firstWallet = true;
        let firstSubscription = true;
        orderedWagers.forEach(w => {
            const wagerWithDetail: {
                wager: Wager;
                betsTypeDescription?: string;
                showCompetitionInfo?: boolean;
            } = { wager: w };
            if ((w.paymentType === 'wallet' || w.paymentType === 'ot_card') && firstWallet) {
                firstWallet = false;
                wagerWithDetail.betsTypeDescription = `Other lines ${game !== 'lucky-clover' ? '(not editable)' : ''}`;
                wagerWithDetail.showCompetitionInfo = true;
            } else if (w.paymentType !== 'wallet' && w.paymentType !== 'ot_card' && firstSubscription) {
                firstSubscription = false;
                wagerWithDetail.betsTypeDescription = `Subscription lines ${
                    game !== 'lucky-clover' ? '(editable)' : ''
                }`;
                if (firstWallet) {
                    wagerWithDetail.showCompetitionInfo = true;
                }
            }

            ret.push(wagerWithDetail);
        });
    });
    return ret;
};

/**
 * Enable play button when selections match offer constraints.
 * If bonus numbers are selected, they must equal offer bonus selections.
 * @param betslipselection
 * @param offers
 * @param minimumCost
 * @param totalCost
 */
export const isPlayEnabled = (
    betslipselection: Array<BetSlip>,
    offers: Offerings,
    minimumCost?: number,
    totalCost?: number,
): boolean => {
    let ret = false;
    for (let i = 0; i < betslipselection.length; i++) {
        const bet = betslipselection[i];
        const offer = offers.offerings.find(o => o.id === bet?.priceID);
        if (bet && offer) {
            ret =
                (bet.numbers?.length === 0 && i > 0) ||
                (bet.pick === bet.numbers?.length &&
                    (!offer.mustIncludeBonus ||
                        (offer.mustIncludeBonus && bet.bonusPick === bet.bonusNumbers.length)) &&
                    (!bet.bonusNumbers || bet.bonusNumbers.length <= 0 || bet.bonusNumbers.length === bet.bonusPick));
            if (!ret) {
                return false;
            }
        }
    }
    if (minimumCost && minimumCost > 0 && totalCost) {
        ret = totalCost >= minimumCost;
    }
    return ret;
};

export const isAllLinesMax = (betslipselection: Array<BetSlip>, offers: Offerings, maximumLines: number): boolean => {
    if (betslipselection.length !== maximumLines) return false;
    let ret = true;
    for (let i = 0; i < betslipselection.length; i++) {
        const bet = betslipselection[i];
        const offer = offers.offerings.find(o => o.id === bet?.priceID);
        if (bet && offer) {
            ret =
                bet.pick === bet.numbers?.length &&
                (!offer.mustIncludeBonus || (offer.mustIncludeBonus && bet.bonusPick === bet.bonusNumbers.length)) &&
                (!bet.bonusNumbers || bet.bonusNumbers.length <= 0 || bet.bonusNumbers.length === bet.bonusPick);
            if (!ret) {
                return false;
            }
        }
    }
    return ret;
};
