declare global {
    interface Number {
        toLocaleStringCash(): string;
    }
}

Number.prototype.toLocaleStringCash = function (): string {
    return Number(this).toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
};

export {};
