import React from 'react';
import { render, RenderResult } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { theme } from '../settings/theme';

export const withTheme = (ui: React.ReactElement): JSX.Element => <ThemeProvider theme={theme}>{ui}</ThemeProvider>;

export const renderWithTheme = (ui: React.ReactElement): RenderResult => render(withTheme(ui));
