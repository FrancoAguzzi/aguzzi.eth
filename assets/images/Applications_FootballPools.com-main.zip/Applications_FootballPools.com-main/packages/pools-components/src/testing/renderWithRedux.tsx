import React from 'react';
import { RenderResult, render } from '@testing-library/react';
import { Provider } from 'react-redux';
import { RootState } from '../state/rootReducer';
import { AppStore, makeStore } from '../state/store';

type renderResult = RenderResult & { store: AppStore };
export const renderWithRedux = (
    ui: React.ReactElement,
    initialState: RootState,
    store: AppStore = makeStore(initialState),
): renderResult => ({
    ...render(<Provider store={store}>{ui}</Provider>),
    store,
});
