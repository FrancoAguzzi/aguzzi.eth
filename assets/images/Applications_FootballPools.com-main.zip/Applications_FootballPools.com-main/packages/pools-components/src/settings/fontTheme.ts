import { DefaultTheme } from 'styled-components';

type PropType<TObj, TProp extends keyof TObj> = TObj[TProp];

type FontTheme = PropType<DefaultTheme, 'fonts'>;

export const fontTheme: FontTheme = {
    gameButtonFontWeight: '100',
    primaryFontFamily: '"Montserrat", sans-serif',
};
