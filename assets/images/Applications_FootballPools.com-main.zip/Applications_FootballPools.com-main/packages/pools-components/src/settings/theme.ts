import { DefaultTheme } from 'styled-components';
import { breakpointValues } from './breakpoints';
import {
    colourValues,
    goalRushColourValues,
    Premier6colourValues,
    Prem10colourValues,
    Jackpot12colourValues,
    LuckyClovercolourValues,
} from './colours';

declare module 'styled-components' {
    export interface DefaultTheme {
        breakpoints: {
            xxs: number;
            xs: number;
            sm: number;
            overlay?: number;
            md: number;
            lg: number;
            l: number;
            xl: number;
        };
        colours: {
            inputActive: string;
            inputError: string;
            inputValid: string;
            buttonActive: string;
            buttonDisabled: string;
            buttonLogin: string;
            primary: string;
            disabled: string;
            primaryFont: string;
            footerBackground: string;
            footerFont: string;
            footerNote: string;
            gameMainColour: string;
            gameMainColourText: string;
            gameSecondaryColour?: string;
            gameButtonBackground: string;
            gameButtonSelectedBackground: string;
            gameButtonHighlightedBackground: string;
            gameButtonFont: string;
            gameButtonSelectedFont: string;
            betslipItemColour: string;
            betslipItemSelectedColour: string;
            betslipItemFontColour: string;
            betslipItemSelectedFontColour: string;
            betslipListMobileBackgroundColour?: string;
            buttonConfirm?: string;
            buttonCancel?: string;
            betslipMobileButtonDisabled?: string;
            scrollBarBackground?: string;
            scrollTrackBackground?: string;
            ballColour: string;
            matchCardBackground?: string;
            matchCardBorder?: string;
            mobileLinesButton?: string;
            mobileLinesButtonDisabled?: string;
            mobilePlayButton?: string;
            mobilePlayDisabledButton?: string;
            mobileAddLinesButton?: string;
            mobileAddLinesButtonDisabled?: string;
            streaksPrizeLevelBackground?: string;
            streaksPrizeLevelText?: string;
            streaksPrizeLevelTextHighlight?: string;
            streaksBallColour?: string;
            streaksBallColourNotSelected?: string;
            streaksLineSelectActive?: string;
            streaksLineSelectNotActibe?: string;
            accountHistoryTableHeader?: string;
            accountHistoryTableCell?: string;
            accountHistoryDetailsTableHeader?: string;
        };
        fonts?: {
            gameButtonFontWeight?: string;
            primaryFontFamily?: string;
        };
    }
}

export const theme: DefaultTheme = {
    breakpoints: breakpointValues,
    colours: colourValues,
};
export const goalRushTheme: DefaultTheme = {
    breakpoints: breakpointValues,
    colours: goalRushColourValues,
};
export const Premier6theme: DefaultTheme = {
    breakpoints: breakpointValues,
    colours: Premier6colourValues,
};
export const Prem10theme: DefaultTheme = {
    breakpoints: breakpointValues,
    colours: Prem10colourValues,
};
export const Jackpot12theme: DefaultTheme = {
    breakpoints: breakpointValues,
    colours: Jackpot12colourValues,
};
export const LuckyClovertheme: DefaultTheme = {
    breakpoints: breakpointValues,
    colours: LuckyClovercolourValues,
};
