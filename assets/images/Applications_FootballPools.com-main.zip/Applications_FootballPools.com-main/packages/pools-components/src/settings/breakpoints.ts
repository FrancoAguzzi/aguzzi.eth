import { ThemeProps, DefaultTheme } from 'styled-components';

type PropType<TObj, TProp extends keyof TObj> = TObj[TProp];

type Breakpoints = PropType<DefaultTheme, 'breakpoints'>;

export const breakpointValues: Breakpoints = {
    xxs: 320,
    xs: 360,
    sm: 600,
    md: 960,
    lg: 1024,
    l: 1600,
    xl: 1920,
};

export const breakpoints = {
    above: (breakpoint: keyof Breakpoints) => ({ theme }: ThemeProps<DefaultTheme>): string =>
        `@media (min-width:${theme.breakpoints[breakpoint]}px)`,
    below: (breakpoint: keyof Breakpoints) => ({ theme }: ThemeProps<DefaultTheme>): string =>
        `@media (max-width:${theme.breakpoints[breakpoint]}px)`,
};
