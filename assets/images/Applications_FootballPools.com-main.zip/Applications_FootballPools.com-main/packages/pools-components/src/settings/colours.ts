import { DefaultTheme } from 'styled-components';

type PropType<TObj, TProp extends keyof TObj> = TObj[TProp];

type Colours = PropType<DefaultTheme, 'colours'>;

export const colourValues: Colours = {
    primary: '#010d68',
    disabled: '#919191',
    primaryFont: '#383838',
    inputActive: '#0070f3',
    inputError: '#ff0000',
    inputValid: '#099b01',
    buttonActive: '#010d68',
    buttonDisabled: '#919191',
    buttonLogin: '#0070f3',
    footerBackground: '#363636',
    footerFont: '#393d41',
    footerNote: '#7a7d85',
    gameMainColour: '#00108b',
    gameMainColourText: 'fff',
    gameButtonBackground: '#fff',
    gameButtonSelectedBackground: '#00108b',
    gameButtonHighlightedBackground: '#0070f3',
    gameButtonFont: '#000',
    gameButtonSelectedFont: '#fff',
    betslipItemColour: '#363636;',
    betslipItemSelectedColour: '#00108b',
    betslipItemFontColour: '#000',
    betslipItemSelectedFontColour: '#fff',
    betslipListMobileBackgroundColour: '#e5e5e5',
    buttonCancel: '#0070f3',
    buttonConfirm: '#099b01',
    betslipMobileButtonDisabled: '#0f1a72',
    scrollBarBackground: '#888',
    scrollTrackBackground: '#f1f1f1',
    ballColour: '#000d68',
    mobilePlayDisabledButton: '#0f1e7c',
    mobileLinesButton: '#0f1e7c',
    mobileLinesButtonDisabled: '#0f1e7c',
    streaksPrizeLevelBackground: '#fff',
    streaksPrizeLevelText: '#000',
    streaksPrizeLevelTextHighlight: '#010d68',
    streaksBallColour: '#010d68',
    streaksBallColourNotSelected: '#010d68',
    streaksLineSelectActive: '#000d68',
    streaksLineSelectNotActibe: '#fff',
    accountHistoryTableHeader: '#919191',
    accountHistoryTableCell: '#222222',
    accountHistoryDetailsTableHeader: '#000',
};

export const goalRushColourValues: Colours = {
    ...colourValues,
    gameMainColour: '#aa0000',
    gameSecondaryColour: '#bb1b1b',
};
export const Premier6colourValues: Colours = {
    ...colourValues,
    gameMainColour: '#008995',
};

export const Prem10colourValues: Colours = {
    ...colourValues,
    gameMainColour: '#00C4C4',
};

export const Jackpot12colourValues: Colours = {
    ...colourValues,
    gameMainColour: '#00108B',
};

export const LuckyClovercolourValues: Colours = {
    ...colourValues,
    gameMainColour: '#00955C',
};
