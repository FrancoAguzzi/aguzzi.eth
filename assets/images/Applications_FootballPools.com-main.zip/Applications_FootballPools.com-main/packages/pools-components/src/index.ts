import { BetSelections, BetSelectionsProps } from './components/BetSlip/BetSelections/BetSelections';
import { BetSlipCircle, BetSlipCircleProps } from './components/BetSlip/BetSlipCircle/BetSlipCircle';
import { BetSlipCircleList, BetSlipCircleListProps } from './components/BetSlip/BetSlipCircleList/BetSlipCircleList';
import BetSlipItem, { BetSlipItemProps } from './components/BetSlip/BetSlipItem/BetSlipItem';
import { BetSlipList, BetSlipListProps } from './components/BetSlip/BetSlipList/BetSlipList';
import { BetSlipMobile, BetSlipMobileProps } from './components/BetSlip/BetSlipMobile/BetSlipMobile';
import { GameActionButtons, GameActionButtonsProps } from './components/GameActionButtons/GameActionButtons';
import { GameCostInfo, GameCostInfoProps } from './components/GameCostInfo/GameCostInfo';
import { ViewLines, ViewLinesProps, ViewLinesCurrent } from './components/BetSlip/ViewLines/ViewLines';

import { ArrowButton, ArrowButtonProps } from './components/Common/ArrowButton/ArrowButton';
import { Button, ButtonProps } from './components/Common/Button/Button';
import { DateTimeFormatter, DateTimeFormatterProps } from './components/Common/DateTimeFormatter/DateTimeFormatter';
import { ExternalLink } from './components/Common/ExternalLink/ExternalLink';
import { ToggleButton, ToggleButtonProps } from './components/Common/ToggleButton/ToggleButton';

import { Countdown, CountdownProps, Count, getCountdown } from './components/Countdown/Countdown';

import {
    DirectDebitForm,
    DirectDebitFormInputProps,
    DirectDebitFormProps,
} from './components/DirectDebitForm/DirectDebitForm';

import { ChevronFigures, ChevronFiguresProps } from './components/Figures/ChevronFigures';
import { DiceFigures, DiceFiguresProps } from './components/Figures/DiceFigures';

import {
    CompetitionSelector,
    CompetitionSelectorProps,
    CompetitionsStyleProps,
} from './components/GameSection/CompetitionSelector/CompetitionSelector';
import {
    ResultsCompetitionSelector,
    ResultsCompetitionSelectorProps,
} from './components/GameSection/CompetitionSelector/ResultsCompetitionSelector';
import { GameSection, GameSectionProps, GameViewType } from './components/GameSection/GameSection/GameSection';
import { HdaButton } from './components/GameSection/HdaButton/HdaButton';
import { HdaMatchCard } from './components/GameSection/HdaMatchCard/HdaMatchCard';
import { MatchCard, MatchCardProps } from './components/GameSection/MatchCard/MatchCard';
import { MatchCardHda, MatchCardHdaProps } from './components/GameSection/MatchCardHda/MatchCardHda';
import {
    MatchCardTeams,
    MatchCardTeamsProps,
    MatchCardTeamsStyleProps,
} from './components/GameSection/MatchCardTeams/MatchCardTeams';
import { NumbersCard, NumbersCardProps } from './components/GameSection/NumbersCard/NumbersCard';
import { NumbersCardBall, NumbersCardBallProps } from './components/GameSection/NumbersCardBall/NumbersCardBall';
import { Loader, LoaderProps } from './components/Loader/Loader';

import { OfferingDropDown, OfferingDropDownProps } from './components/OfferingDropDown/OfferingDropDown';
import {
    OfferingDropDownListItem,
    OfferingDropDownListItemProps,
} from './components/OfferingDropDown/OfferingDropDownListItem';

import { OfferingList, OfferingListProps } from './components/OfferingList/OfferingList';

import { PopupComponent, Popup, PopupProps } from './components/Popup/Popup';
import { PopupsContainer } from './components/Popup/PopupsContainer';
import { AddedLineItem } from './components/Popup/AddedLinesPopup';

import { ResultsKey, ResultsKeyProps } from './components/Results/ResultsKey/ResultsKey';
import {
    MatchCardResults,
    MatchCardResultsProps,
    NumberStyleProps,
} from './components/Results/ResultsSection/MatchCardResults';
import { ResultSection, ResultSectionProps } from './components/Results/ResultsSection/ResultsSection';
import {
    ResultsWagerLineSelector,
    ResultsWagerLineSelectorProps,
} from './components/Results/ResultsWager/ResultsWagerLineSelector';
import { SlideOfferingList } from './components/OfferingList/SlideOfferingList';

import {
    MenuDropdown,
    StyledHeaderDesktop,
    StyledHeaderMobile,
    StyledHeader,
    StyledMain,
    TitleStyle,
    StyledSidebar,
    PageLinkButtonsContainer,
    NavStyle,
    GameInfo,
    PopupText,
    StyledATag,
    StyledBetSlipMobile,
    ErrorPopupText,
    StyledNavBarButtons,
    StyledNavBarButtonsMobile,
    ViewMyLinesContent,
    PaymentPopupContent,
    ClearContainer,
    MenuDropdownOverlay,
    ViewLinesOverlay,
    StyledCurrentLineFloating,
    BannerText,
    BannerTextSmall,
    ChevronText,
    Container,
} from './components/Styles/defaultPageStyles';
import { popupStyles, errorPopupStyles, ViewMyLinesPopupStyle } from './components/Styles/popupStyles';

import popupsSlice, {
    PopupState,
    PopupStates,
    PopupStateActions,
    getPopup,
    addPopup,
    openPopup,
    closePopup,
    showLoading,
} from './state/popupsSlice';

import {
    convertNumbersSelectedToArray,
    convertNumbersSelectedToString,
    ConvertStringToArray,
    convertWagerToBetSlipSelection,
    getIdFromWager,
    testId,
    getTotalLines,
    getTotalPrice,
    getPoints,
    getHdaResult,
    getWinningPoints,
    GameCategory,
    getGameCategory,
    isCPorGR,
    isClover,
    isHDA,
    isNumbers,
    getCompetitionFromId,
    isCurrentViewLines,
    isPlayEnabled,
    isAllLinesMax,
} from './utils/functionUtils';

export {
    BetSelections,
    BetSlipCircle,
    BetSlipCircleList,
    BetSlipItem,
    BetSlipList,
    BetSlipMobile,
    ViewLines,
    ArrowButton,
    Button,
    DateTimeFormatter,
    NumbersCardBall,
    ExternalLink,
    ToggleButton,
    Countdown,
    getCountdown,
    DirectDebitForm,
    ChevronFigures,
    DiceFigures,
    CompetitionSelector,
    ResultsCompetitionSelector,
    GameSection,
    GameActionButtons,
    GameCostInfo,
    HdaButton,
    HdaMatchCard,
    MatchCard,
    MatchCardHda,
    MatchCardTeams,
    NumbersCard,
    Loader,
    OfferingDropDown,
    OfferingDropDownListItem,
    OfferingList,
    PopupComponent,
    Popup,
    PopupsContainer,
    AddedLineItem,
    ResultsKey,
    MatchCardResults,
    ResultSection,
    ResultsWagerLineSelector,
    MenuDropdown,
    SlideOfferingList,
    StyledHeaderDesktop,
    StyledHeaderMobile,
    StyledHeader,
    StyledMain,
    BannerText,
    BannerTextSmall,
    ChevronText,
    Container,
    TitleStyle,
    StyledSidebar,
    PageLinkButtonsContainer,
    NavStyle,
    GameInfo,
    PopupText,
    StyledATag,
    StyledBetSlipMobile,
    ErrorPopupText,
    StyledNavBarButtons,
    StyledNavBarButtonsMobile,
    ViewMyLinesContent,
    PaymentPopupContent,
    ClearContainer,
    MenuDropdownOverlay,
    ViewLinesOverlay,
    StyledCurrentLineFloating,
    popupStyles,
    errorPopupStyles,
    ViewMyLinesPopupStyle,
    popupsSlice,
    getPopup,
    addPopup,
    openPopup,
    closePopup,
    showLoading,
    ConvertStringToArray,
    convertWagerToBetSlipSelection,
    getIdFromWager,
    convertNumbersSelectedToString,
    convertNumbersSelectedToArray,
    testId,
    getTotalLines,
    getTotalPrice,
    getPoints,
    getWinningPoints,
    getHdaResult,
    getGameCategory,
    isCPorGR,
    isClover,
    isHDA,
    isNumbers,
    getCompetitionFromId,
    isCurrentViewLines,
    isPlayEnabled,
    isAllLinesMax,
};

export type {
    BetSelectionsProps,
    BetSlipCircleProps,
    BetSlipCircleListProps,
    BetSlipItemProps,
    BetSlipListProps,
    BetSlipMobileProps,
    ViewLinesProps,
    ViewLinesCurrent,
    ArrowButtonProps,
    ButtonProps,
    DateTimeFormatterProps,
    NumbersCardBallProps,
    ToggleButtonProps,
    CountdownProps,
    Count,
    DirectDebitFormInputProps,
    DirectDebitFormProps,
    ChevronFiguresProps,
    DiceFiguresProps,
    CompetitionSelectorProps,
    CompetitionsStyleProps,
    ResultsCompetitionSelectorProps,
    GameSectionProps,
    GameActionButtonsProps,
    GameCostInfoProps,
    GameViewType,
    MatchCardProps,
    MatchCardHdaProps,
    MatchCardTeamsProps,
    MatchCardTeamsStyleProps,
    NumbersCardProps,
    LoaderProps,
    OfferingDropDownProps,
    OfferingDropDownListItemProps,
    OfferingListProps,
    PopupProps,
    ResultsKeyProps,
    MatchCardResultsProps,
    NumberStyleProps,
    ResultSectionProps,
    ResultsWagerLineSelectorProps,
    PopupState,
    PopupStates,
    PopupStateActions,
    GameCategory,
};
