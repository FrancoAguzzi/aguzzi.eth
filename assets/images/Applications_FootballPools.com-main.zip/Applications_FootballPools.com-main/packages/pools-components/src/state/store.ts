import { configureStore } from '@reduxjs/toolkit';
import thunk from 'redux-thunk';

import rootReducer, { RootState } from './rootReducer';

export const makeStore = (preloadedState?: RootState) => {
    const store = configureStore({
        reducer: rootReducer,
        preloadedState,
        middleware: [thunk],
    });
    return store;
};

export const initialState = makeStore().getState();

export type AppStore = ReturnType<typeof makeStore>;
