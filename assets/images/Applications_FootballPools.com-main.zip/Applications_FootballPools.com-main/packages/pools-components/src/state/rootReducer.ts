import { combineReducers, ThunkDispatch, AnyAction, ThunkAction, Action } from '@reduxjs/toolkit';
import popupsReducer from './popupsSlice';

const rootReducer = combineReducers({
    popups: popupsReducer,
});

export type RootState = ReturnType<typeof rootReducer>;

export default rootReducer;

export type AppDispatch = ThunkDispatch<RootState, null, AnyAction>;

export type AppThunk = ThunkAction<void, RootState, null, Action<string>>;
