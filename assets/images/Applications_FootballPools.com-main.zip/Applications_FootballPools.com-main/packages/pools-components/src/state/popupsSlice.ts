import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface PopupState {
    action: PopupStateActions;
    name: string;
    addToStore?: boolean;
}

export interface PopupStates {
    popups: PopupState[];
}

export type PopupStateActions = 'open' | 'close' | 'loading';

const initialState: PopupStates = {
    popups: [],
};

const isPopup = (obj: PopupState | undefined): obj is PopupState => {
    return obj !== undefined && (obj as PopupState).name !== undefined;
};

export const getPopup = (state: PopupStates, name: string): PopupState => {
    let ret = state.popups.find(p => p.name === name);
    if (!isPopup(ret)) {
        ret = {
            action: 'close',
            name: name,
            addToStore: true,
        };
    }
    return ret;
};

const addPopupState = (state: PopupStates, action: PopupState): void => {
    // console.log(`adding to store: ${action.name} ${action.action}`);
    state.popups.push(action);
};

const updatePopupState = (state: PopupStates, action: PopupStateActions, name: string): void => {
    // console.log(`updating popup state: ${name} ${action}`);
    const popup = getPopup(state, name);
    popup.action = action;
};

const popupsSlice = createSlice({
    name: 'popup',
    initialState: initialState as PopupStates,
    reducers: {
        addPopup: (state, action: PayloadAction<PopupState>): void => addPopupState(state, action.payload),
        openPopup: (state, action: PayloadAction<string>): void => updatePopupState(state, 'open', action.payload),
        closePopup: (state, action: PayloadAction<string>): void => updatePopupState(state, 'close', action.payload),
        showLoading: (state, action: PayloadAction<{ isLoading: boolean; name: string }>): void =>
            updatePopupState(state, action.payload.isLoading === true ? 'loading' : 'open', action.payload.name),
    },
});

export const { addPopup, openPopup, closePopup, showLoading } = popupsSlice.actions;

export default popupsSlice.reducer;
