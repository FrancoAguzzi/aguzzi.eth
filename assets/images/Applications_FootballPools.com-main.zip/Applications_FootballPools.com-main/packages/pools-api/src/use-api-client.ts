import { ApiClient } from './api-client';
import { Response, createClient, send } from './client';
import { Offering, Offerings } from './models/offering';
import { Competition } from './models/competition';
import { CompetitionResult } from './models/competition-result';
import { CompetitionDividends } from './models/dividends';
import { GameType } from './models/game';
import {
    CompetitionWagers,
    ConfirmedWagers,
    PaymentMethods,
    SetupCardResult,
    UpdatedWager,
    Wagers,
} from './models/wagers';

import { useAdaptor } from './use-adaptor';
import { Adaptor } from './adaptor';
import { ApiConfig } from './api';
import { AxiosRequestConfig, AxiosResponse, AxiosInstance } from 'axios';
import { isGameEndpoint, isHealthEndpoint } from './utils';
import { Leaderboard } from './models/leaderboards';
import { LeaderboardResultsResponse } from './models/leaderboard-results';
import { TransactionHistoryResponse } from './models/transaction-history';
import { TransactionDetailsResponse } from './models/transaction-details';

let initialised = false;

let client: AxiosInstance;

export const useApiClient = (): ApiClient => {
    const { getAdaptor, setAdaptor } = useAdaptor();
    const config: ApiConfig = { clientType: 'api' };

    const onRequest = (
        axiosConfig: AxiosRequestConfig,
        req?: unknown,
    ): AxiosRequestConfig | Promise<AxiosRequestConfig> => {
        const adaptor = getAdaptor();
        if (adaptor.onBackendRequest) {
            axiosConfig.data = adaptor.onBackendRequest(
                axiosConfig.url || '',
                axiosConfig.data,
                axiosConfig.headers,
                req,
            );
        }
        return axiosConfig;
    };

    const onRequestError = (error: unknown): unknown => {
        const adaptor = getAdaptor();
        if (adaptor.onRequestError) {
            return adaptor.onRequestError(error);
        }
        throw error;
    };

    const onResponse = (
        res: AxiosResponse<unknown>,
        req?: unknown,
    ): AxiosResponse<unknown> | Promise<AxiosResponse<unknown>> => {
        const adaptor = getAdaptor();
        const url = res.config.url || '';
        if (adaptor.onBackendResponse) {
            res.data = adaptor.onBackendResponse(url, res.data, res.headers, req);
        }
        switch (url) {
            case isGameEndpoint(adaptor.getCompetitionsEndpoint, adaptor.getGameTypes(), config, url): {
                res.data = adaptor.transformCompetitionsResponse(res.data);
                break;
            }
            case isGameEndpoint(adaptor.getCompetitionResultsEndpoint, adaptor.getGameTypes(), config, url): {
                res.data = adaptor.transformCompetitionResultsResponse(res.data);
                break;
            }
            case isGameEndpoint(adaptor.getDividendsEndpoint, adaptor.getGameTypes(), config, url): {
                res.data = adaptor.transformDividendsResponse(res.data);
                break;
            }
            case isGameEndpoint(adaptor.getOfferingsEndpoint, adaptor.getGameTypes(), config, url): {
                res.data = adaptor.transformOfferingsResponse(res.data);
                break;
            }
            case isGameEndpoint(
                adaptor.getFilteredOfferingsEndpoint ||
                    ((game: GameType): string => {
                        return `games/${game}/filtered`;
                    }),
                adaptor.getGameTypes(),
                config,
                url,
            ): {
                res.data = adaptor.transformFilteredOfferingsResponse
                    ? adaptor.transformFilteredOfferingsResponse(res.data)
                    : res.data;
                break;
            }
            case isGameEndpoint(adaptor.getWagersEndpoint, adaptor.getGameTypes(), config, url): {
                res.data = adaptor.transformGetWagersResponse(res.data);
                break;
            }
            case isGameEndpoint(
                adaptor.getWagerResultsEndpoint ||
                    ((game: GameType): string => {
                        return `wager/lines?gameName=${game}`;
                    }),
                adaptor.getGameTypes(),
                config,
                url,
            ): {
                res.data = adaptor.transformGetWagerResultsResponse
                    ? adaptor.transformGetWagerResultsResponse(res.data)
                    : res.data;
                break;
            }
            case isHealthEndpoint(adaptor.getHealthCheckEndpoint, config, url): {
                res.data = adaptor.transformGetHealthCheckResponse
                    ? adaptor.transformGetHealthCheckResponse(res.data)
                    : res.data;
                break;
            }
            case isGameEndpoint(adaptor.getCreateWagersInitEndpoint, adaptor.getGameTypes(), config, url): {
                res.data = adaptor.transformCreateWagersResponse(res.data);
                break;
            }
            case isGameEndpoint(adaptor.getConfirmWagersEndpoint, adaptor.getGameTypes(), config, url): {
                res.data = adaptor.transformConfirmWagersResponse(res.data);
                break;
            }
            case adaptor.getFinaliseWagersEndpoint(config): {
                res.data = adaptor.transformFinaliseWagersResponse(res.data);
                break;
            }
            case isGameEndpoint(
                adaptor.getUpdateWagerEndpoint ||
                    ((game: GameType): string => {
                        return `wagers/update/${game}`;
                    }),
                adaptor.getGameTypes(),
                config,
                url,
            ): {
                res.data = adaptor.transformUpdateWagerResponse
                    ? adaptor.transformUpdateWagerResponse(res.data)
                    : res.data;
                break;
            }
            case isGameEndpoint(
                adaptor.getPaymentMethodsEndpoint ||
                    ((game: GameType): string => {
                        return `wagers/payment-methods/${game}`;
                    }),
                adaptor.getGameTypes(),
                config,
                url,
            ): {
                res.data = adaptor.transformGetPaymentMethodsResponse
                    ? adaptor.transformGetPaymentMethodsResponse(res.data)
                    : res.data;
                break;
            }
            case isGameEndpoint(
                adaptor.getLeaderboardEndpoint ||
                    ((game: GameType): string => {
                        return `leaderboards/${game}`;
                    }),
                adaptor.getGameTypes(),
                config,
                url,
            ): {
                res.data = adaptor.transformLeaderboardResponse
                    ? adaptor.transformLeaderboardResponse(res.data)
                    : res.data;
                break;
            }
            case isGameEndpoint(
                adaptor.getLeaderboardResultsEndpoint ||
                    ((game: GameType): string => {
                        return `leaderboards/${game}/results`;
                    }),
                adaptor.getGameTypes(),
                config,
                url,
            ): {
                res.data = adaptor.transformLeaderboardResultsResponse
                    ? adaptor.transformLeaderboardResultsResponse(res.data)
                    : res.data;
                break;
            }
            case adaptor.getTransactionHistoryEndpoint
                ? adaptor.getTransactionHistoryEndpoint(config)
                : `transactions/history`: {
                res.data = adaptor.transformTransactionHistoryResponse
                    ? adaptor.transformTransactionHistoryResponse(res.data)
                    : res.data;
                break;
            }
            case adaptor.getTransactionDetailsEndpoint
                ? adaptor.getTransactionDetailsEndpoint(config)
                : `transactions/details`: {
                res.data = adaptor.transformTransactionDetailsResponse
                    ? adaptor.transformTransactionDetailsResponse(res.data)
                    : res.data;
                break;
            }
            case adaptor.getSetupCardEndpoint ? adaptor.getSetupCardEndpoint(config) : `orders/setup-card`: {
                res.data = adaptor.transformSetupCardResponse ? adaptor.transformSetupCardResponse(res.data) : res.data;
                break;
            }
            default: {
                console.warn('unhandled backend api response', url, config);
                break;
            }
        }
        return res;
    };

    const onResponseError = (error: unknown): unknown => {
        const adaptor = getAdaptor();
        if (adaptor.onResponseError) {
            return adaptor.onResponseError(error);
        }
        throw error;
    };

    const initialise = (adaptorToUse: Adaptor): void => {
        if (!initialised) {
            setAdaptor(adaptorToUse);
            client = createClient(onRequest, onRequestError, onResponse, onResponseError);
            initialised = true;
        }
    };

    const getCompetitions = async (game: GameType): Promise<Response<Competition[]>> => {
        const url = getAdaptor().getCompetitionsEndpoint(game, config);
        const res = await send<Competition[]>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client,
        });
        return res;
    };

    const getCompetitionResults = async (game: GameType): Promise<Response<CompetitionResult[]>> => {
        const url = getAdaptor().getCompetitionResultsEndpoint(game, config);
        const res = await send<CompetitionResult[]>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client,
        });
        return res;
    };

    const getOfferings = async (game: GameType): Promise<Response<Offerings>> => {
        const url = getAdaptor().getOfferingsEndpoint(game, config);
        const res = await send<Offerings>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client,
        });
        return res;
    };

    const getFilteredOfferings = async (game: GameType, req?: unknown): Promise<Response<Offering[]>> => {
        const fn = getAdaptor().getFilteredOfferingsEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(game, config);
        const res = await send<Offering[]>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client: createClient(
                (config: AxiosRequestConfig) => {
                    onRequest(config, req);
                    return config;
                },
                onRequestError,
                onResponse,
                onResponseError,
            ),
        });
        return res;
    };

    const getDividends = async (game: GameType): Promise<Response<CompetitionDividends>> => {
        const url = getAdaptor().getDividendsEndpoint(game, config);
        const res = await send<CompetitionDividends>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client,
        });
        return res;
    };

    const getWagers = async (game: GameType, req?: unknown): Promise<Response<Wagers>> => {
        const url = getAdaptor().getWagersEndpoint(game, config);
        const res = await send<Wagers>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client: createClient(
                (config: AxiosRequestConfig) => {
                    onRequest(config, req);
                    return config;
                },
                onRequestError,
                onResponse,
                onResponseError,
            ),
        });
        return res;
    };

    const getWagerResults = async (
        data: unknown,
        game: GameType,
        req?: unknown,
    ): Promise<Response<CompetitionWagers>> => {
        const fn = getAdaptor().getWagerResultsEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(game, config);
        const res = await send<CompetitionWagers>({
            url: url,
            method: 'GET',
            data: data,
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client: createClient(
                (config: AxiosRequestConfig) => {
                    onRequest(config, req);
                    return config;
                },
                onRequestError,
                onResponse,
                onResponseError,
            ),
        });
        return res;
    };

    const getHealthCheck = async (req?: unknown): Promise<Response<{ isAlive: boolean }>> => {
        const fn = getAdaptor().getHealthCheckEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(config);
        const res = await send({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client: createClient(
                (config: AxiosRequestConfig) => {
                    onRequest(config, req);
                    return config;
                },
                onRequestError,
                onResponse,
                onResponseError,
            ),
        });
        return res;
    };

    const createWagersInit = async (
        data: unknown,
        game: GameType,
        req?: unknown,
    ): Promise<Response<{ orderId?: number }>> => {
        const url = getAdaptor().getCreateWagersInitEndpoint(game, config);
        const res = await send<{ orderId?: number }>({
            url: url,
            method: 'POST',
            data: data,
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client: createClient(
                (config: AxiosRequestConfig) => {
                    onRequest(config, req);
                    return config;
                },
                onRequestError,
                onResponse,
                onResponseError,
            ),
        });
        return res;
    };

    const confirmCreateWagers = async (
        data: unknown,
        game: GameType,
        req?: unknown,
    ): Promise<Response<ConfirmedWagers>> => {
        const url = getAdaptor().getConfirmWagersEndpoint(game, config);
        const res = await send<ConfirmedWagers>({
            url: url,
            method: 'PUT',
            data: data,
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client: createClient(
                (config: AxiosRequestConfig) => {
                    onRequest(config, req);
                    return config;
                },
                onRequestError,
                onResponse,
                onResponseError,
            ),
        });
        return res;
    };

    const finaliseCreateWagersPayment = async (data: unknown, req?: unknown): Promise<Response<ConfirmedWagers>> => {
        const url = getAdaptor().getFinaliseWagersEndpoint(config);
        const res = await send<ConfirmedWagers>({
            url: url,
            method: 'PUT',
            data: data,
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client: createClient(
                (config: AxiosRequestConfig) => {
                    onRequest(config, req);
                    return config;
                },
                onRequestError,
                onResponse,
                onResponseError,
            ),
        });
        return res;
    };

    const authoriseCardPayment = async (data: unknown, req?: unknown): Promise<Response<unknown>> => {
        const adaptor = getAdaptor();
        if (adaptor.getAuthoriseCardEndpoint) {
            const reqData = data as { PaRes: string; MD: string };
            if (reqData && reqData.PaRes && reqData.MD) {
                // TODO: move to adaptor class when querystring installed in package successfully.
                const q = new URLSearchParams({
                    PaRes: reqData.PaRes,
                    MD: reqData.MD,
                });
                data = q;
            }
            const url = adaptor.getAuthoriseCardEndpoint(config);
            const res = await send<unknown>({
                url: url,
                method: 'POST',
                data: data,
                baseUrl: getAdaptor().getBaseUrl(config),
                onError: getAdaptor().handleError,
                client: createClient(
                    (config: AxiosRequestConfig) => {
                        onRequest(config, req);
                        return config;
                    },
                    onRequestError,
                    onResponse,
                    onResponseError,
                ),
            });
            return res;
        }
        return { isLoading: false };
    };

    const updateWager = async (data: unknown, game: GameType, req?: unknown): Promise<Response<UpdatedWager>> => {
        const fn = getAdaptor().getUpdateWagerEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(game, config);
        const res = await send<UpdatedWager>({
            url: url,
            method: 'PUT',
            data: data,
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client: createClient(
                (config: AxiosRequestConfig) => {
                    onRequest(config, req);
                    return config;
                },
                onRequestError,
                onResponse,
                onResponseError,
            ),
        });
        return res;
    };

    const getPaymentMethods = async (
        data: unknown,
        game: GameType,
        req?: unknown,
    ): Promise<Response<PaymentMethods>> => {
        const fn = getAdaptor().getPaymentMethodsEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(game, config);
        const res = await send<PaymentMethods>({
            url: url,
            method: 'GET',
            data: data,
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client: createClient(
                (config: AxiosRequestConfig) => {
                    onRequest(config, req);
                    return config;
                },
                onRequestError,
                onResponse,
                onResponseError,
            ),
        });
        return res;
    };

    const getLeaderboard = async (data: unknown, game: GameType, req?: unknown): Promise<Response<Leaderboard>> => {
        const fn = getAdaptor().getLeaderboardEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(game, config);
        const res = await send<Leaderboard>({
            url: url,
            method: 'GET',
            data: data,
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client: createClient(
                (config: AxiosRequestConfig) => {
                    onRequest(config, req);
                    return config;
                },
                onRequestError,
                onResponse,
                onResponseError,
            ),
        });
        return res;
    };

    const getLeaderboardResults = async (
        data: unknown,
        game: GameType,
        req?: unknown,
    ): Promise<Response<LeaderboardResultsResponse>> => {
        const fn = getAdaptor().getLeaderboardResultsEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(game, config);
        const res = await send<LeaderboardResultsResponse>({
            url: url,
            method: 'GET',
            data: data,
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client: createClient(
                (config: AxiosRequestConfig) => {
                    onRequest(config, req);
                    return config;
                },
                onRequestError,
                onResponse,
                onResponseError,
            ),
        });
        return res;
    };

    const getTransactionHistory = async (
        data: unknown,
        req?: unknown,
    ): Promise<Response<TransactionHistoryResponse>> => {
        const fn = getAdaptor().getTransactionHistoryEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'Missing Function',
                    title: 'Missing Adaptor Function',
                },
            };
        }
        const url = fn(config);
        const res = await send<TransactionHistoryResponse>({
            url: url,
            method: 'GET',
            data: data,
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client: createClient(
                (config: AxiosRequestConfig) => {
                    onRequest(config, req);
                    return config;
                },
                onRequestError,
                onResponse,
                onResponseError,
            ),
        });
        return res;
    };

    const getTransactionDetails = async (
        data: unknown,
        req?: unknown,
    ): Promise<Response<TransactionDetailsResponse>> => {
        const fn = getAdaptor().getTransactionDetailsEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'Missing Function',
                    title: 'Missing Adaptor Function',
                },
            };
        }
        const url = fn(config);
        const res = await send<TransactionDetailsResponse>({
            url: url,
            method: 'GET',
            data: data,
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client: createClient(
                (config: AxiosRequestConfig) => {
                    onRequest(config, req);
                    return config;
                },
                onRequestError,
                onResponse,
                onResponseError,
            ),
        });
        return res;
    };

    const setupCard = async (data: unknown, req?: unknown): Promise<Response<SetupCardResult>> => {
        const fn = getAdaptor().getSetupCardEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'Missing Function',
                    title: 'Missing Adaptor Function',
                },
            };
        }
        const url = fn(config);
        const res = await send<SetupCardResult>({
            url: url,
            method: 'POST',
            data: data,
            baseUrl: getAdaptor().getBaseUrl(config),
            onError: getAdaptor().handleError,
            client: createClient(
                (config: AxiosRequestConfig) => {
                    onRequest(config, req);
                    return config;
                },
                onRequestError,
                onResponse,
                onResponseError,
            ),
        });
        return res;
    };

    return {
        initialise,
        getCompetitions,
        getCompetitionResults,
        getDividends,
        getOfferings,
        getFilteredOfferings,
        getWagers,
        getWagerResults,
        getHealthCheck,
        createWagersInit,
        confirmCreateWagers,
        finaliseCreateWagersPayment,
        authoriseCardPayment,
        updateWager,
        getPaymentMethods,
        getLeaderboard,
        getLeaderboardResults,
        getTransactionHistory,
        getTransactionDetails,
        setupCard,
    };
};
