import { useApi } from './use-api';
import { useAdaptor } from './use-adaptor';
import { mockAdaptor } from './testing/mock-adaptor';

describe('useApi', () => {
    describe('initialise', () => {
        it('initialises adaptor', () => {
            const { initialise } = useApi({ clientType: 'backend' });
            initialise(mockAdaptor);
            const { getAdaptor } = useAdaptor();
            expect(getAdaptor()).toEqual(mockAdaptor);
        });
    });
});
