import { Adaptor } from '../adaptor';

export const mockGetBaseUrl = jest.fn();
export const mockGetGameTypes = jest.fn();
export const mockGetCompetitionsEndpoint = jest.fn();
export const mockGetCompetitionResultsEndpoint = jest.fn();
export const mockGetOfferingsEndpoint = jest.fn();
export const mockGetDividendsEndpoint = jest.fn();
export const mockGetCreateWagersInitEndpoint = jest.fn();
export const mockGetConfirmWagersEndpoint = jest.fn();
export const mockGetFinaliseWagersEndpoint = jest.fn();
export const mockGetAuthoriseCardEndpoint = jest.fn();
export const mockGetWagersEndpoint = jest.fn();
export const mockOnRequest = jest.fn();
export const mockOnRequestError = jest.fn();
export const mockOnResponse = jest.fn();
export const mockOnResponseError = jest.fn();
export const mockOnBackendRequest = jest.fn();
export const mockOnBackendResponse = jest.fn();
export const mockTransformCompetitionsResponse = jest.fn();
export const mockTransformCompetitionResultsResponse = jest.fn();
export const mockTransformDividendsResponse = jest.fn();
export const mockTransformOfferingsResponse = jest.fn();
export const mockTransformCreateWagersRequest = jest.fn();
export const mockTransformCreateWagersResponse = jest.fn();
export const mockTransformConfirmWagersRequest = jest.fn();
export const mockTransformConfirmWagersResponse = jest.fn();
export const mockTransformFinaliseWagersRequest = jest.fn();
export const mockTransformFinaliseWagersResponse = jest.fn();
export const mockTransformAuthoriseCardRequest = jest.fn();
export const mockTransformGetWagersResponse = jest.fn();
export const mockHandleError = jest.fn();

export const mockAdaptor: Adaptor = {
    getBaseUrl: mockGetBaseUrl,
    getGameTypes: mockGetGameTypes,
    getCompetitionsEndpoint: mockGetCompetitionsEndpoint,
    getCompetitionResultsEndpoint: mockGetCompetitionResultsEndpoint,
    getOfferingsEndpoint: mockGetOfferingsEndpoint,
    getDividendsEndpoint: mockGetDividendsEndpoint,
    getCreateWagersInitEndpoint: mockGetCreateWagersInitEndpoint,
    getConfirmWagersEndpoint: mockGetConfirmWagersEndpoint,
    getFinaliseWagersEndpoint: mockGetFinaliseWagersEndpoint,
    getAuthoriseCardEndpoint: mockGetAuthoriseCardEndpoint,
    getWagersEndpoint: mockGetWagersEndpoint,
    onRequest: mockOnRequest,
    onRequestError: mockOnRequestError,
    onResponse: mockOnResponse,
    onResponseError: mockOnResponseError,
    onBackendRequest: mockOnBackendRequest,
    onBackendResponse: mockOnBackendResponse,
    transformCompetitionsResponse: mockTransformCompetitionsResponse,
    transformCompetitionResultsResponse: mockTransformCompetitionResultsResponse,
    transformDividendsResponse: mockTransformDividendsResponse,
    transformOfferingsResponse: mockTransformOfferingsResponse,
    transformCreateWagersRequest: mockTransformCreateWagersRequest,
    transformCreateWagersResponse: mockTransformCreateWagersResponse,
    transformConfirmWagersRequest: mockTransformConfirmWagersRequest,
    transformConfirmWagersResponse: mockTransformConfirmWagersResponse,
    transformFinaliseWagersRequest: mockTransformFinaliseWagersRequest,
    transformFinaliseWagersResponse: mockTransformFinaliseWagersResponse,
    transformAuthoriseCardRequest: mockTransformAuthoriseCardRequest,
    transformGetWagersResponse: mockTransformGetWagersResponse,
    handleError: mockHandleError,
};

export const resetMockAdaptor = () => {
    mockGetBaseUrl.mockReset();
    mockGetGameTypes.mockReset();
    mockGetCompetitionsEndpoint.mockReset();
    mockGetCompetitionResultsEndpoint.mockReset();
    mockGetOfferingsEndpoint.mockReset();
    mockGetDividendsEndpoint.mockReset();
    mockGetCreateWagersInitEndpoint.mockReset();
    mockGetConfirmWagersEndpoint.mockReset();
    mockGetFinaliseWagersEndpoint.mockReset();
    mockGetAuthoriseCardEndpoint.mockReset();
    mockGetWagersEndpoint.mockReset();
    mockOnRequest.mockReset();
    mockOnRequestError.mockReset();
    mockOnResponse.mockReset();
    mockOnResponseError.mockReset();
    mockOnBackendRequest.mockReset();
    mockOnBackendResponse.mockReset();
    mockTransformCompetitionsResponse.mockReset();
    mockTransformCompetitionResultsResponse.mockReset();
    mockTransformDividendsResponse.mockReset();
    mockTransformOfferingsResponse.mockReset();
    mockTransformCreateWagersRequest.mockReset();
    mockTransformCreateWagersResponse.mockReset();
    mockTransformConfirmWagersRequest.mockReset();
    mockTransformConfirmWagersResponse.mockReset();
    mockTransformFinaliseWagersRequest.mockReset();
    mockTransformFinaliseWagersResponse.mockReset();
    mockTransformAuthoriseCardRequest.mockReset();
    mockHandleError.mockReset();
};
