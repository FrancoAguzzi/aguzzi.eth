import { CompetitionResult } from './competition-result';

export interface TransactionDetailsResponse {
    competition: CompetitionResult;
}
