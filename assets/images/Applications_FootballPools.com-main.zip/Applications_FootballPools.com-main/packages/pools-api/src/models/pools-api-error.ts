export interface PoolsApiError {
    code: string;
    id?: number;
    status?: number;
    title: string;
}
