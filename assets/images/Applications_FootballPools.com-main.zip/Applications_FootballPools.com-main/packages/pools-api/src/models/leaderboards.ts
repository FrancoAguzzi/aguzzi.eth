export interface LeaderboardEntry {
    rank: number;
    previousRank?: number;
    score: number;
    nickname?: string;
    playerId: string;
}

export interface Leaderboard {
    items: LeaderboardEntry[];
    board?: number;
    type?: number;
}
