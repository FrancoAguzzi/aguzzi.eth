export interface LeaderboardResults {
    additional?: RecentLeaderboardResults;
    general: RecentLeaderboardResults;
}

export interface RecentLeaderboardResults {
    current: LeaderboardResult;
    previous: LeaderboardResult;
}

export interface LeaderboardResult {
    id: number;
    name: string;
    productId: number;
    startDate: Date;
    endDate: Date;
    vipLevel: number;
    customerVipLevel: string;
    correct: boolean;
    type: string;
    finalized: boolean;
}

export interface LeaderboardResultMembers {
    totalPages: number;
    members: LeaderboardResultMember[];
    pageSize: number;
    page: number;
}

export interface LeaderboardResultMember {
    nickname: string;
    rank: number;
    previousRank?: number;
    totalPoints: number;
    playerId: number;
    customerMember: boolean;
}

export interface LeaderboardResultsResponse {
    leaderboards?: LeaderboardResults;
    members: LeaderboardResultMembers;
    competitionId: number;
}
