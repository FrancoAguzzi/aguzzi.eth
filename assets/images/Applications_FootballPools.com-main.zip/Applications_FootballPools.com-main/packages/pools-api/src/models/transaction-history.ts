import { GameType } from './game';
import { Wager } from './wagers';

export interface BalanceEntry {
    cashBalance: number;
    date: string;
}

export interface BetHistoryItem {
    amount: number;
    date: string;
    game: string;
    gameLabel: string;
    gameName: string;
    id: string;
    wagers: WagerHistoryItem[];
}

export interface WagerHistoryItem {
    id?: number;
    selections: string[];
    offeringId: number;
    competitionId: number;
    competitionCloseDate?: string;
    lineId?: number;
    bonusSelections?: string[];
    bonusOfferingId?: number;
    bonusCompetitionId?: number;
    result?: number;
    active?: boolean;
    offeringDescription?: string;
}

export interface OfflineTransaction {
    amount: number;
    date: string;
    direction: string;
    gameLabel: string;
    gameName: string;
    type: string;
}

export interface Transaction {
    amount: number;
    date: string;
    gameLabel: string;
    gameName: string;
    id: string;
    wagerIds: string[];
    type: string;
    primaryTransactionsIds: string[];
    channel: string;
}

export interface LineWagers {
    lineId: number;
    offeringId: number;
    offeringDescription: string;
    primaryLineId: number;
    bonusOfferingId: number;
    gameName: GameType;
    type: string;
    wagers: LineWager[];
}

export interface LineWager {
    id: number;
    competitionId: number;
    bonusCompetitionId: number;
    cost: number;
    paymentType: string;
    selections: string[];
    bonusSelections: string[];
}

export interface TransactionHistoryResponse {
    balances: BalanceEntry[];
    bets: BetHistoryItem[];
    offlineTransactions: OfflineTransaction[];
    transactions: Transaction[];
    subscriptionLineWagers: LineWagers[];
    subscriptionWagers: Wager[];
}
