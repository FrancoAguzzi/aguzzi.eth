export interface Dividend {
    level: number;
    amount: number;
    secondaryAmount?: number;
    winningBetsNum: number;
    winningUnits: number;
    totalPayout: number;
    dividendType: string;
}

export interface Dividends {
    competitionId: number;
    dividends: Dividend[];
}

export type CompetitionDividends = Dividends[];
