export interface CreatedWagers {
    orderId?: number;
    isSuccess: boolean;
    competitions?: CompetitionWagers[];
    token?: string;
}

export type PurchaseType = 'Subscription' | 'ByGames' | 'OneOff';

export type ConfirmWagers = WagerConfirmation[] | PaymentDetails;

// GameServiceAPI:

export interface Wagers {
    competitions: CompetitionWagers[];
}

export interface CompetitionWagers {
    competitionId: number;
    wagers: Wager[];
}

export interface Wager {
    wagerId?: number;
    id?: number;
    selections: string | string[];
    offeringId: number;
    paidCost?: number;
    createdAt?: string;
    winStatus?: string;
    winAmount?: number;
    lineId?: number;
    bonusLineId?: number;
    primaryLineId?: number;
    paymentType?: string;
    competitionId?: number;
    competitionCloseDate?: string;
    bonusCompetitionId?: number;
    bonusOfferingId?: number;
    bonusSelections?: string | string[];
    bonusPaidCost?: number;
    linkedWagerRef?: number;
    purchaseType?: PurchaseType;
}
export interface WagerConfirmation {
    wagerId: string;
    paidCost: string;
    offeringId: number;
    selections: string;
    linkedWagerRef?: number;
}

// SubsAPI:
export interface PaymentDetails {
    userAgent?: string;
    cardDetails?: CardDetails;
    paypalDetails?: PaypalDetails;
    directDebitDetails?: DirectDebitDetails;
    oneTime?: boolean;
    purchaseType?: PurchaseType;
    returnUrl?: string;
    sessionId?: string;
}

export interface CardDetails {
    cardNumber: string;
    expiryMonth: string;
    expiryYear: string;
    cvv: string;
    issueNumber?: string;
}

export interface PaypalDetails {
    token: string;
}

export interface DirectDebitDetails {
    accountNumber?: string;
    amount?: number;
    sortCode?: string;
    hasExisting?: boolean;
}

// Response

export interface ConfirmedWagers {
    orderId?: number;
    cardConfirmUrl?: string;
    cardConfirmToken?: string;
    reference?: string;
    isSuccess: boolean;
    error?: string;
}

export interface UpdatedWager {
    isSuccess: boolean;
    code?: string;
    message?: string;
}

export interface PaymentMethods {
    paymentMethods: PaymentMethod[];
    hasExistingDirectDebit?: boolean;
}

export type PaymentMethod = 'card' | 'direct-debit' | 'paypal';

export interface SetupCard {
    cardDetails: CardDetails;
}

export interface SetupCardResult {
    token: string;
    url: string;
    reference?: string;
}

export interface CompletedSetupCard {
    sessionId?: string;
    returnUrl?: string;
}
