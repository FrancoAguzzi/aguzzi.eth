export interface Competition {
    competitionType?: string;
    datumDate: string;
    datumDateWithBuffer: string;
    description: string;
    fixtures: Fixture[];
    id: number;
    number: number;
    poolSize: PoolSize;
    state: string;
    gameId?: number;
    wagers?: string;
    competitionIds?: { [key: string]: number };
    bonusCompetitionId?: number;
}

export interface Fixture {
    awayTeam: string;
    awayTeamDisplay: string;
    externalId: string;
    homeTeam: string;
    homeTeamDisplay: string;
    id: number;
    kickoff: string;
    number: number;
}

export interface PoolSize {
    type: string;
    value: number;
}
