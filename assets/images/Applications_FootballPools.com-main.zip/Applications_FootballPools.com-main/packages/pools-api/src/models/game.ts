import { BetSlipSlice, NumbersSelected } from '../state/bet-slip-slice';

export type GameType = 'classic-pools' | 'goal-rush' | 'jackpot-12' | 'lucky-clover' | 'premier-10' | 'premier-6';

export interface Game {
    current: GameType;
    types: GameType[];
}

export const game: Game = {
    current: 'classic-pools',
    types: ['classic-pools', 'goal-rush', 'jackpot-12', 'premier-10', 'premier-6'],
};

export const toGameType = (appGameType: keyof BetSlipSlice): GameType => {
    let ret: GameType = 'classic-pools';
    switch (appGameType) {
        case 'ClassicPools': {
            ret = 'classic-pools';
            break;
        }
        case 'GoalRush8': {
            ret = 'goal-rush';
            break;
        }
        case 'Jackpot12': {
            ret = 'jackpot-12';
            break;
        }
        case 'Premier10': {
            ret = 'premier-10';
            break;
        }
        case 'Premier6': {
            ret = 'premier-6';
            break;
        }
        case 'LuckyClover': {
            ret = 'lucky-clover';
            break;
        }
    }
    return ret;
};

export const toBetSlipKey = (gameType: GameType): keyof BetSlipSlice => {
    let ret: keyof BetSlipSlice;
    switch (gameType) {
        case 'classic-pools': {
            ret = 'ClassicPools';
            break;
        }
        case 'goal-rush': {
            ret = 'GoalRush8';
            break;
        }
        case 'jackpot-12': {
            ret = 'Jackpot12';
            break;
        }
        case 'lucky-clover': {
            ret = 'LuckyClover';
            break;
        }
        case 'premier-10': {
            ret = 'Premier10';
            break;
        }
        case 'premier-6': {
            ret = 'Premier6';
            break;
        }
        default: {
            ret = 'ClassicPools';
            break;
        }
    }
    return ret;
};

export const numbersSelectedToArray = (selections?: NumbersSelected[]): string[] => {
    const ret =
        selections?.map(s => {
            return s.Id.toString();
        }) || [];
    return ret;
};
