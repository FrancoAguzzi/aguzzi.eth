export interface Offering {
    id: number;
    pricePerEntry: number;
    description: string;
    maximumSelections: number;
    planCode?: string;
    bonusId?: number;
    bonusPricePerEntry?: number;
    bonusDescription?: string;
    bonusMaximumSelections?: number;
    saleable?: boolean;
    additionalOffering?: boolean;
    mustIncludeBonus?: boolean;
}

export interface GameType {
    subscription: boolean;
    oneOff: boolean;
}

export interface Offerings {
    defaultOffering: Offering;
    offerings: Offering[];
    gameType?: GameType;
    productId?: string;
    selectionType?: 'number' | 'hda';
    selectionsOffered?: number[] | string[];
}

// export type HDASelectionsType = ('H' | 'D' | 'A')[];
// export type NumberSelectionsType = number[];
// export type Selections = HDASelectionsType | NumberSelectionsType;
