export interface CompetitionResult {
    id: number;
    number: number;
    datumDate: string;
    state: string;
    description: string;
    fixtures: FixtureResult[];
    winningNumbers?: string[];
    competitionIds?: { [key: string]: number };
}

export interface FixtureResult {
    awayTeam: string;
    awayTeamDisplay: string;
    externalId: string;
    homeTeam: string;
    homeTeamDisplay: string;
    id: number;
    kickoff: string;
    number: number;
    status: string;
    points: number;
    scores: Scores;
}

export interface Scores {
    halfTime: Score;
    fullTime: Score;
    highScoreDraw: boolean;
    poolsPanel?: boolean;
    isVoid?: boolean;
}

export interface Score {
    home: number;
    away: number;
}

export type CompetitionResults = CompetitionResult[];
