import { Response } from './client';
import { Adaptor } from './adaptor';
import { GameType } from './models/game';
import { Competition } from './models/competition';
import { CompetitionResult } from './models/competition-result';
import { Offering, Offerings } from './models/offering';
import { CompetitionDividends } from './models/dividends';
import {
    PurchaseType,
    CreatedWagers,
    ConfirmWagers,
    ConfirmedWagers,
    Wagers,
    CompetitionWagers,
    UpdatedWager,
    Wager,
    PaymentMethods,
    PaymentMethod,
    SetupCardResult,
    SetupCard,
} from './models/wagers';
import { BetSlip } from './state/bet-slip-slice';
import { FinaliseDetails } from './state/wagers-slice';
import { Leaderboard } from './models/leaderboards';
import { LeaderboardResultsResponse } from './models/leaderboard-results';
import { TransactionHistoryResponse } from './models/transaction-history';
import { TransactionDetailsResponse } from './models/transaction-details';

export type ApiClientType = 'api' | 'backend';

export type ApiConfig = {
    clientType?: ApiClientType;
};

export type Api = {
    initialise: (adaptor: Adaptor) => void;
    getOpenCompetitions: (game: GameType) => Response<Competition[]>;
    getOpenCompetitionsAsync: (game: GameType) => Promise<Response<Competition[]>>;
    getCompetitionResults: (game: GameType) => Response<CompetitionResult[]>;
    getCompetitionResultsAsync: (game: GameType) => Promise<Response<CompetitionResult[]>>;
    getOfferings: (game: GameType) => Response<Offerings>;
    getOfferingsAsync: (game: GameType) => Promise<Response<Offerings>>;
    getFilteredOfferings: (game: GameType) => Response<Offering[]>;
    getFilteredOfferingsAsync: (game: GameType) => Promise<Response<Offering[]>>;
    getDividends: (game: GameType) => Response<CompetitionDividends>;
    getDividendsAsync: (game: GameType) => Promise<Response<CompetitionDividends>>;
    getWagers: (game: GameType) => Response<Wagers>;
    getWagersAsync: (game: GameType) => Promise<Response<Wagers>>;
    getWagerResults: (game: GameType, competitionNumber?: number) => Response<Wagers>;
    getWagerResultsAsync: (game: GameType, competitionNumber?: number) => Promise<Response<Wagers>>;
    getHealthCheck: () => Response<{ isAlive: boolean }>;
    getHealthCheckAsync: () => Promise<Response<{ isAlive: boolean }>>;
    createWagersInit: (
        wagers: BetSlip[],
        game: GameType,
        purchaseType: PurchaseType,
        competition?: Competition,
        paymentMethod?: PaymentMethod,
    ) => Response<CreatedWagers>;
    createWagersInitAsync: (
        wagers: BetSlip[],
        game: GameType,
        purchaseType: PurchaseType,
        competition?: Competition,
        paymentMethod?: PaymentMethod,
        numberOfGames?: number,
    ) => Promise<Response<CreatedWagers>>;
    confirmCreateWagers: (
        createWagers: ConfirmWagers,
        game: GameType,
        amount: number,
        wagers?: BetSlip[] | CompetitionWagers[],
    ) => Response<ConfirmedWagers>;
    confirmCreateWagersAsync: (
        createWagers: ConfirmWagers,
        game: GameType,
        amount: number,
        wagers?: BetSlip[] | CompetitionWagers[],
    ) => Promise<Response<ConfirmedWagers>>;
    finaliseCreateWagersPayment: (finaliseDetails: FinaliseDetails, game: GameType) => Response<ConfirmedWagers>;
    finaliseCreateWagersPaymentAsync: (
        finaliseDetails: FinaliseDetails,
        game: GameType,
    ) => Promise<Response<ConfirmedWagers>>;
    updateWager: (wager: Wager, game: GameType, futureGames?: boolean) => Response<UpdatedWager>;
    updateWagerAsync: (wager: Wager, game: GameType, futureGames?: boolean) => Promise<Response<UpdatedWager>>;
    getPaymentMethods: (game: GameType, numberOfLines: number, oneTime?: boolean) => Response<PaymentMethods>;
    getPaymentMethodsAsync: (
        game: GameType,
        numberOfLines: number,
        oneTime?: boolean,
    ) => Promise<Response<PaymentMethods>>;
    getLeaderboardAsync: (
        game: GameType,
        year: number,
        month?: number,
        week?: number,
        count?: number,
        page?: number,
        nickname?: string,
        playerId?: string,
    ) => Promise<Response<Leaderboard>>;
    getLeaderboardResultsAsync: (
        game: GameType,
        competitionId?: number,
        count?: number,
        page?: number,
        // authToken?: string,
    ) => Promise<Response<LeaderboardResultsResponse>>;
    getTransactionHistoryAsync: (
        fromDate?: string,
        toDate?: string,
        beforeTransactionId?: string,
    ) => Promise<Response<TransactionHistoryResponse>>;
    getTransactionDetailsAsync: (game: GameType, id: string) => Promise<Response<TransactionDetailsResponse>>;
    setupCardAsync: (details: SetupCard) => Promise<Response<SetupCardResult>>;
};
