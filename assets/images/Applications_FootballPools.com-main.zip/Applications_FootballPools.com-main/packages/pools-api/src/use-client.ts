import { useEffect, useState } from 'react';
import { Request, Response, send } from './client';

export const useClient = <T = never>({
    url,
    method,
    data,
    transformRequest,
    transformResponse,
    headers,
    baseUrl,
    onError,
    client,
}: Request): Response<T> => {
    const [response, setResponse] = useState<Response<T>>({ isLoading: true });
    useEffect(() => {
        const sendReq = async (): Promise<void> => {
            const res = await send({
                url,
                method,
                data,
                transformRequest,
                transformResponse,
                headers,
                baseUrl,
                onError,
                client,
            });
            setResponse(res);
        };
        sendReq();
    }, []);
    return response;
};
