import { BetSlip, BetSlipSlice } from './bet-slip-slice';
import {
    PurchaseType,
    ConfirmedWagers,
    ConfirmWagers,
    CompetitionWagers,
    PaymentMethod,
    SetupCard,
    SetupCardResult,
    CompletedSetupCard,
    CardDetails,
} from '../models/wagers';
import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { GameType, toGameType } from '../models/game';
import { PoolsApiError } from '../models/pools-api-error';
import { AppThunk } from './root-reducer';
import { useApi } from '../use-api';
import { Competition } from '../models/competition';

export type WagersStage =
    | 'error'
    | 'pending'
    | 'initialised'
    | 'created'
    | 'card-setup'
    | 'card-setup-complete'
    | 'confirmed'
    | 'authorising'
    | 'authorised';

export type FinaliseDetails = Pick<ConfirmedWagers, 'cardConfirmToken' | 'cardConfirmUrl' | 'reference'> & {
    paRes?: string;
    md?: string;
    purchaseType?: PurchaseType;
    transactionId?: string;
    cardDetails?: CardDetails;
};

export type GameViewType = 'match' | 'numbers';

export interface WagersSlice {
    stage: WagersStage;
    game: GameType;
    purchaseType: PurchaseType;
    // TODO: resulted wagers should be a distinct property
    wagers: Array<BetSlip> | CompetitionWagers[];
    finaliseDetails?: FinaliseDetails;
    error?: PoolsApiError;
    preErrorStage?: WagersStage;
    isFetching?: boolean;
    competition?: Competition;
    payPalToken?: string;
    gameVariant?: string;
    numberOfGames?: number;
    orderId?: number;
    gameViewPreference?: GameViewType;
    cardSetup?: SetupCardResult;
    completedCardSetup?: CompletedSetupCard;
}

export const initialState: WagersSlice = {
    stage: 'pending',
    game: 'classic-pools',
    purchaseType: 'OneOff',
    wagers: [],
};

const wagers = createSlice({
    name: 'wagers',
    initialState,
    reducers: {
        createdWagers(
            state,
            action: PayloadAction<{
                wagers: Array<BetSlip> | CompetitionWagers[];
                purchaseType: PurchaseType;
                game: GameType;
                payPalToken?: string;
                orderId?: string;
            }>,
        ): void {
            state.purchaseType = action.payload.purchaseType;
            state.wagers = action.payload.wagers;
            state.stage = 'created';
            state.game = action.payload.game;
            state.error = undefined;
            state.isFetching = false;
            state.payPalToken = action.payload.payPalToken;
        },
        confirmedWagers(state, action: PayloadAction<ConfirmedWagers>): void {
            if (action.payload.isSuccess) {
                state.stage = 'confirmed';
                state.orderId = action.payload.orderId;
            } else if (action.payload.cardConfirmUrl) {
                state.stage = 'authorising';
                state.finaliseDetails = action.payload;
            }
            state.isFetching = false;
        },
        resetWagers(
            state,
            action: PayloadAction<{
                game?: GameType;
            }>,
        ): void {
            state.stage = 'pending';
            state.wagers = [];
            state.error = undefined;
            state.preErrorStage = undefined;
            state.purchaseType = 'OneOff';
            state.game = action.payload?.game || 'classic-pools';
            state.finaliseDetails = undefined;
            state.isFetching = false;
            state.competition = undefined;
            state.payPalToken = undefined;
            state.gameVariant = undefined;
            state.numberOfGames = undefined;
            state.orderId = undefined;
            state.cardSetup = undefined;
            state.completedCardSetup = undefined;
        },
        wagersError(state, action: PayloadAction<PoolsApiError | undefined>): void {
            state.preErrorStage = state.stage;
            state.stage = 'error';
            state.error = action.payload;
            state.isFetching = false;
        },
        authorisedWagers(
            state,
            action: PayloadAction<{
                paRes?: string;
                md?: string;
                transactionId?: string;
            }>,
        ): void {
            state.stage = 'authorised';
            if (state.finaliseDetails) {
                state.finaliseDetails.md = action.payload.md;
                state.finaliseDetails.paRes = action.payload.paRes;
                state.finaliseDetails.transactionId = action.payload.transactionId;
            }
            state.isFetching = false;
        },
        initialiseWagers(
            state,
            action: PayloadAction<{
                wagers: Array<BetSlip>;
                game: GameType;
                purchaseType: PurchaseType;
                competition?: Competition;
                gameVariant?: string;
                numberOfGames?: number;
            }>,
        ): void {
            state.stage = 'initialised';
            state.wagers = action.payload.wagers.filter(w => w.numbers && w.numbers.length > 0);
            state.game = action.payload.game;
            state.purchaseType = action.payload.purchaseType;
            state.error = undefined;
            state.finaliseDetails = undefined;
            state.isFetching = false;
            state.competition = action.payload.competition;
            state.gameVariant = action.payload.gameVariant;
            state.numberOfGames = action.payload.numberOfGames;
        },
        setWagersIsFetching(state, action: PayloadAction<{ isFetching: boolean }>): void {
            state.isFetching = action.payload.isFetching;
        },
        clearError(state, action: PayloadAction<WagersStage>): void {
            state.error = undefined;
            state.preErrorStage = undefined;
            state.stage = action.payload;
        },
        setGameViewPreference(state, action: PayloadAction<{ gameViewPreference: GameViewType }>): void {
            state.gameViewPreference = action.payload.gameViewPreference;
        },
        initialiseCardSetup(state, action: PayloadAction<{ data: SetupCardResult }>): void {
            state.stage = 'card-setup';
            state.cardSetup = action.payload.data;
        },
        completeCardSetup(state, action: PayloadAction<{ data: CompletedSetupCard }>): void {
            state.stage = 'card-setup-complete';
            state.completedCardSetup = action.payload.data;
        },
    },
});

export const {
    createdWagers,
    confirmedWagers,
    resetWagers,
    wagersError,
    authorisedWagers,
    initialiseWagers,
    setWagersIsFetching,
    clearError,
    setGameViewPreference,
    initialiseCardSetup,
    completeCardSetup,
} = wagers.actions;

export default wagers.reducer;

export const createWagers = (
    wagers: Array<BetSlip>,
    gameType: keyof BetSlipSlice,
    purchaseType: PurchaseType = 'Subscription',
    competition?: Competition,
    paymentMethod?: PaymentMethod,
    numberOfGames?: number,
): AppThunk => async (dispatch): Promise<void> => {
    const { createWagersInitAsync } = useApi('backend');
    const game = toGameType(gameType);
    dispatch(setWagersIsFetching({ isFetching: true }));
    const res = await createWagersInitAsync(
        wagers,
        toGameType(gameType),
        purchaseType,
        competition,
        paymentMethod,
        numberOfGames,
    );
    if (res.data && res.data.isSuccess) {
        if (res.data.competitions) {
            dispatch(
                createdWagers({
                    wagers: res.data.competitions as CompetitionWagers[],
                    purchaseType,
                    game,
                }),
            );
        } else {
            dispatch(
                createdWagers({
                    wagers,
                    purchaseType,
                    game,
                    payPalToken: res.data.token,
                }),
            );
        }
    } else {
        dispatch(wagersError(res.error));
    }
};

export const confirmWagers = (confirmWagers: ConfirmWagers, game: GameType, amount: number): AppThunk => async (
    dispatch,
    getState,
): Promise<void> => {
    const { confirmCreateWagersAsync } = useApi('backend');
    const state = getState().wagers;
    if (state.stage === 'error') {
        dispatch(clearError('created'));
    }
    dispatch(setWagersIsFetching({ isFetching: true }));
    const res = await confirmCreateWagersAsync(confirmWagers, game, amount, state.wagers);
    if (res.data) {
        dispatch(confirmedWagers(res.data));
    } else {
        dispatch(wagersError(res.error));
    }
};

export const finaliseWagers = (cardDetails?: CardDetails): AppThunk => async (dispatch, getState): Promise<void> => {
    const { finaliseCreateWagersPaymentAsync } = useApi('backend');
    const finaliseDetails = getState().wagers.finaliseDetails;
    const purchaseType = getState().wagers.purchaseType;
    if (finaliseDetails) {
        dispatch(setWagersIsFetching({ isFetching: true }));
        const res = await finaliseCreateWagersPaymentAsync(
            { ...finaliseDetails, purchaseType, cardDetails },
            getState().wagers.game,
        );
        if (res.data && res.data.isSuccess) {
            dispatch(confirmedWagers(res.data));
        } else {
            dispatch(wagersError(res.error));
        }
    } else {
        dispatch(
            wagersError({
                title: 'Missing finaliseDetails',
                code: 'missingfinalisedetails',
            }),
        );
    }
};

export const setupCard = (details: SetupCard): AppThunk => async (dispatch): Promise<void> => {
    const { setupCardAsync } = useApi('backend');
    dispatch(setWagersIsFetching({ isFetching: true }));
    const res = await setupCardAsync(details);
    if (res && res.data) {
        dispatch(initialiseCardSetup({ data: res.data }));
    } else {
        dispatch(wagersError(res.error));
    }
};
