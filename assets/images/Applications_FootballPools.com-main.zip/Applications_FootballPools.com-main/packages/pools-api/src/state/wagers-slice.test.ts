import wagers, {
    initialState,
    WagersSlice,
    WagersStage,
    createdWagers,
    confirmedWagers,
    resetWagers,
    wagersError,
    authorisedWagers,
    createWagers,
    confirmWagers,
    finaliseWagers,
    initialiseWagers,
    setWagersIsFetching,
    clearError,
    initialiseCardSetup,
    completeCardSetup,
    setupCard,
} from './wagers-slice';
import { AnyAction } from '@reduxjs/toolkit';
import { BetSlip } from './bet-slip-slice';
import { Api } from '../api';
import { PoolsApiError } from '../models/pools-api-error';
import { SetupCard, SetupCardResult } from '../models/wagers';

const mockCreateWagersInitAsync = jest.fn();
const mockConfirmCreateWagersAsync = jest.fn();
const mockFinaliseCreateWagersPaymentAsync = jest.fn();
const mockSetupCardAsync = jest.fn();
jest.mock('../use-api', () => {
    return {
        useApi: (): Partial<Api> => ({
            createWagersInitAsync: mockCreateWagersInitAsync,
            confirmCreateWagersAsync: mockConfirmCreateWagersAsync,
            finaliseCreateWagersPaymentAsync: mockFinaliseCreateWagersPaymentAsync,
            setupCardAsync: mockSetupCardAsync,
        }),
    };
});

const testWagers: Array<BetSlip> = [
    {
        competitionId: 1234,
        competitionName: 'desc',
        pick: 10,
        current: true,
        price: 100,
        priceID: 5,
        numbers: [
            { Id: 1, rows: 1, selections: [] },
            { Id: 2, rows: 1, selections: [] },
            { Id: 3, rows: 1, selections: [] },
            { Id: 4, rows: 1, selections: [] },
            { Id: 5, rows: 1, selections: [] },
            { Id: 6, rows: 1, selections: [] },
            { Id: 7, rows: 1, selections: [] },
            { Id: 8, rows: 1, selections: [] },
            { Id: 9, rows: 1, selections: [] },
            { Id: 10, rows: 1, selections: [] },
        ],
        bonusNumbers: [],
        bonusPick: 0,
        bonusPrice: 0,
        bonusPriceId: 0,
    },
];

describe('wagerSlice tests', () => {
    describe('reducer', () => {
        it('handles initial state', () => {
            const result = wagers(undefined, {} as AnyAction);
            expect(result).toEqual<WagersSlice>(initialState);
        });

        it('handles created wagers: sets wagers, purchase type, game and state', () => {
            const action = createdWagers({
                wagers: testWagers,
                purchaseType: 'Subscription',
                game: 'classic-pools',
            });
            const result = wagers(initialState, action);
            expect(result).toEqual<WagersSlice>({
                wagers: testWagers,
                stage: 'created',
                purchaseType: 'Subscription',
                game: 'classic-pools',
                error: undefined,
                isFetching: false,
            });
        });

        it('handles confirmed wagers: sets stage to confirmed', () => {
            const action = confirmedWagers({ isSuccess: true });
            const result = wagers(initialState, action);
            expect(result.stage).toEqual<WagersStage>('confirmed');
        });

        it('handles confirmed wagers: sets finaliseDetails and stage to authorising', () => {
            const testCardToken = 'tokentokentoken';
            const testCardConfirmUrl = 'https://cardConfirmUrl.com';
            const action = confirmedWagers({
                isSuccess: false,
                cardConfirmToken: testCardToken,
                cardConfirmUrl: testCardConfirmUrl,
            });
            const result = wagers(initialState, action);
            expect(result.stage).toEqual<WagersStage>('authorising');
            expect(result.finaliseDetails).toEqual({
                cardConfirmToken: testCardToken,
                cardConfirmUrl: testCardConfirmUrl,
                isSuccess: false,
            });
        });

        it('handles resets wagers: resets state', () => {
            const currentState: WagersSlice = {
                game: initialState.game,
                wagers: testWagers,
                purchaseType: 'Subscription',
                stage: 'confirmed',
            };
            const action = resetWagers({ game: 'classic-pools' });
            const result = wagers(currentState, action);
            expect(result).toEqual<WagersSlice>({
                game: 'classic-pools',
                stage: 'pending',
                purchaseType: 'OneOff',
                wagers: [],
                error: undefined,
                isFetching: false,
            });
        });

        it('handles wagers error: sets error', () => {
            const error: PoolsApiError = {
                title: 'whoopsie',
                code: 'default.derp',
            };
            const action = wagersError(error);
            const result = wagers(initialState, action);
            expect(result.stage).toEqual<WagersStage>('error');
            expect(result.error).toEqual<PoolsApiError>(error);
        });

        it('handles authorised wagers: sets finaliseDetails and sets stage to authorised', () => {
            const currentState: WagersSlice = {
                stage: 'authorising',
                wagers: testWagers,
                game: 'classic-pools',
                purchaseType: 'OneOff',
                finaliseDetails: {},
            };
            const authorisedWagersRes = {
                paRes: 'sdifsdijdfihmbisd9u0weriuhsdjo',
                md: 'MD1234_12345678',
                transactionId: 'asjfaisfjdg3r2ewfj',
            };
            const action = authorisedWagers(authorisedWagersRes);
            const result = wagers(currentState, action);
            expect(result.stage).toEqual('authorised');
            expect(result.finaliseDetails).toEqual(authorisedWagersRes);
        });

        it('handles initialise wagers: sets wagers, game and purchaseType', () => {
            const action = initialiseWagers({
                wagers: testWagers,
                game: 'classic-pools',
                purchaseType: 'ByGames',
            });
            const result = wagers(initialState, action);
            expect(result).toEqual<WagersSlice>({
                stage: 'initialised',
                wagers: testWagers,
                game: 'classic-pools',
                purchaseType: 'ByGames',
                error: undefined,
                finaliseDetails: undefined,
                isFetching: false,
            });
        });

        it('handles setWagersIsFetching: sets isFetching', () => {
            const action = setWagersIsFetching({ isFetching: true });
            const result = wagers(initialState, action);
            expect(result.isFetching).toEqual<boolean>(true);
        });

        it('handles clearError', () => {
            const action = clearError('initialised');
            const result = wagers(initialState, action);
            expect(result.stage).toEqual<WagersStage>('initialised');
            expect(result.error).toBeUndefined();
            expect(result.preErrorStage).toBeUndefined();
        });

        it('handles initialiseCardSetup', () => {
            const currentState: WagersSlice = {
                game: initialState.game,
                wagers: testWagers,
                purchaseType: 'OneOff',
                stage: 'created',
            };
            const action = initialiseCardSetup({
                data: { token: 'aToken', url: 'https://testurl.com' },
            });
            const result = wagers(currentState, action);
            expect(result).toEqual<WagersSlice>({
                game: 'classic-pools',
                stage: 'card-setup',
                purchaseType: 'OneOff',
                wagers: testWagers,
                cardSetup: { token: 'aToken', url: 'https://testurl.com' },
            });
        });

        it('handles completeCardSetup', () => {
            const currentState: WagersSlice = {
                game: initialState.game,
                wagers: testWagers,
                purchaseType: 'OneOff',
                stage: 'created',
            };
            const action = completeCardSetup({
                data: { sessionId: 'aToken', returnUrl: 'https://testurl.com' },
            });
            const result = wagers(currentState, action);
            expect(result).toEqual<WagersSlice>({
                game: 'classic-pools',
                stage: 'card-setup-complete',
                purchaseType: 'OneOff',
                wagers: testWagers,
                completedCardSetup: {
                    sessionId: 'aToken',
                    returnUrl: 'https://testurl.com',
                },
            });
        });
    });

    describe('thunk actions', () => {
        describe('createWagers thunk', () => {
            beforeEach(() => {
                mockCreateWagersInitAsync.mockReset();
            });

            it('dispatches created wagers', async () => {
                mockCreateWagersInitAsync.mockResolvedValue({
                    isLoading: false,
                    data: {
                        id: 1234,
                        isSuccess: true,
                    },
                });
                const mockDispatch = jest.fn();
                const mockGetState = jest.fn();
                await createWagers(testWagers, 'ClassicPools', 'Subscription')(mockDispatch, mockGetState, null);
                expect(mockCreateWagersInitAsync).toHaveBeenCalledWith(
                    testWagers,
                    'classic-pools',
                    'Subscription',
                    undefined,
                    undefined,
                    undefined,
                );
                expect(mockDispatch).toHaveBeenCalledWith(
                    createdWagers({
                        wagers: testWagers,
                        purchaseType: 'Subscription',
                        game: 'classic-pools',
                    }),
                );
            });

            it('dispatches wagers error', async () => {
                const error: PoolsApiError = {
                    title: 'whoopsie',
                    code: 'derp.default',
                };
                mockCreateWagersInitAsync.mockResolvedValue({
                    isLoading: false,
                    data: {
                        isSuccess: false,
                    },
                    error: error,
                });
                const mockDispatch = jest.fn();
                const mockGetState = jest.fn();
                await createWagers(testWagers, 'ClassicPools', 'Subscription')(mockDispatch, mockGetState, null);
                expect(mockDispatch).toHaveBeenCalledWith(wagersError(error));
            });
        });

        describe('confirmWagers thunk', () => {
            beforeEach(() => {
                mockConfirmCreateWagersAsync.mockReset();
            });

            it('dispatches confirmed wagers', async () => {
                mockConfirmCreateWagersAsync.mockResolvedValue({
                    data: {
                        orderId: 1234,
                        isSuccess: true,
                    },
                    isLoading: false,
                });
                const mockDispatch = jest.fn();
                const mockGetState = jest.fn();
                mockGetState.mockReturnValue({
                    wagers: testWagers,
                });
                await confirmWagers(
                    {
                        cardDetails: {
                            cardNumber: '4444333322221111',
                            expiryMonth: '01',
                            expiryYear: '02',
                            cvv: '987',
                        },
                    },
                    'classic-pools',
                )(mockDispatch, mockGetState, null);
                expect(mockDispatch).toHaveBeenCalledWith(confirmedWagers({ orderId: 1234, isSuccess: true }));
            });

            it('dispatches wagers error', async () => {
                const error: PoolsApiError = {
                    title: 'whoopsie',
                    code: 'derp.default',
                };
                mockConfirmCreateWagersAsync.mockResolvedValue({
                    isLoading: false,
                    error: error,
                });
                const mockDispatch = jest.fn();
                const mockGetState = jest.fn();
                mockGetState.mockReturnValue({
                    wagers: testWagers,
                });
                await confirmWagers(
                    {
                        cardDetails: {
                            cardNumber: '4444333322221111',
                            expiryMonth: '01',
                            expiryYear: '02',
                            cvv: '987',
                        },
                    },
                    'classic-pools',
                )(mockDispatch, mockGetState, null);
                expect(mockDispatch).toHaveBeenCalledWith(wagersError(error));
            });
        });

        describe('finaliseWagers thunk', () => {
            beforeEach(() => {
                mockFinaliseCreateWagersPaymentAsync.mockReset();
            });

            it('dispatches confirmed wagers', async () => {
                mockFinaliseCreateWagersPaymentAsync.mockResolvedValue({
                    data: {
                        isSuccess: true,
                        orderId: 1234,
                    },
                    isLoading: false,
                });
                const mockDispatch = jest.fn();
                const mockGetState = jest.fn();
                mockGetState.mockReturnValue({
                    wagers: {
                        finaliseDetails: {},
                        game: 'classic-pools',
                    },
                });
                await finaliseWagers()(mockDispatch, mockGetState, null);
                expect(mockDispatch).toHaveBeenCalledWith(confirmedWagers({ isSuccess: true, orderId: 1234 }));
            });

            it('dispatches wagers error when missing finalise details', async () => {
                mockFinaliseCreateWagersPaymentAsync.mockResolvedValue({
                    data: {
                        isSuccess: true,
                        orderId: 1234,
                    },
                    isLoading: false,
                });
                const mockDispatch = jest.fn();
                const mockGetState = jest.fn();
                mockGetState.mockReturnValue({
                    wagers: {
                        finaliseDetails: null,
                        game: 'classic-pools',
                    },
                });
                await finaliseWagers()(mockDispatch, mockGetState, null);
                expect(mockDispatch).toHaveBeenCalledWith(
                    wagersError({
                        title: 'Missing finaliseDetails',
                        code: 'missingfinalisedetails',
                    }),
                );
            });

            it('dispatches wagers error when api returns error', async () => {
                const error: PoolsApiError = {
                    title: 'Missing finaliseDetails',
                    code: 'missingfinalisedetails',
                };
                mockFinaliseCreateWagersPaymentAsync.mockResolvedValue({
                    data: {
                        isSuccess: false,
                    },
                    isLoading: false,
                    error: error,
                });
                const mockDispatch = jest.fn();
                const mockGetState = jest.fn();
                mockGetState.mockReturnValue({
                    wagers: {
                        finaliseDetails: null,
                        game: 'classic-pools',
                    },
                });
                await finaliseWagers()(mockDispatch, mockGetState, null);
                expect(mockDispatch).toHaveBeenCalledWith(wagersError(error));
            });
        });
    });

    describe('setupCard thunk', () => {
        beforeEach(() => {
            mockSetupCardAsync.mockReset();
        });

        it('dispatches initialiseCardSetup', async () => {
            const mockDetails: SetupCard = {
                cardDetails: {
                    cardNumber: '4000000000000002',
                    expiryMonth: '01',
                    expiryYear: '22',
                    cvv: '123',
                },
            };
            const mockResponse: SetupCardResult = {
                token: 'aToken',
                url: 'https://testurl.com',
            };
            const mockDispatch = jest.fn();
            mockSetupCardAsync.mockResolvedValue({
                data: mockResponse,
                isLoading: false,
            });
            await setupCard(mockDetails)(mockDispatch, jest.fn(), null);
            expect(mockDispatch).toHaveBeenCalledWith(
                initialiseCardSetup({
                    data: mockResponse,
                }),
            );
        });

        it('dispatches wagers error when missing data', async () => {
            const mockError: PoolsApiError = {
                title: 'derp',
                code: 'whoops',
            };
            mockSetupCardAsync.mockResolvedValue({
                data: undefined,
                isLoading: false,
                error: mockError,
            });
            const mockDispatch = jest.fn();
            const mockDetails: SetupCard = {
                cardDetails: {
                    cardNumber: '4000000000000002',
                    expiryMonth: '01',
                    expiryYear: '22',
                    cvv: '123',
                },
            };
            await setupCard(mockDetails)(mockDispatch, jest.fn(), null);
            expect(mockDispatch).toHaveBeenCalledWith(wagersError(mockError));
        });
    });
});
