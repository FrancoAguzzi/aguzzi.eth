import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Competition } from '../models/competition';
import { Offerings, Offering } from '../models/offering';

export interface BetSlipSlice {
    ClassicPools: Array<BetSlip>;
    Premier6: Array<BetSlip>;
    GoalRush8: Array<BetSlip>;
    Premier10: Array<BetSlip>;
    Jackpot12: Array<BetSlip>;
    LuckyClover: Array<BetSlip>;
}
export interface BetSlip {
    competitionId: number;
    competitionName?: string;
    pick: number;
    bonusPick: number;
    current: boolean;
    price: number;
    bonusPrice: number;
    priceID: number;
    highestRow?: number;
    numbers?: Array<NumbersSelected>;
    bonusPriceId: number;
    bonusNumbers: Array<NumbersSelected>;
    addedToCart?: boolean;
}

export interface NumbersSelected {
    Id: number;
    rows: number;
    selections: Array<string>;
}

export interface NumbersSelectedInput {
    MatchID: number;
    Selection: string;
}

const initialState: BetSlipSlice = {
    ClassicPools: [],
    Premier6: [],
    GoalRush8: [],
    Premier10: [],
    Jackpot12: [],
    LuckyClover: [],
};

export const luckyDip = (betslip: BetSlip, key: keyof BetSlipSlice, isBonus?: boolean): BetSlip => {
    // TODO Make it do home and away
    if (betslip) {
        let AmountOfGames = 49;
        if (key === 'ClassicPools') {
            AmountOfGames = 49;
        } else if (key === 'GoalRush8') {
            AmountOfGames = 35;
        } else if (key === 'Premier6') {
            AmountOfGames = 6;
        } else if (key === 'Premier10') {
            AmountOfGames = 10;
        } else if (key === 'Jackpot12') {
            AmountOfGames = 12;
        } else if (key === 'LuckyClover') {
            AmountOfGames = 47;
        }
        if (isBonus) {
            if (betslip.bonusPick === betslip.bonusNumbers?.length) {
                betslip.bonusNumbers = [];
            }
        } else {
            if (betslip.pick === betslip.numbers?.length) {
                betslip.numbers = [];
            }
        }

        while (
            // eslint-disable-next-line no-unmodified-loop-condition
            (isBonus && betslip.bonusPick !== betslip.bonusNumbers?.length) ||
            // eslint-disable-next-line no-unmodified-loop-condition
            (!isBonus && betslip.pick !== betslip.numbers?.length)
        ) {
            const number = Math.floor(Math.random() * AmountOfGames + 1);
            if (
                betslip.numbers?.find(x => x.Id === number) === undefined &&
                betslip.bonusNumbers?.find(x => x.Id === number) === undefined
            ) {
                let Selection = ['D'];
                if (key === 'Premier6' || key === 'Premier10' || key === 'Jackpot12') {
                    const r = Math.floor(Math.random() * 3) + 1;
                    if (r === 1) {
                        Selection = ['H'];
                    } else if (r === 2) {
                        Selection = ['A'];
                    } else {
                        Selection = ['D'];
                    }
                }
                if (isBonus) {
                    // eslint-disable-next-line no-unused-expressions
                    betslip.bonusNumbers?.push({
                        Id: number as number,
                        rows: 1,
                        selections: Selection,
                    });
                } else {
                    // eslint-disable-next-line no-unused-expressions
                    betslip.numbers?.push({
                        Id: number as number,
                        rows: 1,
                        selections: Selection,
                    });
                }
            }
        }
        if (isBonus) {
            // eslint-disable-next-line no-unused-expressions
            betslip.bonusNumbers?.sort((a, b) => a.Id - b.Id);
        } else {
            // eslint-disable-next-line no-unused-expressions
            betslip.numbers?.sort((a, b) => a.Id - b.Id);
        }
        betslip.highestRow = betslip.numbers?.reduce((maxId, item) => Math.max(maxId, item.rows), 0);
    }

    return betslip;
};

export const updateBetslipWithNumber = (
    betslip: BetSlip,
    action: {
        ItemKey: keyof BetSlipSlice;
        id: number;
        Type: string;
    },
): BetSlip => {
    if (betslip) {
        const NumberID = betslip.numbers?.findIndex(x => x.Id === action.id);
        if (NumberID !== undefined && NumberID > -1) {
            // Game Exists
            if (betslip.numbers![NumberID].selections.includes(action.Type)) {
                if (betslip.numbers![NumberID].selections.length === 1) {
                    // eslint-disable-next-line no-unused-expressions
                    betslip.numbers?.splice(NumberID, 1);
                } else {
                    betslip.numbers![NumberID].selections = betslip.numbers![NumberID].selections.filter(
                        x => x !== action.Type,
                    );
                    betslip.numbers![NumberID].rows = betslip.numbers![NumberID].selections.length;
                }
            } else {
                betslip.numbers![NumberID].selections.push(action.Type);
                betslip.numbers![NumberID].rows = betslip.numbers![NumberID].selections.length;
                betslip.numbers![NumberID].selections = betslip.numbers![NumberID].selections.sort().reverse();
            }
        } else {
            const BonusNumberID = betslip.bonusNumbers?.findIndex(x => x.Id === action.id);
            if (BonusNumberID !== undefined && BonusNumberID > -1) {
                // Game Exists
                if (betslip.bonusNumbers![BonusNumberID].selections.includes(action.Type)) {
                    if (betslip.bonusNumbers![BonusNumberID].selections.length === 1) {
                        // eslint-disable-next-line no-unused-expressions
                        betslip.bonusNumbers?.splice(BonusNumberID, 1);
                    } else {
                        betslip.bonusNumbers![BonusNumberID].selections = betslip.bonusNumbers![
                            BonusNumberID
                        ].selections.filter(x => x !== action.Type);
                        betslip.bonusNumbers![BonusNumberID].rows = betslip.bonusNumbers![
                            BonusNumberID
                        ].selections.length;
                    }
                } else {
                    betslip.bonusNumbers![BonusNumberID].selections.push(action.Type);
                    betslip.bonusNumbers![BonusNumberID].rows = betslip.bonusNumbers![BonusNumberID].selections.length;
                    betslip.bonusNumbers![BonusNumberID].selections = betslip
                        .bonusNumbers![BonusNumberID].selections.sort()
                        .reverse();
                }
            } else {
                if (betslip.pick === betslip.numbers?.length && betslip.bonusPick === betslip.bonusNumbers?.length) {
                    return betslip;
                }
                // eslint-disable-next-line no-unused-expressions
                if (betslip.numbers && betslip.pick > betslip.numbers.length) {
                    betslip.numbers?.push({
                        Id: action.id as number,
                        rows: 1,
                        selections: [action.Type],
                    });
                } else if (betslip.bonusNumbers && betslip.bonusPick > betslip.bonusNumbers.length) {
                    betslip.bonusNumbers?.push({
                        Id: action.id as number,
                        rows: 1,
                        selections: [action.Type],
                    });
                }
            }
        }
        // eslint-disable-next-line no-unused-expressions
        betslip.numbers?.sort((a, b) => a.Id - b.Id);
        betslip.bonusNumbers?.sort((a, b) => a.Id - b.Id);
        betslip.highestRow = betslip.numbers?.reduce((maxId, item) => Math.max(maxId, item.rows), 0);
    }
    return betslip;
};

const betslip = createSlice({
    name: 'BetSlipSlice',
    initialState,
    reducers: {
        UpdateClassicPoolsWithNumber(
            state,
            action: PayloadAction<{
                ItemKey: keyof BetSlipSlice;
                id: number;
                Type: string;
            }>,
        ): void {
            if (state[action.payload.ItemKey].length > 0) {
                const id = state[action.payload.ItemKey].findIndex(x => x.current === true);
                if (id > -1) {
                    const NumberID = state[action.payload.ItemKey][id].numbers?.findIndex(
                        x => x.Id === action.payload.id,
                    );

                    const BonusNumberID = state[action.payload.ItemKey][id].bonusNumbers?.findIndex(
                        x => x.Id === action.payload.id,
                    );

                    const isBonus =
                        (action.payload.ItemKey === 'LuckyClover' &&
                            state[action.payload.ItemKey][id].bonusPriceId > 0 &&
                            state[action.payload.ItemKey][id].numbers?.length ===
                                state[action.payload.ItemKey][id].pick &&
                            NumberID !== undefined &&
                            NumberID === -1) ||
                        (state[action.payload.ItemKey][id].bonusPriceId > 0 &&
                            BonusNumberID !== undefined &&
                            BonusNumberID > -1);

                    const numberId = isBonus ? BonusNumberID : NumberID;
                    const numbers = isBonus
                        ? state[action.payload.ItemKey][id].bonusNumbers
                        : state[action.payload.ItemKey][id].numbers;
                    if (numberId !== undefined && numberId > -1) {
                        // Game Exists
                        if (numbers![numberId].selections.includes(action.payload.Type)) {
                            if (numbers![numberId].selections.length === 1) {
                                // eslint-disable-next-line no-unused-expressions
                                numbers?.splice(numberId, 1);
                            } else {
                                numbers![numberId].selections = numbers![numberId].selections.filter(
                                    x => x !== action.payload.Type,
                                );
                                numbers![numberId].rows = numbers![numberId].selections.length;
                            }
                        } else {
                            numbers![numberId].selections.push(action.payload.Type);
                            numbers![numberId].rows = numbers![numberId].selections.length;
                            numbers![numberId].selections = numbers![numberId].selections.sort().reverse();
                        }
                        if (isBonus) {
                            state[action.payload.ItemKey][id].bonusNumbers = numbers as NumbersSelected[];
                        } else {
                            state[action.payload.ItemKey][id].numbers = numbers;
                        }
                    } else {
                        if (
                            (state[action.payload.ItemKey][id].bonusPick === undefined &&
                                state[action.payload.ItemKey][id].pick === numbers?.length) ||
                            (state[action.payload.ItemKey][id].bonusPick !== undefined &&
                                state[action.payload.ItemKey][id].bonusPick ===
                                    state[action.payload.ItemKey][id].bonusNumbers.length &&
                                state[action.payload.ItemKey][id].pick ===
                                    state[action.payload.ItemKey][id].numbers?.length)
                        ) {
                            return;
                        }

                        if (
                            state[action.payload.ItemKey][id].bonusPick !== undefined &&
                            state[action.payload.ItemKey][id].numbers?.length === state[action.payload.ItemKey][id].pick
                        ) {
                            // eslint-disable-next-line no-unused-expressions
                            state[action.payload.ItemKey][id].bonusNumbers?.push({
                                Id: action.payload.id as number,
                                rows: 1,
                                selections: [action.payload.Type],
                            });
                        } else {
                            // eslint-disable-next-line no-unused-expressions
                            state[action.payload.ItemKey][id].numbers?.push({
                                Id: action.payload.id as number,
                                rows: 1,
                                selections: [action.payload.Type],
                            });
                        }
                    }
                    // eslint-disable-next-line no-unused-expressions
                    state[action.payload.ItemKey][id].numbers?.sort((a, b) => a.Id - b.Id);
                    // eslint-disable-next-line no-unused-expressions
                    state[action.payload.ItemKey][id].bonusNumbers?.sort((a, b) => a.Id - b.Id);
                    state[action.payload.ItemKey][id].highestRow = state[action.payload.ItemKey][id].numbers?.reduce(
                        (maxId, item) => Math.max(maxId, item.rows),
                        0,
                    );
                }
            }
        },
        CreateFirstSlip(
            state,
            action: PayloadAction<{
                ItemKey: keyof BetSlipSlice;
                Competition: Competition;
                Offers: Offerings;
            }>,
        ): void {
            if (state[action.payload.ItemKey].length <= 0) {
                state[action.payload.ItemKey].push({
                    competitionId: action.payload.Competition.id,
                    competitionName: action.payload.Competition.description,
                    current: true,
                    highestRow: 1,
                    pick: action.payload.Offers.defaultOffering.maximumSelections,
                    bonusPick:
                        action.payload.Offers.defaultOffering.bonusMaximumSelections !== undefined
                            ? action.payload.Offers.defaultOffering.bonusMaximumSelections
                            : 0,
                    price: action.payload.Offers.defaultOffering.pricePerEntry,
                    bonusPrice:
                        action.payload.Offers.defaultOffering.bonusPricePerEntry !== undefined
                            ? action.payload.Offers.defaultOffering.bonusPricePerEntry
                            : 0,
                    priceID: action.payload.Offers.defaultOffering.id,
                    numbers: [],
                    bonusPriceId:
                        action.payload.Offers.defaultOffering.bonusId !== undefined
                            ? action.payload.Offers.defaultOffering.bonusId
                            : 0,
                    bonusNumbers: [],
                    addedToCart: false,
                });
            }
        },
        UpdateAmount(
            state,
            action: PayloadAction<{
                ItemKey: keyof BetSlipSlice;
                id: number;
                Amount: Offering;
            }>,
        ): void {
            if (state[action.payload.ItemKey].length > 0) {
                let id: number;
                if (action.payload.Amount.bonusId !== 0) {
                    id = state[action.payload.ItemKey].findIndex(x => x.current === true);
                } else {
                    id = state[action.payload.ItemKey].findIndex(
                        x => x.current === true && x.competitionId === action.payload.id,
                    );
                }

                if (id > -1) {
                    state[action.payload.ItemKey][id].pick = action.payload.Amount.maximumSelections;
                    state[action.payload.ItemKey][id].price = action.payload.Amount.pricePerEntry;
                    state[action.payload.ItemKey][id].priceID = action.payload.Amount.id;
                    if (state[action.payload.ItemKey][id].bonusPick !== undefined) {
                        state[action.payload.ItemKey][id].bonusPick = action.payload.Amount
                            .bonusMaximumSelections as number;
                        state[action.payload.ItemKey][id].bonusPrice = action.payload.Amount
                            .bonusPricePerEntry as number;
                        state[action.payload.ItemKey][id].bonusPriceId = action.payload.Amount.bonusId as number;
                    }

                    if (
                        state[action.payload.ItemKey][id].numbers !== undefined &&
                        action.payload.Amount.maximumSelections < state[action.payload.ItemKey][id].numbers!.length
                    ) {
                        const amounttoremove =
                            state[action.payload.ItemKey][id].numbers!.length - action.payload.Amount.maximumSelections;
                        for (let index = 0; index < amounttoremove; index++) {
                            state[action.payload.ItemKey][id].numbers!.pop();
                        }
                    }

                    if (
                        state[action.payload.ItemKey][id].bonusPick !== undefined &&
                        state[action.payload.ItemKey][id].bonusNumbers !== undefined &&
                        action.payload.Amount.bonusMaximumSelections !== undefined &&
                        action.payload.Amount.bonusMaximumSelections! <
                            state[action.payload.ItemKey][id].bonusNumbers.length
                    ) {
                        const amounttoremove =
                            state[action.payload.ItemKey][id].bonusNumbers!.length -
                            action.payload.Amount.bonusMaximumSelections;
                        for (let index = 0; index < amounttoremove; index++) {
                            state[action.payload.ItemKey][id].bonusNumbers!.pop();
                        }
                    }
                }
            }
        },
        LuckyDip(
            state,
            action: PayloadAction<{
                ItemKey: keyof BetSlipSlice;
                isMillion?: boolean;
            }>,
        ): void {
            // TODO Make it do home and away
            if (state[action.payload.ItemKey].length > 0) {
                const id = state[action.payload.ItemKey].findIndex(x => x.current === true);
                if (id > -1) {
                    let AmountOfGames = 49;
                    if (action.payload.ItemKey === 'ClassicPools') {
                        AmountOfGames = 49;
                    } else if (action.payload.ItemKey === 'GoalRush8') {
                        AmountOfGames = 35;
                    } else if (action.payload.ItemKey === 'Premier6') {
                        AmountOfGames = 6;
                    } else if (action.payload.ItemKey === 'Premier10') {
                        AmountOfGames = 10;
                    } else if (action.payload.ItemKey === 'Jackpot12') {
                        AmountOfGames = 12;
                    } else if (action.payload.ItemKey === 'LuckyClover') {
                        AmountOfGames = 47;
                    }
                    if (action.payload.isMillion) {
                        if (
                            state[action.payload.ItemKey][id].bonusPick ===
                            state[action.payload.ItemKey][id].bonusNumbers?.length
                        ) {
                            state[action.payload.ItemKey][id].bonusNumbers = [];
                        }
                    } else {
                        if (
                            state[action.payload.ItemKey][id].pick === state[action.payload.ItemKey][id].numbers?.length
                        ) {
                            state[action.payload.ItemKey][id].numbers = [];
                        }
                    }

                    // eslint-disable-next-line no-unmodified-loop-condition
                    while (
                        (action.payload.isMillion &&
                            state[action.payload.ItemKey][id].bonusPick !==
                                state[action.payload.ItemKey][id].bonusNumbers?.length) ||
                        (!action.payload.isMillion &&
                            state[action.payload.ItemKey][id].pick !==
                                state[action.payload.ItemKey][id].numbers?.length)
                    ) {
                        const number = Math.floor(Math.random() * AmountOfGames + 1);
                        if (
                            state[action.payload.ItemKey][id].numbers?.find(x => x.Id === number) === undefined &&
                            state[action.payload.ItemKey][id].bonusNumbers?.find(x => x.Id === number) === undefined
                        ) {
                            let Selection = ['D'];
                            if (
                                action.payload.ItemKey === 'Premier6' ||
                                action.payload.ItemKey === 'Premier10' ||
                                action.payload.ItemKey === 'Jackpot12'
                            ) {
                                const r = Math.floor(Math.random() * 3) + 1;
                                if (r === 1) {
                                    Selection = ['H'];
                                } else if (r === 2) {
                                    Selection = ['A'];
                                } else {
                                    Selection = ['D'];
                                }
                            }
                            if (action.payload.isMillion) {
                                // eslint-disable-next-line no-unused-expressions
                                state[action.payload.ItemKey][id].bonusNumbers?.push({
                                    Id: number as number,
                                    rows: 1,
                                    selections: Selection,
                                });
                            } else {
                                // eslint-disable-next-line no-unused-expressions
                                state[action.payload.ItemKey][id].numbers?.push({
                                    Id: number as number,
                                    rows: 1,
                                    selections: Selection,
                                });
                            }
                        }
                    }
                    if (action.payload.isMillion) {
                        // eslint-disable-next-line no-unused-expressions
                        state[action.payload.ItemKey][id].bonusNumbers?.sort((a, b) => a.Id - b.Id);
                    } else {
                        // eslint-disable-next-line no-unused-expressions
                        state[action.payload.ItemKey][id].numbers?.sort((a, b) => a.Id - b.Id);
                    }
                    state[action.payload.ItemKey][id].highestRow = state[action.payload.ItemKey][id].numbers?.reduce(
                        (maxId, item) => Math.max(maxId, item.rows),
                        0,
                    );
                }
            }
        },
        ClearLine(
            state,
            action: PayloadAction<{
                ItemKey: keyof BetSlipSlice;
                id: number;
                isCurrent?: boolean;
            }>,
        ): void {
            if (state[action.payload.ItemKey].length > 0) {
                const id =
                    action.payload.id > -1
                        ? action.payload.id
                        : state[action.payload.ItemKey].findIndex(x => x.current === true);
                if (id > -1) {
                    if (state[action.payload.ItemKey].length === 1) {
                        state[action.payload.ItemKey][id].numbers = [];
                        state[action.payload.ItemKey][id].bonusNumbers = [];
                        state[action.payload.ItemKey][id].highestRow = 1;
                    } else {
                        const isCurrent = action.payload.isCurrent ? action.payload.isCurrent : true;
                        state[action.payload.ItemKey].splice(id, 1);
                        state[action.payload.ItemKey][state[action.payload.ItemKey].length - 1].current = isCurrent;
                        state[action.payload.ItemKey][state[action.payload.ItemKey].length - 1].highestRow = 1;
                    }
                }
            }
        },
        AddedToCart(
            state,
            action: PayloadAction<{
                ItemKey: keyof BetSlipSlice;
                isPressPlay: boolean;
            }>,
        ): void {
            if (action.payload.isPressPlay) {
                for (const bet of state[action.payload.ItemKey]) {
                    bet.addedToCart = true;
                }
            } else {
                const id = state[action.payload.ItemKey].findIndex(x => x.current === true);
                state[action.payload.ItemKey][id].addedToCart = true;
            }
        },
        AddLine(
            state,
            action: PayloadAction<{
                ItemKey: keyof BetSlipSlice;
                Default: Offering;
            }>,
        ): void {
            if (state[action.payload.ItemKey].length > 0) {
                const id = state[action.payload.ItemKey].findIndex(x => x.current === true);
                if (state[action.payload.ItemKey][id].numbers?.length !== state[action.payload.ItemKey][id].pick) {
                    return;
                }
                state[action.payload.ItemKey].push({
                    competitionId: state[action.payload.ItemKey][id].competitionId,
                    competitionName: state[action.payload.ItemKey][id].competitionName,
                    current: true,
                    highestRow: 1,
                    pick: action.payload.Default.maximumSelections,
                    bonusPick:
                        action.payload.Default.bonusMaximumSelections !== undefined
                            ? action.payload.Default.bonusMaximumSelections
                            : 0,
                    price: action.payload.Default.pricePerEntry,
                    bonusPrice:
                        action.payload.Default.bonusPricePerEntry !== undefined
                            ? action.payload.Default.bonusPricePerEntry
                            : 0,
                    priceID: action.payload.Default.id,
                    numbers: [],
                    bonusPriceId: action.payload.Default.bonusId !== undefined ? action.payload.Default.bonusId : 0,
                    bonusNumbers: [],
                    addedToCart: false,
                });
                state[action.payload.ItemKey][id].current = false;
            }
        },
        ChangeCurrentBet(state, action: PayloadAction<{ ItemKey: keyof BetSlipSlice; id: number }>): void {
            if (state[action.payload.ItemKey].length > 0) {
                const id = state[action.payload.ItemKey].findIndex(x => x.current === true);
                if (state[action.payload.ItemKey][id].numbers?.length === state[action.payload.ItemKey][id].pick) {
                    state[action.payload.ItemKey][id].current = false;
                    state[action.payload.ItemKey][action.payload.id].current = true;
                } else if (state[action.payload.ItemKey][id].numbers?.length === 0) {
                    state[action.payload.ItemKey].splice(id, 1);
                    state[action.payload.ItemKey][action.payload.id].current = true;
                }
            }
        },
        AddNewLine(
            state,
            action: PayloadAction<{
                ItemKey: keyof BetSlipSlice;
                CompId: number;
                CompName: string;
                Offer: Offering;
            }>,
        ): void {
            if (state[action.payload.ItemKey].length > 0) {
                const id = state[action.payload.ItemKey].findIndex(x => x.current === true);
                if (
                    state[action.payload.ItemKey][id].numbers?.length !== state[action.payload.ItemKey][id].pick &&
                    state[action.payload.ItemKey][id].numbers?.length !== 0
                ) {
                    return;
                }
                state[action.payload.ItemKey].push({
                    competitionId: action.payload.CompId,
                    competitionName: action.payload.CompName,
                    current: true,
                    highestRow: 1,
                    pick: action.payload.Offer.maximumSelections,
                    bonusPick:
                        action.payload.Offer.bonusMaximumSelections !== undefined
                            ? action.payload.Offer.bonusMaximumSelections
                            : 0,
                    price: action.payload.Offer.pricePerEntry,
                    bonusPrice:
                        action.payload.Offer.bonusPricePerEntry !== undefined
                            ? action.payload.Offer.bonusPricePerEntry
                            : 0,
                    priceID: action.payload.Offer.id,
                    numbers: [],
                    bonusPriceId: action.payload.Offer.bonusId !== undefined ? action.payload.Offer.bonusId : 0,
                    bonusNumbers: [],
                    addedToCart: false,
                });
                state[action.payload.ItemKey][id].current = false;
                if (state[action.payload.ItemKey][id].numbers?.length === 0) {
                    state[action.payload.ItemKey].splice(id, 1);
                }
            }
        },
        MoveLinesToNewComp(
            state,
            action: PayloadAction<{
                ItemKey: keyof BetSlipSlice;
                CompId: number;
                CompName: string;
                Offerings: Offering[];
                lines: BetSlip[];
            }>,
        ): void {
            if (state[action.payload.ItemKey].length > 0) {
                for (const line of action.payload.lines) {
                    const id = state[action.payload.ItemKey].findIndex(x => x.current === true);
                    const offer = action.payload.Offerings.find(offer => offer.id === line.priceID);
                    if (offer === undefined) {
                        return;
                    }

                    state[action.payload.ItemKey].push({
                        competitionId: action.payload.CompId,
                        competitionName: action.payload.CompName,
                        current: true,
                        highestRow: line.highestRow,
                        pick: offer.maximumSelections,
                        bonusPick: offer.bonusMaximumSelections !== undefined ? offer.bonusMaximumSelections : 0,
                        price: offer.pricePerEntry,
                        bonusPrice: offer.bonusPricePerEntry !== undefined ? offer.bonusPricePerEntry : 0,
                        priceID: offer.id,
                        numbers: line.numbers !== undefined ? line.numbers : [],
                        bonusPriceId: offer.bonusId !== undefined ? offer.bonusId : 0,
                        bonusNumbers: line.bonusNumbers !== undefined ? line.bonusNumbers : [],
                        addedToCart: false,
                    });
                    state[action.payload.ItemKey][id].current = false;
                    if (state[action.payload.ItemKey][id].numbers?.length === 0) {
                        state[action.payload.ItemKey].splice(id, 1);
                    }
                }
            }
        },
        RemoveOldCompetitions(
            state,
            action: PayloadAction<{
                ItemKey: keyof BetSlipSlice;
                Competitions: Competition[];
                Offers: Offerings;
            }>,
        ): void {
            if (state[action.payload.ItemKey].length > 0) {
                const arr = state[action.payload.ItemKey].filter(function (item) {
                    return action.payload.Competitions.findIndex(x => x.id === item.competitionId) === -1;
                });
                state[action.payload.ItemKey] = arr;
            }
        },
        CreateFirstSlipAndClearOld(
            state,
            action: PayloadAction<{
                ItemKey: keyof BetSlipSlice;
                Competitions: Competition[];
                Offers: Offerings;
                clearIfOfferUnavailable?: boolean;
                clearIfCompetitionUnavailable?: boolean;
            }>,
        ): void {
            let arr = state[action.payload.ItemKey] || [];
            if (arr?.length > 0) {
                const array = arr.filter(function (item) {
                    return action.payload.Competitions.findIndex(x => x.id === item.competitionId) !== -1;
                });

                if (arr.length !== array.length) {
                    arr = array;
                }

                if (action.payload.clearIfOfferUnavailable) {
                    // Remove any existing bets with an unavailable offer:
                    const validBets = arr.filter(b => action.payload.Offers.offerings.find(o => b.priceID === o.id));
                    if (validBets.length !== arr.length) {
                        arr = validBets;
                    }
                }

                if (action.payload.clearIfCompetitionUnavailable) {
                    // Remove any existing bets with an unavailable competition:
                    const validBets = arr.filter(b => action.payload.Competitions.find(c => b.competitionId === c.id));
                    if (validBets.length !== arr.length) {
                        arr = validBets;
                    }
                }
            }

            if (arr.length <= 0) {
                arr.push({
                    competitionId: action.payload.Competitions[0].id,
                    competitionName: action.payload.Competitions[0].description,
                    current: true,
                    highestRow: 1,
                    pick: action.payload.Offers.defaultOffering.maximumSelections,
                    bonusPick: action.payload.Offers.defaultOffering.bonusMaximumSelections as number,
                    price: action.payload.Offers.defaultOffering.pricePerEntry,
                    bonusPrice:
                        action.payload.Offers.defaultOffering.bonusPricePerEntry !== undefined
                            ? action.payload.Offers.defaultOffering.bonusPricePerEntry
                            : 0,
                    priceID: action.payload.Offers.defaultOffering.id,
                    numbers: [],
                    bonusPriceId:
                        action.payload.Offers.defaultOffering.bonusId !== undefined
                            ? action.payload.Offers.defaultOffering.bonusId
                            : 0,
                    bonusNumbers: [],
                    addedToCart: false,
                });
            }
            if (arr.findIndex(x => x.current === true) === -1) {
                arr[0].current = true;
            }
            state[action.payload.ItemKey] = arr;
        },
        ResetBetSlipSelections(
            state,
            action: PayloadAction<{
                ItemKey: keyof BetSlipSlice;
            }>,
        ): void {
            if (state[action.payload.ItemKey].length > 0) {
                state[action.payload.ItemKey] = [];
            }
        },
    },
});

export const {
    UpdateClassicPoolsWithNumber,
    CreateFirstSlip,
    UpdateAmount,
    LuckyDip,
    ClearLine,
    AddedToCart,
    AddLine,
    ChangeCurrentBet,
    AddNewLine,
    MoveLinesToNewComp,
    RemoveOldCompetitions,
    CreateFirstSlipAndClearOld,
    ResetBetSlipSelections,
} = betslip.actions;

export default betslip.reducer;

// function pad(d: number) {
//     return d < 10 ? '0' + d.toString() : d.toString();
// }

// function ConvertBets(bet: BetSlip): WagerModel {
//     let Selection = '';
//     bet.numbers?.forEach((element) => {
//         Selection += pad(element.Id);
//     });

//     const wager: WagerModel = {
//         Selections: Selection,
//         OfferingId: bet.priceID.toString(),
//         PaidCost: bet.price,
//     };
//     return wager;
// }
