import { createSelector } from '@reduxjs/toolkit';
import { Selector as BaseSelector } from 'react-redux';

import { RootState } from './root-reducer';
import { BetSlipSlice } from './bet-slip-slice';
import { WagersSlice } from './wagers-slice';

export type Selector<T> = BaseSelector<RootState, T>;

const selectBetSlip: Selector<BetSlipSlice> = state => state.betSlip;
export const getBetSlipSelector = createSelector(selectBetSlip, state => state);

const selectWagers: Selector<WagersSlice> = state => state.wagers;
export const getWagersSelector = createSelector(selectWagers, state => state);
