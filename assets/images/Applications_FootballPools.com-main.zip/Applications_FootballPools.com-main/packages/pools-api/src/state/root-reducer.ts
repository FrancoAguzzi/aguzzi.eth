import { combineReducers, ThunkDispatch, AnyAction, ThunkAction, Action } from '@reduxjs/toolkit';
import betSlipReducer from '../state/bet-slip-slice';
import wagersReducer from './wagers-slice';

const rootReducer = combineReducers({
    betSlip: betSlipReducer,
    wagers: wagersReducer,
});

export type RootState = ReturnType<typeof rootReducer>;

export default rootReducer;

export type AppDispatch = ThunkDispatch<RootState, null, AnyAction>;

export type AppThunk = ThunkAction<void, RootState, null, Action<string>>;
