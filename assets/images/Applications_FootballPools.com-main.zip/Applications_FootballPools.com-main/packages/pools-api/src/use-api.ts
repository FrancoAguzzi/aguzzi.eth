import { Api, ApiConfig, ApiClientType } from './api';
import { Response, send, createClient } from './client';
import { useClient } from './use-client';
import { Competition } from './models/competition';
import { CompetitionResult } from './models/competition-result';
import { CompetitionDividends } from './models/dividends';
import { GameType } from './models/game';
import { Offering, Offerings } from './models/offering';
import {
    CreatedWagers,
    ConfirmedWagers,
    PurchaseType,
    Wagers,
    CompetitionWagers,
    UpdatedWager,
    Wager,
    PaymentMethods,
    PaymentMethod,
    SetupCardResult,
    SetupCard,
} from './models/wagers';
import { BetSlip } from './state/bet-slip-slice';
import { Adaptor } from './adaptor';
import { useAdaptor } from './use-adaptor';
import { FinaliseDetails } from './state/wagers-slice';
import { PoolsApiError } from './models/pools-api-error';
import { AxiosRequestConfig, AxiosResponse, AxiosInstance, AxiosError } from 'axios';
import { isType, isGameEndpoint, isHealthEndpoint } from './utils';
import { Leaderboard } from './models/leaderboards';
import { LeaderboardResultsResponse } from './models/leaderboard-results';
import { TransactionHistoryResponse } from './models/transaction-history';
import { TransactionDetailsResponse } from './models/transaction-details';

let initialised = false;

let client: AxiosInstance;

// TODO: move config to method params
export const useApi = (config?: ApiConfig | ApiClientType): Api => {
    let apiConfig: ApiConfig;
    const { getAdaptor, setAdaptor } = useAdaptor();
    if (isType<ApiConfig>(config) && config.clientType) {
        apiConfig = config;
    } else if (isType<ApiClientType>(config)) {
        apiConfig = {
            clientType: config,
        };
    } else {
        apiConfig = {
            clientType: 'api',
        };
    }

    const onRequest = (axiosConfig: AxiosRequestConfig): AxiosRequestConfig | Promise<AxiosRequestConfig> => {
        const adaptor = getAdaptor();
        if (adaptor.onRequest) {
            axiosConfig.data = adaptor.onRequest(
                axiosConfig.url || '',
                axiosConfig.data,
                axiosConfig.headers,
                apiConfig,
            );
        }
        switch (axiosConfig.url) {
            case isGameEndpoint(
                adaptor.getCreateWagersInitEndpoint,
                adaptor.getGameTypes(),
                apiConfig,
                axiosConfig.url,
            ): {
                axiosConfig.data = adaptor.transformCreateWagersRequest(axiosConfig.data);
                break;
            }
            case isGameEndpoint(adaptor.getConfirmWagersEndpoint, adaptor.getGameTypes(), apiConfig, axiosConfig.url): {
                axiosConfig.data = adaptor.transformConfirmWagersRequest(axiosConfig.data);
                break;
            }
            case isGameEndpoint(
                adaptor.getWagerResultsEndpoint ||
                    ((game: GameType): string => {
                        return `wager/lines?gameName=${game}`;
                    }),
                adaptor.getGameTypes(),
                apiConfig,
                axiosConfig.url,
            ): {
                if (adaptor.transformGetWagerResultsRequest) {
                    axiosConfig.data = adaptor.transformGetWagerResultsRequest(axiosConfig.data);
                }
                break;
            }
            case adaptor.getFinaliseWagersEndpoint(apiConfig): {
                axiosConfig.data = adaptor.transformFinaliseWagersRequest(axiosConfig.data as FinaliseDetails);
                break;
            }
            case isGameEndpoint(
                adaptor.getUpdateWagerEndpoint ||
                    ((game: GameType): string => {
                        return `wager/update/${game}`;
                    }),
                adaptor.getGameTypes(),
                apiConfig,
                axiosConfig.url,
            ): {
                if (adaptor.transformUpdateWagerRequest) {
                    axiosConfig.data = adaptor.transformUpdateWagerRequest(axiosConfig.data);
                }
                break;
            }
            case isGameEndpoint(
                adaptor.getPaymentMethodsEndpoint ||
                    ((game: GameType): string => {
                        return `wager/payment-methods/${game}`;
                    }),
                adaptor.getGameTypes(),
                apiConfig,
                axiosConfig.url,
            ): {
                if (adaptor.transformGetPaymentMethodsRequest) {
                    axiosConfig.data = adaptor.transformGetPaymentMethodsRequest(axiosConfig.data);
                }
                break;
            }
            case isGameEndpoint(
                adaptor.getLeaderboardEndpoint ||
                    ((game: GameType): string => {
                        return `games/leaderboards/${game}`;
                    }),
                adaptor.getGameTypes(),
                apiConfig,
                axiosConfig.url,
            ): {
                if (adaptor.transformLeaderboardRequest) {
                    axiosConfig.data = adaptor.transformLeaderboardRequest(axiosConfig.data);
                }
                break;
            }
            case isGameEndpoint(
                adaptor.getLeaderboardResultsEndpoint ||
                    ((game: GameType): string => {
                        return `games/leaderboards/${game}/results`;
                    }),
                adaptor.getGameTypes(),
                apiConfig,
                axiosConfig.url,
            ): {
                if (adaptor.transformLeaderboardResultsRequest) {
                    axiosConfig.data = adaptor.transformLeaderboardResultsRequest(axiosConfig.data);
                }
                break;
            }
            case adaptor.getTransactionHistoryEndpoint
                ? adaptor.getTransactionHistoryEndpoint(apiConfig)
                : `transactions/history/`: {
                if (adaptor.transformTransactionHistoryRequest) {
                    axiosConfig.data = adaptor.transformTransactionHistoryRequest(axiosConfig.data);
                }
                break;
            }
            case adaptor.getTransactionDetailsEndpoint
                ? adaptor.getTransactionDetailsEndpoint(apiConfig)
                : `transactions/details/`: {
                if (adaptor.transformTransactionDetailsRequest) {
                    axiosConfig.data = adaptor.transformTransactionDetailsRequest(axiosConfig.data);
                }
                break;
            }
            default: {
                break;
            }
        }
        return axiosConfig;
    };

    const onRequestError = (error: unknown): unknown => {
        const adaptor = getAdaptor();
        if (adaptor.onRequestError) {
            return adaptor.onRequestError(error);
        }
        throw error;
    };

    const parseResponse = <T>(data: unknown): T | undefined => {
        if (typeof data === 'string') {
            return (JSON.parse(data) as Response<T>).data;
        }
        return (data as Response<T>).data;
    };

    const onResponse = (res: AxiosResponse<unknown>): AxiosResponse<unknown> | Promise<AxiosResponse<unknown>> => {
        const adaptor = getAdaptor();
        const url = res.config.url || '';
        if (adaptor.onResponse) {
            res.data = adaptor.onResponse(url, res.data, res.headers, apiConfig);
        }
        switch (url) {
            case isGameEndpoint(adaptor.getCompetitionsEndpoint, adaptor.getGameTypes(), apiConfig, url): {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformCompetitionsResponse(res.data)
                        : parseResponse<Competition[]>(res.data);
                break;
            }
            case isGameEndpoint(adaptor.getCompetitionResultsEndpoint, adaptor.getGameTypes(), apiConfig, url): {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformCompetitionResultsResponse(res.data)
                        : parseResponse<CompetitionResult[]>(res.data);
                break;
            }
            case isGameEndpoint(adaptor.getDividendsEndpoint, adaptor.getGameTypes(), apiConfig, url): {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformDividendsResponse(res.data)
                        : parseResponse<CompetitionDividends>(res.data);
                break;
            }
            case isGameEndpoint(adaptor.getOfferingsEndpoint, adaptor.getGameTypes(), apiConfig, url): {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformOfferingsResponse(res.data)
                        : parseResponse<Offerings>(res.data);
                break;
            }
            case isGameEndpoint(
                adaptor.getFilteredOfferingsEndpoint ||
                    ((game: GameType): string => {
                        return `games/${game}/filtered`;
                    }),
                adaptor.getGameTypes(),
                apiConfig,
                url,
            ): {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformFilteredOfferingsResponse
                            ? adaptor.transformFilteredOfferingsResponse(res.data)
                            : res.data
                        : parseResponse<Offering[]>(res.data);
                break;
            }
            case isGameEndpoint(adaptor.getWagersEndpoint, adaptor.getGameTypes(), apiConfig, url): {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformGetWagersResponse(res.data)
                        : parseResponse<Wagers>(res.data);
                break;
            }
            case isGameEndpoint(
                adaptor.getWagerResultsEndpoint ||
                    ((game: GameType): string => {
                        return `wager/lines?gameName=${game}`;
                    }),
                adaptor.getGameTypes(),
                apiConfig,
                url,
            ): {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformGetWagerResultsResponse
                            ? adaptor.transformGetWagerResultsResponse(res.data)
                            : res.data
                        : parseResponse<Wagers>(res.data);
                break;
            }
            case isHealthEndpoint(adaptor.getHealthCheckEndpoint, apiConfig, url): {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformGetHealthCheckResponse
                            ? adaptor.transformGetHealthCheckResponse(res.data)
                            : res.data
                        : parseResponse<{ isAlive: boolean }>(res.data);
                break;
            }
            case isGameEndpoint(adaptor.getCreateWagersInitEndpoint, adaptor.getGameTypes(), apiConfig, url): {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformCreateWagersResponse(res.data)
                        : parseResponse<CreatedWagers>(res.data);
                break;
            }
            case isGameEndpoint(adaptor.getConfirmWagersEndpoint, adaptor.getGameTypes(), apiConfig, url): {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformConfirmWagersResponse(res.data)
                        : parseResponse<ConfirmedWagers>(res.data);
                break;
            }
            case adaptor.getFinaliseWagersEndpoint(apiConfig): {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformFinaliseWagersResponse(res.data)
                        : parseResponse<ConfirmedWagers>(res.data);
                break;
            }
            case isGameEndpoint(
                adaptor.getUpdateWagerEndpoint ||
                    ((game: GameType): string => {
                        return `wagers/update/${game}`;
                    }),
                adaptor.getGameTypes(),
                apiConfig,
                url,
            ): {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformUpdateWagerResponse
                            ? adaptor.transformUpdateWagerResponse(res.data)
                            : res.data
                        : parseResponse<UpdatedWager>(res.data);
                break;
            }
            case isGameEndpoint(
                adaptor.getPaymentMethodsEndpoint ||
                    ((game: GameType): string => {
                        return `wagers/payment-methods/${game}`;
                    }),
                adaptor.getGameTypes(),
                apiConfig,
                url,
            ): {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformGetPaymentMethodsResponse
                            ? adaptor.transformGetPaymentMethodsResponse(res.data)
                            : res.data
                        : parseResponse<PaymentMethods>(res.data);
                break;
            }
            case isGameEndpoint(
                adaptor.getLeaderboardEndpoint ||
                    ((game: GameType): string => {
                        return `games/leaderboards/${game}`;
                    }),
                adaptor.getGameTypes(),
                apiConfig,
                url,
            ): {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformLeaderboardResponse
                            ? adaptor.transformLeaderboardResponse(res.data)
                            : res.data
                        : parseResponse<Leaderboard>(res.data);
                break;
            }
            case isGameEndpoint(
                adaptor.getLeaderboardResultsEndpoint ||
                    ((game: GameType): string => {
                        return `games/leaderboard-results/${game}`;
                    }),
                adaptor.getGameTypes(),
                apiConfig,
                url,
            ): {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformLeaderboardResultsResponse
                            ? adaptor.transformLeaderboardResultsResponse(res.data)
                            : res.data
                        : parseResponse<LeaderboardResultsResponse>(res.data);
                break;
            }
            case adaptor.getTransactionHistoryEndpoint
                ? adaptor.getTransactionHistoryEndpoint(apiConfig)
                : `transactions/history`: {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformTransactionHistoryResponse
                            ? adaptor.transformTransactionHistoryResponse(res.data)
                            : res.data
                        : parseResponse<TransactionHistoryResponse>(res.data);
                break;
            }
            case adaptor.getTransactionDetailsEndpoint
                ? adaptor.getTransactionDetailsEndpoint(apiConfig)
                : `transactions/details`: {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformTransactionDetailsResponse
                            ? adaptor.transformTransactionDetailsResponse(res.data)
                            : res.data
                        : parseResponse<TransactionDetailsResponse>(res.data);
                break;
            }
            case adaptor.getSetupCardEndpoint ? adaptor.getSetupCardEndpoint(apiConfig) : `orders/setup-card`: {
                res.data =
                    apiConfig.clientType === 'api'
                        ? adaptor.transformSetupCardResponse
                            ? adaptor.transformSetupCardResponse(res.data)
                            : res.data
                        : parseResponse<SetupCardResult>(res.data);
                break;
            }
            default: {
                console.warn('unhandled api response', url, apiConfig);
                break;
            }
        }
        return res;
    };

    const onResponseError = (error: unknown): unknown => {
        const adaptor = getAdaptor();
        if (adaptor.onResponseError) {
            return adaptor.onResponseError(error);
        }
        throw error;
    };

    const handleError = (error: unknown): PoolsApiError => {
        if (isType<AxiosError<Response<PoolsApiError>>>(error)) {
            return error.response?.data.error as PoolsApiError;
        }
        return getAdaptor().handleError(error);
    };

    const initialise = (adaptorToUse: Adaptor): void => {
        if (!initialised) {
            setAdaptor(adaptorToUse);
            client = createClient(onRequest, onRequestError, onResponse, onResponseError);
            initialised = true;
        }
    };

    const getOpenCompetitions = (game: GameType): Response<Competition[]> => {
        const url = getAdaptor().getCompetitionsEndpoint(game, apiConfig);
        const res = useClient<Competition[]>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getOpenCompetitionsAsync = async (game: GameType): Promise<Response<Competition[]>> => {
        const url = getAdaptor().getCompetitionsEndpoint(game, apiConfig);
        const res = await send<Competition[]>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getCompetitionResults = (game: GameType): Response<CompetitionResult[]> => {
        const url = getAdaptor().getCompetitionResultsEndpoint(game, apiConfig);
        const res = useClient<CompetitionResult[]>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getCompetitionResultsAsync = async (game: GameType): Promise<Response<CompetitionResult[]>> => {
        const url = getAdaptor().getCompetitionResultsEndpoint(game, apiConfig);
        const res = await send<CompetitionResult[]>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getOfferings = (game: GameType): Response<Offerings> => {
        const url = getAdaptor().getOfferingsEndpoint(game, apiConfig);
        const res = useClient<Offerings>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getOfferingsAsync = async (game: GameType): Promise<Response<Offerings>> => {
        const url = getAdaptor().getOfferingsEndpoint(game, apiConfig);
        const res = await send<Offerings>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getFilteredOfferings = (game: GameType): Response<Offering[]> => {
        const fn = getAdaptor().getFilteredOfferingsEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(game, apiConfig);
        const res = useClient<Offering[]>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getFilteredOfferingsAsync = async (game: GameType): Promise<Response<Offering[]>> => {
        const fn = getAdaptor().getFilteredOfferingsEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(game, apiConfig);
        const res = await send<Offering[]>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getDividends = (game: GameType): Response<CompetitionDividends> => {
        const url = getAdaptor().getDividendsEndpoint(game, apiConfig);
        const res = useClient<CompetitionDividends>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getDividendsAsync = async (game: GameType): Promise<Response<CompetitionDividends>> => {
        const url = getAdaptor().getDividendsEndpoint(game, apiConfig);
        const res = await send<CompetitionDividends>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getWagers = (game: GameType): Response<Wagers> => {
        const url = getAdaptor().getWagersEndpoint(game, apiConfig);
        const res = useClient<Wagers>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });

        return res;
    };

    const getWagersAsync = async (game: GameType): Promise<Response<Wagers>> => {
        const url = getAdaptor().getWagersEndpoint(game, apiConfig);
        const res = await send<Wagers>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getWagerResults = (game: GameType, competitionNumber?: number): Response<Wagers> => {
        const fn = getAdaptor().getWagerResultsEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(game, apiConfig);
        const res = useClient<Wagers>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
            data: { competitionNumber },
        });

        return res;
    };

    const getWagerResultsAsync = async (game: GameType, competitionNumber?: number): Promise<Response<Wagers>> => {
        const fn = getAdaptor().getWagerResultsEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(game, apiConfig);
        const res = await send<Wagers>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
            data: { competitionNumber },
        });
        return res;
    };

    const getHealthCheck = (): Response<{ isAlive: boolean }> => {
        const fn = getAdaptor().getHealthCheckEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(apiConfig);
        const res = useClient<{ isAlive: boolean }>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });

        return res;
    };

    const getHealthCheckAsync = async (): Promise<Response<{ isAlive: boolean }>> => {
        const fn = getAdaptor().getHealthCheckEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(apiConfig);
        const res = await send<{ isAlive: boolean }>({
            url: url,
            method: 'GET',
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const createWagersInit = (
        wagers: BetSlip[],
        game: GameType,
        purchaseType: PurchaseType,
        competition?: Competition,
        paymentMethod?: PaymentMethod,
        numberOfGames?: number,
    ): Response<CreatedWagers> => {
        const url = getAdaptor().getCreateWagersInitEndpoint(game, apiConfig);
        const res = useClient<{
            orderId?: number;
            competitions?: CompetitionWagers[];
            token?: string;
        }>({
            url: url,
            method: 'POST',
            data: {
                game,
                wagers,
                purchaseType,
                competition,
                paymentMethod,
                numberOfGames,
            },
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return {
            isLoading: res.isLoading,
            data: {
                isSuccess: !!(typeof res.error === 'undefined' && (res.data?.orderId || res.data?.competitions)),
                orderId: res.data?.orderId,
                competitions: res.data?.competitions as CompetitionWagers[],
                token: res.data?.token,
            },
            error: res.error,
        };
    };

    const createWagersInitAsync = async (
        wagers: BetSlip[],
        game: GameType,
        purchaseType: PurchaseType,
        competition?: Competition,
        paymentMethod?: PaymentMethod,
        numberOfGames?: number,
    ): Promise<Response<CreatedWagers>> => {
        const url = getAdaptor().getCreateWagersInitEndpoint(game, apiConfig);
        const res = await send<{
            orderId?: number;
            competitions?: CompetitionWagers[];
            token?: string;
        }>({
            url: url,
            method: 'POST',
            data: {
                game,
                wagers,
                purchaseType,
                competition,
                paymentMethod,
                numberOfGames,
            },
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return {
            isLoading: res.isLoading,
            data: {
                isSuccess: !!(typeof res.error === 'undefined' && (res.data?.orderId || res.data?.competitions)),
                orderId: res.data?.orderId,
                competitions: res.data?.competitions as CompetitionWagers[],
                token: res.data?.token,
            },
            error: res.error,
        };
    };

    const confirmCreateWagers = (
        confirmWagers: unknown,
        game: GameType,
        amount: number,
        wagers?: BetSlip[] | CompetitionWagers[],
    ): Response<ConfirmedWagers> => {
        const url = getAdaptor().getConfirmWagersEndpoint(game, apiConfig);
        const res = useClient<ConfirmedWagers>({
            url: url,
            method: 'PUT',
            data: { confirmWagers, game, wagers, amount },
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const confirmCreateWagersAsync = async (
        createWagers: unknown,
        game: GameType,
        amount: number,
        wagers?: BetSlip[] | CompetitionWagers[],
    ): Promise<Response<ConfirmedWagers>> => {
        const url = getAdaptor().getConfirmWagersEndpoint(game, apiConfig);
        const res = await send<ConfirmedWagers>({
            url: url,
            method: 'PUT',
            data: { createWagers, game, wagers, amount },
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const finaliseCreateWagersPayment = (
        finaliseDetails: FinaliseDetails,
        game: GameType,
    ): Response<ConfirmedWagers> => {
        const url = getAdaptor().getFinaliseWagersEndpoint(apiConfig);
        const res = useClient<ConfirmedWagers>({
            url: url,
            method: 'PUT',
            data: { finaliseDetails, game },
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const finaliseCreateWagersPaymentAsync = async (
        finaliseDetails: FinaliseDetails,
        game: GameType,
    ): Promise<Response<ConfirmedWagers>> => {
        const url = getAdaptor().getFinaliseWagersEndpoint(apiConfig);
        const res = await send<ConfirmedWagers>({
            url: url,
            method: 'PUT',
            data: { finaliseDetails, game },
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const updateWager = (wager: Wager, game: GameType, futureGames?: boolean): Response<UpdatedWager> => {
        const fn = getAdaptor().getUpdateWagerEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(game, apiConfig);
        const res = useClient<UpdatedWager>({
            url: url,
            method: 'PUT',
            data: { wager, game, futureGames },
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const updateWagerAsync = async (
        wager: Wager,
        game: GameType,
        futureGames?: boolean,
    ): Promise<Response<UpdatedWager>> => {
        const fn = getAdaptor().getUpdateWagerEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(game, apiConfig);
        const res = await send<UpdatedWager>({
            url: url,
            method: 'PUT',
            data: { wager, game, futureGames },
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getPaymentMethods = (game: GameType, numberOfLines: number, oneTime?: boolean): Response<PaymentMethods> => {
        const fn = getAdaptor().getPaymentMethodsEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(game, apiConfig);
        const res = useClient<PaymentMethods>({
            url: url,
            method: 'GET',
            data: { game, numberOfLines, oneTime },
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getPaymentMethodsAsync = async (
        game: GameType,
        numberOfLines: number,
        oneTime?: boolean,
    ): Promise<Response<PaymentMethods>> => {
        const fn = getAdaptor().getPaymentMethodsEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(game, apiConfig);
        const res = await send<PaymentMethods>({
            url: url,
            method: 'GET',
            data: { game, numberOfLines, oneTime },
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getLeaderboardAsync = async (
        game: GameType,
        year: number,
        month?: number,
        week?: number,
        count?: number,
        page?: number,
        nickname?: string,
        playerId?: string,
    ): Promise<Response<Leaderboard>> => {
        const fn = getAdaptor().getLeaderboardEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(game, apiConfig);
        const res = await send<Leaderboard>({
            url: url,
            method: 'GET',
            data: { game, year, month, week, count, page, nickname, playerId },
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getLeaderboardResultsAsync = async (
        game: GameType,
        competitionId?: number,
        count?: number,
        page?: number,
        // authToken?: string,
    ): Promise<Response<LeaderboardResultsResponse>> => {
        const fn = getAdaptor().getLeaderboardResultsEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'missingFunction',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(game, apiConfig);
        const res = await send<LeaderboardResultsResponse>({
            url: url,
            method: 'GET',
            data: { game, competitionId, count, page },
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getTransactionHistoryAsync = async (
        fromDate?: string,
        toDate?: string,
        beforeTransactionId?: string,
    ): Promise<Response<TransactionHistoryResponse>> => {
        const fn = getAdaptor().getTransactionHistoryEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'Missing Function',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(apiConfig);
        const res = await send<TransactionHistoryResponse>({
            url: url,
            method: 'GET',
            data: { fromDate, toDate, beforeTransactionId },
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const getTransactionDetailsAsync = async (
        game: GameType,
        id?: string | string[],
    ): Promise<Response<TransactionDetailsResponse>> => {
        const fn = getAdaptor().getTransactionDetailsEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'Missing Function',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(apiConfig);
        const res = await send<TransactionDetailsResponse>({
            url: url,
            method: 'GET',
            data: { game, id },
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    const setupCardAsync = async (details: SetupCard): Promise<Response<SetupCardResult>> => {
        const fn = getAdaptor().getSetupCardEndpoint;
        if (!fn) {
            return {
                isLoading: false,
                error: {
                    code: 'Missing Function',
                    title: 'Missing adaptor function',
                },
            };
        }
        const url = fn(apiConfig);
        const res = await send<SetupCardResult>({
            url: url,
            method: 'POST',
            data: details,
            baseUrl: getAdaptor().getBaseUrl(apiConfig),
            onError: handleError,
            client,
        });
        return res;
    };

    return {
        initialise,
        getOpenCompetitions,
        getOpenCompetitionsAsync,
        getCompetitionResults,
        getCompetitionResultsAsync,
        getOfferings,
        getOfferingsAsync,
        getFilteredOfferings,
        getFilteredOfferingsAsync,
        getDividends,
        getDividendsAsync,
        getWagers,
        getWagersAsync,
        getWagerResults,
        getWagerResultsAsync,
        getHealthCheck,
        getHealthCheckAsync,
        createWagersInit,
        createWagersInitAsync,
        confirmCreateWagers,
        confirmCreateWagersAsync,
        finaliseCreateWagersPayment,
        finaliseCreateWagersPaymentAsync,
        updateWager,
        updateWagerAsync,
        getPaymentMethods,
        getPaymentMethodsAsync,
        getLeaderboardAsync,
        getLeaderboardResultsAsync,
        getTransactionHistoryAsync,
        getTransactionDetailsAsync,
        setupCardAsync,
    };
};
