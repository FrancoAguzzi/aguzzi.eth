import { Adaptor } from './adaptor';

let adaptor: Adaptor | undefined;

export const useAdaptor = (): {
    getAdaptor: () => Adaptor;
    setAdaptor: (adaptor: Adaptor) => void;
} => {
    const getAdaptor = (): Adaptor => {
        if (typeof adaptor === 'undefined') {
            throw new Error('adaptor is undefined');
        }
        return adaptor;
    };
    const setAdaptor = (adaptorToUse: Adaptor): void => {
        adaptor = adaptorToUse;
    };

    return { getAdaptor, setAdaptor };
};
