import React, { useEffect, useRef } from 'react';

export interface SetupCardFormProps {
    token?: string;
    url?: string;
    onError?: (error: unknown) => void;
    onFormLoaded?: () => void;
    onFormLoading?: () => void;
    onSuccess?: (res: SetupCardFormResponse) => void;
}

export type SetupCardFormResponse = {
    SessionId?: string;
    MessageType?: string;
    Status?: boolean;
};

const origins: string[] = ['https://centinelapistag.cardinalcommerce.com', 'https://centinelapi.cardinalcommerce.com'];

export const SetupCardForm = ({
    token,
    url,
    onError,
    onFormLoaded,
    onFormLoading,
    onSuccess,
}: SetupCardFormProps): JSX.Element => {
    useEffect(() => {
        const handleMessage = (event: MessageEvent): void => {
            try {
                if (origins.includes(event.origin)) {
                    console.debug('SetupCardForm:handleMessage:', event.data);
                    const res = JSON.parse(event.data) as SetupCardFormResponse;
                    if (res && res.SessionId && onSuccess) {
                        onSuccess(res);
                    }
                }
            } catch (error) {
                if (onError) {
                    onError(error);
                }
            }
        };

        window.addEventListener('message', handleMessage);

        return (): void => {
            window.removeEventListener('message', handleMessage);
        };
    }, []);
    const formRef = useRef<HTMLFormElement>(null);
    const iFrameRef = useRef<HTMLIFrameElement>(null);
    useEffect(() => {
        if (iFrameRef.current && onFormLoaded) {
            iFrameRef.current.addEventListener('load', () => {
                onFormLoaded();
            });
        }
        if (onFormLoading) {
            onFormLoading();
        }
        // eslint-disable-next-line no-unused-expressions
        formRef.current?.submit();
    }, []);
    return (
        <React.Fragment>
            <iframe
                name="ddc-iframe"
                height="1"
                width="1"
                style={{ display: 'none' }}
                ref={iFrameRef}
                data-wc-ignore="true"
            />
            <form id="ddc-form" target="ddc-iframe" method="POST" action={url} ref={formRef} data-wc-ignore="true">
                <input type="hidden" name="JWT" value={token} />
            </form>
        </React.Fragment>
    );
};
