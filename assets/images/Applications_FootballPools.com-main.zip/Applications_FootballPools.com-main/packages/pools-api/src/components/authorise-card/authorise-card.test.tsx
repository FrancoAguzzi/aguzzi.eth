import React from 'react';
import { AuthoriseCardFormProps, AuthoriseCardForm } from './authorise-card';
import { render } from '@testing-library/react';

const mockDispatch = jest.fn();
jest.mock('react-redux', () => ({
    useSelector: jest.fn(),
    useDispatch: () => mockDispatch,
}));

const defaultProps: AuthoriseCardFormProps = {
    url: 'https://test.com',
    token: 'asd9ad90fg0i9sdfgjiosdojvsjkofojfdsjko==',
    md: 'MD1234_12345678',
    termUrl: 'https://api/authorise-card-callback',
};

describe('AuthoriseCard', () => {
    it('renders without error', () => {
        const { container } = render(<AuthoriseCardForm {...defaultProps} />);
        expect(container).toMatchSnapshot();
    });

    // TODO: test functions called as expected.
});
