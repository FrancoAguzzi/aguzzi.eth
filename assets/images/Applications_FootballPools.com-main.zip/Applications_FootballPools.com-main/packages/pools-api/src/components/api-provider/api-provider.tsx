import React, { PropsWithChildren } from 'react';
import { Adaptor } from '../../adaptor';
import { ApiConfig } from '../../api';
import { useApi } from '../../use-api';

export type ApiProviderProps = PropsWithChildren<{
    adaptor: Adaptor;
    config: ApiConfig;
}>;

export const ApiProvider = ({ adaptor, config, children }: ApiProviderProps): JSX.Element => {
    const { initialise } = useApi(config);
    initialise(adaptor);
    return <React.Fragment>{children}</React.Fragment>;
};
