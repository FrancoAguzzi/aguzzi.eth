import React, { useEffect, useRef } from 'react';

export interface AuthoriseCardFormProps {
    token?: string;
    url?: string;
    md?: string;
    termUrl?: string;
    onError?: (error: unknown) => void;
    onFormLoaded?: () => void;
    onFormLoading?: () => void;
    onSuccess?: (res: AuthoriseCardResponse) => void;
}

export type AuthoriseCardResponse = {
    paRes?: string;
    md?: string;
    transactionId?: string;
};

export const AuthoriseCardForm = ({
    token,
    url,
    md,
    termUrl,
    onError,
    onFormLoaded,
    onFormLoading,
    onSuccess,
}: AuthoriseCardFormProps): JSX.Element => {
    useEffect(() => {
        const handleMessage = (event: MessageEvent): void => {
            try {
                const res = event.data as AuthoriseCardResponse;
                if (res && res.paRes && res.md && onSuccess) {
                    onSuccess(res);
                }
            } catch (error) {
                if (onError) {
                    onError(error);
                }
            }
        };

        window.addEventListener('message', handleMessage);

        return (): void => window.removeEventListener('message', handleMessage);
    }, []);
    const formRef = useRef<HTMLFormElement>(null);
    const iFrameRef = useRef<HTMLIFrameElement>(null);
    useEffect(() => {
        if (iFrameRef.current && onFormLoaded) {
            iFrameRef.current.addEventListener('load', () => {
                onFormLoaded();
            });
        }
        if (onFormLoading) {
            onFormLoading();
        }
        // eslint-disable-next-line no-unused-expressions
        formRef.current?.submit();
    }, []);
    return (
        <React.Fragment>
            <iframe name="validate-3ds" ref={iFrameRef} style={{ minHeight: '500px' }} />
            <form action={url} method="POST" target="validate-3ds" ref={formRef}>
                <input type="hidden" name="PaReq" value={token} />
                <input type="hidden" name="MD" value={md} />
                <input type="hidden" name="TermUrl" value={termUrl} />
            </form>
        </React.Fragment>
    );
};
