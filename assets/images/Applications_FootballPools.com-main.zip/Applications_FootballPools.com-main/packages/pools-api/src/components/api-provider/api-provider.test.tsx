import React from 'react';
import { render } from '@testing-library/react';
import { ApiProvider } from './api-provider';

import { Api, ApiConfig } from '../../api';
import { Adaptor } from '../../adaptor';

const mockInitialise = jest.fn();
jest.mock('../../use-api', () => {
    return {
        useApi: (): Partial<Api> => ({
            initialise: mockInitialise,
        }),
    };
});

const mockAdaptor: Adaptor = {
    getBaseUrl: jest.fn(),
    getCompetitionsEndpoint: jest.fn(),
    getCompetitionResultsEndpoint: jest.fn(),
    getOfferingsEndpoint: jest.fn(),
    getDividendsEndpoint: jest.fn(),
    getCreateWagersInitEndpoint: jest.fn(),
    getConfirmWagersEndpoint: jest.fn(),
    getFinaliseWagersEndpoint: jest.fn(),
    onRequest: jest.fn(),
    onRequestError: jest.fn(),
    onResponse: jest.fn(),
    onResponseError: jest.fn(),
    transformCompetitionsResponse: jest.fn(),
    transformCompetitionResultsResponse: jest.fn(),
    transformDividendsResponse: jest.fn(),
    transformOfferingsResponse: jest.fn(),
    transformCreateWagersRequest: jest.fn(),
    transformCreateWagersResponse: jest.fn(),
    transformConfirmWagersRequest: jest.fn(),
    transformConfirmWagersResponse: jest.fn(),
    transformFinaliseWagersRequest: jest.fn(),
    transformFinaliseWagersResponse: jest.fn(),
    handleError: jest.fn(),
    getGameTypes: jest.fn(),
    getWagersEndpoint: jest.fn(),
    transformGetWagersResponse: jest.fn(),
};

const config: ApiConfig = {
    clientType: 'backend',
};

describe('apiProvider', () => {
    beforeEach(() => {
        mockInitialise.mockReset();
    });

    it('renders without error', () => {
        const { container } = render(<ApiProvider adaptor={mockAdaptor} config={config} />);
        expect(container).toMatchSnapshot();
    });

    it('renders children without error', () => {
        const { container } = render(
            <ApiProvider adaptor={mockAdaptor} config={config}>
                <div>Test Text</div>
            </ApiProvider>,
        );
        expect(container).toHaveTextContent('Test Text');
    });

    it('initialises api', () => {
        render(<ApiProvider adaptor={mockAdaptor} config={config} />);
        expect(mockInitialise).toHaveBeenCalledWith(mockAdaptor);
    });
});
