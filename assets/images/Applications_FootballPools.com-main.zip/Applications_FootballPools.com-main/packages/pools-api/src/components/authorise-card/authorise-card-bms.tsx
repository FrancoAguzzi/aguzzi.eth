import React, { useEffect, useRef } from 'react';
import { AuthoriseCardResponse } from './authorise-card';

export interface AuthoriseCardFormBmsProps {
    token?: string;
    url?: string;
    // Optional data returned as is in callback (MD).
    md?: string;
    onError?: (error: unknown) => void;
    onFormLoaded?: () => void;
    onFormLoading?: () => void;
    onSuccess?: (res: AuthoriseCardResponse) => void;
}

export const AuthoriseCardFormBms = ({
    token,
    url,
    md,
    onError,
    onFormLoaded,
    onFormLoading,
    onSuccess,
}: AuthoriseCardFormBmsProps): JSX.Element => {
    useEffect(() => {
        const handleMessage = (event: MessageEvent): void => {
            try {
                console.debug('AuthoriseCardFormBms:handleMessage:', event.data);
                const res = event.data as AuthoriseCardResponse;
                if (res && res.transactionId && onSuccess) {
                    onSuccess(res);
                }
            } catch (error) {
                if (onError) {
                    onError(error);
                }
            }
        };

        window.addEventListener('message', handleMessage);

        return (): void => window.removeEventListener('message', handleMessage);
    }, []);
    const formRef = useRef<HTMLFormElement>(null);
    const iFrameRef = useRef<HTMLIFrameElement>(null);
    useEffect(() => {
        if (iFrameRef.current && onFormLoaded) {
            iFrameRef.current.addEventListener('load', () => {
                onFormLoaded();
            });
        }
        if (onFormLoading) {
            onFormLoading();
        }
        // eslint-disable-next-line no-unused-expressions
        formRef.current?.submit();
    }, []);
    return (
        <React.Fragment>
            <iframe name="step-up-iframe" ref={iFrameRef} style={{ minHeight: '500px' }} />
            <form id="step-up-form" target="step-up-iframe" method="POST" action={url} ref={formRef}>
                <input type="hidden" name="JWT" value={token} />
                <input type="hidden" name="MD" value={md} />
            </form>
        </React.Fragment>
    );
};
