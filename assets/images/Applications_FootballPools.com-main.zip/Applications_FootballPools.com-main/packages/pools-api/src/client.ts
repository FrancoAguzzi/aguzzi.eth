import axios, { AxiosRequestConfig, Method, AxiosInstance, AxiosTransformer, AxiosResponse, AxiosError } from 'axios';
import https from 'https';
import { PoolsApiError } from './models/pools-api-error';

const DEFAULT_TIMEOUT_DURATION = 1000 * 90;

export const createClient = (
    onRequest?: (config: AxiosRequestConfig) => AxiosRequestConfig | Promise<AxiosRequestConfig>,
    onRequestError?: (error: unknown) => unknown,
    onResponse?: (res: AxiosResponse<unknown>) => AxiosResponse<unknown> | Promise<AxiosResponse<unknown>>,
    onResponseError?: (error: unknown) => unknown,
): AxiosInstance => {
    const client = axios.create({
        httpsAgent: new https.Agent({ rejectUnauthorized: false }),
    });
    client.interceptors.request.use(onRequest, onRequestError);
    client.interceptors.response.use(onResponse, onResponseError);
    return client;
};

export type Request = {
    url: string;
    method: Method;
    client: AxiosInstance;
    data?: unknown;
    transformRequest?: AxiosTransformer | AxiosTransformer[];
    transformResponse?: AxiosTransformer | AxiosTransformer[];
    headers?: unknown;
    baseUrl?: string;
    onError?: (error: unknown) => PoolsApiError;
};

export type Response<T> = {
    error?: PoolsApiError;
    data?: T;
    status?: number;
    isLoading: boolean;
};

function getErrorMessage(error: unknown) {
    if (error instanceof Error) return error.message;
    return String(error);
}

export const send = async <T = never>({
    url,
    method,
    data,
    transformRequest,
    transformResponse,
    headers,
    baseUrl,
    onError,
    client,
}: Request): Promise<Response<T>> => {
    const ret: Response<T> = {
        isLoading: true,
    };
    const config: AxiosRequestConfig = {
        method: method,
        baseURL: baseUrl,
        url: url,
        data: data,
        transformRequest: transformRequest,
        transformResponse: transformResponse,
        headers: headers,
        params: method === 'GET' ? data : undefined,
        timeout: DEFAULT_TIMEOUT_DURATION,
    };
    try {
        const res = await client.request<T>(config);
        ret.data = res.data;
        ret.status = res.status;
    } catch (error) {
        if (onError) {
            ret.error = onError(error);
        } else if (getErrorMessage(error)) {
            const axiosError = error as AxiosError;
            ret.error = {
                status: axiosError.response?.status,
                title: axiosError.message || 'client send error',
                code: axiosError.code || 'clientSendError.default',
            };
        } else {
            ret.error = {
                code: 'clientSendError.default',
                title: 'client send error',
                status: 500,
            };
        }
        if (ret.error) {
            ret.status = ret.error.status;
        }
    }
    ret.isLoading = false;
    return ret;
};
