import { GameType } from './models/game';
import { ApiConfig } from './api';

export const isGameEndpoint = (
    fn: (game: GameType, config?: ApiConfig) => string,
    gameTypes: GameType[],
    apiConfig: ApiConfig,
    url?: string,
): string => {
    const game = typeof url !== 'undefined' && gameTypes.find(game => fn(game, apiConfig) === url);
    return typeof game !== 'undefined' && typeof url !== 'undefined' ? url : '';
};

export const isHealthEndpoint = (fn?: (config?: ApiConfig) => string, apiConfig?: ApiConfig, url?: string): string => {
    const health = typeof url !== 'undefined' && typeof fn !== 'undefined' && fn(apiConfig) === url;
    return typeof health !== 'undefined' && health && typeof url !== 'undefined' ? url : '';
};

export const isType = <T>(ct: T | any | undefined): ct is T => {
    return (ct as T) !== undefined;
};
