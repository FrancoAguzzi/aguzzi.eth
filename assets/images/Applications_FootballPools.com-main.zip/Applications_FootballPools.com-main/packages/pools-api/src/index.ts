import { Adaptor } from './adaptor';
import { Api, ApiConfig } from './api';
import { ApiClient } from './api-client';
import { Request, Response, send } from './client';
import { useAdaptor } from './use-adaptor';
import { useApi } from './use-api';
import { useApiClient } from './use-api-client';
import { useAuthToken } from './use-auth-token';
import { useClient } from './use-client';

import { ApiProvider } from './components/api-provider/api-provider';
import {
    AuthoriseCardForm,
    AuthoriseCardFormProps,
    AuthoriseCardResponse,
} from './components/authorise-card/authorise-card';
import { AuthoriseCardFormBms, AuthoriseCardFormBmsProps } from './components/authorise-card/authorise-card-bms';
import { SetupCardForm, SetupCardFormProps, SetupCardFormResponse } from './components/setup-card/setup-card';

import { Competition, Fixture, PoolSize } from './models/competition';
import { CompetitionResult, CompetitionResults, FixtureResult, Score, Scores } from './models/competition-result';
import { Dividend, Dividends, CompetitionDividends } from './models/dividends';
import { PoolsApiError } from './models/pools-api-error';
import { Game, GameType, toGameType, toBetSlipKey, numbersSelectedToArray } from './models/game';
import { Leaderboard, LeaderboardEntry } from './models/leaderboards';
import {
    LeaderboardResult,
    LeaderboardResultMember,
    LeaderboardResultMembers,
    LeaderboardResults,
    LeaderboardResultsResponse,
} from './models/leaderboard-results';
import {
    BalanceEntry,
    BetHistoryItem,
    WagerHistoryItem,
    OfflineTransaction,
    Transaction,
    TransactionHistoryResponse,
    LineWagers,
    LineWager,
} from './models/transaction-history';
import { TransactionDetailsResponse } from './models/transaction-details';

import { Offering, Offerings } from './models/offering';
import {
    CreatedWagers,
    PurchaseType,
    ConfirmWagers,
    WagerConfirmation,
    PaymentDetails,
    CardDetails,
    PaypalDetails,
    DirectDebitDetails,
    ConfirmedWagers,
    Wager,
    Wagers,
    CompetitionWagers,
    UpdatedWager,
    PaymentMethod,
    PaymentMethods,
    SetupCard,
    SetupCardResult,
} from './models/wagers';

import betslipSlice, {
    BetSlip,
    BetSlipSlice,
    NumbersSelected,
    UpdateClassicPoolsWithNumber,
    CreateFirstSlip,
    UpdateAmount,
    LuckyDip,
    ClearLine,
    AddedToCart,
    AddLine,
    ChangeCurrentBet,
    AddNewLine,
    MoveLinesToNewComp,
    RemoveOldCompetitions,
    CreateFirstSlipAndClearOld,
    ResetBetSlipSelections,
    luckyDip,
    updateBetslipWithNumber,
} from './state/bet-slip-slice';
import wagersSlice, {
    WagersSlice,
    WagersStage,
    FinaliseDetails,
    createdWagers,
    confirmedWagers,
    resetWagers,
    wagersError,
    createWagers,
    confirmWagers,
    finaliseWagers,
    setGameViewPreference,
    authorisedWagers,
    initialiseWagers,
    setWagersIsFetching,
    clearError,
    initialiseCardSetup,
    completeCardSetup,
    setupCard,
} from './state/wagers-slice';
import { getBetSlipSelector, getWagersSelector } from './state/selectors';

import { isGameEndpoint, isHealthEndpoint, isType } from './utils';

import { withApiMiddleware } from './api-routes/with-api-middleware';
import { ApiRouteRequest } from './api-routes/api-route-request';
import { ApiRouteResponse } from './api-routes/api-route-response';
import { getCompetitionsApiRoute } from './api-routes/get-competitions';
import { getDividendsApiRoute } from './api-routes/get-dividends';
import { getOfferingsApiRoute } from './api-routes/get-offerings';
import { getFilteredOfferingsApiRoute } from './api-routes/get-filtered-offerings';
import { getResultsApiRoute } from './api-routes/get-results';
import { getWagersApiRoute } from './api-routes/get-wagers';
import { getWagerResultsApiRoute } from './api-routes/get-wager-results';
import { getHealthCheckApiRoute } from './api-routes/get-health-check';
import { authoriseCardApiRoute } from './api-routes/authorise-card';
import { confirmWagersApiRoute } from './api-routes/confirm-wagers';
import { createWagersApiRoute } from './api-routes/create-wagers';
import { finaliseWagersApiRoute } from './api-routes/finalise-wagers';
import { updateWagerApiRoute } from './api-routes/update-wager';
import { getPaymentMethodsApiRoute } from './api-routes/get-payment-methods';
import { getLeaderboardApiRoute } from './api-routes/get-leaderboard';
import { getLeaderboardResultsApiRoute } from './api-routes/get-leaderboard-results';
import { getTransactionHistoryApiRoute } from './api-routes/get-transaction-history';
import { getTransactionDetailsApiRoute } from './api-routes/get-transaction-details';
import { setupCardApiRoute } from './api-routes/setup-card';

export {
    send,
    useAdaptor,
    useApi,
    useApiClient,
    useAuthToken,
    useClient,
    ApiProvider,
    AuthoriseCardForm,
    AuthoriseCardFormBms,
    SetupCardForm,
    toGameType,
    toBetSlipKey,
    numbersSelectedToArray,
    betslipSlice,
    UpdateClassicPoolsWithNumber,
    CreateFirstSlip,
    UpdateAmount,
    LuckyDip,
    ClearLine,
    AddedToCart,
    AddLine,
    ChangeCurrentBet,
    AddNewLine,
    MoveLinesToNewComp,
    RemoveOldCompetitions,
    CreateFirstSlipAndClearOld,
    ResetBetSlipSelections,
    luckyDip,
    updateBetslipWithNumber,
    wagersSlice,
    createdWagers,
    confirmedWagers,
    resetWagers,
    wagersError,
    createWagers,
    confirmWagers,
    finaliseWagers,
    setGameViewPreference,
    authorisedWagers,
    initialiseWagers,
    setWagersIsFetching,
    clearError,
    initialiseCardSetup,
    completeCardSetup,
    setupCard,
    getBetSlipSelector,
    getWagersSelector,
    isGameEndpoint,
    isHealthEndpoint,
    isType,
    withApiMiddleware,
    getCompetitionsApiRoute,
    getDividendsApiRoute,
    getOfferingsApiRoute,
    getFilteredOfferingsApiRoute,
    getResultsApiRoute,
    getWagersApiRoute,
    getWagerResultsApiRoute,
    getHealthCheckApiRoute,
    authoriseCardApiRoute,
    confirmWagersApiRoute,
    createWagersApiRoute,
    finaliseWagersApiRoute,
    updateWagerApiRoute,
    getPaymentMethodsApiRoute,
    getLeaderboardApiRoute,
    getLeaderboardResultsApiRoute,
    getTransactionHistoryApiRoute,
    getTransactionDetailsApiRoute,
    setupCardApiRoute,
};

export type {
    Adaptor,
    Api,
    ApiConfig,
    ApiClient,
    Request,
    Response,
    AuthoriseCardResponse,
    AuthoriseCardFormProps,
    AuthoriseCardFormBmsProps,
    SetupCardFormProps,
    SetupCardFormResponse,
    Competition,
    Fixture,
    PoolSize,
    CompetitionResult,
    CompetitionResults,
    FixtureResult,
    Score,
    Scores,
    Dividend,
    Dividends,
    CompetitionDividends,
    PoolsApiError,
    Game,
    GameType,
    Leaderboard,
    LeaderboardEntry,
    LeaderboardResult,
    LeaderboardResultMember,
    LeaderboardResultMembers,
    LeaderboardResults,
    LeaderboardResultsResponse,
    Offering,
    Offerings,
    CreatedWagers,
    PurchaseType,
    ConfirmWagers,
    WagerConfirmation,
    PaymentDetails,
    CardDetails,
    PaypalDetails,
    DirectDebitDetails,
    ConfirmedWagers,
    Wager,
    Wagers,
    CompetitionWagers,
    UpdatedWager,
    PaymentMethod,
    PaymentMethods,
    SetupCard,
    SetupCardResult,
    BetSlip,
    BetSlipSlice,
    NumbersSelected,
    WagersSlice,
    WagersStage,
    FinaliseDetails,
    ApiRouteRequest,
    ApiRouteResponse,
    TransactionHistoryResponse,
    TransactionDetailsResponse,
    BalanceEntry,
    BetHistoryItem,
    WagerHistoryItem,
    OfflineTransaction,
    Transaction,
    LineWagers,
    LineWager,
};
