import { Adaptor } from './adaptor';
import { Response } from './client';
import { Competition } from './models/competition';
import { CompetitionResult } from './models/competition-result';
import { CompetitionDividends } from './models/dividends';
import { GameType } from './models/game';
import { LeaderboardResultsResponse } from './models/leaderboard-results';
import { Leaderboard } from './models/leaderboards';
import { Offering, Offerings } from './models/offering';
import {
    CompetitionWagers,
    ConfirmedWagers,
    PaymentMethods,
    SetupCardResult,
    UpdatedWager,
    Wagers,
} from './models/wagers';
import { TransactionHistoryResponse } from './models/transaction-history';
import { TransactionDetailsResponse } from './models/transaction-details';

export type ApiClient = {
    initialise: (adaptor: Adaptor) => void;
    getCompetitions: (game: GameType, req?: unknown) => Promise<Response<Competition[]>>;
    getCompetitionResults: (game: GameType, req?: unknown) => Promise<Response<CompetitionResult[]>>;
    getOfferings: (game: GameType, req?: unknown) => Promise<Response<Offerings>>;
    getFilteredOfferings: (game: GameType, req?: unknown) => Promise<Response<Offering[]>>;
    getDividends: (game: GameType, req?: unknown) => Promise<Response<CompetitionDividends>>;
    getWagers: (game: GameType, req?: unknown) => Promise<Response<Wagers>>;
    getWagerResults: (data: unknown, game: GameType, req?: unknown) => Promise<Response<CompetitionWagers>>;
    getHealthCheck: (req?: unknown) => Promise<Response<{ isAlive: boolean }>>;
    createWagersInit: (data: unknown, game: GameType, req?: unknown) => Promise<Response<{ orderId?: number }>>;
    confirmCreateWagers: (data: unknown, game: GameType, req?: unknown) => Promise<Response<ConfirmedWagers>>;
    finaliseCreateWagersPayment: (data: unknown, req?: unknown) => Promise<Response<ConfirmedWagers>>;
    authoriseCardPayment: (data: unknown, req?: unknown) => Promise<Response<unknown>>;
    updateWager: (data: unknown, game: GameType, req?: unknown) => Promise<Response<UpdatedWager>>;
    getPaymentMethods: (data: unknown, game: GameType, req?: unknown) => Promise<Response<PaymentMethods>>;
    getLeaderboard: (data: unknown, game: GameType, req?: unknown) => Promise<Response<Leaderboard>>;
    getLeaderboardResults: (
        data: unknown,
        game: GameType,
        req?: unknown,
    ) => Promise<Response<LeaderboardResultsResponse>>;
    getTransactionHistory: (data: unknown, req?: unknown) => Promise<Response<TransactionHistoryResponse>>;
    getTransactionDetails: (data: unknown, req?: unknown) => Promise<Response<TransactionDetailsResponse>>;
    setupCard: (data: unknown, req?: unknown) => Promise<Response<SetupCardResult>>;
};
