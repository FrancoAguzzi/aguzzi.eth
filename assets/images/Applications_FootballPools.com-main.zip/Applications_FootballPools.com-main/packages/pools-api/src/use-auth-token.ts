let token: string | undefined;

export const useAuthToken = (): {
    getToken: () => string | undefined;
    setToken: (val?: string) => string | undefined;
} => {
    // const token = useRef(null);

    const setToken = (apiToken?: string): string | undefined => {
        token = apiToken;
        return token;
    };

    const getToken = (): string | undefined => {
        return token;
    };

    return { getToken, setToken };
};
