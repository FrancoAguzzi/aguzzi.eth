import { ApiRouteRequest } from './api-route-request';
import { ApiRouteResponse } from './api-route-response';
import { useApiClient } from '../use-api-client';

export const getHealthCheckApiRoute = async (req: ApiRouteRequest, res: ApiRouteResponse): Promise<void> => {
    const { getHealthCheck } = useApiClient();
    const apiRes = await getHealthCheck(req);
    res.status(apiRes.status || 500).json(apiRes);
};
