import { useApiClient } from '../use-api-client';
import { Adaptor } from '../adaptor';
import { ApiRouteRequest } from './api-route-request';
import { ApiRouteResponse } from './api-route-response';

export const withApiMiddleware = (
    handler: (req: ApiRouteRequest, res: ApiRouteResponse) => Promise<void>,
    adaptor: Adaptor,
) => {
    const { initialise } = useApiClient();
    initialise(adaptor);

    return async (req: ApiRouteRequest, res: ApiRouteResponse) => {
        return handler(req, res);
    };
};
