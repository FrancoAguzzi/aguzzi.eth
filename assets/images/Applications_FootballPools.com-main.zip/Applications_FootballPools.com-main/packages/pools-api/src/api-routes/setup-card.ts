import { ApiRouteRequest } from './api-route-request';
import { ApiRouteResponse } from './api-route-response';
import { useApiClient } from '../use-api-client';

export const setupCardApiRoute = async (req: ApiRouteRequest, res: ApiRouteResponse): Promise<void> => {
    if (req.method !== 'POST') {
        console.log('setup card incorrect method');
        res.status(404);
        return;
    }
    const { setupCard } = useApiClient();

    const apiRes = await setupCard(req.body, req);
    // console.log('setup card response:', apiRes);
    res.status(apiRes.status || 500).json(apiRes);
};
