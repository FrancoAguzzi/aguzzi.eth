import { ApiRouteRequest } from './api-route-request';
import { ApiRouteResponse } from './api-route-response';
import { useApiClient } from '../use-api-client';

export const authoriseCardApiRoute = async (req: ApiRouteRequest, res: ApiRouteResponse): Promise<void> => {
    if (req.method !== 'POST') {
        console.log('create wagers incorrect method');
        res.status(404);
        return;
    }
    const { authoriseCardPayment } = useApiClient();
    const apiRes = await authoriseCardPayment(req.body, req);
    // console.log('authorise card api response:', apiRes);
    res.setHeader('content-type', 'text/html');
    res.status(apiRes.status || 500).send(apiRes.data);
};
