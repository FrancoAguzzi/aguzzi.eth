import { ServerResponse } from 'http';

type Send<T> = (body: T) => void;

export type ApiRouteResponse<T = unknown> = ServerResponse & {
    send: Send<T>;
    json: Send<T>;
    status: (statusCode: number) => ApiRouteResponse<T>;
    setPreviewData?: (
        data: object | string,
        options?: {
            maxAge?: number;
        },
    ) => ApiRouteResponse<T>;
    clearPreviewData?: () => ApiRouteResponse<T>;
};
