import { ApiRouteRequest } from './api-route-request';
import { ApiRouteResponse } from './api-route-response';
import { useApiClient } from '../use-api-client';

export const getTransactionDetailsApiRoute = async (req: ApiRouteRequest, res: ApiRouteResponse): Promise<void> => {
    const {
        query: { game, id },
    } = req;
    if (!game) {
        res.status(401).json({ title: 'invalid game name' });
    }
    const { getTransactionDetails } = useApiClient();
    const apiRes = await getTransactionDetails({ gameName: game, id }, req);
    res.status(apiRes.status || 500).json(apiRes);
};
