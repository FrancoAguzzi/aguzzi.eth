import { ApiRouteRequest } from './api-route-request';
import { ApiRouteResponse } from './api-route-response';
import { useApiClient } from '../use-api-client';
import { GameType } from '../models/game';

export const getPaymentMethodsApiRoute = async (req: ApiRouteRequest, res: ApiRouteResponse): Promise<void> => {
    const {
        query: { id, game, numberOfLines, oneTime },
    } = req;
    const gameName = id as GameType;
    if (!gameName) {
        res.status(401).json({ title: 'invalid game name' });
    }
    const { getPaymentMethods } = useApiClient();
    const apiRes = await getPaymentMethods(
        { gameName: game, numberOfLines: numberOfLines, oneTime: oneTime },
        gameName,
        req,
    );
    res.status(apiRes.status || 500).json(apiRes);
};
