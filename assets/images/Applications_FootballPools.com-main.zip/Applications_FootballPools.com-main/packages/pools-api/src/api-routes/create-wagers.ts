import { ApiRouteRequest } from './api-route-request';
import { ApiRouteResponse } from './api-route-response';
import { useApiClient } from '../use-api-client';
import { GameType } from '../models/game';

export const createWagersApiRoute = async (req: ApiRouteRequest, res: ApiRouteResponse): Promise<void> => {
    if (req.method !== 'POST') {
        res.status(404);
        return;
    }

    const {
        query: { id },
    } = req;
    const gameName = id as GameType;
    if (!gameName) {
        res.status(401).json({ title: 'invalid game name' });
    }

    const { createWagersInit } = useApiClient();
    const apiRes = await createWagersInit(req.body, gameName, req);
    res.status(apiRes.status || 500).json(apiRes);
};
