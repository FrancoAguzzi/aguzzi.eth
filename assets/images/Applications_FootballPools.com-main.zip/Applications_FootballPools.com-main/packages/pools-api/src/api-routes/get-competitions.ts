import { useApiClient } from '../use-api-client';
import { GameType } from '../models/game';
import { ApiRouteRequest } from './api-route-request';
import { ApiRouteResponse } from './api-route-response';

export const getCompetitionsApiRoute = async (req: ApiRouteRequest, res: ApiRouteResponse): Promise<void> => {
    const {
        query: { id },
    } = req;
    const gameName = id as GameType;
    if (!gameName) {
        res.status(401).json({ title: 'invalid game name' });
    }
    const { getCompetitions } = useApiClient();
    const apiRes = await getCompetitions(gameName);
    res.status(apiRes.status || 500).json(apiRes);
};
