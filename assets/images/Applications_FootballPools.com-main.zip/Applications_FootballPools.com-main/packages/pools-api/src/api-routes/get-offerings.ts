import { ApiRouteRequest } from './api-route-request';
import { ApiRouteResponse } from './api-route-response';
import { useApiClient } from '../use-api-client';
import { GameType } from '../models/game';

export const getOfferingsApiRoute = async (req: ApiRouteRequest, res: ApiRouteResponse): Promise<void> => {
    const {
        query: { id },
    } = req;
    const gameName = id as GameType;
    if (!gameName) {
        res.status(401).json({ title: 'invalid game name' });
    }
    const { getOfferings } = useApiClient();
    const apiRes = await getOfferings(gameName);
    res.status(apiRes.status || 500).json(apiRes);
};
