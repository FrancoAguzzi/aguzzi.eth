import { ApiRouteRequest } from './api-route-request';
import { ApiRouteResponse } from './api-route-response';
import { useApiClient } from '../use-api-client';
import { GameType } from '../models/game';

export const confirmWagersApiRoute = async (req: ApiRouteRequest, res: ApiRouteResponse): Promise<void> => {
    if (req.method !== 'PUT') {
        console.log('create wagers incorrect method');
        res.status(404);
        return;
    }

    const {
        query: { id },
    } = req;
    const gameName = id as GameType;
    if (!gameName) {
        res.status(401).json({ title: 'invalid game name' });
    }

    const { confirmCreateWagers } = useApiClient();

    const apiRes = await confirmCreateWagers(req.body, gameName, req);
    // console.log('confirm api response:', apiRes);
    res.status(apiRes.status || 500).json(apiRes);
};
