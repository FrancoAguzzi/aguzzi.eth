import { ApiRouteRequest } from './api-route-request';
import { ApiRouteResponse } from './api-route-response';
import { useApiClient } from '../use-api-client';

export const finaliseWagersApiRoute = async (req: ApiRouteRequest, res: ApiRouteResponse): Promise<void> => {
    if (req.method !== 'PUT') {
        console.log('create wagers incorrect method');
        res.status(404);
        return;
    }
    const { finaliseCreateWagersPayment } = useApiClient();

    const apiRes = await finaliseCreateWagersPayment(req.body, req);
    // console.log('finalise api response:', apiRes);
    res.status(apiRes.status || 500).json(apiRes);
};
