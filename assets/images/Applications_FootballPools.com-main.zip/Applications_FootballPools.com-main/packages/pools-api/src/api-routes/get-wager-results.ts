import { ApiRouteRequest } from './api-route-request';
import { ApiRouteResponse } from './api-route-response';
import { useApiClient } from '../use-api-client';
import { GameType } from '../models/game';

export const getWagerResultsApiRoute = async (req: ApiRouteRequest, res: ApiRouteResponse): Promise<void> => {
    const {
        query: { id, competitionNumber },
    } = req;
    const gameName = id as GameType;
    if (!gameName) {
        res.status(401).json({ title: 'invalid game name' });
    }
    const { getWagerResults } = useApiClient();
    const apiRes = await getWagerResults({ competitionNumber }, gameName, req);
    res.status(apiRes.status || 500).json(apiRes);
};
