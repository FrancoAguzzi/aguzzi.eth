import { ApiRouteRequest } from './api-route-request';
import { ApiRouteResponse } from './api-route-response';
import { useApiClient } from '../use-api-client';
import { GameType } from '../models/game';

export const getLeaderboardResultsApiRoute = async (req: ApiRouteRequest, res: ApiRouteResponse): Promise<void> => {
    const {
        query: { id, competitionId, count, page },
    } = req;
    const gameName = id as GameType;
    if (!gameName) {
        res.status(400).json({ title: 'invalid game name' });
    }
    const { getLeaderboardResults } = useApiClient();
    const apiRes = await getLeaderboardResults({ competitionId, count, page }, gameName, req);
    res.status(apiRes.status || 500).json(apiRes);
};
