import type { IncomingMessage } from 'http';

export type ApiRouteRequest = IncomingMessage & {
    query: {
        [key: string]: string | string[];
    };
    cookies?: {
        [key: string]: string;
    };
    body?: any;
};
