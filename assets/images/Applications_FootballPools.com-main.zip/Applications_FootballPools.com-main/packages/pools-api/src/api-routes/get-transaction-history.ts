import { ApiRouteRequest } from './api-route-request';
import { ApiRouteResponse } from './api-route-response';
import { useApiClient } from '../use-api-client';

export const getTransactionHistoryApiRoute = async (req: ApiRouteRequest, res: ApiRouteResponse): Promise<void> => {
    const {
        query: { fromDate, toDate, beforeTransactionId },
    } = req;
    const { getTransactionHistory } = useApiClient();
    const apiRes = await getTransactionHistory({ fromDate, toDate, beforeTransactionId }, req);
    res.status(apiRes.status || 500).json(apiRes);
};
