module.exports = {
    root: true,
    ignorePatterns: ['node_modules/*'],
    extends: ['../../.eslintrc.base.js', 'plugin:react/recommended'],
    env: {
        browser: true,
        es6: true,
        node: true,
    },
    rules: {
        'react/react-in-jsx-scope': 'off',
        '@typescript-eslint/explicit-function-return-type': 'warn',
        '@typescript-eslint/no-unused-vars': ['error', { vars: 'all', args: 'after-used', ignoreRestSiblings: false }],
    },
};
