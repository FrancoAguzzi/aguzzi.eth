# FP-Next.js-Template

This project is meant to serve as a learning & template project for future frontend appplications

## Requirements

-   [Node >10.0](https://nodejs.org/en/)
-   [Yarn - steps here](https://classic.yarnpkg.com/en/docs/install/#mac-stable)

## Running

```bash
$ yarn install
$ yarn dev
```

## Testing

Jest can be run with

```bash
$ yarn test
```

This will create a snapshots folder or compare against previous snapshots

Cypress can be run with

```bash
$ yarn cypress:open
```

Please use Visual Studio Code to develop on this project with the following extensions installed (These will appear as recommended when opening the project):

#### MUSTS

-   [Prettier](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode)
-   [EsLint](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint)

#### Suggested

-   [Jest](https://marketplace.visualstudio.com/items?itemName=Orta.vscode-jest)
-   [GitLens](https://marketplace.visualstudio.com/items?itemName=eamodio.gitlens)
-   [Bracket Pair Colorizer](https://marketplace.visualstudio.com/items?itemName=CoenraadS.bracket-pair-colorizer)
-   [Material Icon Theme](https://marketplace.visualstudio.com/items?itemName=PKief.material-icon-theme)

## Tech Stack

-   [Next.js](https://nextjs.org/)
-   [React](https://reactjs.org/)
-   [Typescript](https://www.typescriptlang.org/)

### Styling

-   [Styled-Components](https://styled-components.com/)

### Code Formatting

-   [Prettier](https://prettier.io/)
-   [Eslint](https://eslint.org/)
-   [Husky](https://github.com/typicode/husky)

### Testing

-   [Jest](https://jestjs.io/)
-   [React-testing-library](https://github.com/testing-library/react-testing-library)
-   [Cypress](https://www.cypress.io/)

## Todo

-   Add project specific Storybook examples
