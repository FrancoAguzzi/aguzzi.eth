module.exports = {
    collectCoverageFrom: ['**/src/**/*.{js,jsx,ts,tsx}', '!**/*.d.ts', '!**/node_modules/**', '!**/cypress/**'],
    setupFilesAfterEnv: ['<rootDir>/setupTests.js'],
    transform: {
        '^.+\\.(js|jsx|ts|tsx)$': '<rootDir>/../../node_modules/babel-jest',
    },
    transformIgnorePatterns: ['/node_modules/'],
    testEnvironment: 'jsdom',
    moduleNameMapper: {
        '\\.svg': '<rootDir>/transformSvg.js',
    },
    testPathIgnorePatterns: ['/node_modules/', '/.next/', '/cypress/', '/.storybook/'],
    roots: ['<rootDir>'],
};
