/* eslint-disable @typescript-eslint/no-var-requires */
const withReactSvg = require('next-react-svg');
const path = require('path');

const { PHASE_PRODUCTION_SERVER } = require('next/constants');

const withTM = require('next-transpile-modules')(['@sportech/pools-api', '@fp/shared', '@sportech/pools-components']);

const withComposite = config => withTM(withReactSvg(config));

const NEXTJS_IGNORE_TYPECHECK = process.env.NEXTJS_IGNORE_TYPECHECK === '1' || false;

const nextConfig = {
    env: {},
    publicRuntimeConfig: {
        API_URL: process.env.API_URL || 'https://int-fpsvc.footballpools.com/api',
        API_WEBSITE_BASE: process.env.API_WEBSITE_BASE || 'http://localhost:3000/api/',
        AUTH0_CLIENT_ID: process.env.AUTH0_CLIENT_ID || 'nextjs',
        AUTH0_CLIENT_SECRET: process.env.AUTH0_CLIENT_SECRET || '',
        AUTH0_DOMAIN: process.env.AUTH0_DOMAIN || 'https://int-account.thepools.com',
        AUTH0_SCOPE: 'openid profile offline_access',
        BUILDER_API_KEY: process.env.BUILDER_API_KEY || '',
        CLASSIC_POOLS_IMAGE_URL:
            process.env.CLASSIC_POOLS_IMAGE_URL ||
            'https://cms.thepools.com/api/assets/pool-games/34d6c8a3-9bce-45b7-8ca8-3202781cfb28/fpc-8252-tp-classic-prize-pool-banner-290-tile.jpg?version=0',
        CMS_SITE_URL: process.env.CMS_SITE_URL || 'https://uat-assets.thepools.com/',
        DYNAMIC_POOLS_TOGGLE: process.env.DYNAMIC_POOLS_TOGGLE || true,
        FACEBOOK_SITE_URL: process.env.CMS_SITE_URL || 'https://www.facebook.com/The-Pools-919655051758827',
        FOOTBALL_POOLS_URL: process.env.FOOTBALL_POOLS_URL || 'https://www.footballpools.com/',
        FOOTIE_SITE_URL: process.env.FOOTIE_SITE_URL || 'https://uat-footie5.thepools.com/',
        FP_SITE_URL: process.env.FP_SITE_URL || 'http://uat-footballpools.sportech.tld',
        FSB_BASE_URL: process.env.FSB_BASE_URL || 'https://footballpools-api-qa.fsbtech.com/fsb-api-rest',
        FSB_SITE_URL: process.env.FSB_SITE_URL || 'https://play-qa.thepools.com/',
        FSB_USER_ID: process.env.FSB_USER_ID || 'footballpools',
        FSB_USER_SECRET: process.env.FSB_USER_SECRET || '2$ziPpDQY$y1',
        GAME_SERVICE_API_KEY: process.env.GAME_SERVICE_API_KEY || '',
        GAME_SERVICE_API_URL:
            process.env.GAME_SERVICE_API_URL || 'https://uat-tp-apim.azure-api.net/uat-tp-functionsapp/',
        GTM_ID: process.env.GTM_ID || 'GTM-WMDQHSX',
        HIDE_EXTRA_PLANS: process.env.HIDE_EXTRA_PLANS || 'false',
        HIDE_GAMES: process.env.HIDE_GAMES || "['']", // ['lucky-clover', 'goal-rush', 'soccer-6', 'premier-10', 'jackpot-12']
        INBOX_API_SITE_URL: process.env.INBOX_API_SITE_URL || 'https://int-pimssvc.thepools.com/api/',
        INBOX_SITE_URL: process.env.INBOX_SITE_URL || 'https://int-inbox.thepools.com/',
        LEADERBOARD_MAINTENANCE: process.env.LEADERBOARD_MAINTENANCE || 'false',
        LEADERBOARDS_API_URL: process.env.LEADERBOARDS_API_URL,
        LEGACY_SITE_URL: process.env.LEGACY_SITE_URL || 'https://clubfp.int.tfpsrvs.local',
        LOTTO_GAME_API_URL: process.env.LOTTO_GAME_API_URL || 'https://tpappgw.thepools.com/graphql',
        MILEAGE_API_URL: process.env.MILEAGE_API_URL || 'https://uat-tp-apim.azure-api.net/TFP-INT-MILEAGE-FUNC-UKW/',
        MILEAGE_LINK_URL: process.env.MILEAGE_LINK_URL || 'https://play-qa.thepools.com/mileage',
        POST_LOGOUT_REDIRECT_URI: process.env.POST_LOGOUT_REDIRECT_URI || 'http://localhost:3000/',
        REDIRECT_URI: process.env.REDIRECT_URI || '/api/auth/callback',
        SHOW_CAROUSEL: process.env.SHOW_CAROUSEL || true,
        SHOW_IN_GAME_DEPOSIT: process.env.SHOW_IN_GAME_DEPOSIT || 'false',
        SHOW_LEADERBOARDS: process.env.SHOW_LEADERBOARDS || 'false',
        SHOW_LOTTO: process.env.SHOW_LOTTO || true,
        SHOW_MILEAGE: process.env.SHOW_MILEAGE || 'false',
        SHOW_TILE_HOME_PAGE: process.env.SHOW_TILE_HOME_PAGE || 'true',
        SHOW_QUESTION_OF_THE_DAY_LINK: process.env.SHOW_QUESTION_OF_THE_DAY_LINK || 'false',
        SITE_URL: process.env.SITE_URL,
        SITE_ENVIRONMENT: process.env.SITE_ENVIRONMENT || 'DEV',
        SUBSCRIPTIONS_LINKS_MIGRATION_ONLY: process.env.SUBSCRIPTIONS_LINKS_MIGRATION_ONLY || 'true',
        SUBSCRIPTIONS_SITE_URL: process.env.SUBSCRIPTIONS_SITE_URL || 'https://subscriptions.footballpools.com/',
        SUBSCRIPTION_API_URL: process.env.SUBSCRIPTION_API_URL || 'https://int-fpsvc.footballpools.com/api/',
        THEPOOLS_URL: process.env.THEPOOLS_URL || 'https://uat.thepools.com/',
        TWITTER_SITE_URL: process.env.TWITTER_SITE_URL || 'https://twitter.com/PoolsOfficial',
        USE_GAME_SERVICE: 'game-service',
        WEBSITE_BASE: process.env.WEBSITE_BASE || 'http://localhost:3000',
    },
    serverRuntimeConfig: {},
    include: path.resolve(__dirname, 'public/svg'),
    webpack: (config, { isServer, webpack }) => {
        // Fixes npm packages that depend on `fs` module
        if (!isServer) {
            config.node = {
                fs: 'empty',
            };
        }
        config.plugins.push(new webpack.IgnorePlugin(/\/__tests__\//));

        return config;
    },
    async redirects() {
        return process.env.SHOW_LOTTO
            ? [
                  {
                      source: '/lotto-games/l4l-100k',
                      destination: '/',
                      permanent: false,
                  },
                  {
                      source: '/:path*/jackpot12',
                      destination: '/:path*/premier12',
                      permanent: true,
                  },
              ]
            : [
                  {
                      source: '/:path*/jackpot12',
                      destination: '/:path*/premier12',
                      permanent: true,
                  },
              ];
    },
    typescript: {
        ignoreBuildErrors: NEXTJS_IGNORE_TYPECHECK,
    },
};

module.exports = (phase, { defaultConfig }) => {
    return phase === PHASE_PRODUCTION_SERVER ? withReactSvg(nextConfig) : withComposite(nextConfig);
};
