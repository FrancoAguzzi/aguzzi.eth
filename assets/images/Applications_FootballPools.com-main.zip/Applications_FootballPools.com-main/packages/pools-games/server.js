/* eslint-disable @typescript-eslint/no-var-requires */
const next = require('next');
const { parse } = require('url');
const { createServer } = require('https');
const fs = require('fs');

const dev = process.env.NODE_ENV !== 'production';
const app = next({ dev });
const handle = app.getRequestHandler();

const port = process.env.PORT || 3000;

const httpsOptions = {
    key: fs.readFileSync('./certificates/localhost.key'),
    cert: fs.readFileSync('./certificates/localhost.crt'),
};

(async () => {
    app.prepare().then(
        createServer(httpsOptions, (req, res) => {
            const parsedUrl = parse(req.url, true);
            req.headers['cache-control'] = 'no-cache';
            handle(req, res, parsedUrl);
        }).listen(port, err => {
            if (err) throw err;
            console.log(`🚀 Ready on https://localhost:${port}`);
        }),
    );
})();
