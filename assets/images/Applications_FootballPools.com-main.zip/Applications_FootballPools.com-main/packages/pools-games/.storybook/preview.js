import { ThemeProvider, createGlobalStyle } from 'styled-components';
import { GoalRushtheme } from '../src/settings/theme';

export const parameters = {
    actions: { argTypesRegex: '^on[A-Z].*' },
    controls: {
        matchers: {
            color: /(background|color)$/i,
            date: /Date$/,
        },
    },
};

export const GlobalStyle = createGlobalStyle`
  body {
    background: #363636;
    width: 100vw;
    height: 100vh;
    margin: 0;
    font-family: 'Montserrat', sans-serif;
  }
  li
  {
    display: block;
  }
  button
  {
    font-family: 'Montserrat', sans-serif !important;
  }
  `;

export const decorators = [
    Story => (
        <ThemeProvider theme={GoalRushtheme}>
            <GlobalStyle />
            <Story />
        </ThemeProvider>
    ),
];
