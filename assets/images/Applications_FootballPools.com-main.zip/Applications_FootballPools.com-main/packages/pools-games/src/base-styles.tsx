import styled, { createGlobalStyle } from 'styled-components';
import { breakpointValues } from '@settings/breakpoints';
import { breakpoints } from '@settings/breakpoints';
import ReactJSPopup from 'reactjs-popup';
import { Button } from '@components/Common/Button/Button';

export type fontType = '100' | 'bold';
export type alignType = 'start' | 'center' | 'end';
export type justifyType = 'start' | 'center' | 'end' | 'space-between' | 'space-around';
type StyledListItemProps = {
    area?: number;
    fontSize?: string;
    margin?: string;
};

interface PopupStyleProps {
    maxWidth?: string;
    maxHeight?: string;
    padding?: string;
    rounded?: boolean;
    overflow?: string;
    width?: string;
    height?: string;
    mobileMargin?: string;
    mobileHeight?: string;
}

interface PopupHeaderProps {
    textAlign?: string;
    color?: string;
    padding?: string;
    fontSize?: string;
    position?: string;
    bgColor?: string;
    rounded?: boolean;
    width?: string;
}

interface PopupCrossProps {
    right?: string;
    top?: string;
}
export const BaseStyles = createGlobalStyle`
    body {
        padding: 0;
        margin: 0;
        -webkit-overflow-scrolling: touch;
    }
    a {
        color: inherit;
        text-decoration: none;
    }
`;
export const Underlined = styled.a`
    outline: none;
    border: none;
    text-decoration: underline;
    background-color: transparent;
    font-size: 1rem;
    font-weight: 100;
    margin: 2rem 0;
    cursor: pointer;
`;
export const BottomSelection = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    flex: 1;
    bottom: 0;
`;
export const Container = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    margin-top: 1.5rem;
    height: 100%;
    @media (max-width: 320px) {
        margin: 0;
        margin-bottom: 0.5rem;
    }
`;
export const ContainerPicker = styled.div`
    display: flex;
    flex-direction: row;
    width: 90%;
    flex-wrap: wrap;
    justify-content: space-between;
    overflow: visible;
    overflow-x: scroll;
    ::-webkit-scrollbar {
        display: none;
    }
`;
export const Bottom = styled.div`
    position: absolute;
    bottom: 0;
    padding-top: 15px;
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 100%;
    background: white;
    box-shadow: 0px -2px 10px darkgrey;
    @media (max-width: ${breakpointValues.xs}px) {
        padding-top: 7px;
    }
`;
export const Info = styled.span`
    font-weight: 100;
    font-size: 16px;
    margin-bottom: 1px;
    text-align: center;
    @media (max-width: ${breakpointValues.xs}px) {
        font-size: 14px;
    }
`;
export const Promotion = styled.span`
    font-size: 1.1rem;
    font-weight: bold;
    text-align: center;
    @media (max-width: ${breakpointValues.xs}px) {
        margin: 10px 0 10px 0;
    }
`;
export const Image = styled.img`
    width: 100%;
    height: 100%;
    object-fit: fill;
`;
export const Title = styled.div<{ font: fontType; align: alignType; justify: justifyType }>`
    align-items: ${({ align }) => align};
    justify-content: ${({ justify }) => justify};
    text-align: ${({ align }) => align};
    font-weight: ${({ font }) => font};
    margin-top: 2rem;
    font-size: 1rem;
`;
export const Row = styled.div`
    display: flex;
    flex-flow: row nowrap;
    border-bottom: 0.5px solid #252525;
`;
export const ContainerCircles = styled.div<StyledListItemProps>`
    @media (min-width: 320px) {
        width: ${(props): string => (props.area ? `${props.area / 8}px` : '20px')};
        height: ${(props): string => (props.area ? `${props.area / 8}px` : '20px')};
    }
`;
/* Modal generic */
interface PropsModal {
    height: number;
    transition: string;
}
export const ButtonGen = styled.button`
    font-size: 1rem;
    font-weight: 300;
    background: #fff;
    float: right;
    border: none;
    cursor: pointer;
`;
export const ButtonRightGen = styled.div`
    font-size: 1rem;
    font-weight: 300;
    background: #fff;
    margin-right: 10px;
    margin-left: 10px;
    margin-top: 10px;
    border: none;
`;
export const ButtonXGen = styled.button`
    font-size: 1rem;
    font-weight: 900;
    display: flex;
    border: #707070;
    cursor: pointer;
    background: #707070;
`;

export const MoveContentMobileGen = styled.div<Pick<PropsModal, 'height' | 'transition'>>`
    -webkit-overflow-scrolling: touch;
    background-color: #fff;
    justify-content: center;
    align-items: center;
    height: 70%;
`;
export const MoveContentGen = styled.div<Pick<PropsModal, 'height' | 'transition'>>`
    background-color: #fff;
    justify-content: center;
    align-items: center;
    height: ${({ height }) => (height ? height : '24px')};
`;
export const ModalContentGen = styled.div<{ show: boolean | (() => void) }>`
    display: ${({ show }) => (show ? 'flex' : 'none')};
    flex-direction: column;
    border-top-right-radius: 30px;
    border-top-left-radius: 30px;
    border-bottom-right-radius: 30px;
    border-bottom-left-radius: 30px;
    border: 1px solid #707070;
    background-color: white;
    box-shadow: 2px 2px 2px #707070;
`;

export const BackgroundModalGen = styled.div<{ show: boolean | (() => void) }>`
    top: 0;
    width: 100vw;
    height: 100vh;
    position: fixed;
    background-color: rgba(0, 0, 0, 0.75);
    display: ${({ show }) => (show ? 'flex' : 'none')};
    overflow: hidden;
`;
export const ContentGen = styled.div`
    justify-content: center;
    align-items: center;
    text-align: justify;
    font-size: 1rem;
    font-weight: 100;
    min-height: 1px;
`;
/* Moda for pop ups */
export const Name = styled.h3`
    font-weight: bold;
    color: #188be9;
    margin: 0;
    font-size: 2rem;
    @media (max-width: ${breakpointValues.xs}px) {
        font-size: 24px;
        font-weight: 800;
    }
`;
export const Balance = styled.span`
    font-weight: 700;
    text-align: center;
    margin: 0 0 0.4rem 0;
    font-size: 1rem;
    @media (max-width: ${breakpointValues.xs}px) {
        font-size: 14px;
        margin: 0 0 0.2rem 0;
    }
`;

export const ContainerPopUp = styled(ReactJSPopup)<PopupStyleProps>`
    justify-content: center;
    align-items: center;
    &-content {
        height: ${(props): string => (props.height ? props.height : 'auto')};
        background-color: #fff !important;
        color: #000;
        border-color: #363636 !important;
        border-radius: ${(props): string => (props.rounded ? '20px' : '0')};
        max-height: ${(props): string => (props.maxHeight ? props.maxHeight : '90vh')};
        padding: ${(props): string => (props.padding ? props.padding : '20px 55px !important')};
        font-size: 14px !important;
        overflow: ${(props): string => (props.overflow ? props.overflow : 'hidden')};
        width: '100%';
        ${breakpoints.below('s')} {
            margin-left: 10px !important;
            margin-right: 10px !important;
        }

        ${breakpoints.below('lg')} {
            width: 380px !important;
            ${(props): string | undefined => props.mobileHeight && `height: {props.mobileHeight}`};
            border: none !important;
        }
        ${breakpoints.below('l')} {
            width: 380px !important;
            ${(props): string | undefined => props.mobileHeight && `height: {props.mobileHeight}`};
            border: none !important;
        }
        ${breakpoints.below('xl')} {
            width: 380px !important;
            ${(props): string | undefined => props.mobileHeight && `height: {props.mobileHeight}`};
            border: none !important;
        }
    }
`;

export const PopupHeader = styled.h2<PopupHeaderProps>`
    color: ${(props): string => (props.color ? props.color : '#000')};
    font-size: ${(props): string => (props.fontSize ? props.fontSize : '2.3em')};
    padding: ${(props): string => (props.padding ? props.padding : '0.5em 0')};
    margin: 0;
    text-align: ${(props): string => (props.textAlign ? props.textAlign : 'left')};
    position: ${(props): string => (props.position ? props.position : 'relative')};
    background-color: ${(props): string => (props.bgColor ? props.bgColor : '#fff')};
    max-width: inherit;
    border-top-right-radius: ${(props): string => (props.rounded ? '20px' : '0')};
    border-top-left-radius: ${(props): string => (props.rounded ? '20px' : '0')};
    z-index: 1000;

    ${breakpoints.below('lg')} {
        width: ${(props): string | undefined => props.width};
    }
`;

export const CloseButton = styled(Button)<PopupCrossProps>`
    background-color: transparent;
    color: black;
    position: fixed;

    &:hover {
        background: none;
    }
`;

export const FixedWrapper = styled.div<PopupCrossProps>`
    position: absolute;
    right: ${(props): string => (props.right ? props.right : '60px')};
    top: ${(props): string => (props.top ? props.top : '0px')};
    z-index: 1001;
`;
export const Backdrop = styled.div<{ show: boolean | (() => void) }>`
    display: ${({ show }) => (show ? 'flex' : 'none')};
    width: 100%;
    height: 100vh;
    position: fixed;
    top: 0;
    overflow: hidden;
    z-index: 102;
    background-color: rgba(0, 0, 0, 0.75);
`;
