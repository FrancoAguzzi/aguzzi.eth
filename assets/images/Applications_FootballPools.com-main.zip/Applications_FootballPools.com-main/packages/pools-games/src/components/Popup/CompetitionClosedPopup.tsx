import React, { FunctionComponent } from 'react';
import { CompetitionClosedPopupText } from '@components/Styles/defaultPageStyles';
import { Button } from '@components/Common/Button/Button';
import { useDispatch } from 'react-redux';
import { closePopup } from '@features/popups/popupsSlice';

export const CompetitionClosedPopup: FunctionComponent = () => {
    const dispatch = useDispatch();

    return (
        <CompetitionClosedPopupText>
            <p>Sorry, this competition is no longer selling. Press Ok to view the latest competition.</p>
            <Button
                bgColor={'#22A2FF'}
                textColor={'black'}
                height={'auto'}
                padding={'8px 10px'}
                rounded={'4px'}
                hoverColor={'#22A2FF'}
                onClick={(): void => {
                    dispatch(closePopup('competition_closed'));
                }}
            >
                OK
            </Button>
        </CompetitionClosedPopupText>
    );
};
