import { FunctionComponent } from 'react';

type AnchorAttributes = JSX.IntrinsicElements['a'];
export const ExternalLink: FunctionComponent<AnchorAttributes> = props => (
    <a target={props.target || '_blank'} rel="noopener noreferrer" {...props} />
);
