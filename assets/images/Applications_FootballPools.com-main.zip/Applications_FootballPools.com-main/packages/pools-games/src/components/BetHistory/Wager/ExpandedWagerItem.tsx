import React from 'react';
import { ResultsKey } from '@components/Results/ResultsKey/ResultsKey';
import { DateTimeFormatter } from '@components/Common/DateTimeFormatter/DateTimeFormatter';
import { BetSlipCircle } from '@components/BetSlip/BetSlipCircle/BetSlipCircle';
import { ResultSection } from '@components/Results/ResultsSection/ResultsSection';
import styled from 'styled-components';
import { CompetitionResult, Offering, Dividends, NumbersSelected, Wager } from '@sportech/pools-api';
import {
    classicPoolsPlansToShowPointsFor,
    ConvertStringToArray,
    getLuckyCloverPoints,
    getPoints,
    ReplaceGameName,
} from '@src/utils/functionUtils';
import { GameViewType } from '@components/GameSection/GameSection/GameSection';
import { GameModel } from '@interfaces/PoolGames/GameModel';

interface ExpandedWagerItemProps {
    wager: Wager;
    offering: Offering;
    comp: CompetitionResult;
    dividends: Dividends;
    result: string;
    showFixtures: boolean;
    setShowFixtures: (val: boolean) => void;
    gameModel: GameModel;
    isFirstWager?: boolean;
    hasMulitpleWagers?: boolean;
}

export const ExpandedWagerItem: React.FC<ExpandedWagerItemProps> = props => {
    const wagerSelection = ConvertStringToArray(props.wager.selections as string, !props.gameModel.isHDA());
    const bonusWagerSelection =
        props.wager.bonusSelections !== undefined
            ? ConvertStringToArray(props.wager.bonusSelections as string, !props.gameModel.isHDA())
            : undefined;
    const wagerSelectionFixtures = props.comp?.fixtures?.filter(x => wagerSelection?.find(c => c.Id === x.number));

    let pointsTotal = 0;
    pointsTotal = getPoints(
        wagerSelectionFixtures,
        props.gameModel.isHDA(),
        props.gameModel.name === 'classic-pools',
        wagerSelection,
    ) as number;

    if (props.gameModel.isClover()) {
        const numbers = ConvertStringToArray(props.wager.selections as string, !props.gameModel.isHDA());
        const bonusNumbers =
            props.wager.bonusSelections !== undefined
                ? ConvertStringToArray(props.wager.bonusSelections as string, !props.gameModel.isHDA())
                : undefined;

        pointsTotal = getLuckyCloverPoints(
            props.comp.winningNumbers as string[],
            bonusNumbers !== undefined
                ? (numbers as NumbersSelected[]).concat(bonusNumbers as NumbersSelected[])
                : (numbers as NumbersSelected[]),
        );
    }
    const winStatus =
        props.comp !== undefined
            ? props.comp.state.toLocaleLowerCase() === 'completed'
                ? props.wager.winAmount !== 0
                    ? 'Won'
                    : 'Lost'
                : 'Pending'
            : props.wager.winAmount !== 0
            ? 'Won'
            : 'Settled';
    const numbersFixturesPText = props.showFixtures ? 'Fixtures' : 'Numbers';
    const numbersFixturesViewText = props.showFixtures ? 'View Numbers' : 'View Fixtures';
    const PointsColor = (Numbers: NumbersSelected): string => {
        if (props.comp === undefined) {
            return '#fff';
        }
        const match = props.comp.fixtures.find(x => x.number === Numbers.Id);
        if (
            (props.gameModel.isClover() && props.comp.winningNumbers?.length === 0) ||
            (!props.gameModel.isClover() && match === undefined)
        ) {
            return '#fff';
        }
        if (!props.gameModel.isHDA() && match?.scores.isVoid) {
            return '#dbdbdb';
        }

        if (props.gameModel.isHDA()) {
            if (match?.scores.isVoid) {
                return 'green';
            }
            if (match?.status === 'notstarted') {
                return '#fff';
            }

            if (
                match?.scores.fullTime !== undefined &&
                Numbers.selections.includes('H') &&
                match?.scores.fullTime.home > match?.scores.fullTime.away
            ) {
                return 'green';
            } else if (
                match?.scores.fullTime !== undefined &&
                Numbers.selections.includes('A') &&
                match?.scores.fullTime.home < match?.scores.fullTime.away
            ) {
                return 'green';
            } else if (
                match?.scores.fullTime !== undefined &&
                Numbers.selections.includes('D') &&
                match?.scores.fullTime.home === match?.scores.fullTime.away
            ) {
                return 'green';
            } else if (match?.scores.fullTime !== undefined) {
                return 'red';
            }
        } else if (props.gameModel.name === 'classic-pools') {
            if (match?.points === 3) {
                return 'green';
            } else if (match?.points === 2) {
                return '#272188';
            } else if (match?.points === 1) {
                return '#ff2b2b';
            }
        } else if (props.gameModel.name === 'goal-rush') {
            if (match?.points === 1) {
                return 'green';
            } else if (match?.points === 0) {
                return 'red';
            }
        } else if (props.gameModel.name === 'lucky-clover') {
            if (props.comp.winningNumbers?.map(Number).includes(Numbers.Id)) {
                return 'green';
            } else {
                return 'red';
            }
        }

        return '#fff';
    };

    return (
        <ExpandedWager>
            {props.isFirstWager && (
                <StyledResultsKey>
                    <ResultsKey GameType={props.gameModel.name} isSmall={true} />
                </StyledResultsKey>
            )}
            {props.hasMulitpleWagers && props.isFirstWager && !props.gameModel.isClover() && (
                <Row3>
                    <Row3Item>
                        <p>
                            {`${numbersFixturesPText} `}
                            {props.comp !== undefined ? (
                                <StyledAUnderline
                                    onClick={(e): void => {
                                        props.setShowFixtures(!props.showFixtures);
                                        e.stopPropagation();
                                    }}
                                >
                                    {numbersFixturesViewText}
                                </StyledAUnderline>
                            ) : (
                                <></>
                            )}
                        </p>
                    </Row3Item>
                </Row3>
            )}
            <Row2>
                <StyledExpandedWagerItem>
                    {props.isFirstWager && (
                        <strong>
                            <p>Plan</p>
                        </strong>
                    )}
                    <p>
                        {ReplaceGameName(props.offering?.description)}{' '}
                        {props.wager.bonusSelections !== undefined && '+ Bonus'}{' '}
                    </p>
                </StyledExpandedWagerItem>
                <StyledExpandedWagerItem>
                    {props.isFirstWager && (
                        <strong>
                            <p>Date</p>
                        </strong>
                    )}
                    <p>
                        {props.comp !== undefined ? (
                            <DateTimeFormatter Format={'dd/MM/yyyy HH:mm'} Input={props.comp?.datumDate} />
                        ) : (
                            <>-</>
                        )}
                    </p>
                </StyledExpandedWagerItem>
                <StyledExpandedWagerItem>
                    {props.isFirstWager && (
                        <strong>
                            <p>Points</p>
                        </strong>
                    )}
                    <p>
                        {props.comp !== undefined
                            ? (props.gameModel.name === 'classic-pools' &&
                                  classicPoolsPlansToShowPointsFor.includes(props.offering.id as number)) ||
                              props.gameModel.name !== 'classic-pools'
                                ? pointsTotal
                                : '-'
                            : '-'}
                    </p>
                </StyledExpandedWagerItem>
                <StyledExpandedWagerItem>
                    {props.isFirstWager && (
                        <strong>
                            <p>Result</p>
                        </strong>
                    )}
                    <p>{props.result}</p>
                </StyledExpandedWagerItem>
                <StyledExpandedWagerItem>
                    {props.isFirstWager && (
                        <strong>
                            <p>Status</p>
                        </strong>
                    )}
                    <p>{winStatus}</p>
                </StyledExpandedWagerItem>
            </Row2>
            {!props.hasMulitpleWagers && !props.gameModel.isClover() && (
                <Row3>
                    <Row3Item>
                        <p>
                            {`${numbersFixturesPText} `}
                            {props.comp !== undefined ? (
                                <StyledAUnderline
                                    onClick={(e): void => {
                                        props.setShowFixtures(!props.showFixtures);
                                        e.stopPropagation();
                                    }}
                                >
                                    {numbersFixturesViewText}
                                </StyledAUnderline>
                            ) : (
                                <></>
                            )}
                        </p>
                    </Row3Item>
                </Row3>
            )}
            {!props.showFixtures && (
                <NumbersContainer>
                    <SelectionsNumberContainer>
                        {wagerSelection.map((fixture, index) => (
                            <BetSlipCircle
                                key={index}
                                selected={props.gameModel.isHDA() ? fixture.selections.join('') : fixture.Id}
                                ballColor={PointsColor(fixture)}
                            ></BetSlipCircle>
                        ))}
                        {bonusWagerSelection !== undefined && (
                            <>
                                <BonusBallDiveder>{' / '}</BonusBallDiveder>
                                {bonusWagerSelection.map((fixture, index) => (
                                    <BetSlipCircle
                                        key={index}
                                        selected={props.gameModel.isHDA() ? fixture.selections.join('') : fixture.Id}
                                        ballColor={PointsColor(fixture)}
                                    ></BetSlipCircle>
                                ))}
                            </>
                        )}
                    </SelectionsNumberContainer>
                </NumbersContainer>
            )}
            {props.showFixtures && (
                <ResultSection
                    gameModel={props.gameModel}
                    IsHda={props.gameModel.isHDA()}
                    fixtures={wagerSelectionFixtures}
                    matchCardWidth={'48%'}
                    Wager={wagerSelection}
                    wagerBonusSelection={bonusWagerSelection}
                    gameViewType={props.gameModel.isClover() ? GameViewType.Numbers : GameViewType.Match}
                />
            )}
        </ExpandedWager>
    );
};

const ExpandedWager = styled.div`
    display: flex;
    flex-wrap: wrap;
    width: 100%;
    padding-bottom: 5px;
    justify-content: center;
    font-size: 0.8em;
`;

const StyledExpandedWagerItem = styled.div`
    display: flex;
    flex: 1 1;
    flex-flow: column;
    align-items: center;

    p {
        margin: 2px 0;
    }
`;

const StyledResultsKey = styled.div`
    display: flex;
    flex: 1 1 100%;
    justify-content: center;
`;

const Row2 = styled.div`
    display: flex;
    flex: 1 1 100%;
`;

const Row3 = styled.div`
    display: flex;
    flex: 1 1 100%;
    justify-content: center;
`;

const Row3Item = styled.div`
    display: flex;
`;

const StyledAUnderline = styled.a`
    text-decoration: underline;
    cursor: pointer;
`;

const NumbersContainer = styled.div`
    padding: 0 10px;
`;

const SelectionsNumberContainer = styled.ul`
    display: flex;
    flex: 1 1 100%;
    flex-wrap: wrap;
    padding: 0;
`;

const BonusBallDiveder = styled.li`
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 24px;
    line-height: 24px;
    padding: 0 5px;
`;
