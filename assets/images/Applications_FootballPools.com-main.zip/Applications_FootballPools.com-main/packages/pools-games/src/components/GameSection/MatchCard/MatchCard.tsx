import styled from 'styled-components';
import { MatchCardTeams } from '../MatchCardTeams/MatchCardTeams';
import { breakpoints } from '@settings/breakpoints';
import { NumbersSelected, Scores } from '@sportech/pools-api';
import { MatchCardResults } from '@components/Results/ResultsSection/MatchCardResults';
import { GameModel } from '@interfaces/PoolGames/GameModel';

export interface MatchCardProp {
    /**
     * A label to show on the button
     */
    homeTeam: string;
    awayTeam: string;
    number: number;
    MatchID: number;
    IsHda: boolean;
    action?: (id: number, type: string) => void;
    numbers?: NumbersSelected | undefined;
    IsResults: boolean;
    Score?: Scores;
    Points?: number;
    matchCardWidth?: string;
    isViewLines: boolean;
    gameModel?: GameModel;
    isLineMissingSelection?: boolean;
}

export const MatchCard: React.FC<MatchCardProp> = props => {
    return (
        <MatchCardDiv IsResults={props.IsResults} matchCardWidth={props.matchCardWidth}>
            {props.IsResults ? (
                <MatchCardResults {...props}></MatchCardResults>
            ) : (
                <MatchCardTeams {...props}></MatchCardTeams>
            )}
        </MatchCardDiv>
    );
};

type MatchCardDivProps = {
    matchCardWidth?: string;
    IsResults?: boolean;
};

const MatchCardDiv = styled.li<MatchCardDivProps>`
    width: ${(props): string => (props.matchCardWidth ? props.matchCardWidth : '31%')};
    margin: 0.5%;
    float: left;
    font-size: 13px;
    ${breakpoints.below('lg')} {
        width: ${(props): string => (props.IsResults ? '48%' : '46%')};
        font-size: 12px;
    }
`;
