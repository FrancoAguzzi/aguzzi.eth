import { DepositLimitMessage } from '@components/InGameDeposit/DepositLimitMessage';
import { DepositPopupContent } from '@components/Styles/defaultPageStyles';

export const DepositLimitPopup = () => {
    return (
        <DepositPopupContent>
            <DepositLimitMessage />
        </DepositPopupContent>
    );
};
