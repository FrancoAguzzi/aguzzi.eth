import { BetSlip } from './betslip';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';

describe('BetSlip Component', () => {
    // Test should render
    it('should render', () => {
        const { container } = render(
            <BetSlip
                onClick={() => console.log('hola')}
                name={'Number of lines:'}
                lines={1}
                total={1.0}
                gameDays={[]}
                widthScreen={600}
            >
                Button
            </BetSlip>,
        );
        expect(container).toMatchSnapshot();
        expect(container).toBeInTheDocument();
        expect(container).toHaveTextContent('Number of lines:');
    });
});
