import React, { FunctionComponent, useEffect, useState } from 'react';
import { GameClosesText, StyledGameInfo } from '@components/Styles/defaultPageStyles';
import { DateTimeFormatter } from '@components/Common/DateTimeFormatter/DateTimeFormatter';
import { GameModel } from '@interfaces/PoolGames/GameModel';
import { BetSlip, Competition } from '@sportech/pools-api';
import { getCountdownToGameCloses } from '@src/utils/functionUtils';
import { useDispatch } from 'react-redux';
import { closePopup, openPopup } from '@features/popups/popupsSlice';

interface GameInfoProps {
    gameModel: GameModel;
    isMobileOrTablet: boolean;
    filteredComps: Competition[];
    currentSlip: BetSlip | undefined;
    carrySelectionOver: () => void;
}

export const GameInfo: FunctionComponent<GameInfoProps> = props => {
    const [time, setTime] = useState('');
    const dispatch = useDispatch();
    useEffect(() => {
        const interval = setInterval(
            () => {
                const countdown = getCountdownToGameCloses(props.filteredComps[0].datumDateWithBuffer);
                if (countdown === 'CLOSED') {
                    clearInterval(interval);
                    props.carrySelectionOver();
                    dispatch(openPopup('competition_closed'));
                    dispatch(closePopup('payment'));
                } else {
                    setTime(countdown);
                }
            },

            1000,
        );
        return (): void => {
            clearInterval(interval);
        };
    }, [props.currentSlip]);
    const luckyCloverCountdownTillGameCloses = props.gameModel.isClover() ? `Game Closes: ${time}` : '';
    return (
        <StyledGameInfo>
            {props.gameModel.info}
            {props.isMobileOrTablet ? <br /> : ' '}
            {props.gameModel.isClover() ? (
                <GameClosesText>{luckyCloverCountdownTillGameCloses}</GameClosesText>
            ) : (
                <>
                    {props.currentSlip !== undefined && (
                        <GameClosesText>
                            Game Closes:{' '}
                            <DateTimeFormatter
                                Format={'dd MMM @ HH:mm'}
                                Input={
                                    props.filteredComps.find(
                                        x =>
                                            x.id ===
                                            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                                            props.currentSlip!.competitionId,
                                    )?.datumDateWithBuffer
                                }
                            />
                        </GameClosesText>
                    )}
                </>
            )}
        </StyledGameInfo>
    );
};
