import { Lucky4LifeLayout } from '.';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';

describe('Lucky4LifeLayout Component', () => {
    // Test should render
    it('should render', () => {
        const { container } = render(
            <Lucky4LifeLayout onPreviousClick={() => null} previousText="Back" title="Lucky4Life" isPopUp={true}>
                childre
            </Lucky4LifeLayout>,
        );
        expect(container).toMatchSnapshot();
        expect(container).toBeInTheDocument();
    });
});
