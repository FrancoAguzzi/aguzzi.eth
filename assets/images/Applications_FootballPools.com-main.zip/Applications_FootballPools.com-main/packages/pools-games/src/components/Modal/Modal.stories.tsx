import { ComponentStory, ComponentMeta } from '@storybook/react';
import { Modal } from './Modal';

export default {
    title: 'Components/Modal',
    component: Modal,
} as ComponentMeta<typeof Modal>;

export const PrimaryButton: ComponentStory<typeof Modal> = () => (
    <Modal
        show={false}
        close={() => null}
        title={'how to play'}
        heightModalInitial={0.8}
        font={'100'}
        align={'center'}
        justify={'center'}
    >
        Modal
    </Modal>
);
