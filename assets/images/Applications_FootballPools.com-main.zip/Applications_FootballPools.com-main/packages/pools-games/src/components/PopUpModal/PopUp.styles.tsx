import { breakpointValues } from '@settings/breakpoints';
import styled from 'styled-components';

export const Backdrop = styled.div<{ show: boolean | (() => void) }>`
    display: ${({ show }) => (show ? 'flex' : 'none')};
    width: 100%;
    height: 100vh;
    position: fixed;
    top: 0;
    overflow: hidden;
    z-index: 101;
    background-color: rgba(0, 0, 0, 0.75);
`;
export const PopUpBase = styled.div`
    display: flex;
    flex-direction: column;
    border-radius: 1.5rem;
    height: 80vh;
    width: 400px;
    background-color: white;
    margin: auto auto;
    overflow: hidden;
    position: relative;
    z-index: 100;

    @media (max-width: ${breakpointValues.sm}px) {
        position: fixed;
        top: 0;
        margin: 0;
        width: 100%;
        height: 100%;
        border-radius: 0;
    }
`;
