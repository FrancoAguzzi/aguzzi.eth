import { Modal } from '../PickerModal/Modal';
import { Circle } from '@components/Circle/circle';
import { Button } from '@components/button/button';
import { Loader } from '@components/Loader/Loader';
import { LinesProps } from '@interfaces/PoolGames/LottoGames';
import { orderNumbers } from '@src/utils/functionUtils';
import { Dispatch, useEffect, useState, useMemo, SetStateAction } from 'react';
import { ContainerPicker as Container } from '@src/base-styles';
import { BetSlip } from '@components/BetSlip/betslip';

/**
 * Modal props
 *  @param show boolean to know if the modal is show or not.
 *  @param pickerTitle Title which is shown in the top modal.
 *  @param close handle to close modal.
 *  @param heightModalInitial Modal height initial.
 *  @param selectionMatrices Lines numbers options
 *  @param onDonePickingClick Function to set picks in line
 *  @param isLoading Boolean to know when to show the spinners
 *  @param currentPick Current picking selection to be selected or edited
 *  @param memPicks Map containing a memory with all selections picked previously
 *  @param currentPickSelection Current picker selection
 */

interface Props {
    pickerTitle: string;
    show: boolean;
    close: () => void;
    onDonePickingClick: (
        picks: Array<number | string>,
        previousPick: Array<number | string>,
        currentPickSelection: number | string,
    ) => void;
    heightModalInitial: number;
    selectionMatrices: Array<string>;
    isLoading: boolean;
    lines: LinesProps[];
    currentPick: number | string;
    memPicks: Record<string, boolean>;
    currentPickSelection: string;
    linesBetslip: number;
    total: number;
    onClick: (() => void) | (() => Promise<void>);
    gameDays: Array<string>;
    isShowingPicker: boolean;
    isMobile: boolean;
    widthScreen: number;
    setOpenTwoLinesErrorPopUp: Dispatch<SetStateAction<boolean>>;
}

export const Picker = ({
    show,
    close,
    pickerTitle,
    heightModalInitial,
    selectionMatrices,
    onDonePickingClick,
    isLoading,
    lines,
    currentPick,
    memPicks,
    currentPickSelection,
    total,
    widthScreen,
    linesBetslip,
    onClick,
    isShowingPicker,
    gameDays,
    isMobile,
    setOpenTwoLinesErrorPopUp,
}: Props): JSX.Element => {
    const [picks, setPicks] = useState<Array<number | string>>([]);
    const previousPick = lines[Number(currentPick) - 1]?.selection;

    useEffect(() => {
        if (currentPick === 0) return;
        setPicks(lines[Number(currentPick) - 1]?.selection ?? []);
    }, [lines, setPicks, currentPick]);
    //Handler to add and remove picks in the modal before submitting them
    const addPick = (el: number | string): void => {
        if (picks?.length === 6 && !picks?.includes(el)) return;
        setPicks(picks?.includes(el) ? picks.filter(item => item !== el) : [...picks, el]);
    };

    const matrix = useMemo(() => selectionMatrices?.map(el => Number(el)) ?? [], [selectionMatrices]);

    const onDoneClick = () => {
        onDonePickingClick(picks, previousPick, currentPick);
        setPicks([]);
    };
    const numbers = orderNumbers(picks.map(p => parseInt(String(p)))).toString();

    const disabled = useMemo(() => picks?.length !== 6 || (memPicks?.[numbers] && currentPickSelection !== numbers), [
        picks,
    ]);
    useEffect(() => {
        if (picks.length === 6 && disabled && isShowingPicker) {
            setOpenTwoLinesErrorPopUp(true);
        }
    }, [picks]);
    return (
        <>
            <Modal
                show={show}
                close={close}
                title={pickerTitle}
                heightModalInitial={heightModalInitial}
                font={'100'}
                align={'center'}
                justify={'center'}
            >
                <Container>
                    <Loader isLoading={isLoading} />
                    {matrix?.map((el, idx) => (
                        <Circle
                            key={`line-number-${idx + 1}`}
                            selected={el}
                            isSelected={picks.includes(el)}
                            border={true}
                            isCurrentSelectedLine={true}
                            handleOnClick={addPick}
                            displayId={true}
                            area={widthScreen <= 600 ? widthScreen - 40 : 365}
                            fontSize="thin"
                            isInLine={false}
                            margin={'0 5px 8px 0'}
                        />
                    ))}
                    <Button
                        text="DONE"
                        border={disabled ? '1px solid black' : '1px solid #188BE9'}
                        fontColor={disabled ? 'black' : 'white'}
                        color={disabled ? 'white' : '#188BE9'}
                        width="80%"
                        onClick={disabled ? () => null : () => onDoneClick()}
                        padding={'10px'}
                        margin="30px auto"
                        fontWeight="100"
                    />
                </Container>

                <BetSlip
                    name="Number of lines:"
                    lines={linesBetslip}
                    total={total}
                    width="100%"
                    variant="primary"
                    onClick={onClick}
                    gameDays={[]}
                    isShowingPicker={isShowingPicker}
                    isMobile={isMobile}
                    widthScreen={widthScreen}
                />
            </Modal>
        </>
    );
};
