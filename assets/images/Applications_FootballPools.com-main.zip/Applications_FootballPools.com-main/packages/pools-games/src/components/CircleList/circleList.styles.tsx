import styled from 'styled-components';

export const StyledListItem = styled.div<{ marginTopCircle?: number }>`
    width: 100%;
    margin-top: ${(props): string => (props.marginTopCircle ? `${props.marginTopCircle}px` : '')};
    align-items: center;
    justify-content: space-between;
    display: flex;
`;

export const Text = styled.p`
    margin: 0px;
    font-family: 'Montserrat, SemiBold';
`;
