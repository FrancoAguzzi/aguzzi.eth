import styled from 'styled-components';
import { breakpoints } from '../../settings/breakpoints';

export type alignItemsType = 'flex-start' | 'flex-end';
export type ctaLocationType = 'top' | 'bottom';

interface Props {
    imageUrl: string;
    url: string;
}

const Container = styled.a``;

const TileContainer = styled.div`
    width: 100%;
    max-height: 335px;
    background-color: transparent;
    box-shadow: rgb(0 0 0 / 40%) 3px 5px 6px 1px;
    display: flex;
    aspect-ratio: 16/9;
    cursor: pointer;
    ${breakpoints.above('lg')} {
        width: 1360px;
        height: 25vw;
    }
    @media (min-width: 1024px and max-width: 1340px) {
        max-height: 25vw;
    }
`;

const ImageContainer = styled.div<{ imageUrl: string }>`
    width: 100%;
    height: 25vw;
    background: url('${props => props.imageUrl}');
    background-repeat: no-repeat !important;
    background-size: cover !important;
    aspect-ratio: 16/9;
    @media (min-width: 1024px and max-width: 1340px) {
        max-height: 25vw;
    }
    ${breakpoints.above('lg')} {
        background-size: contain !important;
    }
`;

export const CarouselTile = ({ imageUrl, url }: Props): JSX.Element => {
    return (
        <Container href={url}>
            <TileContainer>
                <ImageContainer imageUrl={imageUrl} />
            </TileContainer>
        </Container>
    );
};
