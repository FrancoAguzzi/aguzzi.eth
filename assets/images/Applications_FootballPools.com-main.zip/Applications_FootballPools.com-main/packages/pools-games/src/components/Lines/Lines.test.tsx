import { Lines } from './lines';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';

describe('Lines Component', () => {
    // Test should render
    it('should render', () => {
        const { container } = render(
            <Lines
                selection={[1, 2, 3, 4, 5]}
                amount={5}
                row={1}
                displayId={true}
                isCurrent={true}
                area={200}
                handleOnClickNumber={() => null}
                diceButton={true}
                editButton={true}
                selected={[false, false, false, false, false]}
                areaContainer={0}
                handleOnClickDice={() => null}
                handleOnClickEdit={() => null}
                handleOnClickDelete={() => null}
            />,
        );
        expect(container).toMatchSnapshot();
        expect(container).toBeInTheDocument();
        expect(container).toHaveTextContent('2');
    });
});
