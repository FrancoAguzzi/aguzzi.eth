import { DepositPopupContent } from '@components/Styles/defaultPageStyles';
import AddNewCardForm from '@components/InGameDeposit/AddNewCardForm';

export const AddNewCardPopup = () => {
    return (
        <DepositPopupContent>
            <AddNewCardForm />
        </DepositPopupContent>
    );
};
