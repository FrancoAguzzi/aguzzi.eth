import { OuterContainer, NavBarTitle, BackButton, TopBar, Arrow } from './layout.styles';
import getConfig from 'next/config';
import { ExternalLink } from '@components/Common/ExternalLink/ExternalLink';

interface Lucky4LifelayoutProps {
    onPreviousClick?: ((event: React.MouseEvent<HTMLButtonElement>) => null) | (() => void);
    previousText?: string;
    title: string;
    isPopUp: boolean;
    children?: React.ReactNode;
    justify?: string;
}

/**
 * Screen props
 * @param onPreviousClick Function to handle back action
 * @param previousText Text of the button that fires the back action
 * @param title Title which is shown in the top bar in mobile and in the top of the image in desktop
 * @param isPopUp Flag in order to know if the Layout is showing in the PopUp
 * @param children Child components to be shown below the top bar
 */

export const Lucky4LifeLayout = ({
    onPreviousClick,
    previousText,
    title,
    isPopUp,
    children,
    justify,
}: Lucky4LifelayoutProps): JSX.Element => {
    const { publicRuntimeConfig } = getConfig();
    const FSBUrl = (path: string): string => publicRuntimeConfig.FSB_SITE_URL + path;

    return (
        <OuterContainer justify={justify}>
            <TopBar isPopUp={isPopUp}>
                {previousText === 'All Lottos' ? (
                    <ExternalLink target={'_self'} href={FSBUrl('lotto')}>
                        <BackButton>
                            <Arrow />
                            {previousText}
                        </BackButton>
                    </ExternalLink>
                ) : (
                    <BackButton onClick={onPreviousClick}>
                        <Arrow />
                        {previousText}
                    </BackButton>
                )}
                <NavBarTitle isPopUp={isPopUp}>{title}</NavBarTitle>
            </TopBar>

            {children}
        </OuterContainer>
    );
};

export default Lucky4LifeLayout;
