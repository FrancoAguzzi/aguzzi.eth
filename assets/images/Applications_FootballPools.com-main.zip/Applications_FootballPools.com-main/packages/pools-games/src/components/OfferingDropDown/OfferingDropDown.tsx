import { FunctionComponent } from 'react';
import styled from 'styled-components';
import { Offerings, BetSlip, Offering } from '@sportech/pools-api';
import { OfferingDropDownListItem } from './OfferingDropDownListItem';

interface OfferingDropDownProps {
    offers: Offerings;
    SelectAmountAction: (id: number, offer: Offering) => void;
    setOfferingDropdownOpen: (val: boolean) => void;
    betslipCurrentSelection: BetSlip;
    setShowMore: (val: boolean) => void;
    setCurrentOffering: (val: number) => void;
    isHda: boolean;
}

export const OfferingDropDown: FunctionComponent<OfferingDropDownProps> = props => {
    return (
        <>
            <StyledDropdown>
                <ul>
                    {props.offers.offerings.slice(3, props.offers.offerings.length).map((item, index) => (
                        <OfferingDropDownListItem
                            offer={item}
                            SelectAmountAction={props.SelectAmountAction}
                            key={index}
                            setShowMore={props.setShowMore}
                            setCurrentOffering={props.setCurrentOffering}
                            betslipCurrentSelection={props.betslipCurrentSelection}
                            setOfferingDropdownOpen={props.setOfferingDropdownOpen}
                            isHda={props.isHda}
                        ></OfferingDropDownListItem>
                    ))}
                </ul>
            </StyledDropdown>
            <DropdownOverlay
                onClick={(): void => {
                    props.setOfferingDropdownOpen(false);
                    props.setCurrentOffering(props.betslipCurrentSelection.priceID);
                }}
            />
        </>
    );
};

const DropdownOverlay = styled.div`
    position: absolute;
    width: 100vw;
    height: 100vw;
    top: 0;
    left: 0;

    z-index: 10;
`;

const StyledDropdown = styled.div`
    margin-top: 10px;
    position: relative;
    z-index: 11;
    height: 200px;
    overflow: scroll;
    width: 100%;
    ul {
        padding: 0 10px;
    }
    li {
        list-style: none;
        font-size: 16px;
        padding: 5px;
        cursor: pointer;
        display: flex;
        flex-wrap: wrap;
        align-items: center;

        button {
            flex: 1;
            max-width: 60%;
            margin: 0 auto;
        }
    }

    hr {
        width: 95%;
    }
`;
