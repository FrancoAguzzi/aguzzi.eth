import { PlaceBet } from './PlaceBet';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';
import { renderWithTheme } from '../../testing/utils/renderWithTheme';

describe('Prize Component', () => {
    // Test should render
    it('should render', () => {
        const { container } = renderWithTheme(
            <PlaceBet
                setGameDays={() => null}
                setNumberOfWeeks={() => null}
                numberOfWeeks={''}
                gameDays={['']}
                checkoutQuick={false}
                widthScreen={600}
            />,
        );
        expect(container).toMatchSnapshot();
    });
});
