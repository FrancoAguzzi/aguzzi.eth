import { DiceFigures } from './DiceFigures';
import { render, fireEvent, act } from '@testing-library/react';
import 'jest-styled-components';

const mockFn = jest.fn();

describe('DiceFigures', () => {
    it('should render', () => {
        const { container } = render(<DiceFigures></DiceFigures>);

        expect(container).toMatchSnapshot();
    });

    it('should render Flipped', () => {
        const { container } = render(<DiceFigures flip={true}></DiceFigures>);

        expect(container).toMatchSnapshot();
    });
});
