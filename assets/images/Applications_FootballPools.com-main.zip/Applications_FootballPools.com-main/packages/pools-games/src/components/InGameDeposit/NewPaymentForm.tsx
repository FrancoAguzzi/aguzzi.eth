import styled from 'styled-components';
import getConfig from 'next/config';
import { ConfirmButton } from '@components/Common/Button/Button';
import { useForm } from 'react-hook-form';
import { callApiRoute, callNetbanxRoute, callPaymentRoute } from '@api/PaymentAPI';
import { Address, Payment } from '@interfaces/FSB';
import { useDispatch } from 'react-redux';
import { closePopup, openPopup } from '@features/popups/popupsSlice';

interface NewPaymentFormProps {
    paymentType: string;
    amount: string;
    cardNum: string;
    cardExpiryMonth: string;
    cardExpiryYear: string;
    cvdNumber: string;
}

const FlexRowContainer = styled.div`
    display: flex;
    flex-direction: row;
`;

const FlexColumnContainer = styled.div`
    display: flex;
    flex-direction: column;
`;

const FormContainer = styled.form`
    display: flex;
    flex-direction: column;
`;

const Container = styled.div`
    padding: 10px;
`;

const FormTitle = styled.h4`
    margin: 0;
`;

const FormRow = styled(FlexRowContainer)`
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
    padding: 10px 0;
`;

const PaymentRow = styled(FormRow)`
    justify-content: center;
`;

const PaymentLabel = styled.div`
    font-size: 12px;
`;

const FormIcon = styled.img`
    width: 50px;
    height: 30px;
    border: 2px solid #000;
    border-radius: 10px;
    margin: 0 5px;
    padding: 5px;
    opacity: 0.5;
    z-index: 3;
`;

const FormLabel = styled.label`
    width: 25%;
    align-items: center;
    display: flex;
`;

const InputContainer = styled(FlexColumnContainer)`
    width: 75%;
`;

const FormInput = styled.input`
    width: 100%;
    height: 28px;
    font-size: 16px;
`;

const ShortFormInput = styled.input`
    width: 35px;
    height: 28px;
    font-size: 16px;
`;

const RadioInput = styled.input`
    &[type='radio'] {
        position: absolute;
        opacity: 0;
        width: 64px;
        height: 44px;
        cursor: pointer;
        z-index: 5;
    }
    &[type='radio']:checked + img {
        border: 2px solid green;
        opacity: 1;
    }
`;

const ButtonContainer = styled.div`
    margin-top: 10px;
`;

const DateSeparator = styled.span`
    padding: 0 5px;
    align-items: center;
    display: flex;
`;

const SecurityCodeImage = styled.img`
    height: 40px;
    margin: 0 10px;
`;

const SecurityCodeDescription = styled.span`
    width: 120px;
    text-align: left;
`;

const ErrorMsg = styled.p`
    font-size: 1em;
    color: red;
    margin: 0;
    text-align: left;
    padding: 5px 0 0 0;
`;

const Iframe = styled.iframe`
    height: 400px;
    width: 100%;
    @media (min-width: 1024px) {
        width: 350px;
    }
    display: none;
`;

const NewPaymentForm = (): JSX.Element => {
    const { register, handleSubmit, errors } = useForm<NewPaymentFormProps>();
    const { publicRuntimeConfig } = getConfig();
    const dispatch = useDispatch();
    const showPayPal = false;

    const minDeposit = 5;

    const isValidAmount = (amount: string): boolean => {
        const inputValue = parseFloat(amount);

        if (+inputValue) {
            if (inputValue < minDeposit) {
                return false;
            }

            const isDecimalNumber = inputValue - Math.floor(inputValue) !== 0;

            if (isDecimalNumber) {
                const index = amount.indexOf('.');
                const numDecimalPlaces = amount.length - index - 1;
                if (numDecimalPlaces > 2) {
                    return false;
                } else {
                    return true;
                }
            } else {
                return true;
            }
        } else {
            return false;
        }
    };

    const displayCardDetails = (): void => {
        const formInputs = document.getElementsByClassName('card-only-field');
        const formRows = document.getElementsByClassName('card-only-row');

        if (formInputs !== null) {
            for (let i = 0; i < formInputs.length; i++) {
                const formInput = formInputs[i] as HTMLElement;
                formInput.hidden = false;
            }
            const cardNum = formInputs[0] as HTMLInputElement;
            const cardExpiryMonth = formInputs[1] as HTMLInputElement;
            const cardExpiryYear = formInputs[2] as HTMLInputElement;
            const cvdNumber = formInputs[3] as HTMLInputElement;

            cardNum.value = '';
            cardExpiryMonth.value = '';
            cardExpiryYear.value = '';
            cvdNumber.value = '';
        }

        if (formRows !== null) {
            for (let i = 0; i < formRows.length; i++) {
                const formRow = formRows[i] as HTMLElement;
                formRow.style.display = 'flex';
            }
        }
    };

    const displayPayPalDetails = (): void => {
        const formInputs = document.getElementsByClassName('card-only-field');
        const formRows = document.getElementsByClassName('card-only-row');

        if (formInputs !== null) {
            for (let i = 0; i < formInputs.length; i++) {
                const formInput = formInputs[i] as HTMLInputElement;
                formInput.hidden = true;
            }
            const cardNum = formInputs[0] as HTMLInputElement;
            const cardExpiryMonth = formInputs[1] as HTMLInputElement;
            const cardExpiryYear = formInputs[2] as HTMLInputElement;
            const cvdNumber = formInputs[3] as HTMLInputElement;

            cardNum.value = '0000000000000000';
            cardExpiryMonth.value = '00';
            cardExpiryYear.value = '00';
            cvdNumber.value = '000';
        }

        if (formRows !== null) {
            for (let i = 0; i < formRows.length; i++) {
                const formRow = formRows[i] as HTMLElement;
                formRow.style.display = 'none';
            }
        }
    };

    const inputFocus = () => {
        if (window.innerWidth <= 430) {
            const popupRoot = document.getElementById('popup-root');
            const popupContainer = popupRoot?.childNodes[0].childNodes[0] as HTMLElement;
            if (popupContainer !== undefined) {
                popupContainer.setAttribute(
                    'style',
                    'margin: 0 3% auto !important; top: 10px; position: relative; height: 57%; overflow: scroll;',
                );
            }
        }
    };

    const inputBlur = () => {
        if (window.innerWidth <= 430) {
            const popupRoot = document.getElementById('popup-root');
            const popupContainer = popupRoot?.childNodes[0].childNodes[0] as HTMLElement;
            if (popupContainer !== undefined) {
                popupContainer.setAttribute(
                    'style',
                    'margin: auto 3%; top: auto; position: relative; height: auto; overflow: none;',
                );
            }
        }
    };

    const onSubmit = handleSubmit(async data => {
        const paymentPopup = document.getElementsByClassName('popup-overlay');
        if (paymentPopup !== null) {
            const popup = paymentPopup[0] as HTMLElement;
            popup.style.display = 'none';
        }

        dispatch(openPopup('loading'));

        const address = await callApiRoute<Address>('getAddress');

        const responseUrl = data.paymentType === 'OPTIMAL-CARD' ? '/deposit-card-complete' : '/deposit-paypal-complete';

        const paymentData = {
            paymentMethodRef: data.paymentType,
            addressId: address.response.customer.address[0].id,
            amount: data.amount,
            responseUrl: `${publicRuntimeConfig.WEBSITE_BASE}${responseUrl}`,
            cardNum: data.cardNum,
            cardExpiryMonth: data.cardExpiryMonth,
            cardExpiryYear: data.cardExpiryYear,
            storeCardIndicator: true,
            cvdNumber: data.cvdNumber,
        };

        const payment = await callPaymentRoute<Payment>(paymentData);

        if (payment.response.status.messageKey !== undefined) {
            if (
                payment.response.status.messageKey === 'api.error.payment.limit.exceeded' ||
                payment.response.status.messageKey === 'api.error.payment.deposit.limit.reached'
            ) {
                dispatch(closePopup('new_payment'));
                dispatch(closePopup('loading'));
                dispatch(openPopup('deposit-limit'));
                return;
            }
        }

        const url = new URL(payment.response.customer.hpResponse.uri);
        if (data.paymentType === 'OPTIMAL-CARD') {
            url.searchParams.append('cardNum', data.cardNum);
            url.searchParams.append('cardExpiryMonth', data.cardExpiryMonth);
            url.searchParams.append('cardExpiryYear', data.cardExpiryYear);
            url.searchParams.append('cvdNumber', data.cvdNumber);
        }
        url.searchParams.append('amount', data.amount.toString());
        url.searchParams.append('storeCardIndicator', 'true');

        if (data.paymentType === 'OPTIMAL-PAYPAL') {
            window.open(url.toString(), 'Popup', 'location,status,scrollbars,resizable,width=600, height=600');

            window.addEventListener('message', function (e) {
                dispatch(closePopup('loading'));

                if (e.data.status === 'success') {
                    dispatch(closePopup('new_payment'));
                    dispatch(openPopup('payment_deposit_success'));
                } else {
                    dispatch(closePopup('new_payment'));
                    dispatch(openPopup('payment_deposit_failure'));
                }
            });
        } else if (data.paymentType === 'OPTIMAL-CARD') {
            const iframe = document.getElementById('optimal-payment') as HTMLIFrameElement;
            const formContainer = document.getElementById('form-container');
            if (formContainer !== null && iframe !== null) {
                formContainer.style.display = 'none';
                iframe.src = url.toString();
                iframe.style.display = 'block';
            }

            dispatch(closePopup('loading'));
            if (paymentPopup !== null) {
                const popup = paymentPopup[0] as HTMLElement;
                popup.style.display = 'flex';
            }

            window.addEventListener('message', function (e) {
                if (e.data.status === 'success') {
                    dispatch(closePopup('new_payment'));
                    dispatch(openPopup('payment_deposit_success'));
                } else {
                    dispatch(closePopup('new_payment'));
                    dispatch(openPopup('payment_deposit_failure'));
                }
            });
        }
    });

    return (
        <Container id="container">
            <FormContainer onSubmit={onSubmit} id="form-container">
                <FormTitle>Select Payment Method</FormTitle>
                <PaymentRow>
                    <FlexColumnContainer>
                        <FlexColumnContainer>
                            <RadioInput
                                type="radio"
                                name="paymentType"
                                value="OPTIMAL-CARD"
                                ref={register()}
                                onClick={(): void => {
                                    displayCardDetails();
                                }}
                                defaultChecked
                            />
                            <FormIcon
                                src="https://cms.thepools.com/api/assets/pool-games/26179d34-7a63-418a-a8dc-e5dff7728648/card-icon.svg?version=0"
                                alt="Direct Debit"
                            />
                            <PaymentLabel>Debit Card</PaymentLabel>
                        </FlexColumnContainer>
                    </FlexColumnContainer>
                    {showPayPal && (
                        <FlexColumnContainer>
                            <FlexColumnContainer>
                                <RadioInput
                                    type="radio"
                                    name="paymentType"
                                    value="OPTIMAL-PAYPAL"
                                    ref={register()}
                                    onClick={(): void => {
                                        displayPayPalDetails();
                                    }}
                                    onFocus={(): void => {
                                        inputFocus();
                                    }}
                                    onBlur={(): void => {
                                        inputBlur();
                                    }}
                                />
                                <FormIcon
                                    src="https://cms.thepools.com/api/assets/pool-games/334755f0-8234-4271-9796-570dd1a45276/paypal-logo-colourized.svg?version=0"
                                    alt="PayPal"
                                />
                                <PaymentLabel>PayPal</PaymentLabel>
                            </FlexColumnContainer>
                        </FlexColumnContainer>
                    )}
                </PaymentRow>
                <FormTitle>Enter Payment Details</FormTitle>
                <FormRow>
                    <FormLabel htmlFor="amount">Amount</FormLabel>
                    <InputContainer>
                        <FormInput
                            type="text"
                            name="amount"
                            id="amount"
                            inputMode="decimal"
                            placeholder={`Minimum Deposit: £${minDeposit}`}
                            ref={register({
                                required: {
                                    value: true,
                                    message: 'This is required',
                                },
                                validate: isValidAmount,
                            })}
                            onFocus={(): void => {
                                inputFocus();
                            }}
                            onBlur={(): void => {
                                inputBlur();
                            }}
                        />
                        <ErrorMsg>
                            {errors.amount &&
                                errors.amount.type === 'validate' &&
                                `Please enter an amount of at least £${minDeposit}`}
                        </ErrorMsg>
                    </InputContainer>
                </FormRow>
                <FormRow className="card-only-row">
                    <FormLabel htmlFor="cardNum">Card Number</FormLabel>
                    <InputContainer>
                        <FormInput
                            type="text"
                            name="cardNum"
                            id="cardNum"
                            className="card-only-field"
                            inputMode="numeric"
                            placeholder="16 Digit debit card number"
                            autoComplete="off"
                            ref={register({
                                required: {
                                    value: true,
                                    message: 'This is required',
                                },
                                pattern: { value: /[0-9]{16}/, message: '' },
                            })}
                            onFocus={(): void => {
                                inputFocus();
                            }}
                            onBlur={(): void => {
                                inputBlur();
                            }}
                        />
                        <ErrorMsg>{errors.cardNum && 'Please enter the 16 digit card number'}</ErrorMsg>
                    </InputContainer>
                </FormRow>
                <FormRow className="card-only-row">
                    <FormLabel>Expiry Date</FormLabel>
                    <InputContainer>
                        <FlexRowContainer>
                            <ShortFormInput
                                type="text"
                                name="cardExpiryMonth"
                                id="cardExpiryMonth"
                                className="card-only-field"
                                inputMode="numeric"
                                maxLength={2}
                                placeholder="MM"
                                ref={register({
                                    required: {
                                        value: true,
                                        message: 'This is required',
                                    },
                                    pattern: { value: /[0-9]{2}/, message: '' },
                                })}
                                onFocus={(): void => {
                                    inputFocus();
                                }}
                                onBlur={(): void => {
                                    inputBlur();
                                }}
                            />
                            <DateSeparator>/</DateSeparator>
                            <ShortFormInput
                                type="text"
                                name="cardExpiryYear"
                                id="cardExpiryYear"
                                className="card-only-field"
                                inputMode="numeric"
                                maxLength={2}
                                placeholder="YY"
                                ref={register({
                                    required: {
                                        value: true,
                                        message: 'This is required',
                                    },
                                    pattern: { value: /[0-9]{2}/, message: '' },
                                })}
                                onFocus={(): void => {
                                    inputFocus();
                                }}
                                onBlur={(): void => {
                                    inputBlur();
                                }}
                            />
                        </FlexRowContainer>
                        <ErrorMsg>
                            {(errors.cardExpiryMonth || errors.cardExpiryYear) && 'Please enter the card expiry date'}
                        </ErrorMsg>
                    </InputContainer>
                </FormRow>
                <FormRow className="card-only-row">
                    <FormLabel htmlFor="amount">Security Code</FormLabel>
                    <InputContainer>
                        <FlexRowContainer>
                            <ShortFormInput
                                type="text"
                                name="cvdNumber"
                                id="cvdNumber"
                                className="card-only-field"
                                inputMode="numeric"
                                maxLength={3}
                                placeholder="CV2"
                                ref={register({
                                    required: {
                                        value: true,
                                        message: 'This is required',
                                    },
                                    pattern: { value: /[0-9]{3}/, message: '' },
                                })}
                                onFocus={(): void => {
                                    inputFocus();
                                }}
                                onBlur={(): void => {
                                    inputBlur();
                                }}
                            />
                            <SecurityCodeImage
                                src="https://cms.thepools.com/api/assets/pool-games/d2454c08-f396-4184-89bd-44e865996713/cv2-icon.svg?version=0"
                                alt="Security Code Icon"
                            />
                            <SecurityCodeDescription>3 digits on the back of the card</SecurityCodeDescription>
                        </FlexRowContainer>
                        <ErrorMsg>{errors.cvdNumber && 'Please enter the 3 digit Security Code'}</ErrorMsg>
                    </InputContainer>
                </FormRow>
                <ButtonContainer>
                    <ConfirmButton>Submit & Finish</ConfirmButton>
                </ButtonContainer>
            </FormContainer>
            <Iframe id="optimal-payment" name="optimal-payment"></Iframe>
        </Container>
    );
};

export default NewPaymentForm;
