import { PopUpModal } from './PopUp';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';

describe('Pop up Component', () => {
    // Test should render
    it('should render', () => {
        const { container } = render(
            <PopUpModal close={() => null} show={false} title={''}>
                Modal
            </PopUpModal>,
        );

        expect(container).toMatchSnapshot();
    });
});
