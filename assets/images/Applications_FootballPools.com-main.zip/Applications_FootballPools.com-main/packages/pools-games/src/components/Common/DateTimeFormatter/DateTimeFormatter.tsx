import { FunctionComponent } from 'react';
import { format } from 'date-fns';
import locale from 'date-fns/locale/en-GB';

interface DateTimeFormatterProps {
    Format: string;
    Input?: Date | string;
}

export const DateTimeFormatter: FunctionComponent<DateTimeFormatterProps> = props => {
    return <>{format(new Date(props.Input ?? ''), props.Format, { locale })}</>;
};
