import { breakpointValues } from '@settings/breakpoints';
import styled, { keyframes } from 'styled-components';
import {
    ButtonGen,
    ButtonRightGen,
    ButtonXGen,
    MoveContentGen,
    ModalContentGen,
    MoveContentMobileGen,
    BackgroundModalGen,
    ContentGen,
} from '@src/base-styles';

/* Animation to fade in modal */
export const fadeIn = keyframes`
    from {
        bottom: -1200px;
        transition: all 1.25s ease;
    }

    to {
        bottom: 0;
    }
`;

/* Animation to fade out modal */
export const fadeOut = keyframes`
    from {
        bottom: 0;
    }

    to {
        bottom: -1200px;
        transition: all .75s ease;
    }
`;
interface PropsModal {
    height: number;
    transition: string;
}
export type fontType = '100' | 'bold';
export type alignType = 'start' | 'center' | 'end';
export type justifyType = 'start' | 'center' | 'end' | 'space-between' | 'space-around';

export const Button = styled(ButtonGen)`
    font-size: 1rem;
    font-weight: 300;
    background: #fff;
    float: right;
    border: none;
    cursor: pointer;
`;
export const ButtonRight = styled(ButtonRightGen)`
    font-size: 1rem;
    font-weight: 300;
    background: #fff;
    margin-right: 10px;
    margin-left: 10px;
    margin-top: 10px;
    border: none;
`;
export const ButtonX = styled(ButtonXGen)`
    @media (max-width: ${breakpointValues.sm}px) {
        margin: 0;
        width: 0;
        height: 0;
        justify-content: center;
        align-items: center;
        margin-top: 1rem;
        margin-left: 2.5rem;
        height: 1px;
        width: 50px;
    }
`;

export const MoveContentMobile = styled(MoveContentMobileGen)<Pick<PropsModal, 'height' | 'transition'>>`
    transition: ${({ transition }) => (transition ? transition : 'none')};
`;
export const MoveContent = styled(MoveContentGen)<Pick<PropsModal, 'height' | 'transition'>>`
    transition: ${({ transition }) => (transition ? transition : 'none')};
`;
export const ModalContent = styled(ModalContentGen)`
    border-radius: 1.5rem;
    width: 550px;
    height: 60vh;
    transition: opacity 0.4s, bottom 0.4s;
    margin: auto auto;
    @media (max-width: ${breakpointValues.sm}px) {
        width: 98.5%;
        position: fixed;
        bottom: 0;
        animation: ${({ show }) => (show ? fadeIn : fadeOut)} 1s ease;

        height: 40vh;
        border-radius: 0;
        margin-left: 0.5%;
        border: 1px solid #707070;
        border-top-right-radius: 30px;
        border-top-left-radius: 30px;
        box-shadow: 10px 10px 10px 10px #707070;
    }
`;

export const BackgroundModal = styled(BackgroundModalGen)<{ show: boolean | (() => void) }>`
    z-index: 10;
`;
export const Content = styled(ContentGen)`
    overflow: auto;
    ::-webkit-scrollbar {
        display: none;
    }
`;
