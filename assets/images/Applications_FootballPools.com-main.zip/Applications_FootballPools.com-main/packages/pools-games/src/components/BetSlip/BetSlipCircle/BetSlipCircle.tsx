import styled from 'styled-components';
import { breakpoints } from '@settings/breakpoints';

interface BetSlipCircleProps {
    selected?: string | number;
    selectedId?: number | undefined;
    isCurrentSelectedLine?: boolean;
    handleOnClick?: (id: number, displayId: string) => void;
    ballColor?: string;
    displayId?: boolean;
    isMobileBetslip?: boolean;
    isPick12Selection?: boolean;
}

export const BetSlipCircle: React.FC<BetSlipCircleProps> = props => {
    return (
        <StyledListItem
            onClick={(): void => {
                if (props.isCurrentSelectedLine && props.selected && props?.handleOnClick !== undefined) {
                    props?.handleOnClick(
                        props.selectedId as number,
                        props.displayId ? 'D' : (props.selected as string),
                    );
                }
            }}
            isCurrentSelectedLine={props.isCurrentSelectedLine}
            ballColor={props.ballColor}
            MultiLetter={typeof props.selected === 'string' && props.selected.length > 1}
            isPick12Selection={props.isPick12Selection}
        >
            {props.selected}
        </StyledListItem>
    );
};

type StyledListItemProps = {
    isCurrentSelectedLine?: boolean;
    ballColor?: string;
    MultiLetter?: boolean;
    isPick12Selection?: boolean;
};

const StyledListItem = styled.li<StyledListItemProps>`
    display: inline-block;
    margin: ${(props): string => (props.isPick12Selection ? '3px 0.5px' : '3px 1px')};
    text-align: center;
    border-radius: ${(props): string => (props.MultiLetter ? '12px' : '50%')};
    padding: 0;
    font-weight: bold;
    border: 2px solid #c2d3d7;
    width: ${(props): string => (props.MultiLetter ? '35px' : '20px')};
    height: 20px;
    line-height: 24px;
    font-size: 14px;
    display: flex;
    align-items: center;
    justify-content: center;

    ${breakpoints.below('lg')} {
        min-width: 30px;
        min-height: 30px;
        font-size: 20px;
    }
    ${breakpoints.below('sm')} {
        min-width: 27px;
        min-height: 27px;
        font-size: 18px;
    }
    ${breakpoints.below('s')} {
        min-width: 23px;
        min-height: 23px;
        font-size: 16px;
    }

    ${breakpoints.below('xs')} {
        min-width: 22px;
        min-height: 22px;
        font-size: 15px;
    }

    ${breakpoints.below('xxs')} {
        min-width: 21px;
        min-height: 21px;
        font-size: 14px;
    }

    &:not(:empty) {
        &.blank-ball {
            border-color: #fff;
            color: #fff;
            cursor: default;
        }
    }

    &:not(:empty) {
        background: ${(props): string => (props.ballColor ? props.ballColor : '#363636')};
        border-color: ${(props): string => (props.ballColor === '#fff' ? '#C2D3D6' : 'transparent')};
        color: ${(props): string =>
            props.ballColor === '#fff' ||
            props.ballColor === '#ffffff' ||
            props.ballColor === '#38d8ff' ||
            props.ballColor === '#E0AC00' ||
            props.ballColor === '#dbdbdb'
                ? '#000'
                : '#fff'};
        cursor: ${(props): string => (props.ballColor ? 'pointer' : 'default')};
    }
`;
