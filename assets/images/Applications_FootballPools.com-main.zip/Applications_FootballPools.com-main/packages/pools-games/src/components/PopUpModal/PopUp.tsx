import { Lucky4LifeLayout } from '@components/Lucky4LifeLayout';
import { PopUpBase, Backdrop } from './PopUp.styles';

export interface PopUpProps {
    show: boolean;
    close?: ((event: React.MouseEvent<HTMLButtonElement>) => null) | (() => void);
    title: string;
    previousText?: string;
    children: React.ReactNode;
}

/**
 * Lucky4LifeBetConfirmation props
 *  @param show Indicates if the pop up is showing or not
 *  @param close Function to close the pop up
 *  @param title Game name
 *  @param children children for pop up
 */

export const PopUpModal: React.FC<PopUpProps> = props => {
    return (
        <Backdrop show={props.show}>
            <PopUpBase>
                <Lucky4LifeLayout
                    onPreviousClick={props.close}
                    previousText={props.previousText ? props.previousText : 'Back'}
                    title={props.title ? props.title : 'Lucky4Life'}
                    isPopUp={true}
                    justify={'start'}
                >
                    {props.children}
                </Lucky4LifeLayout>
            </PopUpBase>
        </Backdrop>
    );
};
