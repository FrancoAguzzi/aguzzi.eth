import styled from 'styled-components';
import { breakpointValues } from '@settings/breakpoints';
import LeftArrow from 'public/svg/icon-left-arrow-white.svg';

export const OuterContainer = styled.div<{ justify?: string }>`
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    background-color: white;
    font-family: 'Montserrat', sans-serif !important;
    justify-content: ${({ justify }) => (justify ? justify : 'space-between')};
    -ms-overflow-style: none; /* IE and Edge */
    scrollbar-width: none; /* Firefox */
    ::-webkit-scrollbar {
        display: none;
    }
`;

export const TopBar = styled.div<{ isPopUp: boolean }>`
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    padding: 1rem;
    background-color: #1a8be9;
    color: white;
    align-items: center;
    font-weight: bold;
    font-size: 1.5rem;
    z-index: 1;
    position: sticky;
    top: 0;

    @media (min-width: ${breakpointValues.md}px) {
        padding: ${({ isPopUp }) => (isPopUp ? '' : '1rem 15%')};
        font-size: 1.5rem !important;
    }
    @media (max-width: ${breakpointValues.xs}px) {
        font-size: 11px;
        padding: 14px;
    }
`;

export const Arrow = styled(LeftArrow)`
    margin-right: 1rem;
`;

export const BackButton = styled.button<{ uppercase?: boolean }>`
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    font-size: 1rem;
    color: white;
    font-weight: bold;
    background-color: transparent;
    border: none;
    text-transform: ${({ uppercase }) => (uppercase ? 'uppercase' : 'none')};
    cursor: pointer;
    font-family: 'Montserrat', sans-serif;

    @media (max-width: ${breakpointValues.xs}px) {
        font-size: 11px;
        padding: 0px;
        svg {
            height: 15px;
            margin-right: 5px;
        }
    }
`;

export const NavBarTitle = styled.span<{ isPopUp: boolean }>`
    @media (min-width: ${breakpointValues.md}px) {
        display: ${({ isPopUp }) => (isPopUp ? 'block' : 'none')};
    }
`;
