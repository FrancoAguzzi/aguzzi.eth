import styled from 'styled-components';

import { breakpoints } from '@settings/breakpoints';
import { NumbersSelected, Scores } from '@sportech/pools-api';
import { HdaButton } from '../hda-button/HdaButton';
import React from 'react';
import { ResultsHDAMatchCard } from '@components/Results/ResultsSection/ResultsHDAMatchCard';

export interface MatchCardProp {
    /**
     * A label to show on the button
     */
    homeTeam: string;
    awayTeam: string;
    number: number;
    MatchID: number;
    IsHda: boolean;
    action?: (id: number, type: string) => void;
    numbers?: NumbersSelected | undefined;
    IsResults: boolean;
    Score?: Scores;
    Points?: number;
    matchCardWidth?: string;
    IsViewLines?: boolean;
}

export const HDAMatchCard: React.FC<MatchCardProp> = props => {
    return (
        <MatchCardDiv matchCardWidth={props.matchCardWidth}>
            {props.IsResults ? (
                <ResultsHDAMatchCard {...props} />
            ) : (
                <>
                    <MatchCardDivs>
                        <NumberDiv>{props.number}</NumberDiv>
                        <TeamsDiv>
                            <Rowone>
                                <HomeDiv>{props.homeTeam}</HomeDiv>
                                <VsDiv>V</VsDiv>
                                <AwayDiv>{props.awayTeam}</AwayDiv>
                            </Rowone>
                            <Rowtwo>
                                <MatchCardbuttonDiv>
                                    <HdaButton
                                        onClick={(): void => {
                                            if (props.action !== undefined) {
                                                props.action(props.number, 'H');
                                            }
                                        }}
                                        active={props.numbers?.selections.includes('H')}
                                        isViewLines={props.IsViewLines}
                                    >
                                        Home
                                    </HdaButton>
                                    <HdaButton
                                        onClick={(): void => {
                                            if (props.action !== undefined) {
                                                props.action(props.number, 'D');
                                            }
                                        }}
                                        active={props.numbers?.selections.includes('D')}
                                        isViewLines={props.IsViewLines}
                                    >
                                        Draw
                                    </HdaButton>
                                    <HdaButton
                                        onClick={(): void => {
                                            if (props.action !== undefined) {
                                                props.action(props.number, 'A');
                                            }
                                        }}
                                        active={props.numbers?.selections.includes('A')}
                                        isViewLines={props.IsViewLines}
                                    >
                                        Away
                                    </HdaButton>
                                </MatchCardbuttonDiv>
                            </Rowtwo>
                        </TeamsDiv>
                    </MatchCardDivs>
                </>
            )}
        </MatchCardDiv>
    );
};

type MatchCardDivProps = {
    matchCardWidth?: string;
};

const MatchCardDiv = styled.li<MatchCardDivProps>`
    width: ${(props): string => (props.matchCardWidth ? props.matchCardWidth : '48%')};
    margin: 0.5%;
    float: left;
    font-size: 12px;
    border: 1px solid transparent;
    height: 70px;
    border-radius: 5px;
    ${breakpoints.below('lg')} {
        width: 96%;
    }
`;

const MatchCardbuttonDiv = styled.div`
    display: flex;
    background: #fff;
    overflow: hidden;
    text-align: center;
    justify-content: center;
`;
const MatchCardDivs = styled.div`
    color: #011fb3;
    background-color: #fff;
    display: flex;
    height: 70px !important;
    width: 100%;
    border-radius: 5px;

    height: 42px;
    line-height: 42px;

    position: relative;
    z-index: 1;
    background: #fff;
    color: #000;
`;

const NumberDiv = styled.div`
    width: 50px;
    line-height: inherit;
    text-align: center;
    color: #000;
    background: #fff;
    position: relative;
    font-size: 30px;
    margin-left: 3px;
    height: 70px;
    display: flex;
    justify-content: center;
    align-items: center;

    :after {
        content: '';
        height: 75%;
        width: 1px;

        position: absolute;
        right: 0;
        top: 12.5%;

        background-color: #000; //
    }

    ${breakpoints.below('lg')} {
        width: 20%;
    }
`;

const TeamsDiv = styled.div`
    display: flex;
    flex-direction: column;
    width: 100%;
    justify-content: center;
    height: 70px;
    background: #fff;
    border-radius: 5px;
`;

const HomeDiv = styled.div`
    flex: 1;
    font-weight: 600;
    width: 40%;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    text-align: right;
    font-size: 15px;
`;

const VsDiv = styled.div`
    width: 1.5em;
    text-align: center;
    font-weight: 600;
    font-size: 0.8em;
    color: #000;
    font-size: 15px;
`;
const AwayDiv = styled.div`
    font-weight: 600;
    width: 40%;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    flex: 1;
    font-size: 15px;
`;

const Rowone = styled.div`
    flex: 1;
    display: flex;
    flex-direction: row;
    max-height: 30px;
    align-items: center;
`;

const Rowtwo = styled.div`
    flex: 1;
`;
