import styled from 'styled-components';
import { FunctionComponent, useState } from 'react';
import { CompetitionResult } from '@sportech/pools-api';
import { format } from 'date-fns';
import DateRange from 'public/svg/date_range.svg';
import { RemoveSoccer6Name } from '@src/utils/functionUtils';
import { GameModel } from '@interfaces/PoolGames/GameModel';

export interface ResultsCompetitionSelectorProp {
    competitions: CompetitionResult[];
    CurrentCompetition: CompetitionResult;
    ChangeCompetitions: (id: number) => void;
    gameModel: GameModel;
}

export const ResultsCompetitionSelector: FunctionComponent<ResultsCompetitionSelectorProp> = props => {
    const [isOpen, setIsOpen] = useState(false);
    const SelectOption = (event: number): void => {
        setIsOpen(false);
        props.ChangeCompetitions(event);
    };
    return (
        <DropDownContainer>
            <DropDownHeader
                onClick={(): void => {
                    setIsOpen(!isOpen);
                }}
            >
                <span>
                    {RemoveSoccer6Name(props.CurrentCompetition.description)} -{' '}
                    {format(new Date(props.CurrentCompetition.datumDate), 'dd/MM/yyyy HH:mm')}
                </span>
                <FloatRightDiv>
                    <DateRange />
                </FloatRightDiv>
            </DropDownHeader>
            {isOpen && (
                <DropDownListContainer>
                    <DropDownList>
                        {props.competitions.map((comp, index) => (
                            <ListItem
                                onClick={(): void => {
                                    props.gameModel.isClover() ? SelectOption(comp.number) : SelectOption(comp.id);
                                }}
                                key={index}
                                value={comp.id}
                            >
                                {RemoveSoccer6Name(comp.description)} -{' '}
                                {format(new Date(comp.datumDate), 'dd/MM/yyyy HH:mm')}
                            </ListItem>
                        ))}
                    </DropDownList>
                </DropDownListContainer>
            )}
        </DropDownContainer>
    );
};

const DropDownContainer = styled.div`
    padding-top: 10px;
    background: white;
`;

const DropDownHeader = styled.div`
    padding: 0.4em 0 0.4em 0;
    font-weight: 500;
    font-size: 1.3rem;
    color: #fff;
    background: ${(props): string => props.theme.colours.gameMainColor};
    width: 100%;
    cursor: pointer;
    > span {
        margin-right: -30px;
    }
`;
const FloatRightDiv = styled.div`
    float: right;

    svg {
        padding-right: 10px;
        fill: #fff;
    }
`;

const DropDownListContainer = styled.div`
    position: relative;
`;

const DropDownList = styled.div`
    position: absolute;
    z-index: 300;
    padding: 0;
    margin: 0;
    height: 200px;
    overflow: scroll;
    background: #eaeaea;
    box-sizing: border-box;
    color: #000;
    font-size: 1.3rem;
    font-weight: 500;
    width: 100%;
    &:first-child {
        padding-top: 0.8em;
    }
`;

const ListItem = styled.li`
    list-style: none;
    margin-bottom: 0.8em;
    cursor: pointer;
`;
