import { Circle } from './circle';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';

describe('Circle Component', () => {
    // Test should render
    it('should render', () => {
        const { container } = render(
            <Circle
                selected={12}
                displayId={false}
                isCurrentSelectedLine={false}
                isSelected={true}
                handleOnClick={() => null}
                isInLine={false}
            />,
        );
        expect(container).toMatchSnapshot();
        expect(container).toBeInTheDocument();
        expect(container).toHaveTextContent('12');
    });
});
