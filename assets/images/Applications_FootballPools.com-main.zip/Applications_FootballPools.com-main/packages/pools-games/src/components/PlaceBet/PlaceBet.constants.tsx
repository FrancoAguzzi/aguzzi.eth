//Title of the first part of the component
export const PICK_YOUR_DAYS = 'Pick your days';

//Title of the second part of the component
export const NUMBER_OF_WEEKS = 'Number of weeks?';

//Days of the first options of the component, this information was provide by the client
export const DAYS = [
    { day: 'Mon', value: 'MON' },
    { day: 'Thu', value: 'THUR' },
    { day: 'Sat', value: 'SAT' },
    { day: 'Sun', value: 'SUN' },
];

//Weeks of the second part of the component
export const WEEKS = [
    [
        { week: '1', value: 'ONE' },
        { week: '2', value: 'TWO' },
        { week: '3', value: 'THREE' },
        { week: '4', value: 'FOUR' },
        { week: '5', value: 'FIVE' },
        { week: '6', value: 'SIX' },
    ],
    [
        { week: '7', value: 'SEVEN' },
        { week: '8', value: 'EIGTH' },
        { week: '9', value: 'NINE' },
        { week: '10', value: 'TEN' },
        { week: '26', value: 'TWENTY_SIX' },
        { week: '52', value: 'FIFTY_TWO' },
    ],
];

export const ARRAYOFWEEKS = [
    { week: '1', value: 'ONE' },
    { week: '2', value: 'TWO' },
    { week: '3', value: 'THREE' },
    { week: '4', value: 'FOUR' },
    { week: '5', value: 'FIVE' },
    { week: '6', value: 'SIX' },
    { week: '7', value: 'SEVEN' },
    { week: '8', value: 'EIGTH' },
    { week: '9', value: 'NINE' },
    { week: '10', value: 'TEN' },
    { week: '26', value: 'TWENTY_SIX' },
    { week: '52', value: 'FIFTY_TWO' },
];

//Colors of the bottons
export const BG_COLOR = '#188BE9';
export const BG_WHITE_COLOR = '#FFFFFF';
export const GRAY_COLOR = '#303030';
export const BORDER_BLACK_COLOR = '1px solid #303030';
export const BORDER_BLUE_COLOR = `1px solid ${BG_COLOR}`;
