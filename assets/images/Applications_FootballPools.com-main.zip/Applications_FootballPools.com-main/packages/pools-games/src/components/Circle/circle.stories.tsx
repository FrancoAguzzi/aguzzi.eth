import { ComponentStory, ComponentMeta } from '@storybook/react';
import { Circle } from './circle';

export default {
    title: 'Components/Circle',
    component: Circle,
} as ComponentMeta<typeof Circle>;

export const CircleSelected: ComponentStory<typeof Circle> = () => (
    <Circle
        isCurrentSelectedLine={false}
        selected={12}
        displayId={false}
        area={200}
        fontSize={'25px'}
        isSelected={true}
        handleOnClick={() => null}
        id={'1'}
        isInLine={false}
    />
);
export const CircleNotSelected: ComponentStory<typeof Circle> = () => (
    <Circle
        isCurrentSelectedLine={true}
        selected={12}
        displayId={false}
        area={200}
        fontSize={'14px'}
        isSelected={false}
        handleOnClick={() => null}
        id={'1'}
        isInLine={false}
    />
);
