import { breakpointValues } from '@settings/breakpoints';
import styled, { keyframes } from 'styled-components';
import { Title as TitleBase } from '@src/base-styles';
import { ButtonXGen, ModalContentGen, ContentGen } from '@src/base-styles';

/* Animation to fade in modal */
export const fadeIn = keyframes`
    from {
        bottom: -1200px;
        transition: all 1.25s ease;
    }

    to {
        bottom: 0;
    }
`;

/* Animation to fade out modal */
export const fadeOut = keyframes`
    from {
        bottom: 0;
    }

    to {
        bottom: -1200px;
        transition: all .75s ease;
    }
`;

export const ButtonX = styled(ButtonXGen)`
    margin-top: 0.8rem;
    height: 1px;
    width: 50px;
    @media (max-width: ${breakpointValues.xs}px) {
        // margin-left: 2.5rem;
    }
`;

export const ModalHandle = styled.div`
    -webkit-overflow-scrolling: touch;
    background-color: #fff;
    justify-content: center;
    align-items: center;
    transition: 0s;
`;

export const ModalContent = styled(ModalContentGen)<{ show: boolean | (() => void) }>`
    display: ${({ show }) => (show ? 'flex' : 'none')};
    flex-direction: column;
    background-color: white;
    border-top-right-radius: 30px;
    border-top-left-radius: 30px;
    border-bottom-right-radius: 30px;
    border-bottom-left-radius: 30px;
    box-shadow: 2px 2px 2px #707070;

    z-index: 5;
    height: calc(100% - 63px);
    width: 100%;
    position: absolute;
    bottom: 0;
    animation: ${({ show }) => (show ? fadeIn : fadeOut)} 1s ease;
    border-radius: 0;
    border: 1px solid #707070;
    border-top-right-radius: 30px;
    border-top-left-radius: 30px;
    box-shadow: 10px 10px 10px 10px #707070;
    @media (max-width: ${breakpointValues.xs}px) {
        height: calc(100% - 45px);
    }
`;

export const Content = styled(ContentGen)`
    margin: 0;
    padding: 0;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
`;

export const Title = styled(TitleBase)`
    margin: 1rem;
    @media (max-width: 375px) {
        // margin-top: 1rem;
    }
`;
