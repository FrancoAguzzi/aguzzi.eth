import styled from 'styled-components';
import { FunctionComponent, useState } from 'react';
import { ArrowButton } from '@components/Common/ArrowButton/ArrowButton';
import { ExpandedWagerItem } from './ExpandedWagerItem';
import { Offering, CompetitionDividends, CompetitionResults, Wager, CompetitionResult } from '@sportech/pools-api';
import { DateTimeFormatter } from '@components/Common/DateTimeFormatter/DateTimeFormatter';
import '@src/utils/extensionMethods';
import { arrayOfCompetitionIds } from '@src/utils/functionUtils';
import { GameModel } from '@interfaces/PoolGames/GameModel';

interface WagerItemProps {
    wager: Wager[];
    offering: Offering[];
    comp: CompetitionResults;
    dividends: CompetitionDividends;
    gameModel: GameModel;
}

const StyledWagerItem = styled.li`
    display: flex;
    flex-flow: wrap;
    justify-content: space-between;
    border-top: 1px solid #333;
    cursor: pointer;
    p {
        flex: 1 1 25%;
    }
`;

type StyledArrowProps = {
    isWagerExpanded: boolean;
};

const StyledArrowButton = styled(ArrowButton)<StyledArrowProps>`
    ${(props): string | undefined => {
        if (props.isWagerExpanded) {
            return ` transform: rotate(90deg);
            margin-top: 10px;
            `;
        }
    }}
    transition: transform 0.15s linear;
`;

export const WagerItem: FunctionComponent<WagerItemProps> = props => {
    const [isWagerItemExpanded, setExpandWagerItem] = useState(false);
    const [showFixtures, setShowFixtures] = useState(false);
    const totalCostOfWagerItem = props.wager.reduce((total, wager) => {
        return (
            total +
            (props.gameModel.isClover() && wager.bonusPaidCost !== undefined
                ? (wager.paidCost as number) + (wager.bonusPaidCost as number)
                : (wager.paidCost as number))
        );
    }, 0);

    const totalWinAmountOfMultipleWagers = props.wager.reduce((total, wager) => {
        return total + (wager.winAmount as number);
    }, 0);

    return (
        <>
            {props.wager !== undefined &&
                props.wager.length > 0 &&
                (props.wager.length > 1 ? (
                    <StyledWagerItem
                        onClick={(): void => {
                            setExpandWagerItem(!isWagerItemExpanded);
                            setShowFixtures(false);
                        }}
                    >
                        <StyledArrowButton
                            isWagerExpanded={isWagerItemExpanded}
                            isFacingLeft={false}
                            color={'#c1c1c1'}
                            backgroundColor={'#F5F5F5'}
                        />
                        <p>
                            <DateTimeFormatter
                                Format={'dd/MM/yyyy HH:mm:ss'}
                                Input={new Date(props.wager[0].createdAt + 'Z')}
                            />
                        </p>
                        <p>£{(totalCostOfWagerItem / 100).toLocaleStringCash()}</p>
                        <p>
                            {totalWinAmountOfMultipleWagers === 0
                                ? '£0.00'
                                : '£' + (totalWinAmountOfMultipleWagers / 100).toLocaleStringCash()}
                        </p>
                        {props.wager.map((item, index) => {
                            return (
                                isWagerItemExpanded && (
                                    <ExpandedWagerItem
                                        gameModel={props.gameModel}
                                        wager={item}
                                        offering={
                                            props.gameModel.isClover()
                                                ? props.offering.filter(x => x.id === item.offeringId)[0]
                                                : props.offering.filter(x => x.id === item.offeringId)[0]
                                        }
                                        comp={
                                            props.gameModel.isClover()
                                                ? (props.comp?.find(x =>
                                                      arrayOfCompetitionIds(
                                                          x.competitionIds as {
                                                              [key: string]: number;
                                                          },
                                                      ).includes(item.competitionId as number),
                                                  ) as CompetitionResult)
                                                : (props.comp?.find(
                                                      x => x.id === item.competitionId,
                                                  ) as CompetitionResult)
                                        }
                                        dividends={
                                            props.dividends.filter(x => x.competitionId === item.competitionId)[0]
                                        }
                                        result={
                                            item.winAmount === 0
                                                ? '£0.00'
                                                : '£' + ((item.winAmount as number) / 100).toLocaleStringCash()
                                        }
                                        isFirstWager={index === 0}
                                        hasMulitpleWagers={props.wager.length > 1}
                                        showFixtures={showFixtures}
                                        key={index}
                                        setShowFixtures={setShowFixtures}
                                    ></ExpandedWagerItem>
                                )
                            );
                        })}
                    </StyledWagerItem>
                ) : (
                    <StyledWagerItem
                        onClick={(): void => {
                            setExpandWagerItem(!isWagerItemExpanded);
                            setShowFixtures(false);
                        }}
                    >
                        <StyledArrowButton
                            isWagerExpanded={isWagerItemExpanded}
                            isFacingLeft={false}
                            color={'#c1c1c1'}
                            backgroundColor={'#F5F5F5'}
                        />
                        <p>
                            <DateTimeFormatter
                                Format={'dd/MM/yyyy HH:mm:ss'}
                                Input={new Date(props.wager[0].createdAt + 'Z')}
                            />
                        </p>
                        <p>£{(totalCostOfWagerItem / 100).toLocaleStringCash()}</p>
                        <p>
                            {props.wager[0].winAmount === 0
                                ? '£0.00'
                                : '£' + ((props.wager[0].winAmount as number) / 100).toLocaleStringCash()}
                        </p>
                        {isWagerItemExpanded && (
                            <ExpandedWagerItem
                                gameModel={props.gameModel}
                                wager={props.wager[0]}
                                offering={props.offering.filter(x => x.id === props.wager[0].offeringId)[0]}
                                comp={
                                    props.gameModel.isClover()
                                        ? (props.comp?.find(x =>
                                              arrayOfCompetitionIds(
                                                  x.competitionIds as {
                                                      [key: string]: number;
                                                  },
                                              ).includes(props.wager[0].competitionId as number),
                                          ) as CompetitionResult)
                                        : (props.comp?.find(
                                              x => x.id === props.wager[0].competitionId,
                                          ) as CompetitionResult)
                                }
                                dividends={
                                    props.dividends.filter(x => x.competitionId === props.wager[0].competitionId)[0]
                                }
                                result={
                                    props.wager[0].winAmount === 0
                                        ? '£0.00'
                                        : '£' + ((props.wager[0].winAmount as number) / 100).toLocaleStringCash()
                                }
                                showFixtures={showFixtures}
                                setShowFixtures={setShowFixtures}
                                isFirstWager={true}
                            ></ExpandedWagerItem>
                        )}
                    </StyledWagerItem>
                ))}
        </>
    );
};
