import styled from 'styled-components';
import { ContainerCircles } from '@src/base-styles';
import { breakpointValues } from '@settings/breakpoints';

type StyledListItemProps = {
    area?: number;
    fontSize?: string;
    margin?: string;
};
export const Container = styled(ContainerCircles)<StyledListItemProps>`
    @media (max-width: ${breakpointValues.xs}px) {
        width: 30px;
        height: 30px;
        svg {
            width: 21px;
        }
        margin: 0 -3px 0 3px;
    }
`;

export const StyledListItem = styled.div<StyledListItemProps>`
    border: 1px solid #c2d3d7;
    width: 100%;
    height: 100%;
    border-radius: 20%;
    text-align: center;
    padding: 0;
    font-weight: 600;
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #188be9;
    color: #fff;
    &:not(:empty) {
        &.blank-ball {
            border-color: #188be9;
            color: #fff;
        }
    }
    cursor: pointer;
    @media (max-width: ${breakpointValues.xs}px) {
        border-radius: 28%;
    }
`;
