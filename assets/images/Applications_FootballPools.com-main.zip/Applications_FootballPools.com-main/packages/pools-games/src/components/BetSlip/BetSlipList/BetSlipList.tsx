import styled from 'styled-components';
import { Button } from '@components/Common/Button/Button';
import BetSlipItem from '../BetSlipItem/BetSlipItem';
import { BetSlip, Offerings, Competition, Offering, Wager } from '@sportech/pools-api';
import { ViewLines } from '../ViewLines/ViewLines';
import { useRef, useEffect, FunctionComponent } from 'react';
import { useRouter } from 'next/router';
import { ExternalLink } from '@components/Common/ExternalLink/ExternalLink';
import { getTotalPrice, getTotalLines, isPlayButtonDisabled } from '@src/utils/functionUtils';
import '@src/utils/extensionMethods';
import { closePopup, openPopup } from '@features/popups/popupsSlice';
import { useDispatch } from 'react-redux';
import { GameModel } from '@interfaces/PoolGames/GameModel';
import { useUser } from '@auth0/nextjs-auth0';

interface BetSlipListProps {
    betslipselection: Array<BetSlip>;
    SelectAmountAction: (id: number, amount: Offering) => void;
    ClearLine: (index?: number | undefined) => void;
    AddLine: () => void;
    ChangeBet: (index: number) => void;
    offers: Offerings;
    gameModel: GameModel;
    handleCircleNumberClick: (id: number, type: string) => void;
    setCurrentOfferingId: (val: number) => void;
    setShowMore: (val: boolean) => void;
    currentOfferingId: number;
    showMoreValue: boolean;
    competitions: Competition[];
    showWagers: boolean;
    setShowWagers: (val: boolean) => void;
    wagers?: Wager[];
    setViewLinesCurrent: (val: number) => void;
    viewLinesCurrent: number;
    pressPlay: () => void;
}

export const BetSlipList: FunctionComponent<BetSlipListProps> = ({ gameModel, ...props }) => {
    const { user } = useUser();
    const router = useRouter();
    const dispatch = useDispatch();
    const lines = getTotalLines(gameModel.isHDA(), props.betslipselection);
    const totalPricenumber = getTotalPrice(gameModel.isHDA(), gameModel.isClover(), props.betslipselection);
    const totalPrice = totalPricenumber.toLocaleStringCash();

    const betslipCurrentSelection = props.betslipselection.find(x => x.current);

    const childBetSlipItemRef = useRef<HTMLDivElement>(null);
    const scrollToCurrentLine = (): void => {
        if (childBetSlipItemRef.current !== null) {
            childBetSlipItemRef.current.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
            });
        }
    };
    let playButtonPressed = false;

    const onPlayButtonClick = (): void => {
        if (!playButtonPressed) {
            if (gameModel.isClover() && props.betslipselection.filter(x => x.bonusNumbers.length === 0).length > 0) {
                dispatch(closePopup('payment'));
                dispatch(openPopup('lucky_clover_no_bonus_selected'));
            } else {
                playButtonPressed = true;
                props.pressPlay();
            }
        }
    };
    useEffect(() => {
        scrollToCurrentLine();
    }, [props.betslipselection.length]);

    return (
        <>
            <Button
                onClick={(): void => props.setShowWagers(false)}
                rounded={user !== null ? '5px 0px 0px 0px' : '5px 5px 0px 0px'}
                width={user !== null ? '50%' : '100%'}
                bgColor={props.showWagers ? '#fff' : '#F5F5F5'}
                textColor={'#000'}
                noHover={user !== null ? false : true}
                cursor={'default'}
            >
                Buy New Lines
            </Button>
            {user !== null && (
                <Button
                    onClick={(): void => {
                        props.setShowWagers(true);
                    }}
                    rounded={'0px 10px 0px 0px'}
                    width={'50%'}
                    bgColor={props.showWagers ? '#F5F5F5' : '#fff'}
                    textColor={'#000'}
                >
                    View Your Lines
                </Button>
            )}
            <StyledListScroll>
                {!props.showWagers ? (
                    props.betslipselection.map((item, index) => (
                        <BetSlipItem
                            ref={childBetSlipItemRef}
                            ChangeBet={(): void => props.ChangeBet(index)}
                            SelectAmountAction={props.SelectAmountAction}
                            ClearLine={props.ClearLine}
                            AddLine={props.AddLine}
                            key={index}
                            offers={props.offers}
                            betslipselection={item}
                            betslipCurrentSelection={betslipCurrentSelection as BetSlip}
                            moreThanOneLine={props.betslipselection.length > 1}
                            handleCircleNumberClick={props.handleCircleNumberClick}
                            setCurrentOfferingId={props.setCurrentOfferingId}
                            currentOfferingId={props.currentOfferingId}
                            setShowMore={props.setShowMore}
                            showMoreValue={props.showMoreValue}
                            competition={
                                props.competitions.find(
                                    x => x.id === betslipCurrentSelection?.competitionId,
                                ) as Competition
                            }
                            gameModel={gameModel}
                        ></BetSlipItem>
                    ))
                ) : (
                    <>
                        <ViewLines
                            competitions={props.competitions}
                            offers={props.offers}
                            gameModel={gameModel}
                            wagers={props.wagers}
                            setViewLinesCurrent={props.setViewLinesCurrent}
                            viewLinesCurrent={props.viewLinesCurrent}
                        ></ViewLines>
                    </>
                )}
            </StyledListScroll>
            {!props.showWagers && (
                <BuyLines>
                    <TotalLines>Total Lines: {lines}</TotalLines>
                    <Price>£{totalPrice}</Price>

                    <Play>
                        <Button
                            disabled={isPlayButtonDisabled(props.betslipselection)}
                            onClick={(): void => {
                                if (user === null || user === undefined) {
                                    router.push('/api/auth/login');
                                } else {
                                    onPlayButtonClick();
                                }
                            }}
                            width={'100%'}
                            bgColor={'#0C9D00'}
                            height={'auto'}
                            padding={'0.75em 1.25em'}
                        >
                            PLAY
                        </Button>
                    </Play>

                    <TermsContainer>
                        <DivTermsSidebar href={`/content/${gameModel.name}-game-rules/`}>
                            View Game Terms &amp; Conditions
                        </DivTermsSidebar>
                    </TermsContainer>
                </BuyLines>
            )}
        </>
    );
};

const TermsContainer = styled.div`
    width: 100%;
    text-align: center;
`;

const DivTermsSidebar = styled(ExternalLink)`
    line-height: 2;
    margin-top: 5px;
    font-size: 0.6em;
    color: #000;
    width: 60%;
    margin-right: 9px;
    cursor: pointer;
    text-decoration: none;
    :hover {
        text-decoration: underline;
    }
`;

const StyledListScroll = styled.div`
    max-height: calc(90vh - 300px);
    overflow-y: scroll;
    overflow-x: hidden;
    min-height: 210px;
`;

const BuyLines = styled.div`
    background: #f5f5f5;
    margin: 0;
    padding: 10px;
    color: #000;
`;

const TotalLines = styled.div`
    cursor: default;
    margin: 10px 0;
    font-size: 0.9em;
    float: left;
`;

const Price = styled.div`
    cursor: default;
    font-size: 1.7em;
    font-weight: 500;
    line-height: 1.5em;
    float: right;
`;

const Play = styled.div`
    display: inline-block;
    width: 100%;
`;
