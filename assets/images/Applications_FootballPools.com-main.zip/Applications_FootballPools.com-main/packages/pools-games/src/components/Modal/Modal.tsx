import { useEffect, useState } from 'react';
import { Container } from '@containers/Lucky4Life/container';
import {
    Button,
    ButtonRight,
    ButtonX,
    MoveContentMobile,
    MoveContent,
    ModalContent,
    BackgroundModal,
    Content,
} from './Modal.styles';
import { breakpointValues } from '@settings/breakpoints';
import { screenYInitial, screenYpercentage, screenYpercentageInitial } from './Modal.constanst';
import { Title } from '@src/base-styles';

/**
 * Modal props
 *  @param show boolean to know if the modal is show or not.
 *  @param title Title which is shown in the top modal.
 *  @param close handle to close modal.
 *  @param children children info component.
 *  @param setShowHowToPlay Modifier for show modal.
 *  @param heightModalInitial Modal height initial.
 *  @param direction: direction flex type for title;
 *  @param align: align type for title;
 *  @param justify: justiry type for title;
 */
interface Props {
    show: boolean;
    title: string;
    children?: React.ReactNode;
    close: () => void;
    heightModalInitial: number;
    font: fontType;
    align: alignType;
    justify: justifyType;
    heigthDesktop?: number | undefined;
}

export type fontType = '100' | 'bold';
export type alignType = 'start' | 'center' | 'end';
export type justifyType = 'start' | 'center' | 'end' | 'space-between' | 'space-around';

export const Modal = ({
    show,
    close,
    children,
    title,
    heightModalInitial,
    font,
    align,
    justify,
    heigthDesktop,
}: Props): JSX.Element => {
    /* Mobile data for responsive mobile view */
    const [isMobile, setIsMobile] = useState(window.innerWidth <= breakpointValues.sm);
    const handleResize = (): void => {
        setIsMobile(window.innerWidth <= breakpointValues.sm);
    };
    let device;
    const height = screen.height;
    if (
        navigator.userAgent.match(/Android/i) ||
        navigator.userAgent.match(/iPhone/i) ||
        navigator.userAgent.match(/webOS/i) ||
        navigator.userAgent.match(/iPad/i) ||
        navigator.userAgent.match(/iPod/i) ||
        navigator.userAgent.match(/BlackBerry/i) ||
        navigator.userAgent.match(/Windows Phone/i)
    )
        device = 'phone';

    useEffect(() => {
        window.addEventListener('resize', handleResize, false);

        return () => window.removeEventListener('resize', handleResize, false);
    }, []);

    // Animation
    const [initPosition, setInitPosition] = useState<number>(0);
    const [dinamicHeight, setDinamicHeight] = useState<number>(heightModalInitial);
    const [transitionDelay, setTransitionDelay] = useState<string>('0s');

    /* function to dragEnd event start */
    function handleDrag(e: { clientY: number }) {
        if (e.clientY !== 0) {
            setTransitionDelay('0s');
            setDinamicHeight(heightModalInitial + (initPosition - e.clientY));
        }
    }

    /* function to dragEnd event ends */
    function handleDragEnd(e: { screenY: number }) {
        setTransitionDelay('0.5s');
        if (e.screenY > initPosition * screenYInitial) {
            setDinamicHeight(heightModalInitial);
        } else {
            setDinamicHeight(heightModalInitial);
        }
        if (e.screenY > height * screenYpercentageInitial) setTimeout(close, 100);
    }

    /* useEffect for the position top of the div move*/
    useEffect(() => {
        setTimeout(() => {
            const element = document.getElementById('content');
            setInitPosition(element?.getBoundingClientRect().top ? element?.getBoundingClientRect().top : 0);
        }, 1000);

        const box = document.getElementById('content');
        if (box && isMobile) {
            box.style.height = heightModalInitial + 'px';
            /* Function for the touch screen mobile move*/
            box?.addEventListener('touchmove', e => {
                // grab the location of touch
                e.stopPropagation();
                e.preventDefault();
                const touchLocation = e.changedTouches[0].clientY;

                // assign box new coordinates based on the touch.
                box.style.height = heightModalInitial * screenYInitial + (initPosition - touchLocation) + 'px';
                setDinamicHeight(heightModalInitial * screenYInitial + (initPosition - touchLocation));
            });
            /* Function for the touch screen mobile move*/
            box?.addEventListener('touchend', e => {
                e.stopPropagation();
                e.preventDefault();

                const touchLocation = e.changedTouches[0].clientY;

                // current box position.
                if (touchLocation > initPosition * screenYInitial) {
                    setDinamicHeight(heightModalInitial);
                    box.style.height = heightModalInitial + 'px';
                } else {
                    setDinamicHeight(heightModalInitial);
                    box.style.height = heightModalInitial + 'px';
                }
                if (touchLocation > height * screenYpercentage) {
                    close();
                    setDinamicHeight(heightModalInitial);
                }

                setTransitionDelay('0.5s');
            });
        }
    }, [show]);
    return (
        <>
            {isMobile ? (
                <ModalContent
                    style={{
                        height: dinamicHeight,
                        transition: transitionDelay,
                    }}
                    show={show}
                    id="content"
                >
                    <Container direction={'column'} align={'center'} justify={'space-between'} width={'90%'}>
                        {device === 'phone' ? (
                            <MoveContentMobile
                                draggable
                                height={dinamicHeight}
                                transition={transitionDelay}
                                onDrag={handleDrag}
                                onDragEnd={handleDragEnd}
                            >
                                <ButtonX></ButtonX>
                            </MoveContentMobile>
                        ) : (
                            <MoveContent
                                draggable
                                onDrag={handleDrag}
                                onDragEnd={handleDragEnd}
                                height={dinamicHeight}
                                transition={transitionDelay}
                            >
                                <ButtonX></ButtonX>
                            </MoveContent>
                        )}
                    </Container>
                    <Title font={font} align={align} justify={justify}>
                        {title}
                    </Title>
                    <Content>{children}</Content>
                </ModalContent>
            ) : (
                <BackgroundModal show={show}>
                    <ModalContent
                        style={{
                            height: heigthDesktop ?? 550,
                            transition: transitionDelay,
                        }}
                        show={show}
                        id="content"
                    >
                        <ButtonRight>
                            <Button onClick={() => close()}>x</Button>
                        </ButtonRight>
                        <Title font={font} align={align} justify={justify}>
                            {title}
                        </Title>
                        <Content>{children}</Content>
                    </ModalContent>
                </BackgroundModal>
            )}
        </>
    );
};
