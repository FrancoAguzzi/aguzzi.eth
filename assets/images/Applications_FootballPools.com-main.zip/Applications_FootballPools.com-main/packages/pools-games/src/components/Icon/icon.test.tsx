import { Icon } from './icon';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';

describe('Icon Component', () => {
    // Test should render
    it('should render', () => {
        const { container } = render(
            <Icon area={200} onClick={() => null} id={0}>
                12
            </Icon>,
        );
        expect(container).toMatchSnapshot();
        expect(container).toBeInTheDocument();
        expect(container).toHaveTextContent('12');
    });
});
