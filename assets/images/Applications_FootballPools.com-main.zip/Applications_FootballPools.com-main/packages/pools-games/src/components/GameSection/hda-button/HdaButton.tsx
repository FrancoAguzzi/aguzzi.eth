import styled from 'styled-components';
import { ButtonHTMLAttributes } from 'react';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    /**
     * A label to show on the button
     */
    active?: boolean;
    bgcolor?: string;
    isResults?: boolean;
    isViewLines?: boolean;
    hasNotStarted?: boolean;
}

export const HdaButton: React.FC<ButtonProps> = props => {
    return <Button {...props}></Button>;
};

const Button = styled.button<ButtonProps>`
    border: ${(props): string => (props.hasNotStarted ? '2px solid #c3d3d7' : '0')};
    outline: 0;
    display: inline-block;

    text-align: center;
    vertical-align: middle;
    text-shadow: 0 1px 5px rgba(0, 0, 0, 0.15);
    user-select: none;
    text-shadow: none;
    border-radius: 10px;
    flex: 1;
    margin-right: 5px;
    text-transform: uppercase;
    padding: 0.7em 1.09em;
    max-width: 30%;
    font: 400 17.3333px;
    background: ${(props): string =>
        props.active === true ? (props.bgcolor ? props.bgcolor : props.theme.colours.gameMainColor) : 'black'};
    color: ${(props): string => (props.active === true && props.hasNotStarted ? 'black' : 'white')};

    ${(props): string | undefined => {
        if (!props.isViewLines) {
            return `
            &:hover {
                cursor: pointer;
            }
        `;
        }
    }}

    ${(props): string | undefined => {
        if (!props.active && !props.isResults && !props.isViewLines) {
            return `
                &:hover {
                background-color: rgb(54, 54, 54);
            }
            `;
        }
    }}
`;
