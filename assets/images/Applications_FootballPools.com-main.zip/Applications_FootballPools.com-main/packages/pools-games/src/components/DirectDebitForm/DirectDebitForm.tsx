import styled from 'styled-components';
import { useForm } from 'react-hook-form';
import { useDispatch } from 'react-redux';
import { confirmWagers, ConfirmWagers } from '@sportech/pools-api';
import { getTotalPrice } from '@src/utils/functionUtils';

interface DirectDebitFormProps {
    accountNumber: string;
    sortCode: string;
}

const Container = styled.div`
    flex: 1;
`;
const FormContainer = styled.form`
    flex: 1;
    flex-direction: column;
`;

const Row1 = styled.div`
    margin-bottom: 5px;
`;

const Row2 = styled.div`
    margin-bottom: 5px;
`;

const Row3 = styled.div``;

const DirecDebitForm: React.FC = () => {
    const { register, handleSubmit, errors } = useForm<DirectDebitFormProps>();

    const dispatch = useDispatch();

    const onSubmit = handleSubmit(data => {
        console.log(data);
        const confirmData: ConfirmWagers = {
            directDebitDetails: {
                accountNumber: data.accountNumber,
                sortCode: data.sortCode,
            },
        };
        // dispatch(confirmWagers(confirmData, 'classic-pools', getTotalPrice(isHdaGame)));
    });

    return (
        <Container>
            <FormContainer onSubmit={onSubmit}>
                <Row1>
                    <label>SORT CODE</label>
                    <input
                        name="sortCode"
                        ref={register({
                            required: {
                                value: true,
                                message: 'This is required',
                            },
                            pattern: { value: /[0-9]{6}/, message: '' },
                        })}
                    />
                    {errors.sortCode && 'Must be 6 numbers'}
                </Row1>
                <Row2>
                    <label>BANK ACCOUNT NUMBER</label>
                    <input
                        name="accountNumber"
                        ref={register({
                            required: {
                                value: true,
                                message: 'This is required',
                            },
                            pattern: { value: /[0-9]{8}/, message: '' },
                        })}
                    />
                    {errors.accountNumber && 'Must be 8 numbers'}
                </Row2>

                <Row3>
                    <input type="submit" />
                </Row3>
            </FormContainer>
        </Container>
    );
};

export default DirecDebitForm;
