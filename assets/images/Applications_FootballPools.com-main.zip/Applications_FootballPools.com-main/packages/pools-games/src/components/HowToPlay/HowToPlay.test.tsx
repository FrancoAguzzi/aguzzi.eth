import { HowToPlay } from './HowToPlay';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';

describe('How to play Component', () => {
    // Test should render
    it('should render', () => {
        const { container } = render(
            <HowToPlay
                show={false}
                close={() => null}
                heightModalInitial={0.8}
                HowToPlayContent={'How to play instructions...'}
                HowToPlayTitle={'How To Play'}
            />,
        );

        expect(container).toMatchSnapshot();
    });
});
