import { ComponentStory, ComponentMeta } from '@storybook/react';
import { BetSlip } from './betslip';

export default {
    title: 'Components/BetSlip',
    component: BetSlip,
} as ComponentMeta<typeof BetSlip>;

export const BetSlipComponent: ComponentStory<typeof BetSlip> = () => (
    <BetSlip
        onClick={() => console.log('hola')}
        name={'Number of lines:'}
        lines={1}
        total={1.0}
        gameDays={[]}
        isShowingPicker={true}
        isMobile={false}
        widthScreen={1}
    >
        BetSlip
    </BetSlip>
);
