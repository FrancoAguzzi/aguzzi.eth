import { useDispatch } from 'react-redux';
import { closePopup } from '@features/popups/popupsSlice';
import getConfig from 'next/config';
import { useRouter } from 'next/router';
import { Button } from '@components/Common/Button/Button';
import { ExternalLink } from '@components/Common/ExternalLink/ExternalLink';

export const MissingAddressMessage = () => {
    const dispatch = useDispatch();
    const { publicRuntimeConfig } = getConfig();
    const router = useRouter();
    const FSBUrl = (path: string): string => publicRuntimeConfig.FSB_SITE_URL + path;

    return (
        <>
            <p>It looks like you haven&#39;t made a deposit on The Pools before.</p>

            <p>For a first time deposit, click &#39;Make a Deposit&#39;</p>

            <ExternalLink
                target="_self"
                href={FSBUrl(`deposit-cash/?redirectUrl=${publicRuntimeConfig.WEBSITE_BASE}${router.asPath}`)}
            >
                <Button
                    bgColor={'#22A2FF'}
                    textColor={'#ffffff'}
                    padding={'8px 20px'}
                    rounded={'4px'}
                    margin={'15px 0 30px'}
                    height={'auto'}
                    hoverColor={'#22A2FF'}
                    hoverOpacity={'0.9'}
                    onClick={(): void => {
                        dispatch(closePopup('missing-address'));
                    }}
                >
                    Make a Deposit
                </Button>
            </ExternalLink>
        </>
    );
};
