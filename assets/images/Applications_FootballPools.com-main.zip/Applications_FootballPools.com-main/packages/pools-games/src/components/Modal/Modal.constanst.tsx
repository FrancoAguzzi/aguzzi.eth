export const screenYInitial = 1.5;
export const screenYpercentage = 0.6;
export const screenYpercentageInitial = 0.4;
