import styled from 'styled-components';
import { NumbersSelected } from '@sportech/pools-api';
import { HdaButton } from '../hda-button/HdaButton';

export interface MatchCardHdaProp {
    /**
     * A label to show on the button
     */
    number: number;
    action?: (id: number, type: string) => void;
    numbers?: NumbersSelected | undefined;
}

export const MatchCardHda: React.FC<MatchCardHdaProp> = props => (
    <MatchCardDiv>
        <HdaButton
            onClick={(): void => {
                if (props.action !== undefined) {
                    props.action(props.number, 'H');
                }
            }}
            active={props.numbers?.selections.includes('H')}
        >
            Home
        </HdaButton>
        <HdaButton
            onClick={(): void => {
                if (props.action !== undefined) {
                    props.action(props.number, 'D');
                }
            }}
            active={props.numbers?.selections.includes('D')}
        >
            Draw
        </HdaButton>
        <HdaButton
            onClick={(): void => {
                if (props.action !== undefined) {
                    props.action(props.number, 'A');
                }
            }}
            active={props.numbers?.selections.includes('A')}
        >
            Away
        </HdaButton>
    </MatchCardDiv>
);

const MatchCardDiv = styled.div`
    padding-top: 27px;
    padding-bottom: 14px;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    background: #e6e9f3;
    overflow: hidden;
    transition: height cubic-bezier(0.8, -0.02, 0.59, 0.96) 0.3s, padding-top cubic-bezier(0.8, -0.02, 0.59, 0.96) 0.3s;
    border: 1px solid #7b8797;
    border-bottom-left-radius: 20px;
    border-bottom-right-radius: 20px;
    position: relative;
    top: -20px;
    padding-left: 21px;
    padding-right: 21px;
    text-align: center;
`;
