import { BetSlip, Offering } from '@sportech/pools-api';
import React, { FunctionComponent, useContext } from 'react';
import styled, { ThemeContext } from 'styled-components';
import { Button } from '@components/Common/Button/Button';

interface OfferingDropDownListItemProps {
    offer: Offering;
    SelectAmountAction: (id: number, offer: Offering) => void;
    setOfferingDropdownOpen: (val: boolean) => void;
    betslipCurrentSelection: BetSlip;
    setShowMore: (val: boolean) => void;
    setCurrentOffering: (val: number) => void;
    isHda: boolean;
}

export const OfferingDropDownListItem: FunctionComponent<OfferingDropDownListItemProps> = props => {
    const themeContext = useContext(ThemeContext);

    return (
        <>
            <li>
                <StyledOfferingDesc
                    onClick={(): void => {
                        props.SelectAmountAction(props.betslipCurrentSelection.competitionId, props.offer);
                        props.setShowMore(true);
                        props.setOfferingDropdownOpen(false);
                        props.setCurrentOffering(props.offer.id);
                    }}
                >
                    {!props.isHda && `${props.offer.description} :`}
                    {` £${(props.offer.pricePerEntry / 100).toLocaleStringCash()}`}
                </StyledOfferingDesc>
                <Button
                    onClick={(): void => {
                        props.SelectAmountAction(props.betslipCurrentSelection.competitionId, props.offer);
                        props.setShowMore(true);
                        props.setOfferingDropdownOpen(false);
                        props.setCurrentOffering(props.offer.id);
                    }}
                    height={'unset'}
                    bgColor={themeContext.colours.gameMainColor}
                >
                    Select
                </Button>
            </li>
            <hr />
        </>
    );
};

const StyledOfferingDesc = styled.p`
    display: inline-block;
    width: 80%;
    margin: 0;
    flex: 7;
`;
