import styled from 'styled-components';
import { breakpointValues } from '@settings/breakpoints';

type StyledLinesItemProps = {
    amount: number;
    area: number;
    areaContainer: number;
    borderContainerRadius?: string;
    padding?: number;
    borderContainer?: boolean;
};
type DivGenProps = {
    percentage: number | undefined;
    margin: string | undefined;
};
export const StyledListItem = styled.div<StyledLinesItemProps>`
    padding: 0.4rem;
    background: #fff;
    display: flex;
    flex-direction: column;
    border: ${(props): string => (props.borderContainer === false ? 'none' : '1px solid #000')};
    border-radius: ${(props): string => (props.borderContainerRadius ? `${props.borderContainerRadius}` : '10px')};
    padding: ${(props): string => (props.padding ? `${props.padding}px` : '')};

    @media (max-width: ${breakpointValues.xs}px) {
        font-weight: normal;
        font-size: 11px;
        border-radius: 10px;
        padding: 0.4rem 0.6rem 0.4rem 0.4rem;
    }
`;
export const DivGen = styled.div<DivGenProps>`
    width: ${(props): string => (props.percentage ? `${props.percentage}%` : '100%')};
    margin: ${(props): string => (props.margin ? `${props.margin}` : '0px')};
`;
