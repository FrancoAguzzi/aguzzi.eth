import styled from 'styled-components';
import { NumbersSelected } from '@sportech/pools-api';
import { BetSlipCircle } from '../BetSlipCircle/BetSlipCircle';

interface BetSlipCircleListProps {
    selection?: Array<NumbersSelected>;
    amount: number;
    row: number;
    displayId?: boolean;
    isCurrent?: boolean;
    handleOnClick?: (id: number, displayId: string) => void;
    ballColor?: string;
    isMobileBetslip?: boolean;
    isClover?: boolean;
    isPick12Selection?: boolean;
}

export const BetSlipCircleList: React.FC<BetSlipCircleListProps> = props => {
    return (
        <StyledListItem isClover={props.isClover} isBetslipMobile={props.isMobileBetslip}>
            {Array.from(Array(props.amount), (e, i) => {
                return (
                    <BetSlipCircle
                        key={`Circle${i}`}
                        selected={
                            props.selection && props.selection[i]
                                ? props.displayId
                                    ? props.selection[i].Id
                                    : props.selection[i].selections[props.row]?.toLocaleUpperCase()
                                : ''
                        }
                        displayId={props.displayId}
                        selectedId={props.selection && props.selection[i] ? props.selection[i].Id : 0}
                        isCurrentSelectedLine={props.isCurrent}
                        handleOnClick={props.handleOnClick}
                        ballColor={props.ballColor}
                        isMobileBetslip={props.isMobileBetslip}
                        isPick12Selection={props.isPick12Selection}
                    ></BetSlipCircle>
                );
            })}
        </StyledListItem>
    );
};

type StyledListItemProps = {
    isBetslipMobile?: boolean;
    isClover?: boolean;
};

const StyledListItem = styled.ul<StyledListItemProps>`
    flex-wrap: wrap;
    padding: ${(props): string => (props.isClover ? '0 0 0 0' : '0 0 5px 0')};
    width: 100%;
    flex: 1;
    display: flex;
    margin: 0em 0;
    ${(props): string | undefined => {
        if (props.isBetslipMobile) {
            return `
            overflow: auto;
            
            flex-wrap: nowrap;
            margin: 0;
        `;
        }
    }}
`;
