import styled from 'styled-components';
import getConfig from 'next/config';
import { ConfirmButton } from '@components/Common/Button/Button';
import { useForm } from 'react-hook-form';
import { useDispatch } from 'react-redux';
import { closePopup, openPopup } from '@features/popups/popupsSlice';
import { useEffect } from 'react';
import { callApiRoute, callPaymentRoute } from '@api/PaymentAPI';
import { Address, Card, Payment } from '@interfaces/FSB';

interface RepeatPaymentFormProps {
    paymentType: string;
    amount: string;
    cardId: number;
    cvdNumber: string;
}

const FlexRowContainer = styled.div`
    display: flex;
    flex-direction: row;
`;

const FlexColumnContainer = styled.div`
    display: flex;
    flex-direction: column;
`;

const FormContainer = styled.form`
    display: flex;
    flex-direction: column;
`;

const Container = styled.div`
    padding: 10px;
`;

const FormTitle = styled.h4`
    margin: 0;
`;

const FormRow = styled(FlexRowContainer)`
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
    padding: 10px 0;
`;

const PaymentRow = styled(FormRow)`
    justify-content: center;
`;

const PaymentLabel = styled.div`
    font-size: 12px;
`;

const FormIcon = styled.img`
    width: 50px;
    height: 30px;
    border: 2px solid #000;
    border-radius: 10px;
    margin: 0 5px;
    padding: 5px;
    opacity: 0.5;
    z-index: 3;
`;

const FormLabel = styled.label`
    width: 25%;
    align-items: center;
    display: flex;
`;

const SelectLabel = styled(FormLabel)`
    vertical-align: top;
    display: inline;
    text-align: left;
    padding-top: 5px;
`;

const InputContainer = styled(FlexColumnContainer)`
    width: 75%;
`;

const FormInput = styled.input`
    width: 100%;
    height: 28px;
    font-size: 16px;
`;

const SelectInput = styled.select`
    width: 75%;
    height: 28px;
    cursor: pointer;
    overflow-y: auto;
    scrollbar-width: none;
    -ms-overflow-style: none;
    &-webkit-scrollbar {
        width: 0;
        height: 0;
    }
`;

const ShortFormInput = styled.input`
    width: 35px;
    height: 28px;
    font-size: 16px;
`;

const RadioInput = styled.input`
    &[type='radio'] {
        position: absolute;
        opacity: 0;
        width: 64px;
        height: 44px;
        cursor: pointer;
        z-index: 5;
    }
    &[type='radio']:checked + img {
        border: 2px solid green;
        opacity: 1;
    }
`;

const ButtonContainer = styled.div`
    margin-top: 10px;
`;

const SecurityCodeImage = styled.img`
    height: 40px;
    margin: 0 10px;
`;

const SecurityCodeDescription = styled.span`
    width: 120px;
    text-align: left;
`;

const ErrorMsg = styled.p`
    font-size: 1em;
    color: red;
    margin: 0;
    text-align: left;
    padding: 5px 0 0 0;
`;

const Iframe = styled.iframe`
    height: 400px;
    width: 100%;
    @media (min-width: 1024px) {
        width: 350px;
    }
    display: none;
`;

const RepeatPaymentForm = (): JSX.Element => {
    const { register, handleSubmit, errors } = useForm<RepeatPaymentFormProps>();
    const { publicRuntimeConfig } = getConfig();
    const dispatch = useDispatch();

    const minDeposit = 5;

    const getCardDetails = async (): Promise<Card> => {
        const cardDetails = await callApiRoute<Card>('getCards');

        return cardDetails;
    };

    const isValidAmount = (amount: string): boolean => {
        const inputValue = parseFloat(amount);

        if (+inputValue) {
            if (inputValue < minDeposit) {
                return false;
            }

            const isDecimalNumber = inputValue - Math.floor(inputValue) !== 0;

            if (isDecimalNumber) {
                const index = amount.indexOf('.');
                const numDecimalPlaces = amount.length - index - 1;
                if (numDecimalPlaces > 2) {
                    return false;
                } else {
                    return true;
                }
            } else {
                return true;
            }
        } else {
            return false;
        }
    };

    const checkOptionValue = (): void => {
        const select = document.getElementById('card-select') as HTMLSelectElement;

        if (select !== null) {
            const value = select.options[select.selectedIndex].value;

            if (value === 'newPayment') {
                dispatch(closePopup('repeat_payment'));
                dispatch(openPopup('add_new_card_payment'));
            }
        }
    };

    const populateCardDropdown = async (): Promise<void> => {
        const cardData = await getCardDetails();
        const select = document.getElementById('card-select');

        if (cardData.response.customer.card !== undefined && select !== null) {
            select.innerHTML = '';

            for (let i = 0; i < cardData.response.customer.card.length; i++) {
                if (cardData.response.customer.card[i].methodRef === 'OPTIMAL-CARD') {
                    const details = cardData.response.customer.card[i]['description'].replace(
                        cardData.response.customer.card[i]['methodRef'],
                        '',
                    );
                    const description = details.charAt(1).toUpperCase() + details.slice(2);
                    select.innerHTML =
                        select?.innerHTML +
                        '<option value="' +
                        cardData.response.customer.card[i]['id'] +
                        '">' +
                        description +
                        '</option>';
                }
            }
            select.innerHTML =
                select?.innerHTML +
                `<option value="newPayment" style="text-decoration: underline">Add new card</option>`;
        }
    };

    useEffect(() => {
        populateCardDropdown();
    }, []);

    const onSubmit = handleSubmit(async data => {
        const paymentPopup = document.getElementsByClassName('popup-overlay');
        if (paymentPopup !== null) {
            const popup = paymentPopup[0] as HTMLElement;
            popup.style.display = 'none';
        }
        dispatch(openPopup('loading'));

        const address = await callApiRoute<Address>('getAddress');

        const paymentData = {
            paymentMethodRef: data.paymentType,
            addressId: address.response.customer.address[0].id,
            amount: data.amount,
            cardId: data.cardId,
            responseUrl: `${publicRuntimeConfig.WEBSITE_BASE}/deposit-card-complete`,
            storeCardIndicator: true,
            cvdNumber: data.cvdNumber,
        };

        const payment = await callPaymentRoute<Payment>(paymentData);

        if (payment.response.status.messageKey !== undefined) {
            if (
                payment.response.status.messageKey === 'api.error.payment.limit.exceeded' ||
                payment.response.status.messageKey === 'api.error.payment.deposit.limit.reached'
            ) {
                dispatch(closePopup('repeat_payment'));
                dispatch(closePopup('loading'));
                dispatch(openPopup('deposit-limit'));
                return;
            }
        }

        const url = new URL(payment.response.customer.hpResponse.uri);
        url.searchParams.append('cvdNumber', data.cvdNumber);
        url.searchParams.append('amount', data.amount.toString());
        url.searchParams.append('cardId', data.cardId.toString());

        const iframe = document.getElementById('optimal-payment') as HTMLIFrameElement;
        const formContainer = document.getElementById('form-container');
        if (formContainer !== null && iframe !== null) {
            formContainer.style.display = 'none';
            iframe.src = url.toString();
            iframe.style.display = 'block';
        }

        dispatch(closePopup('loading'));
        if (paymentPopup !== null) {
            const popup = paymentPopup[0] as HTMLElement;
            popup.style.display = 'flex';
        }

        window.addEventListener('message', function (e) {
            if (e.data.status === 'success') {
                dispatch(closePopup('repeat_payment'));
                dispatch(openPopup('payment_deposit_success'));
            } else {
                dispatch(closePopup('repeat_payment'));
                dispatch(openPopup('payment_deposit_failure'));
            }
        });
    });

    return (
        <Container id="container">
            <FormContainer onSubmit={onSubmit} id="form-container">
                <FormTitle>Select Payment Method</FormTitle>
                <PaymentRow>
                    <FlexColumnContainer>
                        <FlexColumnContainer>
                            <RadioInput
                                type="radio"
                                name="paymentType"
                                value="OPTIMAL-CARD"
                                ref={register()}
                                defaultChecked
                            />
                            <FormIcon
                                src="https://cms.thepools.com/api/assets/pool-games/26179d34-7a63-418a-a8dc-e5dff7728648/card-icon.svg?version=0"
                                alt="Direct Debit"
                            />
                            <PaymentLabel>Debit Card</PaymentLabel>
                        </FlexColumnContainer>
                    </FlexColumnContainer>
                </PaymentRow>
                <FormTitle>Enter Payment Details</FormTitle>
                <FormRow>
                    <FormLabel htmlFor="amount">Amount</FormLabel>
                    <InputContainer>
                        <FormInput
                            type="text"
                            name="amount"
                            id="amount"
                            inputMode="decimal"
                            placeholder={`Minimum Deposit: £${minDeposit}`}
                            ref={register({
                                required: {
                                    value: true,
                                    message: 'This is required',
                                },
                                validate: isValidAmount,
                            })}
                        />
                        <ErrorMsg>
                            {errors.amount &&
                                errors.amount.type === 'validate' &&
                                `Please enter an amount of at least £${minDeposit}`}
                        </ErrorMsg>
                    </InputContainer>
                </FormRow>
                <FormRow>
                    <SelectLabel>Your cards</SelectLabel>
                    <SelectInput
                        name="cardId"
                        id="card-select"
                        onChange={(): void => {
                            checkOptionValue();
                        }}
                        ref={register}
                    >
                        <option value="">-- Loading --</option>
                    </SelectInput>
                </FormRow>
                <FormRow>
                    <FormLabel htmlFor="amount">Security Code</FormLabel>
                    <InputContainer>
                        <FlexRowContainer>
                            <ShortFormInput
                                type="text"
                                name="cvdNumber"
                                id="cvdNumber"
                                inputMode="numeric"
                                maxLength={3}
                                placeholder="CV2"
                                ref={register({
                                    required: {
                                        value: true,
                                        message: 'This is required',
                                    },
                                    pattern: { value: /[0-9]{3}/, message: '' },
                                })}
                            />
                            <SecurityCodeImage
                                src="https://cms.thepools.com/api/assets/pool-games/d2454c08-f396-4184-89bd-44e865996713/cv2-icon.svg?version=0"
                                alt="Security Code Icon"
                            />
                            <SecurityCodeDescription>3 digits on the back of the card</SecurityCodeDescription>
                        </FlexRowContainer>
                        <ErrorMsg>{errors.cvdNumber && 'Please enter the 3 digit Security Code'}</ErrorMsg>
                    </InputContainer>
                </FormRow>
                <ButtonContainer>
                    <ConfirmButton>Submit & Finish</ConfirmButton>
                </ButtonContainer>
            </FormContainer>
            <Iframe id="optimal-payment" name="optimal-payment"></Iframe>
        </Container>
    );
};

export default RepeatPaymentForm;
