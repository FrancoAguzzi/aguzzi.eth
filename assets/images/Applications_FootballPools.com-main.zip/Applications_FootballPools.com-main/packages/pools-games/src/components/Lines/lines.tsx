import { CircleList } from '../CircleList/circleList';
import { StyledListItem, DivGen } from './Lines.styles';
/**
 * @param selection: array of selected to know which circle is selected / matched or not.
 * @param selected: Number selected.
 * @param amount: number of circles.
 * @param date: date of game
 * @param row: the number row of the line.
  
 * @param isCurrentSelectedLine: Is the current line selected to play.
 * @param displayId: boolean to know if the number is displaying in the circle.
 * @param fontSize: sise of the letters in circles.
 * @param margin: margin between circles.
 
 * @param handleOnClickNumber: function that select de circles.
 * @param handleOnClickDice: function for icon dice.
 * @param handleOnClickEdit: function for edit button icon.
 * @param handlleOnClickDelete: function for delete line selection.
 * @param areaContainer: Proportional value for the container width.
 * @param border: if the circles has borders or not.
 * @param area: proportional width to have height and width for the circles and lines. ${props.area / 6.5}px for height.
 
 * @param diceButton: has dice button icon or not.
 * @param editButton: has edit button icon or not.
 * @param percentage: % of width container.
 * @param margin: margin of external container.
 * @param marginTopCircle: Margin of external circlecontainer 
 * @param borderContainerRadius: Radius border for the line container.
 * @param isCheckout Boolean to know if it's the checkout page which is showing the component
 * @param isBetConfirmation Boolean to know if it's the bet confirmation page which is showing the component
 * @param isResults Boolean to show my results
 */
export interface LinesProps {
    selection: Array<number | string>;
    selected?: Array<boolean> | undefined;
    amount: number;
    date?: string;
    row: number | string;
    displayId?: boolean;
    isCurrent?: boolean;
    handleOnClickNumber?: (id: number, displayId: string) => void;
    handleOnClickEdit: (id: number | string) => void;
    handleOnClickDice: (row: number | string) => void;
    handleOnClickDelete?: (row: number | string) => void;
    area: number;
    border?: boolean;
    borderContainerRadius?: string;
    areaContainer: number;
    diceButton?: boolean;
    editButton?: boolean;
    percentage?: number | undefined;
    margin?: string | undefined;
    marginTopCircle?: number | undefined;
    padding?: number;
    isCheckout?: boolean;
    isBetConfirmation?: boolean;
    borderContainer?: boolean;
    isResults?: boolean;
}

export const Lines: React.FC<LinesProps> = props => {
    return (
        <DivGen percentage={props.percentage} margin={props.margin}>
            <StyledListItem
                amount={props.amount}
                area={props.area}
                areaContainer={props.areaContainer}
                borderContainerRadius={props.borderContainerRadius}
                padding={props.padding}
                borderContainer={props.borderContainer}
            >
                <CircleList
                    selection={props.selection}
                    amount={props.amount}
                    row={props.row}
                    date={props.date}
                    displayId={props.displayId}
                    isCurrent={props.isCurrent}
                    handleOnClick={() => null}
                    area={props.area}
                    diceButton={props.diceButton}
                    editButton={props.editButton}
                    border={props.border}
                    marginTopCircle={props.marginTopCircle}
                    selected={props.selected}
                    handleOnClickDice={props.handleOnClickDice}
                    handleOnClickEdit={props.handleOnClickEdit}
                    handleOnClickDelete={props.handleOnClickDelete}
                    isCheckout={props.isCheckout}
                    isBetConfirmation={props.isBetConfirmation}
                    isResults={props.isResults}
                />
            </StyledListItem>
        </DivGen>
    );
};
