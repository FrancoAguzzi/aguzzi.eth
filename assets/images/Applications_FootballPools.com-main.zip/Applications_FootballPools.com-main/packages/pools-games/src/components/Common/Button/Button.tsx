import { breakpoints } from '@settings/breakpoints';
import styled from 'styled-components';

interface ButtonProps {
    rounded?: string;
    bgColor?: string;
    hoverColor?: string;
    texthoverColor?: string;
    hoverOpacity?: string;
    textColor?: string;
    width?: string;
    margin?: string;
    height?: string;
    padding?: string;
    noHover?: boolean;
    cursor?: string;
    border?: string;
}

export const Button = styled.button<ButtonProps>`
    background: ${(props): string => (props.bgColor ? props.bgColor : '#363636')};
    color: ${(props): string => (props.textColor ? props.textColor : '#fff')};
    padding: ${(props): string => (props.padding ? props.padding : '0.5em 1.25em;')};
    font-size: ${(props): string => (props.padding ? props.padding : '12px;')};
    border: ${(props): string => (props.border ? props.border : 'none')};
    border-radius: ${(props): string => (props.rounded ? props.rounded : '8px')};
    cursor: ${(props): string => (props.cursor ? props.cursor : 'pointer')};
    width: ${(props): string => (props.width ? props.width : '')};

    ${breakpoints.above('lg')} {
        ${(props): string | undefined => {
            if (props.noHover !== true) {
                return ` &:hover {
                    background:  ${props.hoverColor ? props.hoverColor : '#cccccc'};
                    opacity: ${props.hoverOpacity ? props.hoverOpacity : '0.9'};
                    color:${props.texthoverColor ? props.texthoverColor : ''};
                    svg {
                        fill: ${props.texthoverColor ? props.texthoverColor : ''};
                    }
                }`;
            }
        }}
    }

    &:disabled {
        cursor: not-allowed;
        background: #d3d3d3;
    }

    height: ${(props): string => (props.height ? props.height : '70px')};
    display: inline-block;
    flex-grow: 1;
    margin: ${(props): string => (props.margin ? props.margin : '')};
    &:focus {
        outline: none;
        box-shadow: none;
    }
`;

export const ConfirmButton = styled(Button)`
    background: #22a2ff;
    color: white;
    height: auto;
    padding: 8px 10px;
    border-radius: 4px;
    &:hover {
        background: #22a2ff;
    }
`;

export default Button;
