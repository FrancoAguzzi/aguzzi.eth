import styled from 'styled-components';
import { ContainerCircles } from '@src/base-styles';
import { breakpointValues } from '@settings/breakpoints';

type StyledListItemProps = {
    isCurrentSelectedLine?: boolean;
    area?: number;
    fontSize?: string;
    margin?: string;
    isSelected?: boolean;
    border?: boolean;
    isInLine: boolean;
};

type ItemBackgroundItemProps = {
    isSelected?: boolean;
    isResults?: boolean;
};

export const StyledListItem = styled.div<StyledListItemProps>`
    border: ${(props): string => (props.border ? '1px solid #333333' : '')};
    width: 100%;
    height: 100%;
    border-radius: 50%;
    text-align: center;
    padding: 0;
    font-weight: 500;
    display: flex;
    flex: 1;
    align-items: center;
    justify-content: center;
    background: ${(props): string => (props.isSelected ? '#188BE9' : '#fff')};
    border-color: #000;
    color: #000;
    cursor: pointer;
`;

export const ItemBackground = styled.div<ItemBackgroundItemProps>`
    width: 65%;
    height: 65%;
    display: flex;
    justify-content: center;
    align-items: center;
    color: ${(props): string => (props.isResults && props.isSelected ? '#fff' : '')};
    background: ${(props): string => (props.isResults && props.isSelected ? '#188BE9' : '#fff')};
    border-radius: 100%;
    position: relative;
`;

export const Bubble = styled.div`
    width: 30%;
    height: 30%;
    background: white;
    border-radius: 100%;
    opacity: 50%;
    position: absolute;
    top: -10%;
    left: 10%;
`;
export const Container = styled(ContainerCircles)<StyledListItemProps>`
    @media (max-width: ${breakpointValues.xs}px) {
        width: ${(props): string =>
            props.area && props.isInLine ? `${props.area / 10}px` : props.area ? `${props.area / 8}px` : '20px'};
        height: ${(props): string =>
            props.area && props.isInLine ? `${props.area / 10}px` : props.area ? `${props.area / 8}px` : '20px'};
    }
    margin: ${(props): string => (props.margin ? props.margin : '0 0 0 0')};
`;
