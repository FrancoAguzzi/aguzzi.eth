import React, { FunctionComponent } from 'react';
import Link from 'next/link';

import { MenuDropdown, MenuDropdownOverlay } from '@components/Styles/defaultPageStyles';

interface BannerDropdownProps {
    dropdownOptions: DropdownOption[];
    onOverlayClick: () => void;
}

interface DropdownOption {
    text: string;
    redirect: string;
}

export const BannerDropdown: FunctionComponent<BannerDropdownProps> = props => {
    return (
        <>
            <MenuDropdown>
                {props.dropdownOptions.map((dropdownOption: DropdownOption, index) => (
                    <li key={index}>
                        <Link href={dropdownOption.redirect} passHref>
                            <a>{dropdownOption.text}</a>
                        </Link>
                        {index !== props.dropdownOptions.length - 1 && <hr />}
                    </li>
                ))}
            </MenuDropdown>
            <MenuDropdownOverlay onClick={(): void => props.onOverlayClick()} />
        </>
    );
};
