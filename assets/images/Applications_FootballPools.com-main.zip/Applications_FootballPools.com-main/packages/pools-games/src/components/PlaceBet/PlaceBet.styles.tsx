import styled from 'styled-components';
import { breakpointValues, breakpoints } from '@settings/breakpoints';

type StyledListItemProps = {
    checkoutQuick: boolean;
    isMobile?: boolean;
};

interface ButtonProps {
    rounded?: string;
    bgColor?: string;
    hoverColor?: string;
    texthoverColor?: string;
    hoverOpacity?: string;
    textColor?: string;
    width?: string;
    margin?: string;
    height?: string;
    padding?: string;
    noHover?: boolean;
    cursor?: string;
    border?: string;
    fontSize?: string;
}

//Titles of the component
export const Title = styled.div<StyledListItemProps>`
    font-size: 1rem;
    margin-top: 0.2rem;
    padding-bottom: 0.2rem;
    text-align: center;
    color: #303030;
    font-weight: ${(props): string => (props.checkoutQuick ? 'bold' : '100')};
    @media (max-width: ${breakpointValues.xs}px) {
        font-size: 12px;
    }
`;

export const PlaceBetContainer = styled.div<StyledListItemProps>`
    display: flex;
    justify-content: center;
    direction: column;
    align: center;
    justify: center;
    width: 100%;
    position: relative;
    background: white;
    bottom: 0px;
    height: ${(props): string => (props.checkoutQuick ? '' : 'auto')};
    @media (max-width: ${breakpointValues.xs}px) {
        height: '150px';
        min-height: auto;
    }

    box-shadow: ${(props): string => (props.checkoutQuick ? '' : '0px 0px 0px #888, 0px -4px 3px #e5e4e4')};
    padding: 0%;
    margin-top: auto;
`;

export const Button = styled.button<ButtonProps>`
    background: ${(props): string => (props.bgColor ? props.bgColor : '#363636')};
    color: ${(props): string => (props.textColor ? props.textColor : '#fff')};
    padding: ${(props): string => (props.padding ? props.padding : '0.5em 1.25em;')};
    font-size: ${(props): string => (props.fontSize ? props.fontSize : '14px')};
    border: ${(props): string => (props.border ? props.border : 'none')};
    border-radius: ${(props): string => (props.rounded ? props.rounded : '8px')};
    cursor: ${(props): string => (props.cursor ? props.cursor : 'pointer')};
    width: ${(props): string => (props.width ? props.width : '')};

    ${breakpoints.above('lg')} {
        ${(props): string | undefined => {
            if (props.noHover !== true) {
                return ` &:hover {
                    background:  ${props.hoverColor ? props.hoverColor : '#cccccc'};
                    opacity: ${props.hoverOpacity ? props.hoverOpacity : '0.9'};
                    color:${props.texthoverColor ? props.texthoverColor : ''};
                    svg {
                        fill: ${props.texthoverColor ? props.texthoverColor : ''};
                    }
                }`;
            }
        }}
    }

    @media (max-width: ${breakpointValues.xs}px) {
        font-size: 12px;
    }
    &:disabled {
        cursor: not-allowed;
        background: #d3d3d3;
    }

    height: ${(props): string => (props.height ? props.height : '70px')};
    display: inline-block;
    margin: ${(props): string => (props.margin ? props.margin : '')};
    &:focus {
        outline: none;
        box-shadow: none;
    }
`;
