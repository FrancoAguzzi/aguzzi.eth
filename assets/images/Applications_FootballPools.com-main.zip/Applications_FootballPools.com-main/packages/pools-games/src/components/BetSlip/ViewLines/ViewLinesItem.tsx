import styled, { ThemeContext } from 'styled-components';
import { BetSlipCircleList } from '../BetSlipCircleList/BetSlipCircleList';
import { useState, FunctionComponent, useContext } from 'react';
import { Fixture, Competition, Offering, Wager } from '@sportech/pools-api';
import {
    ConvertStringToArray,
    convertWagerToBetSlipSelection,
    RemoveGameName,
    RemoveSoccer6Name,
} from '@src/utils/functionUtils';
import { GameSection, GameViewType } from '@components/GameSection/GameSection/GameSection';
import { useMediaQuery } from 'react-responsive';
import { Container } from '@components/Styles/defaultPageStyles';
import { GameModel } from '@interfaces/PoolGames/GameModel';

interface ViewLinesItemProps {
    wager: Wager;
    competition: Competition;
    offering: Offering;
    index: number;
    nothda: boolean;
    gameModel: GameModel;
}

export const ViewLinesItem: FunctionComponent<ViewLinesItemProps> = props => {
    const [showFixtures, setShowFixtures] = useState(false);
    const numbersFixturesViewText = showFixtures ? 'View Numbers' : 'View Fixtures';
    const themeContext = useContext(ThemeContext);
    const isMobileOrTablet = useMediaQuery({
        query: `(max-width: ${themeContext.breakpoints.lg}px )`,
    });

    return (
        <>
            <StyledWager key={props.wager.wagerId}>
                <p>
                    {' '}
                    {RemoveGameName(props.offering?.description)}
                    {props.wager.bonusSelections !== undefined && ' + Bonus'} £
                    {props.wager.bonusPaidCost !== undefined
                        ? ((((props.wager.paidCost as number) + props.wager.bonusPaidCost) as number) / 100).toFixed(2)
                        : ((props.wager.paidCost as number) / 100).toFixed(2)}
                    <br />
                    {props.competition !== undefined && (
                        <strong>{RemoveSoccer6Name(props.competition.description)}</strong>
                    )}
                </p>
            </StyledWager>

            {!showFixtures && (
                <NumberList key={'NumberList' + props.index} isClover={props.gameModel.isClover()}>
                    <Container>
                        <BetSlipCircleList
                            selection={ConvertStringToArray(props.wager.selections as string, props.nothda)}
                            displayId={props.nothda}
                            key={'BetSlipCircleList' + props.index}
                            row={0}
                            amount={ConvertStringToArray(props.wager.selections as string, props.nothda).length}
                            isClover={props.gameModel.isClover()}
                            ballColor={props.gameModel.isClover() ? '#00955C' : '#000'}
                            isPick12Selection={props.offering?.maximumSelections === 12}
                        ></BetSlipCircleList>
                        {props.gameModel.isClover() &&
                            props.wager.bonusSelections !== undefined &&
                            (props.wager.bonusSelections as string).length > 0 && (
                                <>
                                    <p>Bonus</p>
                                    <BetSlipCircleList
                                        selection={ConvertStringToArray(
                                            props.wager.bonusSelections as string,
                                            props.nothda,
                                        )}
                                        displayId={props.nothda}
                                        row={2}
                                        amount={
                                            ConvertStringToArray(props.wager.bonusSelections as string, props.nothda)
                                                .length
                                        }
                                        isClover={props.gameModel.isClover()}
                                        ballColor={'#E0AC00'}
                                        isPick12Selection={props.offering?.maximumSelections === 12}
                                    ></BetSlipCircleList>
                                </>
                            )}
                    </Container>

                    {ConvertStringToArray(props.wager.selections as string, props.nothda).reduce(
                        (maxId, item) => Math.max(maxId, item.rows),
                        0,
                    ) >= 2 ? (
                        <Container>
                            <BetSlipCircleList
                                selection={ConvertStringToArray(props.wager.selections as string, props.nothda)}
                                displayId={props.nothda}
                                key={'BetSlipCircleList' + props.index}
                                row={1}
                                amount={ConvertStringToArray(props.wager.selections as string, props.nothda).length}
                                isClover={false}
                                isPick12Selection={props.offering?.maximumSelections === 12}
                                ballColor={'#000'}
                            ></BetSlipCircleList>
                        </Container>
                    ) : (
                        <></>
                    )}
                    {ConvertStringToArray(props.wager.selections as string, props.nothda).reduce(
                        (maxId, item) => Math.max(maxId, item.rows),
                        0,
                    ) >= 3 ? (
                        <Container>
                            <BetSlipCircleList
                                selection={ConvertStringToArray(props.wager.selections as string, props.nothda)}
                                displayId={props.nothda}
                                key={'BetSlipCircleList' + props.index}
                                row={2}
                                amount={ConvertStringToArray(props.wager.selections as string, props.nothda).length}
                                isClover={false}
                                isPick12Selection={props.offering?.maximumSelections === 12}
                                ballColor={'#000'}
                            ></BetSlipCircleList>
                        </Container>
                    ) : (
                        <></>
                    )}
                </NumberList>
            )}
            {isMobileOrTablet && (
                <>
                    {showFixtures && (
                        <GameSection
                            fixtures={
                                props.competition?.fixtures.filter(x =>
                                    ConvertStringToArray(props.wager.selections as string, props.nothda).find(
                                        s => s.Id === x.number,
                                    ),
                                ) as Fixture[]
                            }
                            betslipselection={convertWagerToBetSlipSelection(
                                props.competition,
                                props.offering,
                                props.wager,
                                ConvertStringToArray(props.wager.selections as string, props.nothda),
                                [],
                            )}
                            gameViewType={GameViewType.Match}
                            isViewLines={true}
                            gameModel={props.gameModel}
                        />
                    )}
                    {!props.gameModel.isClover() && (
                        <ViewFixturesButtonContainer>
                            <StyledAUnderline onClick={(): void => setShowFixtures(!showFixtures)}>
                                {numbersFixturesViewText}
                            </StyledAUnderline>
                        </ViewFixturesButtonContainer>
                    )}
                </>
            )}
        </>
    );
};

const StyledWager = styled.div`
    display: flex;
    flex-direction: row;
    background: #eaeaea;
    color: #000;
    padding: 5px;
    text-align: left;
    p {
        margin: 0.1em 0;
    }
`;
type StyledNumberedListProps = {
    isClover: boolean;
};

const NumberList = styled.div<StyledNumberedListProps>`
    display: flex;
    justify-content: flex-start;
    align-items: center;
    flex-direction: ${(props): string => (props.isClover ? 'row' : 'column')};
    flex: 1;
    padding: 0 0 5px 3px;
    background: #eaeaea !important;

    ul {
        flex: unset;
        width: unset;
    }
`;

const StyledAUnderline = styled.a`
    text-decoration: underline;
    cursor: pointer;
    text-align: center;
`;

const ViewFixturesButtonContainer = styled.div`
    text-align: center;
    background: #eaeaea;
    padding-bottom: 5px;
`;
