import styled from 'styled-components';
import { WagerItem } from '../Wager/WagerItem';
import { Offering, CompetitionResults, CompetitionDividends, CompetitionWagers, Wager } from '@sportech/pools-api';
import { arrayOfCompetitionIds, groupBy, mergedLuckyCloverBonusLinkedWagers } from '@src/utils/functionUtils';
import { GameModel } from '@interfaces/PoolGames/GameModel';

interface WagerSectionProps {
    wagers: CompetitionWagers[];
    offerings: Offering[];
    competitions: CompetitionResults;
    dividends: CompetitionDividends;
    isAllBets: boolean;
    fromDate: Date;
    toDate: Date;
    gameModel: GameModel;
}

export const WagerSection: React.FC<WagerSectionProps> = props => {
    const openComps: number[] = [];
    props.gameModel.isClover()
        ? props.competitions
              .filter(x => x.state.toLocaleLowerCase() !== 'completed')
              .map(comp => {
                  const compIds = arrayOfCompetitionIds(comp.competitionIds as { [key: string]: number });
                  for (let i = 0; i < compIds.length; i++) {
                      openComps.push(compIds[i]);
                  }
              })
        : props.competitions
              .filter(x => x.state.toLocaleLowerCase() !== 'completed')
              .map(comp => {
                  openComps.push(comp.id);
              });
    const openBets = props.wagers?.filter(x => openComps.includes(x.competitionId));

    const wagerComps = props.isAllBets ? props.wagers : openBets;

    let wagersArray: Wager[] = [];

    wagerComps?.map(competition =>
        competition.wagers.map(wager => {
            wager.competitionId = competition.competitionId;
            wagersArray.push(wager);
        }),
    );
    wagersArray.sort((a, b) => (b.wagerId as number) - (a.wagerId as number));
    if (props.gameModel.isClover()) {
        wagersArray = mergedLuckyCloverBonusLinkedWagers(wagersArray);
    }
    const noBetsText = props.isAllBets ? 'No bets within selected date range' : 'No open bets';
    let numberOfWagers = 0;
    const WagersGroupByCreatedAt = groupBy(wagersArray, wagers => wagers.createdAt);
    return (
        <WagerList>
            <WagerListHeader>
                <p>Date</p>
                <p>Stake</p>
                <p>Result</p>
            </WagerListHeader>
            <>
                {props.isAllBets
                    ? Array.from((WagersGroupByCreatedAt.values() as unknown) as Wager[][]).map((wager, index) => {
                          const filteredWagers = ((wager as unknown) as Wager[])?.filter(
                              x =>
                                  new Date(x.createdAt as string) >= props.fromDate &&
                                  new Date(x.createdAt as string) <= props.toDate,
                          );

                          numberOfWagers += filteredWagers.length;
                          return (
                              <WagerItem
                                  gameModel={props.gameModel}
                                  wager={filteredWagers}
                                  key={index}
                                  offering={props.offerings}
                                  comp={props.competitions}
                                  dividends={props.dividends}
                              ></WagerItem>
                          );
                      })
                    : Array.from((WagersGroupByCreatedAt.values() as unknown) as Wager[][]).map((wager, index) => {
                          const wagers = (wager as unknown) as Wager[];
                          numberOfWagers += wagers.length;
                          return (
                              <WagerItem
                                  gameModel={props.gameModel}
                                  wager={wagers}
                                  key={index}
                                  offering={props.offerings}
                                  comp={props.competitions}
                                  dividends={props.dividends}
                              ></WagerItem>
                          );
                      })}
            </>
            {numberOfWagers === 0 && <NoBetText>{noBetsText}</NoBetText>}
        </WagerList>
    );
};

const WagerList = styled.ul`
    list-style: none;
    padding: 0;
    margin-top: 0;
`;

const WagerListHeader = styled.ul`
    list-style: none;
    display: flex;
    padding: 0 0 0 30px;
    background: #363637;
    color: #fff;

    p {
        flex: 1 1 33%;
    }
`;

const NoBetText = styled.p`
    text-align: center;
    background: lightgrey;
    margin: 0;
    padding: 30px 0;
`;
