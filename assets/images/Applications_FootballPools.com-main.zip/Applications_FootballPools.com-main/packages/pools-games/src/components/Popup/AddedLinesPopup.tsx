import { FunctionComponent } from 'react';
import { BetSlip, Offerings } from '@sportech/pools-api';
import { useDispatch } from 'react-redux';
import { AppDispatch } from '@src/store';
import { closePopup, openPopup } from '@features/popups/popupsSlice';
import { PopupStickyFooter } from '@components/Styles/PopupStyles';
import { Button } from '@components/Common/Button/Button';
import { BetSlipCircleList } from '@components/BetSlip/BetSlipCircleList/BetSlipCircleList';
import styled from 'styled-components';
import { useRouter } from 'next/router';
import {
    getTotalLines,
    getTotalPrice,
    isPlayButtonDisabled,
    RemoveGameName,
    RemoveSoccer6Name,
} from '@src/utils/functionUtils';
import '@src/utils/extensionMethods';
import { GameModel } from '@interfaces/PoolGames/GameModel';
import { useUser } from '@auth0/nextjs-auth0';

interface AddedLinesPopupProps {
    betslipselection: Array<BetSlip>;
    offers: Offerings;
    currentBet: BetSlip;
    changeBet: (index: number) => void;
    clearLine: (index?: number) => void;
    addedLines: BetSlip[];
    pressPlay: () => void;
    gameModel: GameModel;
}

export const AddedLinesPopup: FunctionComponent<AddedLinesPopupProps> = props => {
    const dispatch: AppDispatch = useDispatch<AppDispatch>();
    const { user } = useUser();
    const router = useRouter();
    const editLineClick = (index: number): void => {
        if (props.currentBet.pick !== props.currentBet.numbers?.length) {
            props.clearLine();
        }
        props.changeBet(index);
        dispatch(closePopup('added_lines'));
    };

    const removeLineClick = (index: number): void => {
        if (props.betslipselection.length <= 1) {
            props.clearLine(index);
            dispatch(closePopup('added_lines'));
        } else {
            props.clearLine(index);
        }
    };

    const totalPricenumber = getTotalPrice(props.gameModel.isHDA(), props.gameModel.isClover(), props.addedLines);
    const totalPrice = totalPricenumber.toLocaleStringCash();

    const onPlayButtonClick = (): void => {
        if (props.gameModel.isClover() && props.betslipselection.filter(x => x.bonusNumbers.length === 0).length > 0) {
            dispatch(closePopup('payment'));
            dispatch(openPopup('lucky_clover_no_bonus_selected'));
        } else {
            props.pressPlay();
        }
    };

    return (
        <>
            <AddedLinesContent>
                {props.addedLines.map((item, index) => (
                    <AddedLinesItem key={index}>
                        <h4>
                            {RemoveGameName(props.offers.offerings.find(x => x.id === item.priceID)?.description)} £
                            {(
                                (props.gameModel.isClover() && item.bonusNumbers.length === item.bonusPick
                                    ? item.price + item.bonusPrice
                                    : item.price) / 100
                            ).toFixed(2)}
                            <br />
                            <strong>{RemoveSoccer6Name(item.competitionName)}</strong>
                        </h4>
                        <Container isClover={props.gameModel.isClover()}>
                            <BetSlipCircleList
                                key={index}
                                selection={item.numbers}
                                displayId={!props.gameModel.isHDA()}
                                row={0}
                                amount={item.pick}
                                isCurrent={item.current}
                                ballColor={props.gameModel.isClover() ? '#00955C' : '#363636'}
                                isClover={props.gameModel.isClover()}
                                isPick12Selection={
                                    props.offers.offerings.find(x => x.id === item.priceID)?.maximumSelections === 12
                                }
                            ></BetSlipCircleList>
                            {props.gameModel.isClover() && (
                                <>
                                    <p>Bonus</p>
                                    <BetSlipCircleList
                                        selection={item.bonusNumbers}
                                        displayId={!props.gameModel.isHDA()}
                                        row={2}
                                        amount={item.bonusPick}
                                        isCurrent={item.current}
                                        isClover={props.gameModel.isClover()}
                                        ballColor={props.gameModel.isClover() ? '#E0AC00' : '#363636'}
                                    ></BetSlipCircleList>
                                </>
                            )}
                            {item.highestRow !== undefined && item?.highestRow >= 2 ? (
                                <>
                                    <BetSlipCircleList
                                        key={index}
                                        selection={item.numbers}
                                        displayId={!props.gameModel.isHDA()}
                                        row={1}
                                        amount={item.pick}
                                        isCurrent={item.current}
                                        ballColor={'#363636'}
                                        isPick12Selection={
                                            props.offers.offerings.find(x => x.id === item.priceID)
                                                ?.maximumSelections === 12
                                        }
                                    ></BetSlipCircleList>
                                </>
                            ) : (
                                <></>
                            )}
                            {item.highestRow !== undefined && item?.highestRow >= 3 ? (
                                <>
                                    <BetSlipCircleList
                                        key={index}
                                        selection={item.numbers}
                                        displayId={!props.gameModel.isHDA()}
                                        row={2}
                                        amount={item.pick}
                                        isCurrent={item.current}
                                        ballColor={'#363636'}
                                        isPick12Selection={
                                            props.offers.offerings.find(x => x.id === item.priceID)
                                                ?.maximumSelections === 12
                                        }
                                    ></BetSlipCircleList>
                                </>
                            ) : (
                                <></>
                            )}
                        </Container>

                        <StyledAUnderline onClick={(): void => editLineClick(index)}>Edit</StyledAUnderline>

                        <StyledAUnderline onClick={(): void => removeLineClick(index)}>Remove</StyledAUnderline>
                    </AddedLinesItem>
                ))}
            </AddedLinesContent>

            <PopupStickyFooter>
                <p>{`Total Lines: ${getTotalLines(props.gameModel.isHDA() as boolean, props.addedLines)}`}</p>
                <p>YOUR TOTAL: £{totalPrice}</p>
                <Button
                    disabled={isPlayButtonDisabled(props.betslipselection)}
                    height={'auto'}
                    bgColor={'#0C9D00'}
                    textColor={'#fff'}
                    padding={'1em 1.25em'}
                    width={'70%'}
                    onClick={(): void => {
                        if (user === null) {
                            router.push('/api/auth/login');
                        } else {
                            onPlayButtonClick();
                            dispatch(closePopup('added_lines'));
                        }
                    }}
                >
                    PLAY
                </Button>
            </PopupStickyFooter>
        </>
    );
};

const AddedLinesContent = styled.div`
    color: white;
    padding: 10px 0 10px 0;
    text-align: center;
    font-size: 16px;
    line-height: 24px;
    outline: 0;
    margin-top: 30px;
    margin-bottom: 60%;

    p {
        font-weight: bold;
    }
`;

type ContainerProps = {
    isClover: boolean;
};

const Container = styled.div<ContainerProps>`
    display: flex;
    flex: 1;

    flex-direction: ${(props): string => (props.isClover ? 'row' : 'column')};

    p {
        margin-left: 5px;
        margin-right: 5px;
    }
`;

const AddedLinesItem = styled.div`
    width: 100%;
    padding: 0;
    color: #fff;
    margin: 10px 0 40px 0;
    text-align: left;

    h4 {
        width: 100%;
        color: #000;
        margin: 0;
    }
    a {
        font-size: 15px;
        font-weight: bold;
        line-height: 20px;
    }

    a:last-child {
        float: right;
    }

    ul {
        padding: 0;
        margin: 10px 0;
        flex: unset;
        width: unset;
    }

    p {
        color: #000;
    }
`;

const StyledAUnderline = styled.a`
    text-decoration: underline;
    cursor: pointer;
    color: #000;
    float: left;
`;
