/* eslint-disable import/no-unresolved */
import { StyledListItem, Text } from './circleList.styles';
import { Circle } from '../Circle/circle';
import { Icon } from '../Icon/icon';
import PencilEdit from 'public/svg/pencilEdit.svg';
import DiceWhite from 'public/svg/diceWhite.svg';
import CrossWhite from 'public/svg/crossWhite.svg';
/**
 * @param selected: Number selected.
 * @param Area: proportional width to have height and width for the circles and lines. ${props.area / 6.5}px for
 * @param margin: margin between circles.

 
 * @param row: the number row of the line
 * @param fontSize: sise of the letters in circles.
 * @param displayId: boolean to know is the number is display in the column.
 * @param isCurrent: Is the current line selected to play. The user select this lineto play with it.
 * @param selected: array of selected to know which circle is selected / matched or not.
 * @param border: if the circles has borders or not
 
 * @param diceButton: has dice button or not;
 * @param editButton: has edit button or not;
 * @param handleOnClick: function that select de circles.
 * @param handleOnClickDice: function for dice icon button.
 * @param handleOnClickEdit: function for edit icon button.
 * @param marginTopCircle: margin to circles componenet.
 * @param handlleOnClickDelete: function for delete line selection.
 * @param isCheckout Boolean to know if it's the checkout page which is showing the component
 * @param isBetConfirmation Boolean to know if it's the bet confirmation page which is showing the component
 * @param isResults Boolean to show my results
 */
interface CircleListProps {
    area: number;
    selection: Array<number | string>;
    selected?: Array<boolean> | undefined;
    amount: number;
    row: number | string;
    date?: string;
    border?: boolean;
    displayId?: boolean;
    isCurrent?: boolean;
    diceButton?: boolean;
    editButton?: boolean;
    isCheckout?: boolean;
    marginTopCircle?: number | undefined;
    isBetConfirmation?: boolean;
    handleOnClickEdit: (id: number | string) => void;
    handleOnClick?: (id: string | number) => void;
    handleOnClickDice: (row: number | string) => void;
    handleOnClickDelete?: (row: number | string) => void;
    isResults?: boolean;
}

export const CircleList: React.FC<CircleListProps> = props => {
    return (
        <>
            <Text>{props.date}</Text>
            <StyledListItem marginTopCircle={props.marginTopCircle}>
                {Array.from(Array(props.amount), (e, i) => {
                    if (props.selected) {
                        return (
                            <Circle
                                key={`Circle${i}`}
                                selected={props.selection[i]}
                                displayId={props.displayId}
                                isCurrentSelectedLine={props.isCurrent}
                                handleOnClick={props.handleOnClickEdit}
                                isSelected={props.selected[i]}
                                area={props.area}
                                border={props.border}
                                id={props.row}
                                isInLine={true}
                                isResults={props.isResults}
                            ></Circle>
                        );
                    } else {
                        return (
                            <Circle
                                key={`Circle${i}`}
                                selected={props.selection[i]}
                                displayId={props.displayId}
                                isCurrentSelectedLine={props.isCurrent}
                                handleOnClick={props.handleOnClickEdit}
                                area={props.area}
                                border={props.border}
                                id={props.row}
                                isInLine={true}
                            ></Circle>
                        );
                    }
                })}
                {props.editButton && (
                    <Icon area={props.area} onClick={props.handleOnClickEdit} id={props.row}>
                        <PencilEdit />
                    </Icon>
                )}
                {((props.diceButton && props.selection.length === 0) ||
                    (props.isCheckout && !props.isBetConfirmation)) && (
                    <Icon area={props.area} onClick={props.handleOnClickDice} id={props.row}>
                        <DiceWhite />
                    </Icon>
                )}
                {props.handleOnClickDelete &&
                    props.selection.length !== 0 &&
                    !props.isCheckout &&
                    !props.isBetConfirmation && (
                        <Icon area={props.area} onClick={props.handleOnClickDelete} id={props.row}>
                            <CrossWhite />
                        </Icon>
                    )}
            </StyledListItem>
        </>
    );
};
