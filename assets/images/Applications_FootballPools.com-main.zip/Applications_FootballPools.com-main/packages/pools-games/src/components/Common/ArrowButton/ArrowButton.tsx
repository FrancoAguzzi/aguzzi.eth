import styled from 'styled-components';

interface ButtonProps {
    isFacingLeft: boolean;
    backgroundColor: string;
    color: string;
}

export const ArrowButton = styled.button<ButtonProps>`
    background: ${(props): string => props.backgroundColor};
    border-width: 9px 0;
    border-style: solid;
    border-color: transparent;
    align-self: center;
    cursor: pointer;
    ${(props): string =>
        props.isFacingLeft
            ? `border-right-color: ${props.color};
            border-right-width: 10px;
            margin-right: 5px;
            `
            : `border-left-color: ${props.color};
            border-left-width: 10px;
            margin-left: 5px;
            `}
    outline: 0;
`;

export default ArrowButton;
