import { ComponentStory, ComponentMeta } from '@storybook/react';
import { PopUpModal } from './PopUp';
import { Title } from '@src/base-styles';

export default {
    title: 'Components/PopUp',
    component: PopUpModal,
} as ComponentMeta<typeof PopUpModal>;

export const PopUpComponent: ComponentStory<typeof PopUpModal> = () => (
    <PopUpModal show={true} title={''}>
        <Title align="center" justify="center" font="100">
            Pop up Modal
        </Title>
    </PopUpModal>
);
