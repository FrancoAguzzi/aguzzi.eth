import styled from 'styled-components';
import { NumbersSelected } from '@sportech/pools-api';
import { breakpoints } from '@settings/breakpoints';

export interface MatchCardTeamsProp {
    /**
     * A label to show on the button
     */
    homeTeam: string;
    awayTeam: string;
    number: number;
    action?: (id: number, type: string) => void;
    MatchID: number;
    numbers?: NumbersSelected | undefined;
    isViewLines: boolean;
    isLineMissingSelection?: boolean;
}

export interface MatchCardTeamsStyleProp {
    numbers?: NumbersSelected | undefined;
    isViewLines: boolean;
    isLineMissingSelection?: boolean;
}

export const MatchCardTeams: React.FC<MatchCardTeamsProp> = props => {
    return (
        <MatchCardDiv
            numbers={props.numbers}
            isViewLines={props.isViewLines}
            onClick={(): void => {
                if (!props.isViewLines && props.action !== undefined) {
                    props.action(props.number, 'D');
                }
            }}
            isLineMissingSelection={props.isLineMissingSelection}
        >
            <NumberDiv isViewLines={props.isViewLines} numbers={props.numbers}>
                {props.number}
            </NumberDiv>
            <TeamsDiv>
                <HomeDiv>{props.homeTeam}</HomeDiv>
                <AwayDiv>{props.awayTeam}</AwayDiv>
            </TeamsDiv>
        </MatchCardDiv>
    );
};

const NumberDiv = styled.div<MatchCardTeamsStyleProp>`
    width: 50px;
    line-height: inherit;
    text-align: center;
    color: ${(props): string => (props.numbers ? '#fff' : 'inherit')};
    position: relative;
    background: transparent;
    font-size: 16px;
    margin-left: 3px;

    :after {
        content: '';
        height: 75%;
        width: 1px;

        position: absolute;
        right: 0;
        top: 12.5%;

        background-color: ${(props): string => (props.numbers ? '#fff' : '#000')};
    }

    ${breakpoints.below('lg')} {
        width: 20%;
    }
`;

const MatchCardDiv = styled.div<MatchCardTeamsStyleProp>`
    color: #011fb3;
    background-color: #fff;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;

    height: 42px;
    line-height: 42px;
    border: 1px solid #000;

    border-radius: 5px;
    position: relative;
    z-index: 1;
    background: ${(props): string => (props.numbers ? props.theme.colours.gameMainColor : '#fff')};
    color: ${(props): string => (props.numbers ? '#fff' : '#000')};

    &:before {
        background: ${(props): string => props.theme.colours.gameMainColor};
    }
    ${breakpoints.above('lg')} {
        ${(props): string | undefined => {
            if (
                !props.isViewLines &&
                (props.isLineMissingSelection || (props.numbers && !props.isLineMissingSelection))
            ) {
                return `
                        &:hover {
                            cursor: pointer;
                        }`;
            }
        }}
        ${(props): string | undefined => {
            if (!props.isViewLines && !props.numbers && props.isLineMissingSelection) {
                return `
                    &:hover {
                        color: #fff;
                        background: #363636;
                    }
                    &:hover ${NumberDiv}:after {
                        background-color: #fff;
                    }
            `;
            }
        }}
    }
`;

const TeamsDiv = styled.div`
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 10px;
    flex-direction: column;
    width: 63%;
`;

const HomeDiv = styled.div`
    font-weight: 600;
    width: 100%;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    line-height: 16px;
`;

const AwayDiv = styled.div`
    font-weight: 600;
    width: 100%;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    line-height: 16px;
`;
