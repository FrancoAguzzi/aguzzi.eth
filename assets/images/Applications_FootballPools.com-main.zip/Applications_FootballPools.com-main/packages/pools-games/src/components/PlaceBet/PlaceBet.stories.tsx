import { ComponentStory, ComponentMeta } from '@storybook/react';
import { PlaceBet } from './PlaceBet';

export default {
    title: 'Components/PlaceBet',
    component: PlaceBet,
} as ComponentMeta<typeof PlaceBet>;

export const PrimaryButton: ComponentStory<typeof PlaceBet> = () => (
    <>
        <PlaceBet
            setGameDays={() => null}
            setNumberOfWeeks={() => null}
            numberOfWeeks="ONE"
            gameDays={['SAT']}
            checkoutQuick={false}
            isMobile={false}
            widthScreen={1}
        />
    </>
);
