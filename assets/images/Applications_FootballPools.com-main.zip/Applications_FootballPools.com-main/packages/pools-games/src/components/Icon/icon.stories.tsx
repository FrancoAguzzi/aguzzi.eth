/* eslint-disable import/no-unresolved */
import { ComponentStory, ComponentMeta } from '@storybook/react';
import PencilEdit from 'public/svg/pencilEdit.svg';
import DiceWhite from 'public/svg/diceWhite.svg';
import { Icon } from './icon';

export default {
    title: 'Components/Icon',
    component: Icon,
} as ComponentMeta<typeof Icon>;

export const IconChildren: ComponentStory<typeof Icon> = () => (
    <Icon area={200} fontSize={'25px'} onClick={() => null} id={0}>
        X
    </Icon>
);
export const IconPencil: ComponentStory<typeof Icon> = () => (
    <Icon area={200} fontSize={'25px'} onClick={() => null} id={0}>
        <PencilEdit />
    </Icon>
);
export const IconDice: ComponentStory<typeof Icon> = () => (
    <Icon area={200} fontSize={'25px'} onClick={() => null} id={0}>
        <DiceWhite />
    </Icon>
);
