import styled from 'styled-components';
import { breakpointValues } from '@settings/breakpoints';
import CheckIcon from 'public/svg/check.svg';

export const BetSlipContainer = styled.div`
    max-width: ${breakpointValues.xxs};
    margin-left: auto;
    margin-right: auto;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    display: flex row;
    flex-direction: column;
    align-items: center;
    font-weight: 100;
`;

export const BaseBetSlip = styled.button`
    display: flex;
    background-color: #188be9;
    justify-content: space-between;
    color: #fff;
    border: 1px solid #fff;
    border-radius: 25px;
    font-weight: 100;
    padding: 0.3rem 15px 0.3rem 15px;
    @media (max-width: ${breakpointValues.xs}px) {
        padding: 0 0 0 0;
    }
    @media (min-width: 375px) {
        width: 370px;
    }
    @media (max-width: 375px) {
        width: 300px;
    }
`;

export const BaseDiv = styled.div<{ width?: string; margin?: string }>`
    display: flex;
    align-items: center;
    background-color: #188be9;
    justify-content: center;
    min-height: 110px;
    @media (max-width: ${breakpointValues.xs}px) {
        height: auto;
        min-height: auto;
    }
    width: ${(props): string => (props.width ? props.width : '100%')};
    padding-top: 4px;
    border-top: 4px solid #40c7ba;
    border-right: 0px;
    border-left: 0px;
    border-bottom: 0px;
    box-shadow: 2px 10px 23px 7px rgba(0, 0, 0, 0.5);
    position: relative;
    bottom: 0;
    z-index: 20;
    margin: ${(props): string => (props.margin ? props.margin : '0 0 0 0')};
`;

export const TextLeft = styled.span`
    display: flex;
    align-items: center;
    margin-left: 10px;
    border-radius: 25px;
    height: 30px;
    font-size: 14px;
    @media (max-width: ${breakpointValues.xs}px) {
        font-size: 10px;
    }
`;

export const TextRight = styled.span`
    display: flex;
    align-items: center;
    margin-right: 10px;
    border-radius: 25px;
    height: 30px;
    font-size: 16px;
    @media (max-width: ${breakpointValues.xs}px) {
        font-size: 11px;
    }
`;

export const Icon = styled(CheckIcon)`
    margin-right: 1rem;
    margin-bottom: 3px;
`;
