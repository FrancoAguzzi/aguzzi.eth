import { Picker } from './Picker';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';

describe('Picker Component', () => {
    // Test should render
    it('should render', () => {
        const { container } = render(
            <Picker
                pickerTitle={'Pick 6 and 1 bonus'}
                show={true}
                close={() => null}
                onDonePickingClick={() => null}
                heightModalInitial={600}
                selectionMatrices={['1', '2', '3', '4', '5', '6', '7']}
                isLoading={false}
                lines={[
                    {
                        selection: [],
                        amount: 6,
                        row: 1,
                        isCurrent: false,
                        handleOnClickNumber: () => null,
                    },
                ]}
                currentPick={1}
                memPicks={{}}
                currentPickSelection={''}
                total={100}
                widthScreen={600}
                linesBetslip={6}
                onClick={() => null}
                isShowingPicker={true}
                gameDays={[]}
                isMobile={false}
                setOpenTwoLinesErrorPopUp={() => null}
            />,
        );

        expect(container).toMatchSnapshot();
    });
});
