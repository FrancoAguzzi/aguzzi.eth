import { ComponentStory, ComponentMeta } from '@storybook/react';
import { HowToPlay } from './HowToPlay';

export default {
    title: 'Components/HowToPlay',
    component: HowToPlay,
} as ComponentMeta<typeof HowToPlay>;
export const PrimaryButton: ComponentStory<typeof HowToPlay> = () => (
    <HowToPlay
        show={false}
        close={() => null}
        HowToPlayContent={'How to play instructions...'}
        HowToPlayTitle={'How To Play'}
        heightModalInitial={0.8}
    />
);
