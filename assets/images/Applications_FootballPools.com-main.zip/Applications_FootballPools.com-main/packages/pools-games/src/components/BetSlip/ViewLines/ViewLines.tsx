/* eslint-disable prettier/prettier */
import styled, { ThemeContext } from 'styled-components';
import { FunctionComponent, useContext, useEffect } from 'react';
import { Offerings, Competition as Comps, Competition, Offering, Wager } from '@sportech/pools-api';
import { breakpoints } from '@settings/breakpoints';
import { ViewLinesItem } from './ViewLinesItem';
import { arrayOfCompetitionIds } from '@src/utils/functionUtils';
import { GameModel } from '@interfaces/PoolGames/GameModel';

interface ViewLinesProps {
    offers: Offerings;
    competitions?: Comps[];
    gameModel: GameModel;
    wagers?: Wager[];
    setViewLinesCurrent?: (val: number) => void;
    viewLinesCurrent?: number;
    isMobile?: boolean;
}

export const ViewLines: FunctionComponent<ViewLinesProps> = props => {
    const themeContext = useContext(ThemeContext);
    const moreThanOneViewLinesWager = props.wagers !== undefined ? props.wagers.length > 1 : false;
    useEffect(() => {
        if (
            props.wagers !== undefined &&
            props.wagers !== null &&
            props.wagers.length > 0 &&
            props.viewLinesCurrent === 0 &&
            !props.isMobile &&
            props.setViewLinesCurrent !== undefined
        ) {
            props.setViewLinesCurrent(props.wagers[0].wagerId as number);
        }
    });

    const handleViewLineItemClick = (wagerId: number): void => {
        if (props.setViewLinesCurrent !== undefined) {
            props.setViewLinesCurrent(wagerId);
        }
    };

    return (
        <>
            {props.wagers !== undefined && props.wagers !== null && props.wagers.length > 0 ? (
                props.wagers.map((item, index) => (
                    <div key={'WagerList' + index}>
                        <div key={'WagerSection' + index}>
                            <StyledViewLineItemContainer
                                isActiveViewLine={item.wagerId === props.viewLinesCurrent}
                                isActiveColor={themeContext.colours.gameMainColor}
                                onClick={(): void => {
                                    if (!props.isMobile) {
                                        handleViewLineItemClick(item.wagerId as number);
                                    }
                                }}
                                moreThanOneViewLinesWager={moreThanOneViewLinesWager}
                            >
                                <ViewLinesItem
                                    wager={item}
                                    competition={
                                        props.gameModel.isClover()
                                            ? (props.competitions?.find(x =>
                                                  arrayOfCompetitionIds(
                                                      x.competitionIds as {
                                                          [key: string]: number;
                                                      },
                                                  ).includes(item.competitionId as number),
                                              ) as Competition)
                                            : (props.competitions?.find(
                                                  x => x.id === item.competitionId,
                                              ) as Competition)
                                    }
                                    offering={props.offers.offerings.find(x => x.id === item.offeringId) as Offering}
                                    index={index}
                                    nothda={!props.gameModel.isHDA()}
                                    gameModel={props.gameModel}
                                ></ViewLinesItem>
                            </StyledViewLineItemContainer>
                        </div>
                    </div>
                ))
            ) : (
                <p>No lines for competitions starting within the next 8 days</p>
            )}
        </>
    );
};
type StyledViewLineItemContainerProps = {
    isActiveViewLine: boolean;
    isActiveColor: string;
    moreThanOneViewLinesWager: boolean;
};
const StyledViewLineItemContainer = styled.div<StyledViewLineItemContainerProps>`
    ${breakpoints.above('lg')} {
        cursor: ${(props): string =>
            props.moreThanOneViewLinesWager && !props.isActiveViewLine ? 'pointer' : 'default'};
    }
    background: #eaeaea;
    margin-bottom: 10px;
    ${(props): string | undefined => {
        if (props.isActiveViewLine) {
            return `    
            border: 2px solid ${props.isActiveColor};
        `;
        }
    }}
`;
