import { useEffect, useState } from 'react';
import { Container } from '@containers/Lucky4Life/container';
import { breakpointValues } from '@settings/breakpoints';
import { ButtonX, ModalHandle, ModalContent, Content, Title } from './Picker.styles';

/**
 * Modal props
 *  @param show boolean to know if the modal is show or not.
 *  @param title Title which is shown in the top modal.
 *  @param close handle to close modal.
 *  @param children children info component.
 *  @param heightModalInitial Modal height initial.
 *  @param direction: direction flex type for title;
 *  @param align: align type for title;
 *  @param justify: justiry type for title;
 */
interface Props {
    show: boolean;
    title: string;
    children?: React.ReactNode;
    close: () => void;
    heightModalInitial: number;
    font: fontType;
    align: alignType;
    justify: justifyType;
}

export type fontType = '100' | 'bold';
export type alignType = 'start' | 'center' | 'end';
export type justifyType = 'start' | 'center' | 'end' | 'space-between' | 'space-around';

export const Modal = ({ show, close, children, title, font, align, justify }: Props): JSX.Element => {
    /* Mobile data for responsive mobile view */
    const [isMobile, setIsMobile] = useState(window.innerWidth <= breakpointValues.sm);
    const handleResize = (): void => {
        setIsMobile(window.innerWidth <= breakpointValues.sm);
    };
    const height = screen.height;

    useEffect(() => {
        window.addEventListener('resize', handleResize, false);

        return () => window.removeEventListener('resize', handleResize, false);
    }, []);

    /* function to dragEnd event ends */
    function handleDragEnd(e: { screenY: number }) {
        if (e.screenY > height * 0.2) setTimeout(close, 100);
    }

    /* useEffect for the position top of the div move*/
    useEffect(() => {
        const box = document.getElementById('picker');
        if (box && isMobile) {
            /* Function for the touch screen mobile move*/
            box?.addEventListener(
                'touchend',
                e => {
                    e.stopPropagation();

                    const touchLocation = e.changedTouches[0].clientY;

                    if (touchLocation > height * 0.2 && show) {
                        close();
                    }
                },
                { passive: true },
            );
        }
    }, [show]);

    return (
        <>
            <ModalContent show={show}>
                <Container direction={'column'} align={'center'} justify={'space-between'} width={'100%'} id="picker">
                    <ModalHandle draggable onDragEnd={handleDragEnd}>
                        <ButtonX></ButtonX>
                    </ModalHandle>
                </Container>
                <Title font={font} align={align} justify={justify}>
                    {title}
                </Title>
                <Content>{children}</Content>
            </ModalContent>
        </>
    );
};
