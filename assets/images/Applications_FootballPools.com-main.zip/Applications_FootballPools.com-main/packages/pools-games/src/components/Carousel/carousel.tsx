import styled from 'styled-components';
import { breakpoints } from '../../settings/breakpoints';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import Slider from 'react-slick';

const CarouselWrapper = styled.div`
    width: 100vw;
    margin: 0 auto 30px auto;
    padding: 0;
    height: 25vw;
    ${breakpoints.above('sm')} {
        max-height: 25vw;
    }
    ${breakpoints.above('lg')} {
        width: 95vw;
        max-width: 1306px;
        margin: auto;
        height: auto;
    }
`;

const CarouselContainer = styled(Slider)`
    @media (min-width: 1024px and max-width: 1340px) {
        max-height: 25vw;
    }
    max-width: 1360px;
    max-height: 335px;
    margin-bottom: 30px;
    height: 100%;
    & > button {
        z-index: 1;
        height: 100%;
        width: 5vw;
        &:before {
            color: black;
        }
    }
    ul li button {
        &:before {
            font-size: 10px;
        }
    }
    .slick-prev {
        left: -10px;
        ${breakpoints.above('l')} {
            left: -60px;
        }
    }
    .slick-next {
        right: -10px;
        ${breakpoints.above('l')} {
            right: -60px;
        }
    }
    .slick-list {
        overflow: hidden;
        height: 100%;
    }
`;

interface Props {
    children: React.ReactNode;
    draggable: boolean;
    infinite: boolean;
    swipe: boolean;
}

export const Carousel = ({ children, draggable, infinite, swipe }: Props): JSX.Element => {
    const settings = {
        dots: true,
        infinite: infinite,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: false,
        autoplaySpeed: 5000,
        draggable: draggable,
        swipe: swipe,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    arrows: false,
                },
            },
        ],
    };
    return (
        <CarouselWrapper>
            <CarouselContainer {...settings}>{children}</CarouselContainer>
        </CarouselWrapper>
    );
};
