import { render } from '@testing-library/react';
import 'jest-styled-components';
import { NumbersCard } from './NumbersCard';
import { renderWithTheme } from '@testing/utils/renderWithTheme';

// jest.mock('@settings/breakpoints');

describe('Numbers Card', () => {
    it('should match snapshot', () => {
        const { container } = renderWithTheme(<NumbersCard number={1} isResults={false} />);

        expect(container).toMatchSnapshot();
    });
});
