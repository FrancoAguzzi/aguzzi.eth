import { ComponentStory, ComponentMeta } from '@storybook/react';
import { Modal } from './Modal';

export default {
    title: 'Components/PickerModal',
    component: Modal,
} as ComponentMeta<typeof Modal>;

export const PrimaryButton: ComponentStory<typeof Modal> = () => (
    <Modal
        show={false}
        close={() => console.debug('')}
        title={'Pick 5 and 1 bonus'}
        heightModalInitial={500}
        font={'100'}
        align={'center'}
        justify={'center'}
    >
        Modal
    </Modal>
);
