import { ComponentStory, ComponentMeta } from '@storybook/react';
import { CircleList } from './circleList';

export default {
    title: 'Components/CircleList',
    component: CircleList,
} as ComponentMeta<typeof CircleList>;

export const CircleSelected: ComponentStory<typeof CircleList> = () => (
    <CircleList
        selected={[true, true, false, true, false]}
        area={200}
        selection={[1, 2, 3, 4, 5]}
        amount={5}
        row={1}
        displayId={true}
        isCurrent={true}
        handleOnClick={() => null}
        diceButton={true}
        editButton={true}
        border={false}
        handleOnClickDice={() => null}
        handleOnClickEdit={() => null}
        handleOnClickDelete={() => null}
    />
);
export const CircleNotSelected: ComponentStory<typeof CircleList> = () => (
    <CircleList
        area={200}
        selected={[false, false, false, false, false]}
        selection={[15, 17, 22, 1, 9, 12]}
        amount={5}
        row={1}
        displayId={true}
        isCurrent={true}
        handleOnClick={() => null}
        diceButton={true}
        editButton={true}
        handleOnClickDice={() => null}
        handleOnClickEdit={() => null}
        handleOnClickDelete={() => null}
    />
);
export const CircleWithoutButtons: ComponentStory<typeof CircleList> = () => (
    <CircleList
        area={200}
        selected={[false, false, false, false, false]}
        selection={[15, 17, 22, 1, 9, 12]}
        amount={5}
        row={1}
        displayId={true}
        isCurrent={true}
        handleOnClick={() => null}
        diceButton={false}
        editButton={false}
        handleOnClickDice={() => null}
        handleOnClickEdit={() => null}
        handleOnClickDelete={() => null}
    />
);
export const CircleWithEdit: ComponentStory<typeof CircleList> = () => (
    <CircleList
        selected={[false, false, false, false, false]}
        selection={[15, 17, 22, 1, 9, 12]}
        amount={5}
        row={1}
        displayId={true}
        isCurrent={true}
        handleOnClick={() => null}
        diceButton={false}
        editButton={true}
        area={200}
        handleOnClickDice={() => null}
        handleOnClickEdit={() => null}
        handleOnClickDelete={() => null}
    />
);
export const CircleWithDice: ComponentStory<typeof CircleList> = () => (
    <CircleList
        selected={[false, false, false, false, false]}
        selection={[15, 17, 22, 1, 9, 12]}
        amount={5}
        row={1}
        displayId={true}
        isCurrent={true}
        handleOnClick={() => null}
        diceButton={true}
        editButton={false}
        area={200}
        handleOnClickDice={() => null}
        handleOnClickEdit={() => null}
        handleOnClickDelete={() => null}
    />
);
