import { ToggleButton } from './ToggleButton';
import { render, fireEvent, act } from '@testing-library/react';
import 'jest-styled-components';

const mockFn = jest.fn();
jest.mock('@settings/breakpoints');

describe('ToggleButton', () => {
    it('should render', () => {
        const { container } = render(<ToggleButton onClick={mockFn}>ToggleButton</ToggleButton>);

        expect(container).toMatchSnapshot();
    });

    it('should execute a function on click', () => {
        const { getByText } = render(<ToggleButton onClick={mockFn}>ToggleButton</ToggleButton>);

        act(() => {
            fireEvent.click(getByText(/ToggleButton/i));
        });

        expect(mockFn).toHaveBeenCalled();
    });
});
