import { Container, StyledListItem } from './icon.styles';

/**
 * @param area: proportional width to have height and width for the circles and lines. ${props.area / 6.5}px for
 * @param margin: margin between circles.
 * @param fontSize: sise of the letters in circles.
 * @param onClick: function that select de circles.
 * @param row: the number row of the line
 */
interface IconProps {
    onClick: (row: number | string) => void;
    children?: React.ReactNode;
    fontSize?: string;
    margin?: string;
    area: number;
    id: number | string;
}

export const Icon: React.FC<IconProps> = props => {
    return (
        <Container area={props.area}>
            <StyledListItem onClick={() => props.onClick(props.id)} area={props.area}>
                {props.children}
            </StyledListItem>
        </Container>
    );
};
