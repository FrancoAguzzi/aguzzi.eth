import styled from 'styled-components';
import { BetSlip, Fixture } from '@sportech/pools-api';
import { MatchCard } from '../MatchCard/MatchCard';
import { HDAMatchCard } from '../HDAMatchCard/HDAMatchCard';
import { NumbersCard } from '../NumbersCard/NumbersCard';
import { breakpoints } from '@settings/breakpoints';
import Skeleton from 'react-loading-skeleton';
import { GameModel } from '@interfaces/PoolGames/GameModel';
import { isLineMissingSelection } from '@src/utils/functionUtils';

export enum GameViewType {
    Match,
    Numbers,
}
interface GameSectionProps {
    betslipselection?: BetSlip;
    action?: (id: number, type: string) => void;
    fixtures?: Array<Fixture>;
    gameViewType: GameViewType;
    isViewLines: boolean;
    gameModel: GameModel;
}

export const GameSectionLoading: React.FC = () => {
    return (
        <GameList>
            <Skeleton width={'32%'} height={'40px'} count={30} />
        </GameList>
    );
};

export const GameSection: React.FC<GameSectionProps> = props => {
    return (
        <>
            {props.gameViewType === GameViewType.Match ? (
                <GameList>
                    {props.gameModel.isHDA()
                        ? props.fixtures?.map(item => (
                              <HDAMatchCard
                                  key={item.id}
                                  action={props.action}
                                  MatchID={item.id}
                                  number={item.number}
                                  IsHda={props.gameModel.isHDA()}
                                  homeTeam={item.homeTeamDisplay}
                                  awayTeam={item.awayTeamDisplay}
                                  numbers={
                                      props.betslipselection && props.betslipselection.numbers
                                          ? props.betslipselection.numbers?.find(x => x?.Id === item.number)
                                          : undefined
                                  }
                                  IsResults={false}
                                  IsViewLines={props.isViewLines}
                              ></HDAMatchCard>
                          ))
                        : props.fixtures?.map(item => (
                              <MatchCard
                                  key={item.id}
                                  action={props.action}
                                  MatchID={item.id}
                                  number={item.number}
                                  IsHda={props.gameModel.isHDA()}
                                  homeTeam={item.homeTeamDisplay}
                                  awayTeam={item.awayTeamDisplay}
                                  numbers={
                                      props.betslipselection && props.betslipselection.numbers
                                          ? props.betslipselection.numbers?.find(x => x?.Id === item.number)
                                          : undefined
                                  }
                                  IsResults={false}
                                  isViewLines={props.isViewLines}
                                  isLineMissingSelection={isLineMissingSelection(props.betslipselection as BetSlip)}
                              ></MatchCard>
                          ))}
                    <EmptyMatchCard aria-hidden="true" />
                    <EmptyMatchCard aria-hidden="true" />
                </GameList>
            ) : (
                <NumbersGameList>
                    {props.fixtures?.map(item => (
                        <NumbersCard
                            key={item.id}
                            action={props.action}
                            number={item.number}
                            numbers={
                                props.betslipselection && props.betslipselection.numbers
                                    ? props.betslipselection.numbers?.find(x => x?.Id === item.number)
                                    : undefined
                            }
                            bonusNumbers={
                                props.betslipselection && props.betslipselection.bonusNumbers
                                    ? props.betslipselection.bonusNumbers?.find(x => x?.Id === item.number)
                                    : undefined
                            }
                            isResults={false}
                            isViewLines={props.isViewLines}
                            isLineMissingSelection={isLineMissingSelection(props.betslipselection as BetSlip)}
                        ></NumbersCard>
                    ))}
                    {/* used to align bottom row of flex-wrap with the rest of the rows */}
                    <EmptyNumbersCard aria-hidden="true" />
                    <EmptyNumbersCard aria-hidden="true" />
                    <EmptyNumbersCard aria-hidden="true" />
                    <EmptyNumbersCard aria-hidden="true" />
                    <EmptyNumbersCard aria-hidden="true" />
                    <EmptyNumbersCard aria-hidden="true" />
                    <EmptyNumbersCard aria-hidden="true" />
                    <EmptyNumbersCard aria-hidden="true" />
                    <EmptyNumbersCard aria-hidden="true" />
                </NumbersGameList>
            )}
        </>
    );
};

const GameList = styled.ul`
    list-style: none;
    padding-left: 0px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;

    > span {
        width: 100%;
        > span {
            width: 31%;
            margin: 0.5%;
            float: left;
            font-size: 12px;
        }
    }
`;

const NumbersGameList = styled.ul`
    display: flex;
    flex-wrap: wrap;
    list-style: none;
    justify-content: center;
    padding-left: 0px;
    width: 100%;
`;

const EmptyMatchCard = styled.i`
    width: 31%;
    margin: 0.5%;
    float: left;
    font-size: 13px;
    ${breakpoints.below('lg')} {
        width: 46%;
        font-size: 12px;
    }
`;

const EmptyNumbersCard = styled.i`
    width: 80px;
    margin: 0.5% 10px;
    ${breakpoints.below('sm')} {
        margin: 0.5% 0;
        width: 70px;
    }
`;
