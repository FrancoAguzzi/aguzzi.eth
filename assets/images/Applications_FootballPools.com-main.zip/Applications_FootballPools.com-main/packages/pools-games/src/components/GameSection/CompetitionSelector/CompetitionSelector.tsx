import styled from 'styled-components';
import { BetSlip, Competition } from '@sportech/pools-api';
import { useDispatch } from 'react-redux';
import { openPopup } from '@features/popups/popupsSlice';
import { RemoveSoccer6Name } from '@src/utils/functionUtils';

interface CompetitionSelectorProp {
    competitions: Competition[];
    currentCompetition: number;
    ChangeCompetitions: (id: number, desc: string) => void;
    BetSlipSelection: Array<BetSlip>;
}

interface CompetitionsStyleprops {
    length?: number;
    active?: boolean;
    offset?: number;
}

export const CompetitionSelector: React.FC<CompetitionSelectorProp> = props => {
    const dispatch = useDispatch();
    const BetslipCurrentSelection = props.BetSlipSelection.filter(x => x.current)[0];
    const currentSelectedIndex: number = props.competitions.findIndex(x => props.currentCompetition === x.id);
    const calculatedoffset: number = currentSelectedIndex * -130 + 10;
    return (
        <>
            <ContainerStyle>
                <LeftArrowButtonStyle
                    onClick={(): void => {
                        const index = props.competitions.findIndex(x => props.currentCompetition === x.id);
                        if (index > 0) {
                            if (
                                BetslipCurrentSelection.pick === BetslipCurrentSelection.numbers?.length ||
                                BetslipCurrentSelection.numbers?.length === 0
                            ) {
                                props.ChangeCompetitions(
                                    props.competitions[index - 1].id,
                                    props.competitions[index - 1].description,
                                );
                            } else {
                                dispatch(openPopup('error_on_change_betslip_line'));
                            }
                        }
                    }}
                />
                <ScrollStyle>
                    <CompetitionsStyle length={props.competitions.length} offset={calculatedoffset}>
                        {props.competitions.map(item => (
                            <ComButtonStyle
                                onClick={(): void => {
                                    if (props.currentCompetition !== item.id) {
                                        if (
                                            BetslipCurrentSelection.pick === BetslipCurrentSelection.numbers?.length ||
                                            BetslipCurrentSelection.numbers?.length === 0
                                        ) {
                                            props.ChangeCompetitions(item.id, item.description);
                                        } else {
                                            dispatch(openPopup('error_on_change_betslip_line'));
                                        }
                                    }
                                }}
                                active={props.currentCompetition === item.id}
                                key={item.id}
                            >
                                {RemoveSoccer6Name(item.description)}
                            </ComButtonStyle>
                        ))}
                    </CompetitionsStyle>
                </ScrollStyle>
                <RightArrowButtonStyle
                    onClick={(): void => {
                        const index = props.competitions.findIndex(x => props.currentCompetition === x.id);
                        if (index < props.competitions.length - 1) {
                            if (
                                BetslipCurrentSelection.pick === BetslipCurrentSelection.numbers?.length ||
                                BetslipCurrentSelection.numbers?.length === 0
                            ) {
                                props.ChangeCompetitions(
                                    props.competitions[index + 1].id,
                                    props.competitions[index + 1].description,
                                );
                            } else {
                                dispatch(openPopup('error_on_change_betslip_line'));
                            }
                        }
                    }}
                />
            </ContainerStyle>
        </>
    );
};

const ContainerStyle = styled.div`
    margin-top: 10px;
    display: flex;
    justify-content: space-between;
    overflow-x: hidden;
    height: 55px;
    background: #eaeaea;
`;

const ScrollStyle = styled.div`
    overflow-x: visible;
    margin: 0 5px;
    width: 100%;
    position: relative;
`;

const CompetitionsStyle = styled.div<CompetitionsStyleprops>`
    white-space: nowrap;
    position: absolute;
    left: 100%;
    transition: left 0.5s ease-in-out;
    left: ${(props): string => (props.offset ? `calc((50% - 70px) + ${props.offset}px)` : 'calc(50% + -50px)')};
`;

const LeftArrowButtonStyle = styled.button`
    cursor: pointer;
    width: 30px;
    background: ${(props): string => props.theme.colours.gameMainColor};
    border: none;
    flex-shrink: 0;
    z-index: 4;
    &::after {
        content: '';
        border-style: solid;
        font-size: 0;
        margin-top: 3px;
        display: inline-block;
        border-width: 9px 10px 9px 0;
        border-color: transparent #fff transparent transparent;
    }
`;

const RightArrowButtonStyle = styled.button`
    cursor: pointer;
    width: 30px;
    background: ${(props): string => props.theme.colours.gameMainColor};
    border: none;
    flex-shrink: 0;
    z-index: 4;
    &::after {
        content: '';
        border-style: solid;
        font-size: 0;
        margin-top: 3px;
        display: inline-block;
        border-width: 9px 0 9px 10px;
        border-color: transparent transparent transparent #fff;
    }
`;

const ComButtonStyle = styled.button<CompetitionsStyleprops>`
    display: inline-block;
    min-width: 120px;
    max-width: 200px;

    height: 55px;
    padding: 8px 17px 17px;
    font-size: 17.5px;
    line-height: 40px;
    border: none;
    border-left: 3px solid #fff;
    border-right: 3px solid #fff;
    font-weight: 500;
    cursor: pointer;
    background: ${(props): string => (props.active ? props.theme.colours.gameMainColor : '#EAEAEA')};
    color: ${(props): string => (props.active ? '#fff' : '#000')};
    /* box-shadow: ${(props): string => (props.active ? '2px 2px 0 0 #c0c0c0' : '')}; */
    outline: 0;
`;
