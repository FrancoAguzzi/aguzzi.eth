import styled from 'styled-components';
import { Button } from '@components/Common/Button/Button';
import { BetSlipCircleList } from '../BetSlipCircleList/BetSlipCircleList';
import { Offerings, BetSlip, Offering, Competition } from '@sportech/pools-api';
import React, { forwardRef, useEffect } from 'react';
import { OfferingList } from '@components/OfferingList/OfferingList';
import { useDispatch } from 'react-redux';
import { openPopup } from '@features/popups/popupsSlice';
import { isAddedLineDisabled, RemoveGameName, RemoveSoccer6Name } from '@src/utils/functionUtils';
import { Container } from '@components/Styles/defaultPageStyles';
import { GameModel } from '@interfaces/PoolGames/GameModel';

interface BetSlipItemProps {
    betslipselection: BetSlip;
    SelectAmountAction: (id: number, amount: Offering) => void;
    ClearLine: () => void;
    AddLine: () => void;
    ChangeBet: () => void;
    offers: Offerings;
    betslipCurrentSelection: BetSlip;
    moreThanOneLine: boolean;
    handleCircleNumberClick: (id: number, displayId: string) => void;
    setCurrentOfferingId: (val: number) => void;
    setShowMore: (val: boolean) => void;
    showMoreValue: boolean;
    currentOfferingId: number;
    competition: Competition;
    gameModel: GameModel;
}

export const BetSlipItem = forwardRef<HTMLDivElement, BetSlipItemProps>((props, ref) => {
    const dispatch = useDispatch();

    const updateCurrentOfferingId = (item: BetSlip): void => {
        props.setCurrentOfferingId(item.priceID);
        props.setShowMore(false);
    };

    useEffect(() => {
        updateCurrentOfferingId(props.betslipCurrentSelection);
    }, [props.betslipselection]);
    return (
        <>
            <StyledListItem
                ref={props.betslipselection.current ? ref : null}
                onClick={(): void => {
                    if (!props.betslipselection.current) {
                        if (
                            props.betslipCurrentSelection.pick === props.betslipCurrentSelection.numbers?.length ||
                            props.betslipCurrentSelection.numbers?.length === 0
                        ) {
                            props.ChangeBet();
                        } else {
                            dispatch(openPopup('error_on_change_betslip_line'));
                        }
                    }
                }}
                isCurrent={props.betslipselection.current}
            >
                {props.betslipselection.current && (
                    <OfferingList
                        setShowMore={props.setShowMore}
                        showMoreValue={props.showMoreValue}
                        setCurrentOfferingId={props.setCurrentOfferingId}
                        currentOfferingId={props.currentOfferingId}
                        offerings={props.offers}
                        currentSlip={props.betslipCurrentSelection}
                        selectAmount={props.SelectAmountAction}
                        gameModel={props.gameModel}
                    ></OfferingList>
                )}
                {!props.gameModel.isClover() && (
                    <StyledDescAndClearContainer>
                        <StyledListh4>
                            {RemoveGameName(
                                props.offers.offerings.find(x => x.id === props.betslipselection.priceID)?.description,
                            )}{' '}
                            £{(props.betslipselection.price / 100).toFixed(2)} <br />
                            <strong>{RemoveSoccer6Name(props.betslipselection?.competitionName)}</strong>
                        </StyledListh4>

                        {props.betslipselection.current && (
                            <StyledListClear onClick={props.ClearLine}>
                                <img src="/close.png" />
                            </StyledListClear>
                        )}
                    </StyledDescAndClearContainer>
                )}
                <StyledNumberedList isClover={props.gameModel.isClover()}>
                    <Container>
                        <BetSlipCircleList
                            selection={props.betslipselection.numbers}
                            displayId={!props.gameModel.isHDA()}
                            row={0}
                            amount={props.betslipselection.pick}
                            handleOnClick={props.handleCircleNumberClick}
                            isCurrent={props.betslipselection.current}
                            isClover={props.gameModel.isClover()}
                            ballColor={props.gameModel.isClover() ? '#00955C' : '#000'}
                            isPick12Selection={
                                props.offers.offerings.find(x => x.id === props.betslipselection.priceID)
                                    ?.maximumSelections === 12
                            }
                        ></BetSlipCircleList>
                        {props.gameModel.isClover() && (
                            <>
                                <p>Bonus</p>
                                <BetSlipCircleList
                                    selection={props.betslipselection.bonusNumbers}
                                    displayId={!props.gameModel.isHDA()}
                                    row={2}
                                    amount={props.betslipselection.bonusPick}
                                    handleOnClick={props.handleCircleNumberClick}
                                    isCurrent={props.betslipselection.current}
                                    isClover={props.gameModel.isClover()}
                                    ballColor={'#E0AC00'}
                                ></BetSlipCircleList>
                            </>
                        )}
                    </Container>
                    {props.betslipselection.current && props.gameModel.isClover() && (
                        <StyledListClear onClick={props.ClearLine}>
                            <img src="/close.png" />
                        </StyledListClear>
                    )}
                    {props.betslipselection.highestRow && props.betslipselection.highestRow >= 2 ? (
                        <>
                            <Container>
                                <BetSlipCircleList
                                    selection={props.betslipselection.numbers}
                                    displayId={!props.gameModel.isHDA()}
                                    row={1}
                                    amount={props.betslipselection.pick}
                                    handleOnClick={props.handleCircleNumberClick}
                                    isCurrent={props.betslipselection.current}
                                    isPick12Selection={
                                        props.offers.offerings.find(x => x.id === props.betslipselection.priceID)
                                            ?.maximumSelections === 12
                                    }
                                    ballColor={'#000'}
                                ></BetSlipCircleList>
                            </Container>
                        </>
                    ) : (
                        <></>
                    )}
                    {props.betslipselection.highestRow && props.betslipselection.highestRow >= 3 ? (
                        <>
                            <Container>
                                <BetSlipCircleList
                                    selection={props.betslipselection.numbers}
                                    displayId={!props.gameModel.isHDA()}
                                    row={2}
                                    amount={props.betslipselection.pick}
                                    handleOnClick={props.handleCircleNumberClick}
                                    isCurrent={props.betslipselection.current}
                                    isPick12Selection={
                                        props.offers.offerings.find(x => x.id === props.betslipselection.priceID)
                                            ?.maximumSelections === 12
                                    }
                                    ballColor={'#000'}
                                ></BetSlipCircleList>
                            </Container>
                        </>
                    ) : (
                        <></>
                    )}
                </StyledNumberedList>

                {props.betslipselection.current && (
                    <DivButtonContainer>
                        <Button
                            onClick={(): void => {
                                props.AddLine();
                            }}
                            disabled={isAddedLineDisabled(props.betslipselection)}
                            bgColor={'#22A2FF'}
                            width={'100%'}
                            height={'auto'}
                            padding={'0.75em 1em'}
                            textColor={'#ffffff'}
                        >
                            ADD LINE
                        </Button>
                    </DivButtonContainer>
                )}
            </StyledListItem>
        </>
    );
});

type StyledListItemProps = {
    isCurrent: boolean;
};

const StyledListItem = styled.div<StyledListItemProps>`
    margin-bottom: 5px;
    background: #f5f5f5;
    cursor: ${(props): string => (props.isCurrent ? 'default' : 'pointer')};
    padding: 0;
    width: 100%;
`;

const StyledDescAndClearContainer = styled.div`
    h4 {
        width: 65%;
        display: inline-block;
    }

    a {
        margin: 10px 10px 10px 0;
        display: inline-block;
    }
`;

const StyledListClear = styled.a`
    display: block;
    color: #000;
    font-size: 0.85em;
    line-height: 1em;
    text-align: right;
    cursor: pointer;
    float: right;
    &:hover {
        text-decoration: none;
    }

    img {
        height: 16px;
        width: 16px;
    }
`;
const StyledListh4 = styled.h4`
    box-sizing: border-box;
    line-height: 1.1;
    color: inherit;
    margin-top: 10px;
    margin-bottom: 10px;
    font-size: 20px;
    color: #000;
    font-weight: 400;
    font-size: 15px;
    cursor: inherit;
    padding-left: 10px;
`;

type StyledNumberedListProps = {
    isClover: boolean;
};

const StyledNumberedList = styled.div<StyledNumberedListProps>`
    display: flex;
    justify-content: flex-start;
    align-items: center;
    flex-direction: ${(props): string => (props.isClover ? 'row' : 'column')};
    flex: 1;
    margin: 0 0 0 5px;

    ul {
        flex: unset;
        width: unset;
    }
`;

const DivButtonContainer = styled.div`
    display: inline-block;
    width: 95%;
    margin: 10px 2.5%;
`;

BetSlipItem.displayName = 'BetSlipItem';

export default BetSlipItem;
