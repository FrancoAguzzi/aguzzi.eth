import { Container, ItemBackground, Bubble, StyledListItem } from './circle.styles';
/**
 * @param area: proportional width to have height and width for the circles and lines. ${props.area / 6.5}px
 * @param selected: Number selected.
 * @param isSelected: is selected number or matched.
 * @param isCurrentSelectedLine: Is the current line selected to play.
 * @param displayId: boolean to know is the number is display in the column.
 * @param fontSize: sise of the letters in circles.
 * @param margin: margin between circles.
 * @param handleOnClick: function that select de circles.
 * @param border: if the circles has borders or not.
 * @param isResults Boolean to show my results
 */
interface CircleProps {
    selected?: string | number;
    isSelected?: boolean | undefined;
    border?: boolean;
    isCurrentSelectedLine?: boolean;
    handleOnClick?: (id: number | string) => void;
    displayId?: boolean;
    area?: number;
    fontSize?: string;
    margin?: string;
    id?: number | string;
    isInLine: boolean;
    isResults?: boolean;
}

export const Circle: React.FC<CircleProps> = props => {
    return (
        <Container area={props.area} isInLine={props.isInLine} margin={props.margin}>
            <StyledListItem
                onClick={() => {
                    if (props?.handleOnClick !== undefined && props.id) {
                        return props?.handleOnClick(props.id);
                    }
                    if (props.isCurrentSelectedLine && props.selected && props?.handleOnClick !== undefined) {
                        return props?.handleOnClick(props.selected);
                    }
                }}
                isCurrentSelectedLine={props.isCurrentSelectedLine}
                area={props.area}
                fontSize={props.fontSize}
                isSelected={props.isSelected}
                border={props.border}
                isInLine={props.isInLine}
            >
                <ItemBackground isSelected={props.isSelected} isResults={props?.isResults}>
                    {props?.selected ? Number(props.selected) : ''}
                    {!props?.isResults && <Bubble />}
                </ItemBackground>
            </StyledListItem>
        </Container>
    );
};
