import { CircleList } from './circleList';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';

describe('Circle Component', () => {
    // Test should render
    it('should render', () => {
        const { container } = render(
            <CircleList
                selection={[1, 2, 3, 4, 5, 6]}
                amount={5}
                row={1}
                displayId={true}
                isCurrent={true}
                handleOnClick={() => null}
                diceButton={true}
                editButton={true}
                area={200}
                selected={[false, false, false, false, false]}
                handleOnClickDice={() => null}
                handleOnClickEdit={() => null}
                handleOnClickDelete={() => null}
            />,
        );
        expect(container).toMatchSnapshot();
        expect(container).toBeInTheDocument();
        expect(container).toHaveTextContent('2');
    });
});
