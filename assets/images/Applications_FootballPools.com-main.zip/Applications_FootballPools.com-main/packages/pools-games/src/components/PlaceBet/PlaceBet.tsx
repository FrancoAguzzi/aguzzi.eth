import { Dispatch, SetStateAction } from 'react';
import {
    DAYS,
    WEEKS,
    PICK_YOUR_DAYS,
    NUMBER_OF_WEEKS,
    BG_COLOR,
    BG_WHITE_COLOR,
    GRAY_COLOR,
    BORDER_BLACK_COLOR,
    BORDER_BLUE_COLOR,
} from './PlaceBet.constants';
import { Container } from '@containers/Lucky4Life/container';
import { Title, PlaceBetContainer, Button } from './PlaceBet.styles';

//Types
interface Props {
    setGameDays: Dispatch<SetStateAction<string[]>>;
    setNumberOfWeeks: Dispatch<SetStateAction<string>>;
    numberOfWeeks: string;
    gameDays: string[];
    checkoutQuick: boolean;
    isMobile?: boolean;
    widthScreen: number;
}
interface DaysTypes {
    day: string;
    value: string;
}

interface WeeksTypes {
    week: string;
    value: string;
}

const days = ['MON', 'THUR', 'SAT', 'SUN'];

export const PlaceBet = ({
    setGameDays,
    setNumberOfWeeks,
    numberOfWeeks,
    gameDays,
    checkoutQuick,
    isMobile,
    widthScreen,
}: Props): JSX.Element => {
    /**
     * // onClickDays: Handle click of the first part of the component (the days)
     * @param day // Day component selected in the click
     * @param index // Number of the index of the day selected
     */
    const onClickDays = (day: string) => {
        const findDay = gameDays.indexOf(day);
        if (findDay >= 0) {
            const days = gameDays;
            let daysNew: string[];
            // eslint-disable-next-line prefer-const
            daysNew = [];
            days.map((item, index) => {
                if (index !== findDay) {
                    daysNew.push(item);
                }
            });
            setGameDays(daysNew);
            return;
        }
        const finalDays = [...gameDays, day];
        finalDays.sort((a, b) => days.indexOf(a) - days.indexOf(b));
        setGameDays(finalDays);
        return;
    };

    /**
     * // onClickWeeks: Handle click of the second part of the component (the weeks)
     * @param week // Day component selected in the click
     * @param index // Number of the index of the day selected
     */
    const onClickWeeks = (week: string) => {
        setNumberOfWeeks(week);
    };
    return (
        <PlaceBetContainer checkoutQuick={checkoutQuick}>
            <Container direction={'column'} align={'center'} justify={'center'} width={'90%'}>
                <Title checkoutQuick={checkoutQuick} isMobile={isMobile}>
                    {PICK_YOUR_DAYS}
                </Title>
                <Container direction={'row'} align={'center'} justify={'center'} width={'70%'}>
                    {DAYS.map(({ value, day }: DaysTypes, index: number) => {
                        const isSelected = gameDays.includes(value);
                        return (
                            <Button
                                bgColor={isSelected ? BG_COLOR : BG_WHITE_COLOR}
                                textColor={isSelected ? BG_WHITE_COLOR : GRAY_COLOR}
                                height={widthScreen < 365 ? '33px' : '44px'}
                                width={widthScreen < 365 ? '47px' : '60px'}
                                padding={'3px'}
                                rounded={'20%'}
                                fontSize={'14px'}
                                hoverColor={BG_COLOR}
                                onClick={() => onClickDays(value)}
                                key={index}
                                margin={widthScreen < 365 ? '3px' : '5px'}
                                border={isSelected ? `1px solid ${BG_COLOR}` : BORDER_BLACK_COLOR}
                                texthoverColor={BG_WHITE_COLOR}
                            >
                                {day}
                            </Button>
                        );
                    })}
                </Container>
                <Title checkoutQuick={checkoutQuick} isMobile={isMobile}>
                    {NUMBER_OF_WEEKS}
                </Title>
                <Container direction={'row'} align={'center'} justify={'center'} width={'100%'}>
                    <Container direction={'column'} align={'center'} justify={'center'} width={'100%'}>
                        {WEEKS.map((row: Array<WeeksTypes>, key: number) => (
                            <Container direction={'row'} align={'center'} justify={'center'} width={'100%'} key={key}>
                                {row.map(({ value, week }: WeeksTypes, columnIndex: number) => {
                                    const isSelected = numberOfWeeks === value;
                                    return (
                                        <Button
                                            bgColor={isSelected ? BG_COLOR : BG_WHITE_COLOR}
                                            textColor={isSelected ? BG_WHITE_COLOR : GRAY_COLOR}
                                            height={widthScreen < 365 ? '33px' : '44px'}
                                            width={widthScreen < 365 ? '33px' : '44px'}
                                            padding={'2px'}
                                            rounded={'20%'}
                                            hoverColor={BG_COLOR}
                                            margin={widthScreen < 365 ? '0 8px 5px 8px' : '8px'}
                                            onClick={() => onClickWeeks(value)}
                                            key={columnIndex}
                                            border={isSelected ? BORDER_BLUE_COLOR : BORDER_BLACK_COLOR}
                                            texthoverColor={BG_WHITE_COLOR}
                                            fontSize={'14px'}
                                        >
                                            {week}
                                        </Button>
                                    );
                                })}
                            </Container>
                        ))}
                    </Container>
                </Container>
            </Container>
        </PlaceBetContainer>
    );
};
