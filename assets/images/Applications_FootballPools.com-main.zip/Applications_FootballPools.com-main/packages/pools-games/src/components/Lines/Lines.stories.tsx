import { ComponentStory, ComponentMeta } from '@storybook/react';
import { Lines } from './lines';

export default {
    title: 'Components/Lines',
    component: Lines,
} as ComponentMeta<typeof Lines>;

export const LinesSelected: ComponentStory<typeof Lines> = () => (
    <Lines
        selection={[1, 2, 3, 4, 5, 6]}
        selected={[true, true, false, true, false]}
        amount={6}
        row={1}
        displayId={true}
        isCurrent={true}
        area={300}
        areaContainer={300}
        handleOnClickNumber={() => null}
        diceButton={true}
        editButton={true}
        border={false}
        handleOnClickDice={() => null}
        handleOnClickEdit={() => null}
        handleOnClickDelete={() => null}
    />
);
export const LinesNoSelected: ComponentStory<typeof Lines> = () => (
    <Lines
        selection={[11, 21, 31, 41, 5]}
        selected={[false, false, false, false, false]}
        amount={6}
        row={1}
        area={200}
        areaContainer={300}
        displayId={true}
        isCurrent={true}
        handleOnClickNumber={() => null}
        diceButton={true}
        editButton={true}
        border={true}
        handleOnClickDice={() => null}
        handleOnClickEdit={() => null}
        handleOnClickDelete={() => null}
    />
);
export const LinesWithoutButtonsMob: ComponentStory<typeof Lines> = () => (
    <Lines
        selection={[11, 21, 31, 41, 5]}
        selected={[false, false, false, false, false]}
        amount={6}
        row={1}
        area={300}
        areaContainer={400}
        displayId={true}
        isCurrent={true}
        handleOnClickNumber={() => null}
        diceButton={false}
        editButton={false}
        border={true}
        handleOnClickDice={() => null}
        handleOnClickEdit={() => null}
        handleOnClickDelete={() => null}
    />
);
export const LinesWithoutButtonsDesk: ComponentStory<typeof Lines> = () => (
    <Lines
        selection={[11, 21, 31, 41, 5]}
        selected={[false, false, false, false, false]}
        amount={6}
        row={1}
        area={250}
        areaContainer={300}
        displayId={true}
        isCurrent={true}
        handleOnClickNumber={() => null}
        diceButton={false}
        editButton={false}
        border={true}
        handleOnClickDice={() => null}
        handleOnClickEdit={() => null}
        handleOnClickDelete={() => null}
    />
);
export const LinesWithDice: ComponentStory<typeof Lines> = () => (
    <Lines
        selection={[11, 21, 31, 41, 5]}
        selected={[false, false, false, false, false]}
        amount={6}
        row={1}
        area={200}
        areaContainer={300}
        displayId={true}
        isCurrent={true}
        handleOnClickNumber={() => null}
        diceButton={true}
        editButton={false}
        border={true}
        handleOnClickDice={() => null}
        handleOnClickEdit={() => null}
        handleOnClickDelete={() => null}
        isCheckout={true}
    />
);
export const LinesWithEdit: ComponentStory<typeof Lines> = () => (
    <Lines
        selection={[11, 21, 31, 41, 5]}
        selected={[false, false, false, false, false]}
        amount={6}
        row={1}
        area={200}
        areaContainer={300}
        displayId={true}
        isCurrent={true}
        handleOnClickNumber={() => null}
        diceButton={false}
        editButton={true}
        border={true}
        handleOnClickDice={() => null}
        handleOnClickEdit={() => null}
        handleOnClickDelete={() => null}
    />
);
