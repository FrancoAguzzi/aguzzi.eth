// eslint-disable-next-line import/default
import LoaderSpinner from 'react-loader-spinner';
import { FunctionComponent, useContext } from 'react';
import styled, { ThemeContext } from 'styled-components';

interface LoaderProps {
    isLoading: boolean;
    loaderType?:
        | 'Audio'
        | 'BallTriangle'
        | 'Bars'
        | 'Circles'
        | 'Grid'
        | 'Hearts'
        | 'Oval'
        | 'Puff'
        | 'Rings'
        | 'TailSpin'
        | 'ThreeDots'
        | 'Watch'
        | 'RevolvingDot'
        | 'Triangle'
        | 'Plane'
        | 'MutatingDots';
    position?: string;
    height?: number;
}

const Container = styled.div<{ isLoading: boolean; position: string }>`
    display: ${(props): string => (props.isLoading ? 'flex' : 'none')};
    align-items: center;
    justify-content: center;
    position: ${(props): string => (props.position ? props.position : 'absolute')};
    width: 100%;
    height: 100%;
    background: white;
    text-align: center;
    top: 0;
    left: 0;
    border-radius: 5px;
    z-index: 200;
`;

export const Loader: FunctionComponent<LoaderProps> = ({
    isLoading,
    loaderType,
    position,
    height,
    children,
    ...props
}) => {
    const themeContext = useContext(ThemeContext);

    return (
        <Container role="container" isLoading={isLoading} position={position as string}>
            <LoaderSpinner
                {...props}
                visible={isLoading}
                color={themeContext?.colours.gameMainColor ?? '#000'}
                type={loaderType ? loaderType : 'MutatingDots'}
                width={100}
                height={height ? height : 100}
            />
            {children}
        </Container>
    );
};
