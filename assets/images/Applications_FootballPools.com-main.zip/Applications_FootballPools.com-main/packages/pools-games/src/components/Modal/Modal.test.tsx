import { Modal } from './Modal';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';

describe('Modal Component', () => {
    // Test should render
    it('should render', () => {
        const { container } = render(
            <Modal
                close={() => null}
                show={false}
                title={''}
                heightModalInitial={0.8}
                font={'100'}
                align={'center'}
                justify={'center'}
            >
                How To Play
            </Modal>,
        );

        expect(container).toMatchSnapshot();
    });
});
