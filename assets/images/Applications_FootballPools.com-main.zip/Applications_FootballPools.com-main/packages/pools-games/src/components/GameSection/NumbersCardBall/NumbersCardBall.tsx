import styled from 'styled-components';
import { NumbersSelected } from '@sportech/pools-api';
import { breakpoints } from '@settings/breakpoints';

export interface NumbersCardBallProp {
    /**
     * A label to show on the ball button
     */
    number: number;
    action?: (id: number, type: string) => void;
    numbers?: NumbersSelected | undefined;
    bonusNumbers?: NumbersSelected | undefined;
    isViewLines?: boolean;
    isResults?: boolean;
    ballColor?: string;
    isLineMissingSelection?: boolean;
}

export interface NumbersCardBallStyleProp {
    numbers?: NumbersSelected | undefined;
    bonusNumbers?: NumbersSelected | undefined;
    isViewLines?: boolean;
    isResults?: boolean;
    isLineMissingSelection?: boolean;
}

export const NumbersCardBall: React.FC<NumbersCardBallProp> = props => {
    return (
        <NumbersCardDiv
            numbers={props.numbers}
            bonusNumbers={props.bonusNumbers}
            onClick={(): void => {
                if (!props.isViewLines && props.action !== undefined) {
                    props.action(props.number, 'D');
                }
            }}
            isViewLines={props.isViewLines}
            isResults={props.isResults}
            isLineMissingSelection={props.isLineMissingSelection}
        >
            {props.ballColor ? (
                <NumbersImageDiv isResults={props.isResults}>
                    <BallImage isResults={props.isResults} src={`/${props.ballColor}ball.png`} />
                </NumbersImageDiv>
            ) : props.numbers ? (
                <NumbersImageDiv isResults={props.isResults}>
                    <BallImage isResults={props.isResults} src="/greenball.png" />
                </NumbersImageDiv>
            ) : props.bonusNumbers ? (
                <NumbersImageDiv isResults={props.isResults}>
                    <BallImage isResults={props.isResults} src="/goldenball.png" />
                </NumbersImageDiv>
            ) : props.isResults ? (
                <NumbersImageDiv isResults={props.isResults}>
                    <BallImage isResults={props.isResults} src="/greenball.png" />
                </NumbersImageDiv>
            ) : (
                <div></div>
            )}
            <NumberDiv numbers={props.numbers} bonusNumbers={props.bonusNumbers} isResults={props.isResults}>
                {props.number}
            </NumberDiv>
        </NumbersCardDiv>
    );
};

const NumbersCardDiv = styled.div<NumbersCardBallStyleProp>`
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    background: #ffffff;
    align-items: center;
    border: ${(props): string => (props.numbers || props.bonusNumbers ? '1px solid transparent' : '1px solid #959595')};
    border-radius: 50%;
    height: 80px;
    justify-content: center;
    width: 80px;
    margin: 5px;
    ${breakpoints.below('sm')} {
        width: ${(props): string => (props.isResults ? '40px' : '50px')};
        height: ${(props): string => (props.isResults ? '40px' : '50px')};
    }
    ${breakpoints.above('lg')} {
        ${(props): string | undefined => {
            if (
                !props.isViewLines &&
                (props.isLineMissingSelection ||
                    (props.numbers && !props.isLineMissingSelection) ||
                    (props.bonusNumbers && !props.isLineMissingSelection))
            ) {
                return `
                        &:hover {
                            cursor: pointer;
                        }`;
            }
        }}
        ${(props): string | undefined => {
            if (!props.isViewLines && !props.numbers && !props.bonusNumbers && props.isLineMissingSelection) {
                return `
                    &:hover {
                    background: #cccccc;
                    opacity: 0.9;
            
                    & div:last-child {
                        color: #000;
                    }
                }
                    `;
            }
        }}
    }
`;

const NumberDiv = styled.div<NumbersCardBallStyleProp>`
    line-height: inherit;
    text-align: center;
    color: ${(props): string => (props.numbers || props.bonusNumbers || props.isResults ? '#000000' : '#959595')};
    background: transparent;
    position: relative;
    font-size: 2em;
    font-weight: bold;
    ${breakpoints.below('sm')} {
        font-size: ${(props): string => (props.isResults ? '1.5em' : '2em')};
    }
`;

const NumbersImageDiv = styled.div<NumbersCardBallStyleProp>`
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    position: absolute;
    align-items: center;
    height: 80px;
    justify-content: center;
    width: 80px;
    ${breakpoints.below('sm')} {
        width: ${(props): string => (props.isResults ? '40px' : '50px')};
        height: ${(props): string => (props.isResults ? '40px' : '50px')};
    }
`;

const BallImage = styled.img<NumbersCardBallStyleProp>`
    width: 80px;
    height: 80px;
    ${breakpoints.below('sm')} {
        width: ${(props): string => (props.isResults ? '40px' : '50px')};
        height: ${(props): string => (props.isResults ? '40px' : '50px')};
    }
`;
