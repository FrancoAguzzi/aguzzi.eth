import { useDispatch } from 'react-redux';
import { closePopup } from '@features/popups/popupsSlice';
import { Button } from '@components/Common/Button/Button';

export const DepositLimitMessage = () => {
    const dispatch = useDispatch();
    return (
        <>
            <p>Your deposit limit has been reached.</p>

            <Button
                bgColor={'#22A2FF'}
                textColor={'#ffffff'}
                padding={'8px 20px'}
                rounded={'4px'}
                margin={'15px 0 30px'}
                height={'auto'}
                hoverColor={'#22A2FF'}
                hoverOpacity={'0.9'}
                onClick={(): void => {
                    dispatch(closePopup('deposit-limit'));
                }}
            >
                OK
            </Button>
        </>
    );
};
