import { LeaderboardResultMember, LeaderboardResultMembers } from '@sportech/pools-api';
import { FunctionComponent } from 'react';
import styled from 'styled-components';

const Container = styled.table`
    width: 100%;
    margin: 10px 0;
    font-weight: bold;
`;

interface LeaderboardTableProps {
    leaderboard?: LeaderboardResultMembers;
    isLoading?: boolean;
    tableHeadings?: string[];
    showMemberInTable?: boolean;
}

export const LeaderboardTable: FunctionComponent<LeaderboardTableProps> = ({
    leaderboard,
    isLoading,
    tableHeadings,
    showMemberInTable,
}) => {
    return (
        <Container>
            <thead style={{ textTransform: 'uppercase' }}>
                <tr>
                    {tableHeadings ? (
                        tableHeadings.map(heading => (
                            <TableHeading key={`table-heading_${heading}`}>{heading}</TableHeading>
                        ))
                    ) : (
                        <>
                            <TableHeading textAlign="left">Pos</TableHeading>
                            <TableHeading textAlign="left">Nickname</TableHeading>
                            <TableHeading textAlign="right">Points</TableHeading>
                        </>
                    )}
                </tr>
            </thead>
            <TableBody>
                {isLoading && (!leaderboard || !leaderboard?.members || leaderboard?.members.length === 0) && (
                    <LoadingCells />
                )}
                {leaderboard &&
                    leaderboard.members &&
                    leaderboard.members.map((member, index) =>
                        showMemberInTable || !member.customerMember ? (
                            <LeaderboardRow key={`LeaderboardEntry${index}`} {...member} />
                        ) : (
                            <></>
                        ),
                    )}
            </TableBody>
        </Container>
    );
};

const TableHeading = styled.th<{ textAlign?: string }>`
    text-align: ${(props): string | undefined => props.textAlign};
    font-size: 0.75rem;
`;

const TableBody = styled.tbody`
    position: relative;
    /* > tr:nth-child(2n) {
        background: rgba(0, 0, 0, 0.09);
    } */
    min-height: 200px;
`;
const ItemRow = styled.tr`
    min-height: 20px;
`;
const CellData = styled.td<{ textAlign?: string }>`
    text-align: ${(props): string | undefined => props.textAlign};
    padding: 0.8em;
`;
const StatusUp = styled.div`
    width: 0;
    height: 0;
    padding: 0;
    border-left: 11px solid transparent;
    border-right: 11px solid transparent;
    border-bottom: 13px solid #197b30;
    font-size: 0;
    line-height: 0;
`;
const StatusDown = styled.div`
    width: 0;
    height: 0;
    padding: 0;
    border-left: 11px solid transparent;
    border-right: 11px solid transparent;
    border-top: 13px solid #cb2a20;
    font-size: 0;
    line-height: 0;
`;
const StatusEqual = styled.div`
    width: 20px;
    height: 6px;
    padding: 0;
    border: none;
    background-color: #8b8b8b;
`;
const RankContainer = styled.div`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-start;
`;

const LeaderboardRow = (item: LeaderboardResultMember): JSX.Element => {
    const status: 'up' | 'down' | 'equal' =
        item.previousRank && item.previousRank > item.rank
            ? 'up'
            : !item.previousRank || item.previousRank === item.rank
            ? 'equal'
            : 'down';
    return (
        <ItemRow>
            <CellData textAlign="left">
                <RankContainer>
                    <div style={{ minWidth: '30px' }}>{item.rank}</div>
                    {status === 'up' ? <StatusUp /> : status === 'down' ? <StatusDown /> : <StatusEqual />}
                </RankContainer>
            </CellData>
            <CellData textAlign="left">{item.nickname}</CellData>
            <CellData textAlign="right">{item.totalPoints}</CellData>
        </ItemRow>
    );
};

const LoadingCells = (): JSX.Element => (
    <>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
    </>
);
