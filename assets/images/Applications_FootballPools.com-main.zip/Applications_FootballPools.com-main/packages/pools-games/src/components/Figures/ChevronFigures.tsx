import { FunctionComponent } from 'react';
import styled from 'styled-components';

interface ChevronFiguresProps {
    rotation?: string;
    color?: string;
    width?: string;
    height?: string;
    margin?: string;
}

export const ChevronFigures: FunctionComponent<ChevronFiguresProps> = props => {
    return (
        <ChevronStyle {...props} viewBox="0 0 70.9 43.8">
            <path d="M62.5 0L35.4 27.1 8.4 0 0 8.4l35.4 35.4L70.9 8.4 62.5 0z" />
        </ChevronStyle>
    );
};

const ChevronStyle = styled.svg<ChevronFiguresProps>`
    position: relative;
    display: inline-block;
    transform: ${(props): string => (props.rotation ? `rotate(${props.rotation}deg)` : `rotate(0)`)};
    fill: ${(props): string => (props.color ? `${props.color}` : `black`)};
    max-width: ${(props): string => (props.width ? `${props.width}` : `30px`)};
    height: ${(props): string => (props.height ? `${props.height}` : `30px`)};
    margin: ${(props): string => (props.margin ? `${props.margin}` : `0`)};
`;
