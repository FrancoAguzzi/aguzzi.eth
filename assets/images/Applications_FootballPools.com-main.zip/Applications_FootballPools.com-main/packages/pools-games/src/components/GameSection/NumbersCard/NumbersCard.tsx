import styled from 'styled-components';
import { breakpoints } from '@settings/breakpoints';
import { NumbersSelected } from '@sportech/pools-api';
import { NumbersCardBall } from '../NumbersCardBall/NumbersCardBall';
import { GameModel } from '@interfaces/PoolGames/GameModel';

export interface NumbersCardProp {
    /**
     * A label to show on the button
     */
    number: number;
    action?: (id: number, type: string) => void;
    numbers?: NumbersSelected | undefined;
    bonusNumbers?: NumbersSelected | undefined;
    isResults: boolean;
    matchCardWidth?: string;
    isViewLines?: boolean;
    ballColor?: string;
    luckyCloverWinningNumbers?: NumbersSelected[];
    gameModel?: GameModel;
    isLineMissingSelection?: boolean;
}

export const NumbersCard: React.FC<NumbersCardProp> = props => {
    let ballColor = props.ballColor;
    const luckyCloverWinningNumbersNumbers = props.luckyCloverWinningNumbers?.map(x => x.Id) as number[];

    if (props.isResults && props.gameModel?.isClover() && props.luckyCloverWinningNumbers !== undefined) {
        if (luckyCloverWinningNumbersNumbers.includes(props.number)) {
            ballColor = props.number === props.numbers?.Id ? 'green' : 'golden';
        }
    }

    return (
        <NumbersCardDiv isResults={props.isResults} matchCardWidth={props.matchCardWidth}>
            <NumbersCardBall
                ballColor={ballColor}
                number={props.number}
                numbers={props.numbers}
                bonusNumbers={props.bonusNumbers}
                isViewLines={props.isViewLines}
                isResults={props.isResults}
                action={props.action}
                isLineMissingSelection={props.isLineMissingSelection}
            ></NumbersCardBall>
        </NumbersCardDiv>
    );
};

type NumbersCardDivProps = {
    matchCardWidth?: string;
    isResults: boolean;
    isViewLines?: boolean;
    isLineMissingSelection?: boolean;
    numbers?: NumbersSelected | undefined;
};

const NumbersCardDiv = styled.li<NumbersCardDivProps>`
    width: 80px;
    margin: 0.5% 10px;
    font-size: 12px;
    ${breakpoints.below('sm')} {
        margin: 0.5% 0;
        width: 70px;
    }
    ${breakpoints.below('s')} {
        width: ${(props): string => (props.isResults ? '45px' : '70px')};
    }
`;
