import { FunctionComponent, useEffect, useContext } from 'react';
import styled, { ThemeContext } from 'styled-components';

import { Button } from '@components/Common/Button/Button';
import { BetSlip, NumbersSelected, Offering, Offerings } from '@sportech/pools-api';
import { useDispatch } from 'react-redux';
import { AppDispatch } from '@src/store';
import { closePopup, openPopup } from '@features/popups/popupsSlice';
import { getTotalLines, getTotalPrice, isAddedLineDisabled, isPlayButtonDisabled } from '@src/utils/functionUtils';
import { useRouter } from 'next/router';
import '@src/utils/extensionMethods';
import { useMediaQuery } from 'react-responsive';
import { GameModel } from '@interfaces/PoolGames/GameModel';
import { useUser } from '@auth0/nextjs-auth0';

interface BetSlipMobileProps {
    betslipselection: Array<BetSlip>;
    SelectAmountAction: (id: number, amount: Offering) => void;
    ClearLine: () => void;
    AddLine: () => void;
    ChangeBet: (index: number) => void;
    offers: Offerings;
    setCurrentOfferingId: (val: number) => void;
    currentOfferingId: number;
    setShowMore: (val: boolean) => void;
    showMoreValue: boolean;
    addedLines: BetSlip[];
    pressPlay: () => void;
    gameModel: GameModel;
}

export const BetSlipMobile: FunctionComponent<BetSlipMobileProps> = props => {
    const { user } = useUser();
    const router = useRouter();
    const lines = getTotalLines(props.gameModel.isHDA(), props.addedLines);
    const totalPricenumber = getTotalPrice(props.gameModel.isHDA(), props.gameModel.isClover(), props.betslipselection);

    const totalPrice = totalPricenumber.toLocaleStringCash();

    const currentBet = props.betslipselection.filter(x => x.current)[0];
    const themeContext = useContext(ThemeContext);

    const dispatch: AppDispatch = useDispatch<AppDispatch>();

    const updateCurrentOfferingId = (item: BetSlip): void => {
        props.setCurrentOfferingId(item.priceID);
        props.setShowMore(false);
    };

    useEffect(() => {
        updateCurrentOfferingId(currentBet);
    }, [props.betslipselection]);

    let playButtonPressed = false;

    const onPlayButtonClick = (): void => {
        if (!playButtonPressed) {
            if (
                props.gameModel.isClover() &&
                props.betslipselection.filter(x => x.bonusNumbers.length === 0).length > 0
            ) {
                dispatch(closePopup('payment'));
                dispatch(openPopup('lucky_clover_no_bonus_selected'));
            } else {
                playButtonPressed = true;
                props.pressPlay();
            }
        }
    };

    const isSmallMobile = useMediaQuery({
        query: `(max-width: ${themeContext.breakpoints.xs}px)`,
    });

    return (
        <>
            <MobileBetSlipItem>
                <Button
                    height={'50px'}
                    bgColor={themeContext.colours.gameMainColor}
                    textColor={'#fff'}
                    padding={'0 0.5em'}
                    disabled={props.addedLines.length === 0}
                    onClick={(): void => {
                        dispatch(openPopup('added_lines'));
                    }}
                >
                    {lines > 1 ? `${lines} Lines Added ` : `${lines} Line Added `} £{totalPrice}
                </Button>
            </MobileBetSlipItem>
            {currentBet.bonusNumbers?.length !== 0 ? (
                <MobileBetSlipItem>
                    {(currentBet.numbers as NumbersSelected[]).length + currentBet.bonusNumbers?.length} /{' '}
                    {currentBet.pick + currentBet.bonusPick}
                </MobileBetSlipItem>
            ) : (
                <MobileBetSlipItem>
                    {currentBet.numbers?.length}/{currentBet.pick}
                </MobileBetSlipItem>
            )}
            <MobileBetSlipItem>
                <Button
                    height={'auto'}
                    bgColor={'#22A2FF'}
                    textColor={'#ffffff'}
                    padding={'1em 0.75em'}
                    onClick={(): void => {
                        props.AddLine();
                    }}
                    disabled={isAddedLineDisabled(currentBet)}
                >
                    Add Line
                </Button>
            </MobileBetSlipItem>
            <MobileBetSlipItem>
                <Button
                    height={'auto'}
                    width={isSmallMobile ? '80px' : '100px'}
                    bgColor={'#0C9D00'}
                    textColor={'#fff'}
                    padding={'1em 0.75em'}
                    disabled={isPlayButtonDisabled(props.betslipselection)}
                    onClick={(): void => {
                        if (user === null || user === undefined) {
                            router.push('/api/auth/login');
                        } else {
                            onPlayButtonClick();
                        }
                    }}
                >
                    PLAY
                </Button>
            </MobileBetSlipItem>
        </>
    );
};

const MobileBetSlipItem = styled.div`
    max-width: 40%;
`;
