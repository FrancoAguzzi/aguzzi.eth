import { Button } from '@components/button/button';
import { formatTwoDecimalPoints } from '@src/utils/functionUtils';
import { useMemo } from 'react';
import { BetSlipContainer, BaseBetSlip, BaseDiv, TextRight, TextLeft, Icon } from './betslip.styles';

interface Props {
    onClick: (() => void) | (() => Promise<void>);
    variant?: 'primary' | 'secondary' | 'tertiary';
    children?: React.ReactNode;
    name: string;
    lines: number;
    total: number;
    url?: string;
    color?: string;
    fontColor?: string;
    width?: string;
    gameDays: Array<string>;
    isShowingPicker?: boolean;
    isMobile?: boolean;
    widthScreen: number;
    margin?: string;
}

export const BetSlip = ({
    url,
    name,
    lines,
    total,
    width,
    fontColor,
    variant,
    onClick,
    isShowingPicker,
    gameDays,
    isMobile,
    widthScreen,
    margin,
}: Props): JSX.Element => {
    const checkoutButtonColor = useMemo(
        () => (lines === 0 || isShowingPicker || gameDays.length === 0 ? 'transparent' : '#fff'),
        [lines, gameDays, isShowingPicker],
    );
    return (
        <BaseDiv width={width} margin={margin}>
            <BetSlipContainer>
                <BaseBetSlip>
                    <TextLeft>
                        {name}
                        {lines}
                    </TextLeft>
                    <TextRight>£{formatTwoDecimalPoints(total)}</TextRight>
                </BaseBetSlip>
                <Button
                    onClick={onClick}
                    variant={variant}
                    color={checkoutButtonColor}
                    fontColor={fontColor}
                    border="1px solid #FFF"
                    fontWeight="100"
                    text="Play"
                    url={url}
                    width={'80%'}
                    disabled={lines === 0 || gameDays.length === 0 || isShowingPicker}
                    padding={widthScreen > 360 ? '9px 0 9px 0' : '0 0 0 0'}
                    fontSize={!isMobile ? '16px' : '14px'}
                    margin={widthScreen > 360 ? '8px 0 22px 0' : '5px 0 10px 0'}
                >
                    <Icon />
                </Button>
            </BetSlipContainer>
        </BaseDiv>
    );
};
