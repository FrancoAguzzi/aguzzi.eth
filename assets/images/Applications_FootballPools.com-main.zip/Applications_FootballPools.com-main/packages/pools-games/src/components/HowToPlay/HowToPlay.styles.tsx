import styled from 'styled-components';
import { Info as InfoBase } from '@src/base-styles';

export const Info = styled(InfoBase)`
    display: flex;
    flex-direction: column;
    text-align: left;
    padding: 0 2rem 3rem 2rem;

    p {
        margin: 0.5rem;

        u {
            margin-right: 4rem;
        }
    }

    @media (max-width: 420px) {
        p {
            u {
                margin-right: 1rem;
            }
        }
    }
`;
