import { Modal } from '../Modal/Modal';
import { Info } from './HowToPlay.styles';

/**
 * Modal props
 *  @param show boolean to know if the modal is show or not.
 *  @param HowToPlayTitle Title which is shown in the top modal.
 *  @param close handle to close modal.
 *  @param HowToPlayContent Conten for the children.
 *  @param setHowPlay Modifier for show modal.
 *  @param heightModalInitial Modal height initial.
 */

interface Props {
    HowToPlayTitle: string;
    HowToPlayContent: string | Array<string>;
    show: boolean;
    close: () => void;
    heightModalInitial: number;
}

export const HowToPlay = ({
    show,
    close,
    HowToPlayTitle,
    HowToPlayContent,
    heightModalInitial,
}: Props): JSX.Element => {
    return (
        <>
            <Modal
                show={show}
                close={close}
                title={HowToPlayTitle}
                heightModalInitial={heightModalInitial}
                font={'bold'}
                align={'center'}
                justify={'center'}
            >
                <Info dangerouslySetInnerHTML={{ __html: String(HowToPlayContent) }} />
            </Modal>
        </>
    );
};
