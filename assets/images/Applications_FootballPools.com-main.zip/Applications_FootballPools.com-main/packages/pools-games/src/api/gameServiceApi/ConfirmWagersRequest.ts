export interface ConfirmWagersRequest {
    operatorId: string;
    userId: string;
    wagers: WagerConfirmation[];
}

export interface WagerConfirmation {
    wagerId: string;
    clientWagerId: string;
    clientTransactionId: string;
}
