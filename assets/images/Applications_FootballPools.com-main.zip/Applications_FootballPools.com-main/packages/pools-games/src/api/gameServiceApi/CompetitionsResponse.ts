export interface Competition {
    competitionType: string;
    datumDate: string;
    datumDateWithBuffer: string;
    description: string;
    fixtures: Fixture[];
    competitionId: number;
    number: number;
    poolSize: PoolSize;
    state: string;
    gameID?: number;
    competitionIds?: { [key: string]: number };
    bonusCompetitionId?: number;
}

export interface Fixture {
    awayTeam: string;
    awayTeamDisplay: string;
    awayTeamExternalId: string;
    externalId: string;
    homeTeam: string;
    homeTeamDisplay: string;
    homeTeamExternalId: string;
    id: number;
    kickoff: string;
    number: number;
}

export interface PoolSize {
    type: string;
    value: number;
}

export type CompetitionsResponse = Competition[];
