export interface CompetitionResult {
    competitionId: number;
    number: number;
    datumDate: string;
    state: string;
    description: string;
    fixtures: FixtureResult[];
    winningNumbers: string[];
    competitionIds: { [key: string]: number };
}

export interface FixtureResult {
    awayTeam: string;
    awayTeamDisplay: string;
    awayTeamExternalId: string;
    externalId: string;
    homeTeam: string;
    homeTeamDisplay: string;
    homeTeamExternalId: string;
    id: number;
    kickoff: string;
    number: number;
    status: string;
    points: number;
    scores: Scores;
}

export interface Score {
    home: number;
    away: number;
}

export interface Scores {
    halfTime: Score;
    fullTime: Score;
    highScoreDraw: boolean;
    poolsPanel: boolean;
    isVoid: boolean;
}

export type CompetitionResultsResponse = CompetitionResult[];
