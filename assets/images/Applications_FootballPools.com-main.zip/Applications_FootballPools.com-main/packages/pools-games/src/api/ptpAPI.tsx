import { GameType, LeaderboardResultsResponse, Response, PoolsApiError } from '@sportech/pools-api';
import useSWR from 'swr';
import getConfig from 'next/config';
import { NextApiRequest, NextApiResponse } from 'next';
import axios from 'axios';
import auth0 from '@src/utils/auth0';
import { Mileage } from '@interfaces/VIPLevels/Mileage';
import { useUser } from '@auth0/nextjs-auth0';
import querystring from 'querystring';

const { publicRuntimeConfig } = getConfig();

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
const fetcher = (url: RequestInfo) => fetch(url).then(res => res.json());

export function GetWagerURL(gametype: GameType): string {
    return `/api/wagers/get/${gametype}`;
}
// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
export default function getWagersSWR(gametype: GameType, showWagers: boolean) {
    const { data, error } = useSWR(showWagers ? GetWagerURL(gametype) : null, fetcher);
    return {
        wagers: data,
        isLoading: !error && !data,
        isError: error,
    };
}

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
export function getMailSWR() {
    const { user } = useUser();

    const { data, error } = useSWR(user !== undefined ? `/api/Inbox/getCount` : '', fetcher, {
        refreshInterval: 60000,
    });
    return {
        data: data,
        mailLoading: !error && !data,
        mailError: error,
    };
}

export const GetMailCount = async (req: NextApiRequest, res: NextApiResponse): Promise<number> => {
    const { accessToken } = await auth0.getAccessToken(req, res);
    const url = `${publicRuntimeConfig.INBOX_API_SITE_URL}Inbox/Count`;
    const { data } = await axios.get<number>(url, {
        headers: {
            Authorization: `Bearer ${accessToken}`,
        },
    });
    return data;
};

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
export function getMileageSWR(getMileage: boolean) {
    const { data, error } = useSWR(getMileage ? `/api/Mileage/getMileage` : null, fetcher);
    return {
        data: data,
        mileageLoading: !error && !data,
        mileageError: error,
    };
}

export const getMileage = async (req: NextApiRequest, res: NextApiResponse): Promise<Mileage> => {
    const { accessToken } = await auth0.getAccessToken(req, res);
    const url = `${publicRuntimeConfig.MILEAGE_API_URL}GetAccount`;
    const mileageAPIKey =
        publicRuntimeConfig.SITE_ENVIRONMENT === 'DEV'
            ? '342445a799fe491fb16ed989ec4c2241'
            : process.env.MILEAGE_API_KEY;
    const { data } = await axios.get<Mileage>(url, {
        headers: {
            Authorization: `Bearer ${accessToken}`,
            'Ocp-Apim-Subscription-Key': `${mileageAPIKey}`,
        },
    });

    return data;
};

export const getLeaderboard = async (
    req: NextApiRequest,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    res: NextApiResponse,
): Promise<LeaderboardResultsResponse> => {
    // let token: string | undefined = undefined;
    // try {
    //     const { accessToken } = await auth0.getAccessToken(req, res);
    //     token = accessToken;
    // } catch {}

    const url = `${publicRuntimeConfig.LEADERBOARDS_API_URL}/GetLeaderboard?${querystring.stringify(req.query)}`;

    const { data } = await axios.get<LeaderboardResultsResponse>(url);

    return data;
};

export const getLeaderboardResultsAsync = async (
    game: GameType,
    competitionId?: number,
    count?: number,
    page?: number,
): Promise<Partial<Response<LeaderboardResultsResponse>>> => {
    const url = `${publicRuntimeConfig.LEADERBOARDS_API_URL}/GetLeaderboard?${querystring.stringify({
        game,
        competitionId,
        count,
        page,
    })}`;

    try {
        const { data } = await axios.get<LeaderboardResultsResponse>(url, {
            withCredentials: true,
        });
        return { data: data };
    } catch (error) {
        console.log('leaderboards error', error);
        return ({ error: error } as unknown) as PoolsApiError;
    }

    return { error: { title: 'Something went wrong', code: 'default' } };
};
