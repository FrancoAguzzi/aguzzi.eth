import {
    Adaptor,
    GameType,
    Competition,
    CompetitionResult,
    Offerings,
    CompetitionDividends,
    ConfirmedWagers,
    PoolsApiError,
    ApiConfig,
    isType,
    isGameEndpoint,
    BetSlip,
    NumbersSelected,
    Leaderboard,
} from '@sportech/pools-api';
import getConfig from 'next/config';
import { CompetitionsResponse } from './CompetitionsResponse';
import { CompetitionResultsResponse } from './CompetitionResultsResponse';
import { IncomingHttpHeaders, IncomingMessage } from 'http';
import { Wager, WagerConfirmation } from '@sportech/pools-api/src/models/wagers';
import { GamesConfirmedWagersResponse } from './ConfirmWagerResponse';
import { CreateWagersRequest } from './CreateWagerRequest';
import { getCompIdLuckyClover } from '@src/utils/functionUtils';

const { publicRuntimeConfig, serverRuntimeConfig } = getConfig();

export type GameServiceGameType = '1' | '2';

export const useGameServiceApiAdaptor = (): Adaptor => {
    const getGameTypes = (): GameType[] => {
        return ['classic-pools', 'goal-rush', 'premier-10', 'jackpot-12', 'premier-6', 'lucky-clover'];
    };

    const backendBaseUrl = publicRuntimeConfig.API_WEBSITE_BASE;
    const gameServiceApiKey = publicRuntimeConfig.GAME_SERVICE_API_KEY;
    const getBaseUrl = (config?: ApiConfig): string => {
        return config && config.clientType === 'backend' ? backendBaseUrl : publicRuntimeConfig.GAME_SERVICE_API_URL;
    };

    const getCompetitionsEndpoint = (game: GameType, config?: ApiConfig): string => {
        return config && config.clientType === 'backend'
            ? `games/competitions/${game}`
            : `OpenCompetition?GameType=${game}&subscription-key=${gameServiceApiKey}`;
    };

    const getCompetitionResultsEndpoint = (game: GameType, config?: ApiConfig): string => {
        return config && config.clientType === 'backend'
            ? `games/results/${game}`
            : `ResultedCompetition?GameType=${game}&subscription-key=${gameServiceApiKey}`;
    };

    const getOfferingsEndpoint = (game: GameType, config?: ApiConfig): string => {
        return config && config.clientType === 'backend'
            ? `games/${game}`
            : `GetOfferingsFunction?GameType=${game}&subscription-key=${gameServiceApiKey}`;
    };

    const getDividendsEndpoint = (game: GameType, config?: ApiConfig): string => {
        return config && config.clientType === 'backend'
            ? `games/dividends/${game}`
            : `DividentsForCompetition?GameType=${game}&subscription-key=${gameServiceApiKey}`;
    };

    const getWagersEndpoint = (game: GameType, config?: ApiConfig): string => {
        return config && config.clientType === 'backend'
            ? `wagers/get/${game}`
            : `GetWagersFunction?GameType=${game}&subscription-key=${gameServiceApiKey}`;
    };

    const getCreateWagersInitEndpoint = (game: GameType, config?: ApiConfig): string => {
        const apiConfig = typeof config?.clientType === 'string' ? config.clientType : 'backend';
        return apiConfig && apiConfig === 'backend'
            ? `wagers/create/${game}`
            : `CreateWagerFunction?GameType=${game}&subscription-key=${gameServiceApiKey}`;
    };

    const getConfirmWagersEndpoint = (game: GameType, config?: ApiConfig): string => {
        return config && config.clientType === 'backend'
            ? `wagers/confirm/${game}`
            : `ConfirmWagerFunction?GameType=${game}&subscription-key=${gameServiceApiKey}`;
    };

    const getFinaliseWagersEndpoint = (): string => {
        return ``;
    };

    const getLeaderboardResultsEndpoint = (game: GameType, config?: ApiConfig): string => {
        return config && config.clientType === 'backend'
            ? `leaderboards/${game}`
            : `GetLeaderboardFunction?GameType=${game}&subscription-key=${serverRuntimeConfig.LEADERBOARDS_API_URL}`;
    };

    const transformCompetitionsResponse = (responseData: unknown): Competition[] => {
        // console.log('transform competition response', responseData);
        const ret: Competition[] = [];

        const apiCompetitions = responseData as CompetitionsResponse;
        if (apiCompetitions !== null) {
            for (let i = 0; i < apiCompetitions.length; i++) {
                const apiCompetition = apiCompetitions[i];
                ret.push({
                    id: apiCompetition.competitionId,
                    datumDate: apiCompetition.datumDate,
                    datumDateWithBuffer: apiCompetition.datumDateWithBuffer,
                    description: apiCompetition.description,
                    number: apiCompetition.number,
                    poolSize: apiCompetition.poolSize,
                    state: apiCompetition.state,
                    fixtures: apiCompetition.fixtures,
                    gameId: apiCompetition.gameID,
                    competitionIds: apiCompetition.competitionIds,
                    bonusCompetitionId:
                        apiCompetition.bonusCompetitionId !== undefined ? apiCompetition.bonusCompetitionId : 0,
                });
            }
        }

        // console.log('transformed competition response', ret);
        return ret;
    };

    const transformCompetitionResultsResponse = (responseData: unknown): CompetitionResult[] => {
        // console.log('transform resulted competition response', responseData);
        const ret: CompetitionResult[] = [];

        const apiCompetitions = responseData as CompetitionResultsResponse;
        if (apiCompetitions !== null) {
            for (let i = 0; i < apiCompetitions.length; i++) {
                const apiCompetition = apiCompetitions[i];
                ret.push({
                    id: apiCompetition.competitionId,
                    datumDate: apiCompetition.datumDate,
                    description: apiCompetition.description,
                    number: apiCompetition.number,
                    state: apiCompetition.state,
                    fixtures: apiCompetition.fixtures,
                    winningNumbers: apiCompetition.winningNumbers,
                    competitionIds: apiCompetition.competitionIds,
                });
            }
        }

        // console.log('transformed competition response', ret);
        return ret;
    };

    const transformDividendsResponse = (responseData: unknown): CompetitionDividends => {
        return responseData as CompetitionDividends;
    };

    const transformOfferingsResponse = (responseData: unknown): Offerings => {
        return responseData as Offerings;
    };

    const transformGetWagersResponse = (responseData: unknown): Wager => {
        // console.log('tranform get wagers response', responseData);
        return responseData as Wager;
    };

    interface BetSlipWithLinkingRef {
        competitionId: number;
        competitionName?: string;
        pick: number;
        bonusPick: number;
        current: boolean;
        price: number;
        bonusPrice: number;
        priceID: number;
        highestRow?: number;
        numbers?: Array<NumbersSelected>;
        bonusPriceId: number;
        bonusNumbers: Array<NumbersSelected>;
        bonusCompetitionId: number;
        linkedWagerRef: number;
    }

    const transformCreateWagersRequest = (data: unknown): unknown => {
        const dc = data as {
            game: GameType;
            wagers: BetSlip[];
            competition: Competition;
        };

        const comps = {
            competitions: new Array<CreateWagersRequest>(),
        };
        const withLinkedWagersRef: BetSlipWithLinkingRef[] = [];
        for (let i = 0; i < dc.wagers.length; i++) {
            withLinkedWagersRef.push({
                competitionId:
                    dc.game === 'lucky-clover'
                        ? getCompIdLuckyClover(
                              dc.wagers[i].pick,
                              dc.competition.competitionIds as {
                                  [key: string]: number;
                              },
                          )
                        : dc.wagers[i].competitionId,
                competitionName: dc.wagers[i].competitionName,
                bonusCompetitionId:
                    dc.competition.competitionIds !== undefined ? dc.competition?.competitionIds[44] : 0,
                price: dc.wagers[i].price,
                priceID: dc.wagers[i].priceID,
                bonusPrice: dc.wagers[i].bonusPrice,
                bonusNumbers: dc.wagers[i].bonusNumbers,
                numbers: dc.wagers[i].numbers,
                bonusPick: dc.wagers[i].bonusPick,
                pick: dc.wagers[i].pick,
                current: dc.wagers[i].current,
                highestRow: dc.wagers[i].highestRow,
                bonusPriceId: dc.wagers[i].bonusPriceId,
                linkedWagerRef: dc.wagers[i].bonusNumbers.length !== 0 ? i + 1 : 0,
            });
        }
        if (withLinkedWagersRef.find(x => x.bonusNumbers.length !== 0)) {
            const luckyCloverWithBonusWagers = withLinkedWagersRef.filter(w => w.bonusNumbers.length !== 0);
            for (let i = 0; i < luckyCloverWithBonusWagers.length; i++) {
                const luckyCloverBonusWagerNumbers = (luckyCloverWithBonusWagers[i].numbers as NumbersSelected[])
                    .concat(luckyCloverWithBonusWagers[i].bonusNumbers)
                    .sort((a, b) => a.Id - b.Id);
                const wager = luckyCloverWithBonusWagers[i];
                const newWager: BetSlipWithLinkingRef = {
                    numbers: luckyCloverBonusWagerNumbers,
                    priceID: wager.bonusPriceId,
                    price: wager.bonusPrice,
                    pick: wager.pick,
                    competitionId: wager.bonusCompetitionId,
                    bonusPick: 0,
                    bonusPrice: 0,
                    bonusCompetitionId: wager.bonusCompetitionId,
                    bonusNumbers: [],
                    bonusPriceId: 0,
                    current: false,
                    linkedWagerRef: wager.linkedWagerRef,
                };
                withLinkedWagersRef.push(newWager);
            }
        }
        const compsList = withLinkedWagersRef.map(w => w.competitionId);
        const compsListFiltered = compsList.filter((v, i) => compsList.indexOf(v) === i);

        for (let i = 0; i < compsListFiltered.length; i++) {
            const filteredWagers = withLinkedWagersRef.filter(w => w.competitionId === compsListFiltered[i]);
            comps.competitions.push({
                competitionId: compsListFiltered[i],
                wagers: filteredWagers.map(w => {
                    let numbersString = '';
                    if (dc.game === 'classic-pools' || dc.game === 'goal-rush' || dc.game === 'lucky-clover') {
                        if (w && w.numbers !== null && w.numbers !== undefined && w.numbers.length > 0) {
                            for (let i = 0; i < w.numbers.length; i++) {
                                if (w.numbers[i].Id < 10) {
                                    numbersString += `0${w.numbers[i].Id}`;
                                } else {
                                    numbersString += w.numbers[i].Id;
                                }
                            }
                        }
                    } else {
                        if (w.numbers !== null && w.numbers !== undefined && w.numbers.length > 0) {
                            for (let i = 0; i < w.numbers.length; i++) {
                                numbersString += `${w.numbers[i].selections.join('')},`;
                            }
                            numbersString = numbersString.slice(0, -1).toLocaleLowerCase();
                        }
                    }

                    return {
                        selections: numbersString,
                        offeringId: w.priceID,
                        paidCost: w.price,
                        linkedWagerRef: w.linkedWagerRef,
                    };
                }),
            });
        }
        // console.log('transform create wagers init req');
        return comps;
    };

    const transformCreateWagersResponse = (data: unknown): unknown => {
        // console.log('transform create wager response', data);
        return data;
    };
    class WagersArray {
        constructor(item: ConfirmCompetitionWagers[]) {
            this.Competitions = item;
        }
        Competitions: ConfirmCompetitionWagers[];
    }
    const transformConfirmWagersRequest = (data: unknown): unknown => {
        // console.log('transform confirm wagers request', data);
        return new WagersArray((data as ConfirmCompetitionWagersArray).wagers);
    };

    interface ConfirmCompetitionWagers {
        competitionId: number;
        wagers: WagerConfirmation[];
    }
    interface ConfirmCompetitionWagersArray {
        wagers: ConfirmCompetitionWagers[];
    }

    const hasError = (value: unknown): value is { error: string } => !!(value as { error: string }).error;

    const transformConfirmWagersResponse = (data: unknown): ConfirmedWagers => {
        const res = data as GamesConfirmedWagersResponse;
        if (hasError(res)) {
            return {
                isSuccess: false,
                error: res.error,
            };
        }
        const isSuccess = res.wagers.filter(x => x.confirmed === true).length === res.wagers.length ? true : false;

        return isSuccess
            ? {
                  isSuccess: true,
              }
            : {
                  isSuccess: false,
                  error: 'confirm_wagers_error',
              };
    };

    const transformFinaliseWagersRequest = (data: unknown): unknown => {
        return data;
    };

    const transformFinaliseWagersResponse = (data: unknown): ConfirmedWagers => {
        const ret: ConfirmedWagers = {
            isSuccess: Boolean(data !== null),
        };
        return ret;
    };

    const onRequest = (
        url: string,
        data: unknown,
        headers: unknown,
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        config?: ApiConfig,
        req?: unknown,
    ): unknown => {
        switch (url) {
            case isGameEndpoint(getWagersEndpoint, getGameTypes(), { clientType: 'api' }, url): {
                if (isType<IncomingMessage>(req) && isType<IncomingHttpHeaders>(headers)) {
                    headers.Authorization = req.headers.Authorization;
                }
            }
        }

        return data;
    };

    const onBackendRequest = (url: string, data: unknown, headers: unknown, originalRequest?: unknown): unknown => {
        switch (url) {
            case isGameEndpoint(getCreateWagersInitEndpoint, getGameTypes(), { clientType: 'api' }, url):
            case isGameEndpoint(getConfirmWagersEndpoint, getGameTypes(), { clientType: 'api' }, url):
            case isGameEndpoint(getWagersEndpoint, getGameTypes(), { clientType: 'api' }, url): {
                if (isType<IncomingMessage>(originalRequest) && isType<IncomingHttpHeaders>(headers)) {
                    headers.Authorization = originalRequest.headers.Authorization;
                }
            }
        }

        return data;
    };

    const handleError = (): PoolsApiError => {
        const ret: PoolsApiError = {
            title: 'Something went wrong',
            status: 418,
            code: 'gameserviceapi.error.default',
        };
        return ret;
    };

    const transformLeaderboardResponse = (data: unknown): Leaderboard => {
        const res = data as Leaderboard;
        console.log('transform leaderboard response', res);
        return res;
    };

    return {
        getGameTypes,
        getBaseUrl,
        getCompetitionsEndpoint,
        getCompetitionResultsEndpoint,
        getOfferingsEndpoint,
        getDividendsEndpoint,
        getCreateWagersInitEndpoint,
        getConfirmWagersEndpoint,
        getFinaliseWagersEndpoint,
        getWagersEndpoint,
        getLeaderboardResultsEndpoint,
        transformCompetitionsResponse,
        transformCompetitionResultsResponse,
        transformDividendsResponse,
        transformOfferingsResponse,
        transformGetWagersResponse,
        transformCreateWagersRequest,
        transformCreateWagersResponse,
        transformConfirmWagersRequest,
        transformConfirmWagersResponse,
        transformFinaliseWagersRequest,
        transformFinaliseWagersResponse,
        transformLeaderboardResponse,
        onRequest,
        handleError,
        onBackendRequest,
    };
};
