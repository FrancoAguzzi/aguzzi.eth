import { builder } from '@builder.io/react';
import getConfig from 'next/config';

const { publicRuntimeConfig } = getConfig();

builder.init(process.env.BUILDER_API_KEY || publicRuntimeConfig.BUILDER_API_KEY);

export const getContent = async () => {
    const content = await builder.getAll('app-game', {
        fields:
            'data.howToPlayTitle,data.howToPlayBody,data.prizeBreakdownTitle,data.prizeBreakdownContent,data.note,data.lottoImage,data.productPageImage',
    });
    return {
        content: content,
    };
};

export const LOTTO_URL: RequestInfo | URL | undefined = process.env.LOTTO_GAME_API_URL;
interface Body<TVariables> {
    query: string;
    variables?: TVariables;
    token?: string | unknown;
}
/**
 * Function to minimize fetch repetition
 * @param data object with three types of variants
 */
export async function fetchLottoApi<TVariables>(data: Body<TVariables>) {
    return fetch(`${window.location.origin}/api/lotto/`, {
        method: 'POST',
        body: JSON.stringify(data),
    }).then(response => response.json());
}
