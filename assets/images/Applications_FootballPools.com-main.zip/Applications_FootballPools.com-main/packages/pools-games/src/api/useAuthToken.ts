let token: string | undefined;

export const useAuthToken = (): {
    getToken: () => string | undefined;
    setToken: (val?: string) => string | undefined;
} => {
    // const token = useRef(null);

    const setToken = (apiToken?: string): string | undefined => {
        console.log(`setting token: ${apiToken}`);
        token = apiToken;
        return token;
    };

    const getToken = (): string | undefined => {
        console.log(`getting token: ${token}`);
        return token;
    };

    return { getToken, setToken };
};
