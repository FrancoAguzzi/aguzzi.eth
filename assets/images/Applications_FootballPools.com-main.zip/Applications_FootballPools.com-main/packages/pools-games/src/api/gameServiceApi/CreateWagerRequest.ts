export interface CreateWagersRequest {
    competitionId: number;
    wagers: Wager[];
}
export interface Wager {
    selections: string;
    offeringId: number;
    paidCost: number;
    linkedWagerRef: number;
}
