export type GamesConfirmedWagersResponse =
    | {
          wagers: GamesConfirmedWagers[];
      }
    | InsufficientFundsError;

export interface GamesConfirmedWagers {
    wagerId: number;
    confirmed: boolean;
    clientWagerId: string;
    clientTransactionId: string;
}

type InsufficientFundsError = {
    error: 'insufficient_funds';
};
