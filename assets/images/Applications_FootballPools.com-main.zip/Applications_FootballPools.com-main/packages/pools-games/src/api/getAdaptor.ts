import { Adaptor } from '@sportech/pools-api';
import { useGameServiceApiAdaptor } from './gameServiceApi/useGameServiceApiAdaptor';

export const getAdaptor = (): Adaptor => {
    return useGameServiceApiAdaptor();
};
