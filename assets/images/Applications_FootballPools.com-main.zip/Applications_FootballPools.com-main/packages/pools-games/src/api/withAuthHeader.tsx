import { ApiRouteRequest, ApiRouteResponse } from '@sportech/pools-api';
import auth0 from '@src/utils/auth0';
import { NextApiRequest, NextApiResponse, NextPage, NextPageContext } from 'next';

export const withAuthHeader = (handler: (req: ApiRouteRequest, res: ApiRouteResponse) => Promise<void>) => {
    // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
    return async (req: ApiRouteRequest, res: ApiRouteResponse) => {
        const { accessToken } = await auth0.getAccessToken(req, res);
        if (req !== undefined && accessToken !== undefined) {
            req.headers.Authorization = `Bearer ${accessToken}`;
        } else {
            req.headers.Authorization = ``;
        }
        return handler(req, res);
    };
};

const withAuthReq = <T extends {}>(Page: NextPage<T>): NextPage<T> => {
    const WithAuthReq: NextPage<T> = (props: T) => {
        return <Page {...props} />;
    };

    WithAuthReq.getInitialProps = async (context: NextPageContext): Promise<T> => {
        if (!context.isServer) {
            return {
                ...(Page.getInitialProps ? await Page.getInitialProps(context) : {}),
            } as T;
        }
        let accessToken = undefined;
        try {
            accessToken = await auth0.getAccessToken(context.req as NextApiRequest, context.res as NextApiResponse);
        } catch {}
        if (context.req !== undefined && accessToken !== undefined) {
            context.req.headers.Authorization = `Bearer ${accessToken.accessToken}`;
        } else if (context.req !== undefined && accessToken === undefined) {
            context.req.headers.Authorization = ``;
        }
        return {
            ...(Page.getInitialProps ? await Page.getInitialProps(context) : {}),
        } as T;
    };

    return WithAuthReq;
};

export default withAuthReq;
