import fetch from 'isomorphic-unfetch';
import { useEffect, useState } from 'react';

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
function initialState(args) {
    return {
        response: null,
        error: null,
        isLoading: true,
        ...args,
    };
}

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
export default (url, options = {}) => {
    const [state, setState] = useState(() => initialState({}));

    useEffect(() => {
        // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
        const fetchData = async () => {
            try {
                const res = await fetch(url, {
                    ...options,
                });

                if (res.status >= 400) {
                    setState(
                        initialState({
                            error: await res.json(),
                            isLoading: false,
                        }),
                    );
                } else {
                    setState(
                        initialState({
                            response: await res.json(),
                            isLoading: false,
                        }),
                    );
                }
            } catch (error) {
                setState(
                    initialState({
                        error: {
                            error: getErrorMessage(error),
                        },
                        isLoading: false,
                    }),
                );
            }
        };
        fetchData();
    }, []);
    return state;
};
