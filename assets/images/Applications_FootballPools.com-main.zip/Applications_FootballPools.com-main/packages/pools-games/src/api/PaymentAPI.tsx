import getConfig from 'next/config';
import fetch from 'node-fetch';
import { Address, Card, Payment, PaymentData, PaymentDetails, Ping } from '@interfaces/FSB';
import { getAccessToken } from './CustomerAPi';
import { NextApiRequest, NextApiResponse } from 'next';

const { publicRuntimeConfig } = getConfig();

const apiUrl = publicRuntimeConfig.FSB_BASE_URL;
const apiUsername = publicRuntimeConfig.FSB_USER_ID;
const apiPassword =
    publicRuntimeConfig.SITE_ENVIRONMENT === 'DEV' ? '2$ziPpDQY$y1' : publicRuntimeConfig.FSB_USER_SECRET;
const token = Buffer.from(`${apiUsername}:${apiPassword}`).toString('base64');

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
export async function callApiRoute<T>(endpoint: string) {
    const accessToken = await getAccessToken();

    const res = fetch(`/api/Payment/${endpoint}`, {
        headers: {
            AccessToken: accessToken,
        },
    });

    const response = ((await res).json() as unknown) as T;

    return response;
}

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
export async function callPaymentRoute<T>(data: PaymentData) {
    const accessToken = await getAccessToken();

    const paymentData = new URLSearchParams();
    paymentData.append('access_token', accessToken);
    paymentData.append('paymentMethodRef', data.paymentMethodRef);
    paymentData.append('addressId', data.addressId.toString());
    paymentData.append('responseUrl', data.responseUrl);
    paymentData.append('amount', data.amount.toString());
    if (data.cardId !== undefined) {
        paymentData.append('cardId', data.cardId.toString());
    }

    const method = data.cardId !== undefined ? 'PUT' : 'POST';

    const res = fetch(`/api/Payment/postPayment`, {
        method: method,
        body: paymentData,
        headers: {
            AccessToken: accessToken,
        },
    });

    const response = ((await res).json() as unknown) as T;

    return response;
}

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
export async function callNetbanxRoute(data: PaymentDetails) {
    const paymentData = new URLSearchParams();
    if (data.cardNum !== undefined && data.cardExpiryMonth !== undefined && data.cardExpiryYear !== undefined) {
        paymentData.append('cardNum', data.cardNum);
        paymentData.append('cardExpiryMonth', data.cardExpiryMonth);
        paymentData.append('cardExpiryYear', data.cardExpiryYear);
    }
    paymentData.append('cvdNumber', data.cvdNumber);

    const res = fetch(`/api/Payment/postNetbanx`, {
        method: 'POST',
        body: paymentData,
        headers: {
            Netbanx: data.url,
        },
    });

    // const response = ((await res).json() as unknown) as T;
    const response = await (await res).text();

    return response;
}

export const healthCheck = async (req: NextApiRequest, res: NextApiResponse): Promise<Ping> => {
    const data = await fetch(`${apiUrl}/ping.json`);

    const response = (await data.json()) as Ping;

    return response;
};

export const getAddress = async (req: NextApiRequest, res: NextApiResponse): Promise<Address> => {
    const i = req.rawHeaders.indexOf('AccessToken');
    const accessToken = req.rawHeaders[i + 1];
    if (accessToken !== undefined) {
        const data = await fetch(`${apiUrl}/address.json?access_token=${accessToken}`, {
            headers: { Authorization: `Basic ${token}` },
        });

        const response = (await data.json()) as Address;

        return response;
    } else {
        return {} as Address;
    }
};

export const getCustomer = async (req: NextApiRequest, res: NextApiResponse): Promise<Card> => {
    const i = req.rawHeaders.indexOf('AccessToken');
    const accessToken = req.rawHeaders[i + 1];
    const data = await fetch(`${apiUrl}/customer.json?access_token=${accessToken}`, {
        headers: { Authorization: `Basic ${token}` },
    });

    const response = (await data.json()) as Card;

    return response;
};

export const getCards = async (req: NextApiRequest, res: NextApiResponse): Promise<Card> => {
    const i = req.rawHeaders.indexOf('AccessToken');
    const accessToken = req.rawHeaders[i + 1];
    const data = await fetch(`${apiUrl}/card.json?access_token=${accessToken}`, {
        headers: { Authorization: `Basic ${token}` },
    });

    const response = (await data.json()) as Card;

    return response;
};

export const postPayment = async (
    req: NextApiRequest,
    res: NextApiResponse,
    reqData: PaymentData,
): Promise<Payment> => {
    const i = req.rawHeaders.indexOf('AccessToken');
    const accessToken = req.rawHeaders[i + 1];

    const paymentMethodRef = reqData.paymentMethodRef;
    const addressId = reqData.addressId;
    const responseUrl = reqData.responseUrl;
    const amount = reqData.amount;
    const cardId = reqData.cardId;

    const url = cardId !== undefined ? `${apiUrl}/optimalPayment/${cardId}.json` : `${apiUrl}/optimalPayment.json`;
    const method = cardId !== undefined ? 'PUT' : 'POST';

    const paymentData = new URLSearchParams();
    paymentData.append('access_token', accessToken);
    paymentData.append('paymentMethodRef', paymentMethodRef);
    paymentData.append('addressId', addressId.toString());
    paymentData.append('responseUrl', responseUrl);
    paymentData.append('amount', amount.toString());

    const data = await fetch(url, {
        method: method,
        body: paymentData,
        headers: { Authorization: `Basic ${token}` },
    });

    const response = (await data.json()) as Payment;

    return response;
};

export const postNetbanx = async (
    req: NextApiRequest,
    res: NextApiResponse,
    reqData: PaymentDetails,
): Promise<string> => {
    const i = req.rawHeaders.indexOf('Netbanx');
    const netbanxUri = req.rawHeaders[i + 1];

    const cardNum = reqData.cardNum;
    const cardExpiryMonth = reqData.cardExpiryMonth;
    const cardExpiryYear = reqData.cardExpiryYear;
    const cvdNumber = reqData.cvdNumber;

    const paymentData = new URLSearchParams();
    if (cardNum !== undefined && cardExpiryMonth !== undefined && cardExpiryYear !== undefined) {
        paymentData.append('cardNum', cardNum);
        paymentData.append('cardExpiryMonth', cardExpiryMonth);
        paymentData.append('cardExpiryYear', cardExpiryYear);
    }
    paymentData.append('cvdNumber', cvdNumber);
    paymentData.append('storeCardIndicator', 'on');

    const data = await fetch(netbanxUri, {
        method: 'POST',
        body: paymentData,
        headers: {
            'Content-Type': 'text/html; charset=utf-8',
        },
    });

    const response = await data.text();

    return response;
};
