import auth0 from '@src/utils/auth0';
import axios from 'axios';
import { Customer } from '@interfaces/FSB/Customer';
import useSWR from 'swr';
import getConfig from 'next/config';
import { NextApiRequest, NextApiResponse } from 'next';

const { publicRuntimeConfig } = getConfig();
const fetcher = (url: RequestInfo): Promise<Customer> => fetch(url).then(res => res.json());
const gameServiceApiKey = publicRuntimeConfig.GAME_SERVICE_API_KEY || process.env.GAME_SERVICE_API_KEY;
export const GetCustomer = async (
    req: NextApiRequest,
    res: NextApiResponse,
    FSBaccessToken: string,
): Promise<Customer> => {
    try {
        const { accessToken } = await auth0.getAccessToken(req, res);
        const url = `${publicRuntimeConfig.GAME_SERVICE_API_URL}GetCustomerFunctionWithToken?FsbToken=${FSBaccessToken}`;

        const { data } = await axios.get<Customer>(url, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Ocp-Apim-Subscription-Key': `${gameServiceApiKey}`,
            },
        });
        data.lastUpdated = new Date();
        if (data && (data as Customer).error === 'error.tpgi.session_invalid') {
            const accessToken2 = await auth0.getAccessToken(req, res, {
                refresh: true,
            });
            const data2 = await axios.get<Customer>(url, {
                headers: {
                    Authorization: `Bearer ${accessToken2.accessToken}`,
                    'Ocp-Apim-Subscription-Key': `${gameServiceApiKey}`,
                },
            });

            data2.data.lastUpdated = new Date();
            return data2.data;
        }
        return data;
    } catch (e) {
        return {} as Customer;
    }
};

export const GetCustomerWithToken = async (
    req: NextApiRequest,
    res: NextApiResponse,
    FSBaccessToken: string,
): Promise<Customer> => {
    const url = `${publicRuntimeConfig.GAME_SERVICE_API_URL}GetCustomerFunctionWithToken?FsbToken=${FSBaccessToken}`;
    const { data } = await axios.get<Customer>(url, {
        headers: {
            'Ocp-Apim-Subscription-Key': `${gameServiceApiKey}`,
        },
    });
    return data;
};

export function GetCustomerData(): {
    userdata: Customer;
    loading: boolean;
    isError: string;
} {
    const { data, error } = useSWR(`/api/Customer/getToken`, fetcher, {
        refreshInterval: 60000,
        refreshWhenHidden: true,
    });

    return {
        userdata: data as Customer,
        loading: !error && !data,
        isError: !error && data ? (data as Customer).error : error,
    };
}

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
export const getCustomerInfo = async () => {
    const res = await fetch(`/api/Customer/getToken`);

    const body = (await res.json()) as Customer;

    return body;
};

export const getAccessToken = async (): Promise<string> => {
    const customerInfo = await getCustomerInfo();
    const accessToken = customerInfo.accessToken;
    return accessToken;
};
