import { useEffect } from 'react';

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
export default function useTitle(title) {
    useEffect(() => {
        document.title = title;
    });
}
