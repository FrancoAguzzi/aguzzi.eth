declare module 'axios-middleware' {
    export class Service {
        constructor(axios: AxiosStatic): Service;
        setHttp(axios: AxiosStatic): Service;
        unsetHttp(): Service;
        has(middleware: unknown): boolean;
        register(middlewares: unknown): Service;
        unregister(middleware: unknown): Service;
        reset(): Service;
        adapter(config: unknown): Promise<void>;
    }
}
