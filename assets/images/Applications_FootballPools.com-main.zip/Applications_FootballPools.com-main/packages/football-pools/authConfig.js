import { initAuth0 } from '@auth0/nextjs-auth0';
import getConfig from 'next/config';

const { publicRuntimeConfig } = getConfig();

export default initAuth0({
    secret: 'wefgpihqeoighqiopehfqenkqeihjieqfnoefeqfwfew',
    issuerBaseURL: publicRuntimeConfig.SSO_URL,
    clientSecret: publicRuntimeConfig.SSO_SECRET,
    clientID: publicRuntimeConfig.SSO_CLIENT,
    baseURL: publicRuntimeConfig.SITE_URL,
    authorizationParams: {
        scope: 'openid profile offline_access',
    },
});
