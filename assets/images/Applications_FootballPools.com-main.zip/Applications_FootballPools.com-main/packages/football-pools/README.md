# Website: footballpools.com

This project is the codebase for the website footballpools.com. It is a [next.js](https://nextjs.org/) website using [ISR](https://nextjs.org/docs/basic-features/data-fetching/incremental-static-regeneration) and [SSR](https://nextjs.org/docs/basic-features/pages#server-side-rendering). It utilises [react](https://reactjs.org/) and is written in [typescript](https://www.typescriptlang.org/)

This project is dependent on the following packages inside this monorepo

-   [pools-api](../pools-api)
-   [pools-components](../pools-components)
-   [shared](../shared)

This project uses [builder](https://builder.io) as a CMS for static pages and configurable data in the default [workspace](https://builder.io/content)

## Running as production

With Docker installed running the following command will launch the project in docker as it is in production.

```sh
docker compose up footballpools.com --build
```

# Contributing

The working branch is `main` and all pull requests should be made against it. Commits on `main` should be released to production as soon as possible.

## Getting started

The following are required before beginning development

-   Node >14.0
-   Yarn
-   .env.local file found [here](https://footballpools0.sharepoint.com/:u:/s/Technology/EUxRb7SV_6tGn-cyGPY-2LQBDF2V0SzB3wDNkMKAmcmC_Q?e=prKYd8&isSPOFile=1)

To develop locally:

1. Clone the repo

    ```sh
    git clone https://github.com/Sportech/Applications_FootballPools.com.git
    ```

2. Create a new branch

3. Install dependencies

    ```sh
    yarn
    ```

4. Start developing

    ```sh
    yarn dev
    ```

#### **Note about workspace development**

In this monorepo you can run yarn commands in two ways:

1. Navigating to the project directory and running the command (e.g. `./packages/football-pools`) to run yarn commands

    ```sh
    cd ./packages/football-pools
    yarn dev
    ```

2. Run commands at top level using `yarn workspace`

    ```sh
    yarn workspace football-pools dev
    ```

## Before commiting, run the following checks:

## Building

You can build the project with

```sh
yarn build
```

## Testing

To run tests against the project:

```sh
yarn test
```

If snapshots need updated, you can run

```sh
yarn test -u
```

## Linting

To check the formatting of your code run

```sh
yarn lint
```

## Typecheck

You can verify that the typescript types are all valid by running

```sh
yarn typecheck
```
