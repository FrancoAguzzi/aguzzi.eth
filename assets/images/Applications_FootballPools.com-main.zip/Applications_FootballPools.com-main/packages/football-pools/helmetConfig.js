// eslint-disable-next-line
const helmet = require('helmet');

module.exports = () => ({
    contentSecurityPolicy: {
        directives: {
            'default-src': helmet.contentSecurityPolicy.dangerouslyDisableDefaultSrc,
            frameAncestors: [
                "'self'",
                'https://builder.io',
                'https://localhost:3000',
                'https://*.footballpools.com/',
                'http://*.footballpools.com/',
            ],
        },
    },
    hsts: {
        maxAge: 63072000,
        includeSubDomains: true,
    },
});
