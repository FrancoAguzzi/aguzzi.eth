/* eslint-disable @typescript-eslint/no-var-requires */
const withReactSvg = require('next-react-svg');
const path = require('path');

const { PHASE_PRODUCTION_SERVER } = require('next/constants');

const withTM = require('next-transpile-modules')(['@fp/shared', '@sportech/pools-api', '@sportech/pools-components']);

const withComposite = config => withTM(withReactSvg(config));

const NEXTJS_IGNORE_TYPECHECK = process.env.NEXTJS_IGNORE_TYPECHECK === '1' || false;

const nextConfig = {
    env: {},
    include: path.resolve(__dirname, 'public/svg'),
    poweredByHeader: false,
    publicRuntimeConfig: {
        API_URL: process.env.API_URL || 'https://int-fpsvc.footballpools.com/api',
        APPINSIGHTS_INSTRUMENTATIONKEY: process.env.APPINSIGHTS_INSTRUMENTATIONKEY,
        BUILDER_API_KEY: process.env.BUILDER_API_KEY || '',
        GTM_ID: process.env.GTM_ID || 'GTM-PSFHGCW',
        LEGACY_FP_URL: process.env.LEGACY_FP_URL || 'https://uat.footballpools.com',
        PAYPAL_MERCHANT_ID: process.env.PAYPAL_MERCHANT_ID || '',
        SITE_URL: process.env.SITE_URL,
        STAGING_ENVIRONMENT: process.env.STAGING_ENVIRONMENT || 'uat',
        SSO_URL: process.env.SSO_URL || 'https://localhost:5000',
        SSO_SECRET: process.env.SSO_SECRET || 'secret',
        SSO_CLIENT: process.env.SSO_CLIENT || 'code-flow-iframe',
        THE_POOLS_URL: process.env.THE_POOLS_URL || 'https://www.thepools.com',
        THE_POOLS_SPORTSBOOK_URL: process.env.THE_POOLS_SPORTSBOOK_URL || 'https://play.thepools.com/sportsbook/',
        THE_POOLS_CASINO_URL: process.env.THE_POOLS_CASINO_URL || 'https://play.thepools.com/casino',
        THE_POOLS_VIRTUALS_URL: process.env.THE_POOLS_VIRTUALS_URL || 'https://play.thepools.com/sportsbook/VIRTUAL',
        SPEND_LIMIT_API_URL: process.env.SPEND_LIMIT_API_URL || 'http://uat-websrvs-01.sportech.tld:31573',
        ACCOUNT_HISTORY_IFRAME: process.env.TOGGLE_ACCOUNT_HISTORY_IFRAME || 'true',
        TOGGLE_REACTIVATION: process.env.TOGGLE_REACTIVATION || false,
        EDIT_LC_SELECTIONS: process.env.TOGGLE_EDIT_LC_SELECTIONS || false,
        LEADERBOARD_MAINTENANCE: process.env.LEADERBOARD_MAINTENANCE || 'true',
    },
    webpack: (config, { isServer, webpack }) => {
        // Fixes npm packages that depend on `fs` module
        if (!isServer) {
            config.node = {
                fs: 'empty',
            };
        }
        config.plugins.push(new webpack.IgnorePlugin(/\/__tests__\//));
        return config;
    },
    typescript: {
        ignoreBuildErrors: NEXTJS_IGNORE_TYPECHECK,
    },
    async redirects() {
        return [
            {
                source: '/',
                destination: '/home',
                permanent: false,
            },
            {
                source: '/account',
                destination: '/account/details/personal',
                permanent: true,
            },
            {
                source: '/account/details',
                destination: '/account/details/personal',
                permanent: true,
            },
            {
                source: '/games/:slug/results',
                destination: '/results/:slug',
                permanent: true,
            },
            {
                source: `/casino`,
                destination: '/casino-match-bet',
                permanent: true,
            },
            {
                source: `/pool-games/classic-pools`,
                destination: '/games/classic-pools',
                permanent: true,
            },
            {
                source: `/pool-games/goal-rush`,
                destination: '/games/goal-rush',
                permanent: true,
            },
            {
                source: `/pool-games/lucky-clover`,
                destination: '/games/lucky-clover',
                permanent: true,
            },
            {
                source: `/pool-games/:slug`,
                destination: `/home`,
                permanent: true,
            },
            {
                source: `/pool-games`,
                destination: `/home`,
                permanent: true,
            },
            {
                source: '/match-bet',
                destination: '/casino-match-bet',
                permanent: true,
            },
            {
                source: '/virtual-sports',
                destination: '/casino-match-bet',
                permanent: true,
            },
            {
                source: '/cash-out-pools',
                destination: '/casino-match-bet',
                permanent: true,
            },
            {
                source: '/results',
                destination: '/results/classic-pools',
                permanent: true,
            },
            {
                source: '/leaderboards',
                destination: '/leaderboards/classic-pools',
                permanent: true,
            },
            {
                source: '/games',
                destination: '/games/classic-pools/game',
                permanent: true,
            },
            {
                source: '/blog-item',
                destination: '/blog',
                permanent: true,
            },
            {
                source: '/news-article',
                destination: '/news-article/follow-mrs-potts',
                permanent: true,
            },
            {
                source: '/privilege-item',
                destination: '/privileges',
                permanent: true,
            },
        ];
    },
};

module.exports = (phase, { defaultConfig }) => {
    return phase === PHASE_PRODUCTION_SERVER ? withReactSvg(nextConfig) : withComposite(nextConfig);
};
