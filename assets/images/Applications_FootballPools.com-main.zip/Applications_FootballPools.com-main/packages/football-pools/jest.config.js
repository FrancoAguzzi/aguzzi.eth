module.exports = {
    collectCoverageFrom: ['**/src/**/*.{js,jsx,ts,tsx}', '!**/*.d.ts', '!**/node_modules/**', '!**/cypress/**'],
    setupFilesAfterEnv: ['<rootDir>/setupTests.js'],
    testPathIgnorePatterns: ['/node_modules/', '/.next/', '/cypress/', '/e2e/', '/k6/', '/.storybook/'],
    transform: {
        '^.+\\.(js|jsx|ts|tsx)$': '<rootDir>/../../node_modules/babel-jest',
    },
    transformIgnorePatterns: ['/node_modules/'],
    testEnvironment: 'jsdom',
    moduleNameMapper: {
        '\\.svg': '<rootDir>/src/testing/utils/transformSvg.js',
    },
    roots: ['<rootDir>'],
    reporters: [
        'default',
        ['jest-junit', { suiteNameTemplate: '{filepath}', outputDirectory: '.', outputName: 'junit.xml' }],
    ],
};
