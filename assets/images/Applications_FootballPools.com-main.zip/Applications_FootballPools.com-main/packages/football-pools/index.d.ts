declare module '@builder.io/widgets/dist/lib/components/Carousel.config';
declare module '@builder.io/widgets/dist/lib/components/Carousel';
declare module '@builder.io/widgets/dist/lib/components/Tabs.config';
declare module '@builder.io/widgets/dist/lib/components/Tabs';
declare module '@builder.io/widgets/dist/lib/components/Accordion.config';
declare module '@builder.io/widgets/dist/lib/components/Accordion';
declare module '@builder.io/widgets/dist/lib/components/Masonry.config';
declare module '@builder.io/widgets/dist/lib/components/Masonry';
