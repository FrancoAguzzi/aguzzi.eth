module.exports = {
    plugins: [
        ['styled-components', { ssr: true, displayName: true, preprocess: false }],
        [
            'module-resolver',
            {
                root: ['.'],
                alias: {
                    '@api': './src/api',
                    '@components': './src/components',
                    '@containers': './src/containers',
                    '@features': './src/features',
                    '@interfaces': './src/interfaces',
                    '@pages': './src/pages',
                    '@testing': './src/testing',
                    '@services': './src/services',
                    '@settings': './src/settings',
                    '@src': './src/',
                    '@sportech/pools-api': '../pools-api/src',
                    '@sportech/pools-components': '../pools-components/src',
                },
            },
        ],
    ],
    presets: ['next/babel'],
};
