module.exports = {
    root: true,
    ignorePatterns: ['node_modules/*', '.next'],
    extends: [
        '../../.eslintrc.base.js',

        'plugin:react/recommended',
        // TODO: Enable 'plugin:react-hooks/recommended',
        // TODO: Enable 'plugin:jsx-a11y/recommended',
        'plugin:@next/next/recommended',
        // TODO: Enable 'plugin:testing-library/react',
    ],

    env: {
        browser: true,
        es6: true,
        node: true,
    },
    rules: {
        'react/react-in-jsx-scope': 'off',
        'react/prop-types': 'off',
        '@typescript-eslint/explicit-function-return-type': ['off'],
        '@typescript-eslint/no-use-before-define': ['off'],
        'import/newline-after-import': ['error', { count: 1 }],
    },
    settings: {
        'import/ignore': ['dayjs'],
    },
    overrides: [
        {
            files: ['*.js', '*.jsx'],
            rules: {
                '@typescript-eslint/explicit-function-return-type': 'off',
            },
        },
    ],
};
