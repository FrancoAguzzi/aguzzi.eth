import styled from 'styled-components';
import { Button } from '@sportech/pools-components';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import { Step, TooltipRenderProps } from 'react-joyride';

export interface TourProps {
    stepIndex: number;
    run: boolean;
    inProgress: boolean;
}

export const getSteps = (isMobileOrTablet: boolean): Step[] => [
    {
        content: <h2>Tap or click the lucky dip button or the clovers to start choosing your numbers...</h2>,
        disableBeacon: true,
        target: '.step-1',
    },
    {
        content: <h2>...select 6 numbers between 1 and 47...</h2>,
        disableBeacon: true,
        target: isMobileOrTablet ? '.step-2m .step-2a' : '.step-2 .step-2a',
    },
    {
        content: <h2>...choose how many draws you want to enter...</h2>,
        disableBeacon: true,
        target: isMobileOrTablet ? '.step-2m .step-3' : '.step-2 .step-3',
    },
    {
        content: <h2>...once you have made all of your selections choose buy now...</h2>,
        disableBeacon: true,
        target: isMobileOrTablet ? '.step-2m .step-3 .step-4' : '.step-2 .step-3 .step-4',
    },
    {
        content: <h2>...and win up to £1 Million</h2>,
        disableBeacon: true,
        target: isMobileOrTablet ? '.step-2m .step-5' : '.step-2 .step-5',
    },
];

export const HowToPlayTooltip = ({
    index,
    step,
    backProps,
    closeProps,
    primaryProps,
    tooltipProps,
}: TooltipRenderProps) => (
    <TooltipBody {...tooltipProps}>
        <TooltipHeader>
            <TooltipCloseButton {...closeProps}>
                <img src="/cross_mark.png" />
            </TooltipCloseButton>
        </TooltipHeader>
        <TooltipContent>{step.content}</TooltipContent>
        <TooltipFooter>
            {index > 0 && (
                <TooltipButton {...(index == 4 ? closeProps : backProps)} id="back" index={index}>
                    <FormattedMessage>{index == 4 ? 'Close' : 'Back'}</FormattedMessage>
                </TooltipButton>
            )}
            {index < 4 && (
                <TooltipButton {...primaryProps} id="next" index={index}>
                    <FormattedMessage>Next</FormattedMessage>
                </TooltipButton>
            )}
        </TooltipFooter>
    </TooltipBody>
);

const TooltipBody = styled.div`
    display: flex;
    flex-direction: column;
    background-color: #fff;
    width: 250px;
    padding: 10px;
    border-radius: 10px;
`;
const TooltipContent = styled.div`
    font-size: 14px;
    text-align: center;
    h2 {
        margin: 0 0 10px 0;
    }
`;
const TooltipHeader = styled.div`
    height: auto;
`;
const TooltipFooter = styled.div`
    height: auto;
`;
const TooltipButton = styled(Button)<{ id: string; index?: number }>`
    background-color: ${props => (props.id == 'close' || props.id == 'back' ? '#d33838' : '#68d338')};
    float: ${props => (props.id == 'close' || props.id == 'back' ? 'left' : 'right')};
    border-radius: 25px;
    font-size: 14px;
    font-weight: bold;
    width: ${props => (props.index && props.index > 0 && props.index < 4 ? '49%' : '100%')};
    height: 100%;
    ${breakpoints.below('sm')} {
        font-size: 12px;
    }
    ${breakpoints.below('xs')} {
        font-size: 9px;
    }
    min-height: 25px;
`;
const TooltipCloseButton = styled(Button)`
    background-color: #fff;
    float: right;
    padding: 0;
    height: auto;
    font-size: 12px;
    font-weight: bold;
`;
const FormattedMessage = styled.div`
    color: #fff;
`;

export default HowToPlayTooltip;
