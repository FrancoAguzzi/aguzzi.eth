import { waitFor } from '@testing-library/react';

import LoginDetails from './loginDetails';
import { RecursivePartial } from '@fp/shared/src/testing/utils/RecursivePartial';
import { UserDetails } from '@fp/shared/src/features/authentication/UserDetails';
import { RootState } from '@fp/shared/src/rootReducer';
import { renderWithRedux } from '@fp/shared/src/testing/utils/renderWithRedux';

jest.mock('@fp/shared/src/settings/breakpoints');

const partialUser: RecursivePartial<UserDetails> = {
    email: 'test@test.com',
};

const userDetails: UserDetails = partialUser as UserDetails;

describe('LoginDetails', () => {
    it('should match snapshot', async () => {
        const { container } = renderWithRedux(<LoginDetails />, { authentication: { userDetails } } as RootState);

        await waitFor(() => expect(container).toMatchSnapshot());
    });
});
