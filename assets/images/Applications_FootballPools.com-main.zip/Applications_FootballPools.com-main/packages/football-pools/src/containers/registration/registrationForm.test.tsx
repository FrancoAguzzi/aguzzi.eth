import 'jest-styled-components';
import { RegistrationForm } from './registrationForm';
import { withTheme } from '@fp/shared/src/testing/utils/renderWithTheme';
import { renderWithRedux } from '@fp/shared/src/testing/utils/renderWithRedux';
import { RootState } from '@fp/shared/src/rootReducer';

describe('RegistrationForm', () => {
    it('should render without throwing an error and match snapshot', async () => {
        const { container, findByRole } = renderWithRedux(withTheme(<RegistrationForm />), {} as RootState);
        await findByRole(/button/i);
        expect(container).toMatchSnapshot();
    });
});
