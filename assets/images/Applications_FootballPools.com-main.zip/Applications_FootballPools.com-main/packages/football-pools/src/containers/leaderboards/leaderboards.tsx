/* eslint-disable import/named */
import withResultsLayout from '@fp/shared/src/components/Layouts/ResultsLayout/ResultsLayout';
import { useApi, GameType, LeaderboardResults, LeaderboardResultMembers } from '@sportech/pools-api';
import { NextPage } from 'next';
import { useRouter } from 'next/router';
import { useEffect, useRef, useState } from 'react';
import { LeaderboardTable } from '@fp/shared/src/components/Leaderboard/Leaderboard';
import styled, { ThemeProvider } from 'styled-components';
import { Button } from '@sportech/pools-components';
import { Loader } from '@fp/shared/src/components/Loader/Loader';
import { Select } from '@fp/shared/src/components/Forms/Inputs/Select';
import { getGameTitle, getThemeForGameType } from '@fp/shared/src/lib/utils';
import Link from 'next/link';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import { isEnabled } from '@fp/shared/src/core/toggle.builder';
import { LeaderboardResultWinners, LeaderboardWinners } from '@fp/shared/src/components/Leaderboard/LeaderboardWinners';
import { getLeaderboardWinnersDataByDuration } from '@fp/shared/src/core/leaderboardWinners.builder';
import { DropdownSelector } from '@fp/shared/src/components/Leaderboard/DropdownSelector';
import { HeadComponent } from '@fp/shared/src/settings/HeadComponent';
import { BuilderComponent } from '@builder.io/react';
import getConfig from 'next/config';

const { publicRuntimeConfig } = getConfig();

const PageContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
`;
const AsideContainer = styled.aside`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    align-self: flex-start;
    margin: 0 0 0 10px;
    width: 375px;
    @media (max-width: 750px) {
        display: none;
    }
`;
const ContentContainer = styled.div`
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: center;
    width: 100%;
`;

const Container = styled.main`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 750px;
    @media (max-width: 750px) {
        max-width: 95%;
        width: 95%;
    }
    position: relative;
`;
const PaginationContainer = styled.div`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-start;
    margin: 10px auto;
    width: 100%;
`;
const PaginationButton = styled(Button)`
    flex: 0;
`;
export const Tabs = ({
    game,
    enabledLeaderboards,
}: {
    game: GameType;
    enabledLeaderboards: Record<string, boolean>;
}): JSX.Element => {
    const tabRef = useRef<HTMLDivElement>(null);
    const outerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const tabRect = tabRef.current?.getBoundingClientRect();
        const outerRect = outerRef.current?.getBoundingClientRect();
        const inline: 'start' | 'end' | undefined =
            tabRect && outerRect && tabRect.left + tabRect.width > outerRect.width
                ? 'end'
                : tabRect && outerRect && tabRect.left < 0
                ? 'start'
                : undefined;
        if (inline) {
            tabRef.current?.scrollIntoView({
                behavior: 'smooth',
                block: 'end',
                inline: inline,
            });
        }
    }, [game]);
    return (
        <TabContainer ref={outerRef}>
            <TabScroll>
                {enabledLeaderboards['leaderboards-classic-pools'] && (
                    <Link href="/leaderboards/[id]" as="/leaderboards/classic-pools">
                        <Tab active={game === 'classic-pools'} ref={game === 'classic-pools' ? tabRef : null}>
                            <TabImg src="/logo_classic-pools.png" />
                        </Tab>
                    </Link>
                )}
                {enabledLeaderboards['leaderboards-goal-rush'] && (
                    <Link href="/leaderboards/[id]" as="/leaderboards/goal-rush">
                        <Tab active={game === 'goal-rush'} ref={game === 'goal-rush' ? tabRef : null}>
                            <TabImg src="/logo_goal-rush.png" />
                        </Tab>
                    </Link>
                )}
                {enabledLeaderboards['leaderboards-premier-6'] && (
                    <Link href="/leaderboards/[id]" as="/leaderboards/premier-6">
                        <Tab active={game === 'premier-6'} ref={game === 'premier-6' ? tabRef : null}>
                            <TabImg src="/logo_premier-6.png" />
                        </Tab>
                    </Link>
                )}
                {enabledLeaderboards['leaderboards-premier-10'] && (
                    <Link href="/leaderboards/[id]" as="/leaderboards/premier-10">
                        <Tab active={game === 'premier-10'} ref={game === 'premier-10' ? tabRef : null}>
                            <TabImg src="/logo_premier-10.png" />
                        </Tab>
                    </Link>
                )}
                {enabledLeaderboards['leaderboards-jackpot-12'] && (
                    <Link href="/leaderboards/[id]" as="/leaderboards/premier-12">
                        <Tab active={game === 'jackpot-12'} ref={game === 'jackpot-12' ? tabRef : null}>
                            <TabImg src="/logo_jackpot-12.png" />
                        </Tab>
                    </Link>
                )}
            </TabScroll>
        </TabContainer>
    );
};

const TabContainer = styled.div`
    display: flex;
    max-width: 100vw;
    overflow-x: scroll;
`;
const TabScroll = styled.div`
    display: flex;
    flex-shrink: 0;
`;
const Tab = styled.div<{ active?: boolean }>`
    width: 120px;
    height: 45px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #fff;
    border-radius: 10px 10px 0 0;
    opacity: ${({ active }) => (active ? '1' : '0.7')};
    cursor: pointer;
    :hover {
        opacity: 1;
    }
`;
const TabImg = styled.img`
    max-width: 100%;
`;

const StyledSelect = styled(Select)`
    margin: 0;
`;

const BannerContainer = styled.div<{ backgroundImgSrc?: string }>`
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-end;
    width: 100%;
    background-color: ${props => props.theme.colours.gameMainColour};
    background-image: ${(props): string =>
        props.backgroundImgSrc ? `url('${props.backgroundImgSrc}')` : `url('/background_dots.png')`};
    min-height: 150px;
    padding-left: 13%;
    @media (max-width: 1040px) {
        padding-left: 3%;
    }

    ${breakpoints.below('sm')} {
        min-height: 60px;
        padding-left: 0px;
    }
`;
const BannerHeader = styled.h1`
    color: #fff;
    font-style: italic;
    font-size: 3em;
    margin: 0;
    padding: 5px;
    ${breakpoints.below('sm')} {
        font-size: 2em;
    }
    ${breakpoints.below('xs')} {
        font-size: 1.5em;
    }
`;
const MobileOnlyContent = styled.div`
    display: none;
    @media (max-width: 750px) {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }
    width: 100%;
`;

const MaintenanceText = styled.p`
    font-size: 20px;
    font-weight: 400;
`;

const HelpEmail = styled.a`
    font-size: 20px;
`;

interface LeaderboardProps {
    game: GameType;
    enabledLeaderboards: Record<string, boolean>;
    count?: number;
    showCommunityTabs?: boolean;
}

export const Leaderboards: NextPage<LeaderboardProps> = ({
    game,
    count,
    enabledLeaderboards,
    showCommunityTabs,
}): JSX.Element => {
    const router = useRouter();
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [currentLeaderboards, setCurrentLeaderboards] = useState<LeaderboardResults | undefined>(undefined);
    const [currentMembers, setCurrentMembers] = useState<LeaderboardResultMembers | undefined>(undefined);
    const [currentPage, setCurrentPage] = useState<number>(1);
    const [currentCompetitionId, setCurrentCompetitionId] = useState<number | undefined>(undefined);
    const [currentWinners, setCurrentWinners] = useState<LeaderboardResultWinners[] | undefined>(undefined);
    const [currentWinnersIndex, setCurrentWinnersIndex] = useState<number | undefined>(undefined);
    const [selectOptions, setSelectOptions] = useState<{ label: string; value: string }[]>([]);
    const maintenance = publicRuntimeConfig.LEADERBOARD_MAINTENANCE === 'true';
    useEffect(() => {
        const leaderboardsEnabled = isEnabled('leaderboards-page');
        if (!leaderboardsEnabled) {
            router.push('/', '/home');
        }
        setCurrentCompetitionId(undefined);
        setCurrentPage(1);
    }, [game]);
    const handleSelectChange = (value: unknown): void => {
        const selection = parseInt((value as { label: string; value: string }).value as string);
        if (selection && !Number.isNaN(selection)) {
            setCurrentCompetitionId(selection);
            setCurrentPage(1);
        }
    };
    const itemListCount = count || 20;

    const { getLeaderboardResultsAsync } = useApi('backend');
    const mountedRef = useRef(true);
    useEffect(() => {
        return () => {
            mountedRef.current = false;
        };
    }, []);

    {
        !maintenance &&
            useEffect(() => {
                const fetchLeaderboard = async (): Promise<void> => {
                    if (mountedRef.current) {
                        // This check is required to prevent warning:
                        // Warning: Can't perform a React state update on an unmounted component. This is a no-op, ...

                        setIsLoading(true);
                        const res = await getLeaderboardResultsAsync(game, currentCompetitionId, count, currentPage);
                        const updateGameNameString = (name: string): string => {
                            return name
                                .replace('Goal Rush 8', 'Goal Rush')
                                .replace('Soccer 6', 'Premier 6')
                                .replace('Jackpot 12', 'Premier 12');
                        };
                        if (res.data) {
                            if (res.data.leaderboards) {
                                // Update only when present.
                                setCurrentLeaderboards(res.data.leaderboards);
                                setSelectOptions([
                                    {
                                        label: updateGameNameString(res.data.leaderboards.general.current.name),
                                        value: res.data.leaderboards.general.current.id.toString(),
                                    },
                                    {
                                        label: updateGameNameString(res.data.leaderboards.general.previous.name),
                                        value: res.data.leaderboards.general.previous.id.toString(),
                                    },
                                ]);
                                setCurrentCompetitionId(res.data.leaderboards.general.current.id);
                            }
                            setCurrentMembers(res.data.members);
                        } else {
                            // No leaderboard data for this game,
                            // clear any data from previous leaderboard data:
                            setSelectOptions([]);
                            setCurrentLeaderboards(undefined);
                        }
                        setIsLoading(false);
                    }
                };
                fetchLeaderboard();
            }, [currentPage, currentCompetitionId]);
    }
    {
        !maintenance &&
            useEffect(() => {
                const fetchLeaderboardWinners = async (): Promise<void> => {
                    if (mountedRef.current) {
                        const leaderboardWinnersData = await getLeaderboardWinnersDataByDuration(game, { months: 3 });
                        setCurrentWinners(leaderboardWinnersData);
                        setCurrentWinnersIndex(
                            leaderboardWinnersData && leaderboardWinnersData.length > 0 ? 0 : undefined,
                        );
                    }
                };
                fetchLeaderboardWinners();
            }, [game]);
    }

    const showWinnersOverride = game === 'classic-pools';
    const showPlayButton = game === 'classic-pools' || game === 'goal-rush';

    return router.isFallback && !maintenance ? (
        <Loader isLoading={true} />
    ) : (
        <>
            {showCommunityTabs && <BuilderComponent model="community-tabs" />}
            <HeadComponent title={`Leaderboards | ${getGameTitle(game)}`} />
            <ThemeProvider theme={getThemeForGameType(game)}>
                <PageContainer>
                    <BannerContainer backgroundImgSrc="/background_dots.png">
                        <BannerHeader>Leaderboards</BannerHeader>
                        <Tabs game={game} enabledLeaderboards={enabledLeaderboards} />
                    </BannerContainer>
                    <ContentContainer>
                        <Container>
                            <Loader isLoading={isLoading} zIndex={1} />
                            {!maintenance && (
                                <StyledSelect
                                    id="leaderboard-select"
                                    width="100%"
                                    options={selectOptions}
                                    isClearable={false}
                                    onChange={handleSelectChange}
                                    value={selectOptions.find(o => o.value === currentCompetitionId?.toString())}
                                />
                            )}
                            {/* <BasicSelector
                                defaultOption={
                                    selectOptions && selectOptions.length > 0 ? selectOptions[0].value : undefined
                                }
                                options={selectOptions}
                                onChange={e => {
                                    const selection = parseInt(e.target.value);
                                    if (selection && !Number.isNaN(selection)) {
                                        setCurrentCompetitionId(selection);
                                        setCurrentPage(1);
                                    }
                                }}
                            /> */}
                            {maintenance ? (
                                <MaintenanceText>
                                    Our Pools Leaderboard pages are currently under maintenance, please be assured that
                                    points are being calculated in the background and up to date Leaderboards will be
                                    published as soon as possible. All prizes will be paid in the usual timeframe. Thank
                                    you for your patience. If you require any further information, please contact{' '}
                                    <HelpEmail
                                        style={{ textDecoration: 'none', color: 'blue' }}
                                        href="mailto:help@footballpools.com"
                                    >
                                        help@footballpools.com
                                    </HelpEmail>
                                </MaintenanceText>
                            ) : (
                                <>
                                    <LeaderboardTable leaderboard={currentMembers} isLoading={isLoading} />
                                    <PaginationContainer>
                                        <PaginationButton
                                            onClick={() => {
                                                if (currentPage > 1) {
                                                    setCurrentPage(currentPage - 1);
                                                }
                                            }}
                                            bgColor="linear-gradient(to bottom, #d32703 0, #b02002 80%)"
                                            textColor="#fff"
                                            disabled={currentPage <= 1}
                                            height="30px"
                                            width="100px"
                                            fontWeight="bold"
                                            padding="5px 20px"
                                            margin="0 3px 0 0"
                                        >
                                            PREV
                                        </PaginationButton>
                                        <PaginationButton
                                            onClick={() => {
                                                if (currentMembers && currentMembers.members.length >= itemListCount) {
                                                    setCurrentPage(currentPage + 1);
                                                }
                                            }}
                                            bgColor="linear-gradient(to bottom, #d32703 0, #b02002 80%)"
                                            textColor="#fff"
                                            height="30px"
                                            width="100px"
                                            fontWeight="bold"
                                            padding="5px 20px"
                                            margin="0 0 0 3px"
                                            disabled={currentMembers && currentMembers.members.length < itemListCount}
                                        >
                                            NEXT
                                        </PaginationButton>
                                    </PaginationContainer>
                                    <MobileOnlyContent>
                                        <WinnersSection
                                            game={game}
                                            winners={currentWinners}
                                            setCurrentWinnersIndex={setCurrentWinnersIndex}
                                            currentWinnersIndex={currentWinnersIndex}
                                            showWinnersOverride={showWinnersOverride}
                                            showPlayButton={showPlayButton}
                                        />
                                    </MobileOnlyContent>
                                </>
                            )}
                        </Container>
                        {!maintenance &&
                            ((currentWinners && currentWinners.length > 0) ||
                                showWinnersOverride ||
                                showPlayButton) && (
                                // Don't render an aside element if there's no content to display/
                                <AsideContainer>
                                    <WinnersSection
                                        game={game}
                                        winners={currentWinners}
                                        setCurrentWinnersIndex={setCurrentWinnersIndex}
                                        currentWinnersIndex={currentWinnersIndex}
                                        showWinnersOverride={showWinnersOverride}
                                        showPlayButton={showPlayButton}
                                    />
                                </AsideContainer>
                            )}
                    </ContentContainer>
                </PageContainer>
            </ThemeProvider>
        </>
    );
};

const WinnersContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: ${props => props.theme.colours.primaryFont};
    width: 350px;
    @media (max-width: 350px) {
        width: 100%;
    }
`;
const LeaderboardWinnersSelectorContainer = styled.div`
    width: 100%;
    background: #363636;
    text-align: center;
    margin: 10px 0;
`;
const LeaderboardWinnersTitle = styled.div`
    text-transform: uppercase;
    font-size: 1rem;
    font-weight: bold;
    margin-top: 20px;
`;

interface WinnersSectionProps {
    game: GameType;
    setCurrentWinnersIndex: (index: number | undefined) => void;
    currentWinnersIndex?: number;
    winners?: LeaderboardResultWinners[];
    showWinnersOverride?: boolean;
    showPlayButton?: boolean;
}

const WinnersSection = ({
    game,
    setCurrentWinnersIndex,
    currentWinnersIndex,
    winners,
    showWinnersOverride,
    showPlayButton,
}: WinnersSectionProps): JSX.Element => {
    const title = getGameTitle(game);
    const currentWinnersBoard = winners && winners.length ? winners[currentWinnersIndex ?? 0] : undefined;
    return (
        <WinnersContainer>
            {((winners && winners.length > 0) || showWinnersOverride) && (
                <>
                    <LeaderboardWinnersTitle>{`${title} Leaderboard Winners`}</LeaderboardWinnersTitle>
                    <LeaderboardWinnersSelectorContainer>
                        <DropdownSelector
                            onClick={(id: number | string): void => {
                                setCurrentWinnersIndex(id as number);
                            }}
                            title={currentWinnersBoard?.name?.toLocaleUpperCase()}
                            items={winners?.map((l, index) => {
                                return {
                                    label: l.name as string,
                                    value: index,
                                };
                            })}
                            styles={{ titleFontSize: '1rem' }}
                        />
                    </LeaderboardWinnersSelectorContainer>

                    {currentWinnersBoard ? (
                        <LeaderboardWinners winners={currentWinnersBoard.winners} />
                    ) : (
                        <div style={{ textAlign: 'center', margin: '10px auto' }}>
                            Sorry, there is currently no data available to display for this period.
                        </div>
                    )}
                </>
            )}
            {showPlayButton && (
                <Link href="/games/[id]/game" as={`/games/${game}/game`}>
                    <Button
                        width="100%"
                        bgColor="#00c307"
                        hoverColor="green"
                        height="50px"
                        margin="20px auto"
                        textColor="white"
                        fontWeight="bold"
                    >
                        PLAY {title.toLocaleUpperCase()}
                    </Button>
                </Link>
            )}
            <TCLink href="/leaderboards-terms-and-conditions">Terms and Conditions</TCLink>
        </WinnersContainer>
    );
};

const TCLink = styled.a`
    align-self: end;
    :hover {
        text-decoration: underline;
    }
`;

export default withResultsLayout(Leaderboards);
