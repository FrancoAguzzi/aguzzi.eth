import { fireEvent, waitFor } from '@testing-library/react';
import { UserDetails } from '@fp/shared/src/features/authentication/UserDetails';
import { updateEmail } from '@fp/shared/src/api/account';
import { ChangeEmailForm } from './changeEmailForm';
import { ApiResponse } from '@fp/shared/src/services/apiResponse';
import { renderWithRedux } from '@fp/shared/src/testing/utils/renderWithRedux';
import { RootState } from '@fp/shared/src/rootReducer';
import { RecursivePartial } from '@fp/shared/src/testing/utils/RecursivePartial';

jest.mock('@fp/shared/src/api/account');

jest.mock('next/config', () => () => ({
    publicRuntimeConfig: {
        API_URL: 'api.url',
    },
}));

const partialUser: RecursivePartial<UserDetails> = {
    email: 'test@test.com',
};

const userDetails: UserDetails = partialUser as UserDetails;

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
const renderComponent = (initialState: RecursivePartial<RootState>) => {
    const utils = renderWithRedux(<ChangeEmailForm />, initialState as RootState);
    const emailField = utils.getByLabelText(/New Email/);
    const passwordField = utils.getByLabelText(/Confirm Password/);
    const formButton = utils.getByText(/Update Email/);

    const successfulSubmit = async (): Promise<void> => {
        const mockUpdateEmail = updateEmail as jest.MockedFunction<typeof updateEmail>;
        mockUpdateEmail.mockResolvedValue(userDetails);

        fireEvent.input(emailField, { target: { value: 'test@test.com' } });
        fireEvent.input(passwordField, { target: { value: 'Testtest1' } });
        fireEvent.click(formButton);

        await utils.findByRole(/alert/);
    };

    const failedSubmit = async (error: ApiResponse<never>): Promise<void> => {
        const mockUpdateEmail = updateEmail as jest.MockedFunction<typeof updateEmail>;
        mockUpdateEmail.mockResolvedValue(error);

        fireEvent.input(emailField, { target: { value: 'test@test.com' } });
        fireEvent.input(passwordField, { target: { value: 'Testtest1' } });
        fireEvent.click(formButton);

        await utils.findAllByRole(/alert/);
    };

    return {
        ...utils,
        emailField,
        passwordField,
        formButton,
        successfulSubmit,
        failedSubmit,
    };
};

describe('changeEmailForm', () => {
    it('should match snapshot', async () => {
        const { container } = renderComponent({ authentication: { userDetails } });

        await waitFor(() => expect(container).toMatchSnapshot());
    });

    it('should only be able to be submitted if form is valid', async () => {
        const { emailField, passwordField, formButton } = renderComponent({ authentication: { userDetails } });

        await waitFor(() => formButton);

        expect(formButton).toBeDisabled();

        fireEvent.input(emailField, { target: { value: 'test@test.com' } });
        fireEvent.input(passwordField, { target: { value: 'Testtest1' } });

        await waitFor(() => formButton);

        expect(formButton).toBeEnabled();
    });

    it('should show an error for an invalid email', async () => {
        const { emailField, findByRole } = renderComponent({ authentication: { userDetails } });

        await waitFor(() => emailField);

        fireEvent.input(emailField, { target: { value: 'Not an Email' } });

        const error = await findByRole(/alert/);

        expect(error).toBeVisible();
        expect(error).toHaveTextContent(/Invalid email/);
    });

    it('should call updateEmail on form submit', async () => {
        const { successfulSubmit } = renderComponent({ authentication: { userDetails } });
        const mockUpdateEmail = updateEmail as jest.MockedFunction<typeof updateEmail>;
        mockUpdateEmail.mockResolvedValue(userDetails);

        expect(mockUpdateEmail).not.toHaveBeenCalled();

        await successfulSubmit();

        expect(mockUpdateEmail).toHaveBeenCalled();
    });

    it('should show an error for duplicate email after submit', async () => {
        const { failedSubmit, findByRole } = renderComponent({ authentication: { userDetails } });

        await failedSubmit({ isError: true, message: 'email_exists' });
        const emailError = await findByRole(/alert/);

        expect(emailError).toBeVisible();
        expect(emailError).toHaveTextContent('This email address is already registered to an account.');
    });

    it('should show an error for invalid password after submit', async () => {
        const { failedSubmit, findByRole } = renderComponent({ authentication: { userDetails } });

        await failedSubmit({ isError: true, message: 'incorrect_password' });
        const emailError = await findByRole(/alert/);

        expect(emailError).toBeVisible();
        expect(emailError).toHaveTextContent('Your password was incorrect. Please try again.');
    });

    it('should show success message when submit is successful', async () => {
        const { successfulSubmit, findByRole } = renderComponent({ authentication: { userDetails } });

        await successfulSubmit();
        const successMessage = await findByRole(/alert/);

        expect(successMessage).toHaveTextContent(/Email updated/);
    });
});
