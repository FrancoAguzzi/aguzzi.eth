import { useState, useRef } from 'react';
import styled from 'styled-components';

const TooltipContainer = styled.div<{ isOpen: boolean; isShaking?: boolean }>`
    position: absolute;
    opacity: ${props => (props.isOpen ? 1 : 0)};
    transition: opacity 0.5s linear;
    top: -50px;
    max-width: 251px;
    text-align: center;
    animation: ${props => (props.isShaking ? 'shake 0.5s' : '')};

    @keyframes shake {
        0% {
            transform: translate(1px, 1px) rotate(0deg);
        }
        10% {
            transform: translate(-1px, -2px) rotate(-1deg);
        }
        20% {
            transform: translate(-3px, 0px) rotate(1deg);
        }
        30% {
            transform: translate(3px, 2px) rotate(0deg);
        }
        40% {
            transform: translate(1px, -1px) rotate(1deg);
        }
        50% {
            transform: translate(-1px, 2px) rotate(-1deg);
        }
        60% {
            transform: translate(-3px, 1px) rotate(0deg);
        }
        70% {
            transform: translate(3px, 1px) rotate(-1deg);
        }
        80% {
            transform: translate(-1px, -1px) rotate(1deg);
        }
        90% {
            transform: translate(1px, 2px) rotate(0deg);
        }
        100% {
            transform: translate(1px, -2px) rotate(-1deg);
        }
    }
`;

const TooltipContentContainer = styled.div`
    font-size: 0.75rem;
    padding: 5px 10px;
    background: #fff;
    border-radius: 10px;
    border: 1px solid #000;
`;

const TooltipContent = styled.h4`
    color: #000;
`;

const TooltipArrow = styled.div`
    position: absolute;
    width: 0;
    height: 0;
    border-color: transparent;
    border-right-color: transparent;
    border-style: solid;
    top: auto;
    bottom: -9px;
    left: 50%;
    border-width: 10px 10px 0;
    border-top-color: #000;
`;

interface CheckFindTooltipProps {
    isOpen: boolean;
    shake: boolean;
}

export const CheckFindTooltip = ({ isOpen, shake }: CheckFindTooltipProps) => {
    const [toggleShake, setToggleShake] = useState<boolean>(false);
    const [isShaking, setIsShaking] = useState<boolean>(false);
    const elRef = useRef<HTMLInputElement>(null);

    if (toggleShake != shake) {
        setToggleShake(shake);
        setIsShaking(true);
        if (elRef.current) elRef.current.scrollIntoView(false);
        setTimeout(() => {
            setIsShaking(false);
        }, 500);
    }

    return (
        <TooltipContainer isOpen={isOpen} isShaking={isShaking} ref={elRef}>
            <TooltipArrow />
            <TooltipContentContainer>
                <TooltipContent>Click Find to search for your address</TooltipContent>
            </TooltipContentContainer>
        </TooltipContainer>
    );
};

export default CheckFindTooltip;
