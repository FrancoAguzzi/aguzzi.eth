/* eslint-disable import/named */
import { FunctionComponent, useEffect, ChangeEvent, useState } from 'react';
import styled, { useTheme } from 'styled-components';
import { useSelector, useDispatch } from 'react-redux';
import {
    getWagersSelector,
    ConfirmWagers,
    confirmWagers,
    getBetSlipSelector,
    toBetSlipKey,
    createWagers,
    PurchaseType,
    ApiConfig,
    finaliseWagers,
    authorisedWagers,
    AuthoriseCardResponse,
    PoolsApiError,
    wagersError,
    WagersSlice,
    clearError,
    useApi,
    PaymentMethod,
    PaymentMethods,
    resetWagers,
    ResetBetSlipSelections,
    initialiseWagers,
    BetSlip,
    PaymentDetails,
    setupCard,
    CardDetails,
    SetupCardForm,
    completeCardSetup,
} from '@sportech/pools-api';
import { AppDispatch } from '@fp/shared/src/store';
import { useRouter } from 'next/router';
import { useSubscriptionApiAdaptor } from '@fp/shared/src/api/subscriptionApi/useSubscriptionApiAdaptor';
import { getSpendCheck, getSpendLimit } from '@fp/shared/src/api/spendLimitApi/useSpendLimitApiAdaptor';
import { isHdaGame } from '@fp/shared/src/lib/utils';
import { getAuthenticationSelector } from '@fp/shared/src/features/authentication/authenticationSelectors';
import { closePopup, getTotalPrice, openPopup, Popup } from '@sportech/pools-components';
import { FundsCompliancePopup } from '@fp/shared/src/components/Popup/FundsCompliancePopup';
import { isAppError } from '@fp/shared/src/core/appError';
import { updateFundsCompliance } from '@fp/shared/src/api/account';
import { addUserDetails } from '@fp/shared/src/features/authentication/authenticationSlice';
import { useEcommerceTags } from '@fp/shared/src/core/ecommerceTags';
import { MaximumLinesReachedPopup } from '@fp/shared/src/components/Popup/MaximumLinesReachedPopup';
import { PaymentMethodsUnavailablePopup } from '@fp/shared/src/components/Popup/PaymentMethodsUnavailablePopup';
import { PaymentPageProps } from '@pages/games/payment';
import { PayPalCheckoutApi } from '@fp/shared/src/components/Forms/Payment/PayPalForm';
import { SlimPopup } from '@fp/shared/src/components/Popup/SlimPopup';
import { AuthenticationHandler } from '@fp/shared/src/components/AuthenticationHandler/AuthenticationHandler';
import { SetWeeklySubscriptionLimitForm } from '@fp/shared/src/containers/account/setWeeklySubscriptionLimit';
import { SpendLimitForm } from '@fp/shared/src/containers/account/setSpendLimitForm';
import { SubscriptionPaymentView } from './SubscriptionPaymentView';
import { OneTimePaymentView } from './OneTimePaymentView';
import { logger } from '@services/appInsights';
import { useAuthToken } from '@fp/shared/src/api/subscriptionApi/useAuthToken';
import getConfig from 'next/config';

const { publicRuntimeConfig } = getConfig();

const SubtitleText = styled.h4<{ fontColour?: string; fontSize?: string }>`
    color: ${props => props.fontColour || props.theme.colours.primary};
    font-size: ${props => props.fontSize || '1rem'};
    margin: 10px;
`;

const Container = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    max-width: 390px;
    min-width: 320px;
`;

//type PaymentMethodType = 'directDebit' | 'visaDebit' | 'paypal';

const validateWagers = (wagersState: WagersSlice): boolean => {
    let ret = true;
    if (!wagersState.wagers || wagersState.wagers.length <= 0) {
        ret = false;
    }
    return ret;
};

export const Payment = ({
    paymentDetailsContent,
    oneTimePayment,
    competitions,
    headerRef,
}: PaymentPageProps): JSX.Element => {
    const wagersState = useSelector(getWagersSelector);
    const betslipState = useSelector(getBetSlipSelector);
    const userState = useSelector(getAuthenticationSelector);
    const dispatch = useDispatch<AppDispatch>();
    const router = useRouter();
    const { getPaymentMethodsAsync } = useApi('backend');
    const [cardErrors, setCardErrors] = useState<PoolsApiError[] | undefined>(undefined);
    const [directDebitErrors, setDirectDebitErrors] = useState<PoolsApiError[] | undefined>(undefined);
    const [payPalErrors, setPayPalErrors] = useState<PoolsApiError[] | undefined>(undefined);
    const [confirmWagersData, setConfirmWagersData] = useState<ConfirmWagers | undefined>(undefined);
    const [paymentMethodOptions, setPaymentMethodOptions] = useState<PaymentMethods | undefined>(undefined);
    const [isLoading, setIsLoading] = useState<boolean>(wagersState.isFetching || false);
    const [fundsComplianceAccepted, setFundsComplianceAccepted] = useState<boolean>(false);
    const [isPayPalCallback, setIsPayPalCallback] = useState<boolean>(() => {
        const paypal = router.query.paypal as string;
        const token = router.query.token as string;
        return Boolean(paypal && token && (paypal === 'confirm' || paypal === 'cancel'));
    });
    const [paymentStep, setPaymentStep] = useState<'details' | 'confirming' | 'confirm'>(
        isPayPalCallback ? 'confirming' : 'details',
    );
    const [hasSpendLimit, setHasSpendLimit] = useState<boolean>(false);
    const { checkoutOption, confirmPlay, purchase, paymentError } = useEcommerceTags(
        'football-pools',
        'The Football Pools',
    );
    const { getToken } = useAuthToken();
    const theme = useTheme();

    const totalPrice = (inPence?: boolean) =>
        getTotalPrice(
            isHdaGame(wagersState.game),
            wagersState.game === 'lucky-clover',
            betslipState[toBetSlipKey(wagersState.game)],
        ) * (inPence ? 100 : 1);

    // useEffect(() => {
    //     // Redirect user to game page if wagers are invalid.
    //     if (userState.isStateLoaded && wagersState && !validateWagers(wagersState)) {
    //         console.log('invalid wagers');
    //         router.push(`/games/${wagersState.gameVariant || wagersState.game}/game`);
    //     }
    // }, [userState.isStateLoaded]);

    /**
     * Helper function.
     * Determine whether user has returned to page from paypal portal.
     */

    /**
     * Toggle payment method control.
     * Setting this triggers the create wagers action.
     */
    const [currentPaymentMethod, setCurrentPaymentMethod] = useState<PaymentMethod | undefined>(
        isPayPalCallback ? 'paypal' : undefined,
    );

    useEffect(() => {
        setIsLoading(wagersState.isFetching || paymentMethodOptions === undefined || false);
    }, [wagersState.isFetching]);

    /**
     * Set isPayPalCallback flag when redirected from PayPal portal.
     */
    useEffect(() => {
        if (isPayPalCallback) {
            const paypal = router.query.paypal as string;
            const token = router.query.token as string;

            if (wagersState.stage === 'created' && paypal === 'confirm' && token) {
                // User has confirmed agreement with PayPal, confirm the order:
                const data: ConfirmWagers = {
                    paypalDetails: {
                        token: token,
                    },
                };
                dispatch(confirmWagers(data, wagersState.game, totalPrice(true)));
            } else if (paypal === 'cancel') {
                // User has cancelled agreement with PayPal, show error message:
                dispatch(wagersError({ title: 'Not authorised with PayPal', code: 'paypal_cancel' }));
                // router.replace('games/payment', undefined, { shallow: true });
            }
        }
    }, []);

    useEffect(() => {
        headerRef ? headerRef.scrollIntoView() : window.scrollTo(0, 0);
    }, [paymentStep, isLoading]);

    /**
     * Get available payment methods for this order on page load.
     */
    useEffect(() => {
        const fetchPaymentMethods = async (): Promise<void> => {
            if (
                paymentMethodOptions === undefined &&
                getToken() !== undefined &&
                getToken() !== '' &&
                userState.isStateLoaded &&
                wagersState.wagers &&
                wagersState.wagers.length > 0 &&
                userState.isLoggedIn &&
                userState.userDetails !== undefined &&
                userState.userDetails.firstName
            ) {
                setIsLoading(true);

                if (oneTimePayment) {
                    const spendLimit = await getSpendLimit();
                    setHasSpendLimit(spendLimit.currentSpendLimits.length > 0);
                    const spendCheck = await getSpendCheck(totalPrice(true));
                    if (!spendCheck) {
                        dispatch(openPopup('spendLimitExceeded'));
                        dispatch(closePopup('payment'));
                        return;
                    }
                }

                const paymentMethodsRes = await getPaymentMethodsAsync(
                    wagersState.game,
                    wagersState.wagers.length,
                    oneTimePayment,
                );
                const paymentMethodOpts: PaymentMethods | undefined = paymentMethodsRes.data;

                if (!paymentMethodsRes.data || paymentMethodsRes.error) {
                    console.debug(
                        'payment:fetchPaymentMethods:payment methods error',
                        paymentMethodsRes.data,
                        paymentMethodsRes.error,
                    );
                    // Show error message if the request fails:
                    dispatch(
                        wagersError({
                            title: 'No payment methods available',
                            code: 'payment_methods_unavailable',
                        }),
                    );
                    setIsLoading(false);
                }
                if (paymentMethodOpts && paymentMethodOpts.paymentMethods && wagersState.game === 'lucky-clover') {
                    // We cannot accept RT clover payments:
                    paymentMethodOpts.paymentMethods = paymentMethodOpts.paymentMethods.filter(p => p !== 'card');
                }
                if (paymentMethodOpts && paymentMethodOpts.paymentMethods) {
                    if (
                        wagersState.game == 'classic-pools' &&
                        paymentMethodOpts.paymentMethods.includes('direct-debit')
                    ) {
                        setCurrentPaymentMethod('direct-debit');
                    } else if (paymentMethodOpts.paymentMethods.includes('card')) {
                        setCurrentPaymentMethod('card');
                    } else if (paymentMethodOpts.paymentMethods.includes('direct-debit')) {
                        setCurrentPaymentMethod('direct-debit');
                    } else if (paymentMethodOpts.paymentMethods.includes('paypal')) {
                        setCurrentPaymentMethod('paypal');
                    }
                    if (paymentMethodOpts.paymentMethods.length <= 0) {
                        console.debug('payment:fetchPaymentMethods:payment methods empty', paymentMethodOpts);
                        // No payment types available, show popup:
                        dispatch(
                            wagersError({
                                title: 'No payment methods available',
                                code: 'payment_methods_unavailable',
                            }),
                        );
                    } else if (!paymentMethodOpts.paymentMethods.find(p => p === 'direct-debit')) {
                        // Only card payments are allowed.
                        if (wagersState.game === 'lucky-clover') {
                            // We cannot accept RT clover payments:
                            dispatch(
                                wagersError({
                                    title: 'Unsupported payment method',
                                    code: 'unsupported_payment_method',
                                }),
                            );
                        }
                    }
                }
                setPaymentMethodOptions(paymentMethodOpts);
            } else {
                setIsLoading(true);
            }
        };
        fetchPaymentMethods();
    }, [getToken(), userState.isStateLoaded, userState.userDetails]);

    /**
     * Create wagers order for selected payment type.
     * Triggered on payment method toggle updates.
     */
    useEffect(() => {
        if (paymentMethodOptions && (!isPayPalCallback || currentPaymentMethod !== 'paypal')) {
            const betslipKey = toBetSlipKey(wagersState.game);
            const purchaseType: PurchaseType =
                oneTimePayment && wagersState.purchaseType === 'OneOff'
                    ? 'OneOff'
                    : currentPaymentMethod === 'direct-debit'
                    ? 'Subscription'
                    : 'ByGames';
            const paymentMethod: PaymentMethod =
                currentPaymentMethod === 'direct-debit'
                    ? 'direct-debit'
                    : currentPaymentMethod === 'card'
                    ? 'card'
                    : 'paypal';
            // console.log('updating payment method', betslipKey, purchaseType);
            dispatch(
                createWagers(
                    wagersState.wagers as BetSlip[],
                    betslipKey,
                    purchaseType,
                    wagersState.competition,
                    paymentMethod,
                ),
            );
            checkoutOption(
                wagersState.game,
                getTotalPrice(
                    isHdaGame(wagersState.game),
                    wagersState.game === 'lucky-clover',
                    betslipState[betslipKey],
                ),
                currentPaymentMethod === 'direct-debit'
                    ? 'subscription-direct-debit'
                    : 'visaCard'
                    ? 'subscription-credit-card'
                    : 'subscription-paypal',
                wagersState.gameVariant,
            );
        }
    }, [currentPaymentMethod, paymentMethodOptions]);

    /**
     * Triggered on wagersState.stage updates.
     */
    useEffect(() => {
        /**
         * BMS Card payment has been setup, confirm wagers with api.
         */
        const handleSetupCardComplete = (): void => {
            if (wagersState.stage === 'card-setup-complete') {
                const data = confirmWagersData as PaymentDetails;
                if (data) {
                    data.sessionId = wagersState.completedCardSetup?.sessionId;
                    data.returnUrl = `${publicRuntimeConfig.API_URL}/orders/authorise-card`;
                    dispatch(confirmWagers(data, wagersState.game, totalPrice(true)));
                } else {
                    dispatch(wagersError({ title: 'card-setup error', code: 'card_setup_failed' }));
                }
                // setConfirmWagersData(undefined);
            }
        };
        /**
         * Payment has been confirmed, navigate to game page to show confirm popup.
         */
        const handleConfirmed = async (): Promise<void> => {
            if (wagersState.stage === 'confirmed') {
                // dispatch(ResetBetSlipSelections({ ItemKey: 'ClassicPools' }));
                purchase(
                    betslipState[toBetSlipKey(wagersState.game)],
                    wagersState.game,
                    currentPaymentMethod === 'direct-debit'
                        ? 'subscription-direct-debit'
                        : 'visaCard'
                        ? 'subscription-credit-card'
                        : 'subscription-paypal',
                    userState.userDetails && userState.userDetails.status && userState.userDetails?.status !== 'player'
                        ? 'FTS'
                        : 'RS',
                    wagersState.orderId,
                    wagersState.gameVariant,
                );

                setPaymentStep('confirm');
            }
        };
        /**
         * Card payment has been 3DS authorised, finalise wagers with api.
         */
        const handleFinalise = (): void => {
            if (wagersState.stage === 'authorised') {
                dispatch(finaliseWagers((confirmWagersData as PaymentDetails)?.cardDetails));
            }
        };
        /**
         * Handle api errors.
         * Pass any form specific errors to card / debit forms.
         */
        const handleError = (): void => {
            if (wagersState.stage === 'error') {
                const error = { ...(wagersState.error as PoolsApiError) };
                const setFormErrors = (err: PoolsApiError): void => {
                    if (currentPaymentMethod === 'card') {
                        setCardErrors([err]);
                    } else if (currentPaymentMethod === 'direct-debit') {
                        setDirectDebitErrors([err]);
                    } else {
                        setPayPalErrors([err]);
                    }
                };
                if (error) {
                    if (error.code) {
                        switch (error.code) {
                            // case 'pending_verification': {
                            //     if (wagersState.finaliseDetails) {
                            //         dispatch(confirmedWagers(wagersState.finaliseDetails as ConfirmedWagers));
                            //     }
                            //     break;
                            // }
                            case 'payment_failed':
                            case 'card_setup_failed':
                            case '3ds_error': {
                                error.title =
                                    'Sorry, there was an error processing your payment. Please try again later.';
                                setFormErrors(error);
                                dispatch(openPopup('paymentFailed'));
                                break;
                            }
                            case 'unsupported_payment_method': {
                                error.title = 'Sorry you have reached the limit of purchasable lines for this game.';
                                setFormErrors(error);
                                dispatch(openPopup('maximumLinesReached'));
                                break;
                            }
                            case 'ValidationError': {
                                error.title =
                                    currentPaymentMethod === 'card'
                                        ? 'Please enter a valid Visa card number. If you do not have a Visa card, please select a different payment option.'
                                        : 'Please enter a valid direct debit number.';
                                setFormErrors(error);
                                break;
                            }
                            case 'payment_methods_unavailable': {
                                setFormErrors(error);
                                dispatch(openPopup('paymentMethodsUnavailable'));
                                break;
                            }
                            case 'limit_incompatibility':
                            case 'limit_incompatibility_within_cooling_off': {
                                setFormErrors(error);
                                dispatch(openPopup('exceededSubscriptionLimit'));
                                break;
                            }
                            default: {
                                setFormErrors(error);
                                break;
                            }
                        }
                    } else {
                        console.error('payment error', wagersState.stage, error);
                        setFormErrors(error);
                    }
                    paymentError(`pv1:${error.code}:${wagersState.game}`, `${error.title}`);
                    logger.log(`pv1:${error.code}:${wagersState.game}`, `${error.title}`);
                }
                if (!error || error.code !== 'limit_incompatibility') {
                    // tidy wagers state so payment can be re-attempted:
                    if (wagersState.preErrorStage === 'initialised') {
                        dispatch(clearError('initialised'));
                    } else {
                        dispatch(clearError('created'));
                    }
                }
            }
        };
        handleSetupCardComplete();
        handleConfirmed();
        handleFinalise();
        handleError();
    }, [wagersState.stage]);

    const onToggleChange = (event: ChangeEvent<HTMLInputElement>): void => {
        const method = event.target.value as PaymentMethod;
        // console.log('toggle', method);
        if (payPalErrors) {
            setPayPalErrors(undefined);
            router.replace('payment', undefined, { shallow: true });
        }
        setCurrentPaymentMethod(method);
    };

    const onPaymentTypeSelected = (paymentType: PaymentMethod): void => {
        setIsLoading(true);
        setCurrentPaymentMethod(paymentType);
    };

    const onSubmitCardForm = async (data: ConfirmWagers): Promise<void> => {
        confirmPlay(
            wagersState.game,
            totalPrice(),
            currentPaymentMethod === 'direct-debit'
                ? 'subscription-direct-debit'
                : currentPaymentMethod === 'card'
                ? 'subscription-credit-card'
                : 'subscription-paypal',
            wagersState.gameVariant,
        );
        const pd = data as PaymentDetails;
        if (pd) {
            pd.purchaseType = wagersState.purchaseType;
            pd.oneTime = oneTimePayment;
        }
        if (!userState.userDetails?.consents?.fundsCompliance) {
            // User must confirm funds compliance:
            setConfirmWagersData(data);
            dispatch(openPopup('fundsCompliance'));
        } else {
            // Proceed with order flow:
            setConfirmWagersData(data);
            dispatch(setupCard({ cardDetails: (data as PaymentDetails)?.cardDetails as CardDetails }));
        }
    };
    const onSubmitDirectDebitForm = (data: ConfirmWagers): void => {
        // console.log('submit direct debit', data);
        confirmPlay(
            wagersState.game,
            totalPrice(),
            currentPaymentMethod === 'direct-debit'
                ? 'subscription-direct-debit'
                : currentPaymentMethod === 'card'
                ? 'subscription-credit-card'
                : 'subscription-paypal',
            wagersState.gameVariant,
        );
        const pd = data as PaymentDetails;
        if (pd) {
            pd.purchaseType = wagersState.purchaseType;
        }
        dispatch(confirmWagers(data, wagersState.game, totalPrice(true)));
    };
    const getTermUrl = (): string => {
        const adaptor = useSubscriptionApiAdaptor();
        const apiConfig: ApiConfig = { clientType: 'backend' };
        const ret = `${adaptor.getBaseUrl(apiConfig)}${
            adaptor.getAuthoriseCardEndpoint ? adaptor.getAuthoriseCardEndpoint(apiConfig) : ''
        }`;
        return ret;
    };
    const onAuthoriseSuccess = (res: AuthoriseCardResponse): void => {
        dispatch(authorisedWagers(res));
    };
    const onAuthoriseError = (error: unknown): void => {
        console.error('auth error', error);
        dispatch(wagersError({ title: '3ds auth error', code: '3ds_error' }));
    };
    const onSubmitPayPalForm = (): boolean => {
        let ret = false;
        confirmPlay(
            wagersState.game,
            totalPrice(),
            currentPaymentMethod === 'direct-debit'
                ? 'subscription-direct-debit'
                : currentPaymentMethod === 'card'
                ? 'subscription-credit-card'
                : 'subscription-paypal',
            wagersState.gameVariant,
        );
        if (!userState.userDetails?.consents?.fundsCompliance) {
            // User must confirm funds compliance:
            dispatch(openPopup('fundsCompliance'));
        } else {
            // Redirect user to PayPal payment portal:
            // setPaymentStep('confirming');
            setIsLoading(true);
            ret = true;
        }
        return ret;
    };
    const getAmount = (): string => {
        const ret = (totalPrice() * 10).toLocaleStringCash();
        return ret;
    };
    const onFundsComplianceClickClose = (): void => {
        if (!fundsComplianceAccepted) {
            setConfirmWagersData(undefined);
            router.push(`/games/${wagersState.gameVariant || wagersState.game}/game`);
        }
    };
    const onFundsComplianceClickConfirm = async (): Promise<void> => {
        setFundsComplianceAccepted(true);
        const res = await updateFundsCompliance({ fundsCompliance: true });
        if (!isAppError(res)) {
            dispatch(addUserDetails(res));
            if (currentPaymentMethod === 'direct-debit') {
                dispatch(confirmWagers(confirmWagersData as ConfirmWagers, wagersState.game, totalPrice(true)));
                setConfirmWagersData(undefined);
            } else if (currentPaymentMethod === 'card') {
                dispatch(setupCard({ cardDetails: (confirmWagersData as PaymentDetails)?.cardDetails as CardDetails }));
            } else if (currentPaymentMethod === 'paypal') {
                const paypal = window.paypal as {
                    checkout: PayPalCheckoutApi;
                };
                if (paypal && wagersState.payPalToken) {
                    try {
                        paypal.checkout.startFlow(wagersState.payPalToken);
                    } catch (error) {
                        paypal.checkout.closeFlow();
                    }
                }
            }
        } else {
            if (isAppError(res)) {
                dispatch(
                    wagersError({
                        title: res.apiError?.title || 'Error accepting funds compliance',
                        code: res.apiError?.code || 'funds_compliance',
                    }),
                );
            } else {
                router.push(`/games/${wagersState.gameVariant || wagersState.game}/game`);
            }
        }
        dispatch(closePopup('fundsCompliance'));
    };

    const onClickBack = (): void => {
        if (paymentStep === 'details') {
            setIsLoading(true);
            dispatch(resetWagers({ game: wagersState.game }));
            router.push(`/games/${wagersState.gameVariant || wagersState.game}/game`);
        } else if (paymentStep === 'confirming') {
            dispatch(
                initialiseWagers({
                    wagers: wagersState.wagers as BetSlip[],
                    game: wagersState.game,
                    purchaseType: oneTimePayment && wagersState.purchaseType === 'OneOff' ? 'OneOff' : 'Subscription',
                    competition: wagersState.competition,
                    gameVariant: wagersState.gameVariant,
                }),
            );
            setCurrentPaymentMethod(undefined);
            setPaymentStep('details');
            setCardErrors(undefined);
            setDirectDebitErrors(undefined);
            setPayPalErrors(undefined);
            setIsPayPalCallback(false);
        } else {
        }
    };

    return (
        <Container>
            <AuthenticationHandler operator="footballpools" />
            {/* <Loader isLoading={isLoading} backgroundColour={'rgba(0,0,0,0.75)'} position={'fixed'} /> */}

            <FundsCompliancePopup
                onClickClose={onFundsComplianceClickClose}
                onClickConfirm={onFundsComplianceClickConfirm}
            />
            <MaximumLinesReachedPopup
                onClickConfirm={() => {
                    dispatch(closePopup('maximumLinesReached'));
                    setIsLoading(true);
                    if (oneTimePayment) {
                        dispatch(closePopup('payment'));
                    } else {
                        router.push(`/games/${wagersState.gameVariant || wagersState.game}/game`);
                    }
                    dispatch(ResetBetSlipSelections({ ItemKey: toBetSlipKey(wagersState.game) }));
                    dispatch(resetWagers({ game: wagersState.game }));
                }}
            />
            <PaymentMethodsUnavailablePopup
                onClickConfirm={() => {
                    dispatch(closePopup('paymentMethodsUnavailable'));
                    setIsLoading(true);
                    if (oneTimePayment) {
                        dispatch(closePopup('payment'));
                    } else {
                        router.push(`/games/${wagersState.gameVariant || wagersState.game}/game`);
                    }
                    dispatch(ResetBetSlipSelections({ ItemKey: toBetSlipKey(wagersState.game) }));
                    dispatch(resetWagers({ game: wagersState.game }));
                }}
            />
            <Popup
                popupStyles={{
                    width: '390px !important',
                    padding: '20px 55px !important',
                    mobileMargin: 'auto',
                    rounded: true,
                    headerStyles: {
                        textAlign: 'center',
                        color: theme.colours.primaryFont,
                    },
                    crossStyles: {
                        top: '5px',
                        right: '60px',
                    },
                    overflow: 'scroll',
                }}
                popupName="responsibleGambling"
                title="Responsible Gambling"
                withCloseButton={true}
            >
                <SubtitleText fontColour={theme.colours.primaryFont} fontSize="unset">
                    SET WEEKLY SUBSCRIPTION LIMIT
                </SubtitleText>
                <SetWeeklySubscriptionLimitForm
                    selectPosition="raised"
                    onUpdatedSuccess={() => {
                        dispatch(closePopup('responsibleGambling'));
                        setIsLoading(false);
                    }}
                />
            </Popup>
            <Popup
                popupStyles={{
                    width: '390px !important',
                    padding: '20px 55px !important',
                    mobileMargin: 'auto',
                    rounded: true,
                    headerStyles: {
                        textAlign: 'center',
                        color: theme.colours.primaryFont,
                    },
                    crossStyles: {
                        top: '5px',
                        right: '60px',
                    },
                    overflow: 'scroll',
                }}
                popupName="spendLimit"
                title="Responsible Gambling"
                withCloseButton={true}
            >
                <SpendLimitForm
                    onUpdatedSuccess={async () => {
                        dispatch(closePopup('spendLimit'));
                        setIsLoading(false);

                        const spendCheck = await getSpendCheck(totalPrice(true));
                        if (!spendCheck) {
                            dispatch(openPopup('betslipExceededLimit'));
                            dispatch(closePopup('payment'));
                        }
                    }}
                />
            </Popup>
            <SlimPopup
                popupName="exceededSubscriptionLimit"
                popupTitle="Subscription Limits"
                content={
                    wagersState &&
                    wagersState.error &&
                    wagersState.error.code &&
                    wagersState.error.code.includes('within_cooling_off')
                        ? 'The purchase you want to add would exceed the Weekly Spend Limit you have currently set. You have asked us to increase your Weekly Spend Limit which you will need to confirm. After that, you will then be able to make a new purchase. If you have any questions about your Weekly Spend Limit, please contact us on  0800 953 9933'
                        : 'The purchase you want to add would exceed the Weekly Spend Limit you have set, We cannot therefore complete this transaction until you speak to our Contact Centre Agents. Please call our Contact Centre on 0800 953 9933'
                }
                allowClose={false}
                onClickConfirm={() => {
                    setIsLoading(true);
                    dispatch(closePopup('exceededSubscriptionLimit'));
                    dispatch(closePopup('payment'));
                    router.push(`/games/${wagersState.gameVariant || wagersState.game}/game`, undefined, {
                        shallow: false,
                    });
                    dispatch(resetWagers({ game: wagersState.game }));
                }}
            />
            <SlimPopup
                popupName="paymentFailed"
                popupTitle="Payment Failed"
                content={'Sorry, there was an error processing your payment. Please try again.'}
                allowClose={false}
                onClickConfirm={() => {
                    setIsLoading(true);
                    const betslipKey = toBetSlipKey(wagersState.game);
                    const purchaseType: PurchaseType =
                        oneTimePayment && wagersState.purchaseType === 'OneOff'
                            ? 'OneOff'
                            : currentPaymentMethod === 'direct-debit'
                            ? 'Subscription'
                            : 'ByGames';
                    setCardErrors(undefined);
                    setDirectDebitErrors(undefined);
                    setPayPalErrors(undefined);
                    dispatch(
                        initialiseWagers({
                            wagers: wagersState.wagers as BetSlip[],
                            game: wagersState.game,
                            purchaseType: 'Subscription',
                            competition: wagersState.competition,
                            gameVariant: wagersState.gameVariant,
                            numberOfGames: wagersState.numberOfGames,
                        }),
                    );
                    dispatch(
                        createWagers(
                            betslipState[betslipKey].filter(b => b.numbers && b.numbers.length === b.pick),
                            betslipKey,
                            purchaseType,
                            wagersState.competition,
                            currentPaymentMethod,
                            wagersState.numberOfGames,
                        ),
                    );
                    setPaymentStep('details');
                    dispatch(closePopup('paymentFailed'));
                }}
            />
            {wagersState.stage === 'card-setup' &&
                wagersState.cardSetup &&
                wagersState.cardSetup.token &&
                wagersState.cardSetup.url && (
                    <SetupCardForm
                        token={wagersState.cardSetup?.token}
                        url={wagersState.cardSetup?.url}
                        onSuccess={res => {
                            console.debug('setup card completed', res);
                            dispatch(completeCardSetup({ data: { sessionId: res.SessionId } }));
                        }}
                        onError={error => {
                            console.debug('setup card error', error);
                            dispatch(wagersError({ title: '3ds auth error', code: '3ds_error' }));
                        }}
                    />
                )}
            {oneTimePayment ? (
                <OneTimePaymentView
                    wagersState={wagersState}
                    betslipState={betslipState}
                    userState={userState}
                    paymentStep={paymentStep}
                    isLoading={isLoading}
                    setIsLoading={setIsLoading}
                    onPaymentMethodToggleChange={onToggleChange}
                    currentPaymentMethod={currentPaymentMethod}
                    paymentMethodOptions={paymentMethodOptions}
                    cardErrors={cardErrors}
                    setCardErrors={setCardErrors}
                    directDebitErrors={directDebitErrors}
                    setDirectDebitErrors={setDirectDebitErrors}
                    payPalErrors={payPalErrors}
                    setPayPalErrors={setPayPalErrors}
                    onSubmitCardForm={onSubmitCardForm}
                    onSubmitDirectDebitForm={onSubmitDirectDebitForm}
                    onSubmitPayPalForm={onSubmitPayPalForm}
                    onClickBack={onClickBack}
                    paymentDetailsContent={paymentDetailsContent}
                    getAmount={getAmount}
                    getTermUrl={getTermUrl}
                    onAuthoriseError={onAuthoriseError}
                    onAuthoriseSuccess={onAuthoriseSuccess}
                    competitions={competitions}
                    setCurrentPaymentMethod={setCurrentPaymentMethod}
                    hasSpendLimit={hasSpendLimit}
                />
            ) : (
                <SubscriptionPaymentView
                    wagersState={wagersState}
                    betslipState={betslipState}
                    userState={userState}
                    paymentStep={paymentStep}
                    isLoading={isLoading}
                    setIsLoading={setIsLoading}
                    onPaymentMethodToggleChange={onToggleChange}
                    currentPaymentMethod={currentPaymentMethod}
                    paymentMethodOptions={paymentMethodOptions}
                    cardErrors={cardErrors}
                    setCardErrors={setCardErrors}
                    directDebitErrors={directDebitErrors}
                    setDirectDebitErrors={setDirectDebitErrors}
                    payPalErrors={payPalErrors}
                    setPayPalErrors={setPayPalErrors}
                    onSubmitCardForm={onSubmitCardForm}
                    onSubmitDirectDebitForm={onSubmitDirectDebitForm}
                    onSubmitPayPalForm={onSubmitPayPalForm}
                    onClickBack={onClickBack}
                    paymentDetailsContent={paymentDetailsContent}
                    getAmount={getAmount}
                    getTermUrl={getTermUrl}
                    onAuthoriseError={onAuthoriseError}
                    onAuthoriseSuccess={onAuthoriseSuccess}
                    setCurrentPaymentMethod={setCurrentPaymentMethod}
                />
            )}
        </Container>
    );
};
