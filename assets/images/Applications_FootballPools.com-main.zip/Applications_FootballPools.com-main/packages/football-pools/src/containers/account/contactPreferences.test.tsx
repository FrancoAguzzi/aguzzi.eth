import ContactPreferences from './contactPreferences';
import { renderWithRedux } from '@fp/shared/src/testing/utils/renderWithRedux';
import { UserDetails } from '@fp/shared/src/features/authentication/UserDetails';
import { RecursivePartial } from '@fp/shared/src/testing/utils/RecursivePartial';
import { RootState } from '@fp/shared/src/rootReducer';
import { fireEvent, waitFor } from '@testing-library/react';
import { updateContactPrefs } from '@fp/shared/src/api/account';
import { ApiResponse } from '@fp/shared/src/services/apiResponse';

jest.mock('@fp/shared/src/settings/breakpoints');
jest.mock('@fp/shared/src/api/account');

jest.mock('next/config', () => () => ({
    publicRuntimeConfig: {
        API_URL: 'api.url',
    },
}));

const partialUser: RecursivePartial<UserDetails> = {
    preferences: {
        communication: { email: false, sms: true, telephone: true, post: false },
        showAdditionalOfferings: false,
    },
};

const userDetails: UserDetails = partialUser as UserDetails;

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
const renderComponent = (initialState: RecursivePartial<RootState>) => {
    const utils = renderWithRedux(<ContactPreferences />, initialState as RootState);

    const formButton = utils.getByRole(/button/);
    const emailCheckbox = utils.getAllByRole(/checkbox/)[0];

    // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
    const submitForm = async (apiResponse: ApiResponse<UserDetails>) => {
        const mockUpdatePrefs = updateContactPrefs as jest.MockedFunction<typeof updateContactPrefs>;
        mockUpdatePrefs.mockResolvedValue(apiResponse);

        fireEvent.click(emailCheckbox);
        fireEvent.click(formButton);

        await waitFor(() => formButton);

        return mockUpdatePrefs;
    };

    return { ...utils, formButton, emailCheckbox, submitForm };
};

describe.only('Contact Preferences', () => {
    it('should match snapshot', async () => {
        const { container } = renderComponent({ authentication: { userDetails } });

        expect(container).toMatchSnapshot();
    });

    it('should submit form when form button is clicked', async () => {
        const { submitForm } = renderComponent({ authentication: { userDetails } });

        const mockApiCall = await submitForm(userDetails);

        expect(mockApiCall).toHaveBeenCalled();
    });

    it('should show alert when form submit successfully,', async () => {
        const { submitForm, findByRole } = renderComponent({ authentication: { userDetails } });

        await submitForm(userDetails);
        const successMessage = await findByRole(/alert/);

        expect(successMessage).toHaveTextContent(/Contact Preferences updated/);
    });

    it('should show error message when form submit failed,', async () => {
        const { submitForm, findByRole } = renderComponent({ authentication: { userDetails } });

        await submitForm({ isError: true, message: 'Invalid auth token' });
        const errorMessage = await findByRole(/alert/);

        expect(errorMessage).toHaveTextContent(/Something went wrong/);
    });
});
