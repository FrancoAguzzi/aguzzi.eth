import styled from 'styled-components';

import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import withLayout, {
    ContentContainer as PrimaryContentContainer,
} from '@fp/shared/src/components/Layouts/Layout/Layout';
import { AccountLayout } from '@fp/shared/src/components/Layouts/AccountLayout/AccountLayout';
import { getPaymentDetails, PaymentDetailsArray } from '@fp/shared/src/api/account';
import { BankDetails, PaymentDetails } from './bankDetails';
import { NextPage } from 'next';
import { isAppError } from '@fp/shared/src/core/appError';
import { thunkShowToast } from '@fp/shared/src/features/notifications/notificationsSlice';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { HeadComponent } from '@fp/shared/src/settings/HeadComponent';
import { Loader } from '@fp/shared/src/components/Loader/Loader';
import { useSelector } from 'react-redux';
import { userDetailsSelector } from '@fp/shared/src/features/authentication/authenticationSelectors';

interface PaymentDetailsProps {
    details: PaymentDetails[];
}

const Container = styled(PrimaryContentContainer)`
    display: flex;
    flex-direction: column;
    width: 800px;
    font-size: 0.875em;
    margin: 0 auto;
    margin-top: 70px;
    ${breakpoints.below('md')} {
        width: 100%;
        margin-top: 30px;
    }
    ${breakpoints.below('sm')} {
        margin-top: 20px;
    }
    p {
        color: #383838;
        margin: 1.5em 0 1.5em 0;
        ${breakpoints.below('sm')} {
            margin: 0;
        }
    }
    h5 {
        font-size: 0.875em;
    }
    hr {
        border: 0;
        width: 100%;
        background-color: #000;
        height: 1px;
    }
`;

export const PaymentDetailsPage: NextPage = () => {
    const [paymentDetails, setPaymentDetails] = useState<PaymentDetailsArray>({ directDebits: [] });
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const { setError } = useForm<PaymentDetailsProps>();
    const hasPaymentDetails = paymentDetails && paymentDetails.directDebits.length > 0;

    const details = useSelector(userDetailsSelector);

    useEffect(() => {
        const asyncAction = async (): Promise<{ details: PaymentDetails[] }> => {
            if (isLoading && typeof details !== 'undefined') {
                const details = await getPaymentDetails();

                if (!isAppError(details)) {
                    setPaymentDetails(details);
                    setIsLoading(false);
                    return { details: details.directDebits };
                } else {
                    setError('general', 'general', 'Something went wrong');
                    thunkShowToast({ message: details.message });
                }
                setIsLoading(false);
            }
            return { details: [] };
        };
        asyncAction();
    });

    if (isLoading) {
        return <Loader isLoading={isLoading} />;
    }

    return (
        <>
            <HeadComponent title={'Account | Payment Details'} />
            <AccountLayout operator="footballpools">
                <Container>
                    <h5>Direct Debit Details</h5>
                    <hr />
                    {paymentDetails.directDebits.map(p => (
                        <BankDetails key={p.accountNumber} accountNumber={p.accountNumber} sortCode={p.sortCode} />
                    ))}
                    {hasPaymentDetails && (
                        <p>
                            To update your bank details, please contact our customer services team on (0800) 953 9933.
                            Please note that changes can take up to 2 weeks to take effect. In the mean time, payments
                            may be taken using the current account details.
                        </p>
                    )}

                    {!hasPaymentDetails && (
                        <p>You have no bank details to show. Once details have been added they will be shown here.</p>
                    )}
                </Container>
            </AccountLayout>
        </>
    );
};

export default withLayout(PaymentDetailsPage);
