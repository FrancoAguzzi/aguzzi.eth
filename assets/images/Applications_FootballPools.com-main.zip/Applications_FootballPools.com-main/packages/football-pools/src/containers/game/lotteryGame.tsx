/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable import/named */
// eslint-disable-next-line import/default
import React, { useEffect, useContext, useState } from 'react';
import { GetServerSideProps, NextPage } from 'next';
import { useSelector, useDispatch } from 'react-redux';
import styled, { DefaultTheme, ThemeContext, ThemeProvider } from 'styled-components';
import MediaQuery, { useMediaQuery } from 'react-responsive';

import { openPopup } from '@fp/shared/src/features/popups/popupsSlice';
// import { useAuthToken } from '@api/subscriptionApi/useAuthToken';
import { theme, goalRushTheme, luckyCloverTheme } from '@fp/shared/src/settings/theme';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
// import { Popup } from '@fp/shared/src/components/Popup/Popup';
import { Loader } from '@fp/shared/src/components/Loader/Loader';
import { SubscriptionConfirmationPopup } from '@fp/shared/src/components/Popup/SubscriptionConfirmationPopup';

import {
    Button,
    DiceFigures,
    CompetitionSelector,
    BetSlipList,
    GameSection,
    DateTimeFormatter,
    Popup,
    BetSlipMobile,
    OfferingList,
    StyledMain,
    StyledHeaderDesktop,
    StyledHeaderMobile,
    MenuDropdown,
    NavStyle,
    StyledNavBarButtons,
    StyledNavBarButtonsMobile,
    GameInfo,
    StyledBetSlipMobile,
    StyledSidebar,
    PageLinkButtonsContainer,
    convertWagerToBetSlipSelection,
    ConvertStringToArray,
    PopupsContainer,
    ChevronFigures,
    ToggleButton,
    BetSlipCircleList,
    StyledCurrentLineFloating,
    ClearContainer,
    ViewLinesOverlay,
    MenuDropdownOverlay,
    getIdFromWager,
    errorPopupStyles,
    popupStyles,
    convertNumbersSelectedToString,
    convertNumbersSelectedToArray,
    closePopup,
    testId,
    StyledHeader,
    BannerText,
    BannerTextSmall,
    ChevronText,
    ViewLinesCurrent,
    Countdown,
} from '@sportech/pools-components';
import {
    useApi,
    Competition,
    Offerings,
    Offering,
    UpdateAmount,
    UpdateClassicPoolsWithNumber,
    LuckyDip,
    ClearLine,
    AddLine,
    ChangeCurrentBet,
    AddNewLine,
    BetSlipSlice,
    BetSlip,
    GameType,
    getBetSlipSelector,
    getWagersSelector,
    Wagers,
    Wager,
    toGameType,
    initialiseWagers,
    resetWagers,
    toBetSlipKey,
    ResetBetSlipSelections,
    CreateFirstSlipAndClearOld,
    CompetitionWagers,
    NumbersSelected,
    confirmedWagers,
    updateBetslipWithNumber,
    luckyDip,
    UpdatedWager,
    PoolsApiError,
} from '@sportech/pools-api';

import { RootState } from '@fp/shared/src/rootReducer';
import { AuthenticationState } from '@fp/shared/src/features/authentication/authenticationSlice';
import withGameLayout from '@fp/shared/src/components/Layouts/GameLayout/GameLayout';
import { useRouter } from 'next/router';
import { BetslipEditLine, FutureGamesToggleSection } from '@fp/shared/src/components/BetslipEditLine/BetslipEditLine';
import { thunkShowToast } from '@fp/shared/src/features/notifications/notificationsSlice';
import { EditWagerErrorPopup } from '@fp/shared/src/components/Popup/EditWagerErrorPopup';
import {
    BetslipEditLineMobile,
    FutureGamesToggleSectionMobile,
} from '@fp/shared/src/components/BetslipEditLine/BetslipEditLineMobile';
import { LotteryOfferingInfo } from '@fp/shared/src/components/Lottery/LotteryOfferingInfo';
import { LotteringOfferingList } from '@fp/shared/src/components/Lottery/LotteryOfferingList';
import { LotteryGameSection } from '@fp/shared/src/components/Lottery/LotteryGameSection';
import { LotteryCostInfo } from '@fp/shared/src/components/Lottery/LotteryCostInfo';
import { arrayEquals, GameProps } from './game.shared';
import { HeadComponent } from '@fp/shared/src/settings/HeadComponent';

export const getGameTitle = (game: GameType): string => {
    let ret = '';
    switch (game) {
        case 'classic-pools': {
            ret = 'Classic Pools';
            break;
        }
        case 'goal-rush': {
            ret = 'Goal Rush';
            break;
        }
        case 'jackpot-12': {
            ret = 'Jackpot 12';
            break;
        }
        case 'lucky-clover': {
            ret = 'Lucky Clover';
            break;
        }
        case 'premier-10': {
            ret = 'Premier 10';
            break;
        }
        case 'premier-6': {
            ret = 'Soccer 6';
            break;
        }
        default: {
            ret = 'Classic Pools';
            break;
        }
    }
    return ret;
};

const getGameInstructions = (gameType: GameType, numberOfSelections: number): string => {
    let ret = `Pick ${numberOfSelections} matches you think will end in a score draw.`;
    switch (gameType) {
        case 'classic-pools': {
            ret = `Pick ${numberOfSelections} matches you think will end in a score draw.`;
            break;
        }
        case 'goal-rush': {
            `Pick ${numberOfSelections} matches where both teams will score.`;
            break;
        }
        case 'lucky-clover': {
            `Pick ${numberOfSelections} matches you think will end in a score draw`;
            break;
        }
        case 'jackpot-12':
        case 'premier-10':
        case 'premier-6': {
            `Predict the outcome of the ${numberOfSelections} matches below.`;
            break;
        }
        default: {
            `Pick ${numberOfSelections} matches you think will end in a score draw.`;
        }
    }
    return ret;
};

const LuckyDipButton = styled(StyledNavBarButtons)`
    font-family: ${props => props.theme.fonts?.primaryFontFamily};
`;

const HowToPlayButton = styled(StyledNavBarButtons)`
    ::before {
        display: none;
    }
`;

const CurrentInfo = styled(GameInfo)`
    color: ${props => props.theme.colours.primaryFont};
    width: 100%;
    justify-self: center;
    font-size: 0.75rem;
    padding: 0 10px;
    display: flex;
    flex-direction: column !important;

    ${breakpoints.above('lg')} {
        font-size: 0.875rem;
        max-width: 50%;
    }
`;

const InfoDescription = styled.span`
    font-weight: bold;
`;

// const NavBarButtons = styled(StyledNavBarButtons)`
//     &:not(:first-child)::before {
//         height: 50%;
//         top: 25%;
//         background-color: #d0d0d0;
//     }
// `;

// const NavBarButtonsMobile = styled(StyledNavBarButtonsMobile)`
//     &:not(:first-child)::before {
//         height: 50%;
//         top: 25%;
//         background-color: #d0d0d0;
//     }
// `;

export const StyledBetSlipMobileContainer = styled.div`
    z-index: 2;
    display: flex;
    flex-direction: column-reverse;
    position: fixed;
    color: #fff;
    background: ${props => props.theme.colours.gameMainColour}; // #313131;
    height: auto;
    bottom: 0;
    left: 0;
    right: 0;
    justify-content: space-around;
    align-items: center;
    flex-wrap: wrap;

    ${breakpoints.above('lg')} {
        display: none;
    }
`;
export const StyledBetSlipMobileSelectionsContainer = styled.div`
    display: flex;
    flex-direction: row;
    background: ${props => props.theme.colours.betslipListMobileBackgroundColour};
    width: 100%;
`;

const Game: NextPage<GameProps> = props => {
    if (!props.competitions || props.competitions.length <= 0 || !props.offers) {
        // Missing essential data, show error or loading spinner?
        return <>Oops, it looks like we don&apos;t have any competitions available at this time</>;
    }

    const dispatch = useDispatch();
    const router = useRouter();
    const { getWagersAsync, updateWagerAsync } = useApi('backend');
    const [betslipGameType] = useState<keyof BetSlipSlice>(toBetSlipKey(props.game));
    const [isLoading, setIsLoading] = useState(false);

    // useEffect(() => {
    //     if (props.competitions && props.offers) {
    //         dispatch(
    //             CreateFirstSlipAndClearOld({
    //                 ItemKey: betslipGameType,
    //                 Competitions: props.competitions,
    //                 Offers: props.offers,
    //             }),
    //         );
    //     }
    // }, []);

    if (props.competitions && props.offers) {
        dispatch(
            CreateFirstSlipAndClearOld({
                ItemKey: betslipGameType,
                Competitions: props.competitions,
                Offers: props.offers,
            }),
        );
    }

    const themeContext = useContext(ThemeContext);
    const wagersState = useSelector(getWagersSelector);
    const betslipSelection = useSelector(getBetSlipSelector);
    const userState = useSelector<RootState>(state => state.authentication) as AuthenticationState;

    const [showFutureGames, setShowFutureGames] = useState(true);
    const [showHDA] = useState(
        betslipGameType == 'Jackpot12' || betslipGameType == 'Premier10' || betslipGameType == 'Premier6',
    );

    const currentSlip = betslipSelection[betslipGameType].find(x => x.current == true);
    const [menuDropdownOpen, setMenuDropdownOpen] = useState(false);
    const [showWagers, setShowWagers] = useState(false);
    const [showWagersMobile, setShowWagersMobile] = useState(false);
    const [currentOffering, setCurrentOffering] = useState(currentSlip?.priceID);

    const [showMore, setShowMore] = useState(false);
    if (
        showMore == false &&
        props.offers != undefined &&
        props.offers.offerings.slice(0, 3).find(x => x.id == currentSlip?.priceID) == undefined
    ) {
        setShowMore(true);
    }

    const isMobileOrTablet = useMediaQuery({
        query: `(max-width: ${themeContext.breakpoints.lg}px )`,
    });

    if (showWagers && isMobileOrTablet && !props.offers?.gameType?.subscription) {
        setShowWagers(false);
    }

    /**
     * Get existing wagers for a logged in user.
     */
    const [wagers, setWagers] = useState<Wagers>({ competitions: [] });
    const fetchWagers = async (): Promise<void> => {
        const wagersRes = userState.isLoggedIn ? await getWagersAsync(props.game) : undefined;
        if (wagersRes && wagersRes.data) {
            setWagers(wagersRes.data);
        }
    };
    useEffect(() => {
        fetchWagers();
    }, []);

    /**
     * Find upcoming wagers and current wager to display on game UI.
     */
    const [viewLinesCurrent, setViewLinesCurrent] = useState<ViewLinesCurrent>({ id: 0, competitionId: undefined });
    const [betslipWager, setBetslipWager] = useState<BetSlip | undefined>(undefined);
    const [canEditLine, setCanEditLine] = useState(false);
    const [betslipWagerHasEdits, setBetslipWagerHasEdits] = useState(false);
    const [editLineAllFutureGames, setEditLineAllFutureGames] = useState(false);
    const [wagersForCompetitions, setWagersForCompetitions] = useState<Wager[]>([]);
    const getWagersForCompetitions = (): Wager[] => {
        const ret: Wager[] = [];
        if (wagers && wagers.competitions && wagers.competitions.length > 0) {
            const competitionWagers = wagers.competitions
                .filter(wc => props.competitions?.some(c => c.id === wc.competitionId))
                .flatMap(wc => wc.wagers);
            // .sort((a, b) => (b.lineId as number) - (a.lineId as number));
            for (let i = 0; i < competitionWagers.length; i++) {
                const w = competitionWagers[i];
                ret.push({
                    ...w,
                    selections: typeof w.selections === 'string' ? w.selections : [...w.selections],
                });
            }
        }
        return ret;
    };

    /**
     * Update betslip wagers when user wagers response received:
     */
    useEffect(() => {
        if (!betslipWagerHasEdits) {
            setWagersForCompetitions(getWagersForCompetitions());
        }
    }, [wagers]);
    /**
     * Reset edit states when viewLinesCurrent changes:
     */
    useEffect(() => {
        setBetslipWagerHasEdits(false);
        setWagersForCompetitions(getWagersForCompetitions());
        const currentWager = wagersForCompetitions?.find(w => getIdFromWager(w) === viewLinesCurrent.id);
        setCanEditLine(
            Boolean(
                currentWager &&
                    currentWager.paymentType &&
                    (currentWager.paymentType.includes('rt_card') || currentWager.paymentType.includes('direct_debit')),
            ),
        );
        setBetslipWager(
            currentWager
                ? convertWagerToBetSlipSelection(
                      props.competitions?.find(c => c.id === currentWager?.competitionId) as Competition,
                      props.offers?.offerings.find(o => o.id === currentWager?.offeringId) as Offering,
                      currentWager as Wager,
                      ConvertStringToArray(currentWager.selections, !showHDA),
                      [],
                  )
                : undefined,
        );
    }, [viewLinesCurrent]);
    /**
     * Update wagersForCompetitions selections when edit made.
     * Update betslipWagerHasEdits when selections differ.
     * Required for UI on betslip
     */
    useEffect(() => {
        if (betslipWager) {
            // Determine if wager selections have been edited:
            const originalWager = wagers.competitions
                .find(wc => wc.wagers.findIndex(w => getIdFromWager(w) === viewLinesCurrent.id) !== -1)
                ?.wagers.find(w => getIdFromWager(w) === viewLinesCurrent.id);
            if (originalWager) {
                setBetslipWagerHasEdits(
                    Boolean(
                        betslipWager.numbers &&
                            betslipWager.numbers.length > 0 &&
                            !arrayEquals(
                                originalWager.selections as string[],
                                convertNumbersSelectedToArray(betslipWager?.numbers as NumbersSelected[]),
                            ),
                    ),
                );
            }
            if (wagersForCompetitions) {
                wagersForCompetitions[
                    wagersForCompetitions.findIndex(x => getIdFromWager(x) === viewLinesCurrent.id)
                ].selections = convertNumbersSelectedToArray(betslipWager.numbers as NumbersSelected[], showHDA);
                setWagersForCompetitions([...wagersForCompetitions]);
            }
        }
    }, [betslipWager]);

    /**
     * Reset any existing edits when changing to buy lines view.
     */
    useEffect(() => {
        if (betslipWagerHasEdits) {
            resetBetslipWagerSelections();
        }
    }, [showWagers]);

    const resetBetslipWagerSelections = (): void => {
        const originalWager = wagers.competitions
            .find(wc => wc.wagers.findIndex(w => getIdFromWager(w) === viewLinesCurrent.id) !== -1)
            ?.wagers.find(w => getIdFromWager(w) === viewLinesCurrent.id);
        if (originalWager && betslipWager) {
            const updatedBetslipWager: BetSlip = {
                ...betslipWager,
                numbers: ConvertStringToArray(originalWager.selections, !showHDA),
            };
            setBetslipWager(updatedBetslipWager);
        }
    };

    /**
     * Update an existing wager.
     */
    const [editWagerError, setEditWagerError] = useState<PoolsApiError | undefined>(undefined);
    const handleUpdateWager = async (): Promise<void> => {
        if (betslipWager) {
            if (betslipWager.pick != betslipWager.numbers?.length && betslipWager.numbers?.length !== 0) {
                dispatch(openPopup('error_on_change_betslip_line'));
                return;
            }
            const currentWager = getWagersForCompetitions().find(w => w.lineId === viewLinesCurrent.id);
            const wager: Wager = {
                lineId: currentWager?.lineId,
                competitionId: currentWager?.competitionId,
                selections: convertNumbersSelectedToArray(betslipWager.numbers as NumbersSelected[]),
                offeringId: currentWager?.offeringId as number,
            };
            setIsLoading(true);
            const res = await updateWagerAsync(wager, props.game, editLineAllFutureGames);
            setIsLoading(false);
            if (res && res.data) {
                const message = editLineAllFutureGames
                    ? `Successfully updated line for all future games`
                    : `Successfully updated line`;
                dispatch(thunkShowToast({ message: message }));
            } else if (!res || res.error) {
                // Show popup
                setEditWagerError(res.error);
                dispatch(openPopup('editWagerError'));
                return;
            }

            // Reset edit lines:
            setEditLineAllFutureGames(false);
            setBetslipWagerHasEdits(false);
            await fetchWagers();
        }
    };
    const onCloseEditWagerErrorPopup = (): void => {
        dispatch(closePopup('editWagerError'));
        setEditWagerError(undefined);
    };

    /**
     * Show congratulation message when order confirmed.
     */
    useEffect(() => {
        const handleConfirmed = (): void => {
            if (wagersState.stage === 'confirmed') {
                dispatch(openPopup('paymentConfirmed'));
            }
        };
        handleConfirmed();
    }, [wagersState.stage]);

    const toggleFuture = (): void => {
        setShowFutureGames(!showFutureGames);
    };

    /**
     * Change current offering.
     * @param id
     * @param amount the offering
     */
    const SelectAmount = (id: number, amount: Offering): void => {
        dispatch(UpdateAmount({ ItemKey: betslipGameType, id: id, Amount: amount }));
    };

    /**
     * Add selection to betslip.
     * @param id
     * @param type
     */
    const SelectMatch = (id: number, type: string): void => {
        if (showWagers && viewLinesCurrent.id > 0 && canEditLine && betslipWager !== undefined) {
            const updatedWager = updateBetslipWithNumber(
                { ...betslipWager },
                {
                    ItemKey: betslipGameType,
                    id: id,
                    Type: type,
                },
            );
            setBetslipWager(updatedWager);
        } else {
            dispatch(
                UpdateClassicPoolsWithNumber({
                    ItemKey: betslipGameType,
                    id: id,
                    Type: type,
                }),
            );
        }
    };

    /**
     * Lucky dip.
     */
    const Lucky = (isBonus?: boolean, noSelectionsMade?: boolean): void => {
        if (showWagers && viewLinesCurrent.id > 0 && canEditLine && betslipWager !== undefined) {
            // Updating existing line.
            const updatedWager = luckyDip({ ...betslipWager }, betslipGameType);
            setBetslipWager(updatedWager);
        } else {
            // Updating new line.
            if (isBonus && noSelectionsMade) {
                dispatch(LuckyDip({ ItemKey: betslipGameType, isMillion: false }));
                dispatch(LuckyDip({ ItemKey: betslipGameType, isMillion: isBonus }));
            } else {
                dispatch(LuckyDip({ ItemKey: betslipGameType, isMillion: isBonus }));
            }
        }
    };

    const onClickToggleBonus = (): void => {
        if (currentSlip && currentSlip.bonusNumbers && currentSlip.bonusNumbers.length > 0) {
            // clear bonus selections
            const currentBonusSelections = [...currentSlip.bonusNumbers];
            for (let i = 0; i < currentBonusSelections.length; i++) {
                SelectMatch(currentBonusSelections[i].Id, 'D');
            }
        } else {
            // set bonus balls randomly:
            Lucky(true, currentSlip?.numbers?.length === 0);
        }
    };
    useEffect(() => {
        if (currentSlip?.competitionId) {
            SelectAmount(
                currentSlip?.competitionId,
                props.offers?.offerings.find(o => o.id === currentOffering) as Offering,
            );
        }
    }, [currentOffering]);

    /**
     * Clear selections.
     * @param index
     */
    const Clear = (index?: number): void => {
        if (showWagers && betslipWager !== undefined) {
            const updatedWager: BetSlip = {
                ...betslipWager,
                numbers: [],
            };
            setBetslipWager(updatedWager);
        } else {
            if (index !== undefined) {
                dispatch(ClearLine({ ItemKey: betslipGameType, id: index }));
            } else {
                dispatch(ClearLine({ ItemKey: betslipGameType, id: -1 }));
            }
        }
    };

    const AddLines = (): void => {
        if (props.offers) {
            dispatch(
                AddLine({
                    ItemKey: betslipGameType,
                    Default: props.offers.defaultOffering,
                }),
            );
        }
    };

    const ChangeCurrentBets = (index: number): void => {
        dispatch(ChangeCurrentBet({ ItemKey: betslipGameType, id: index }));
    };

    const ChangeComp = (compId: number, compName: string): void => {
        if (props.offers) {
            dispatch(
                AddNewLine({
                    ItemKey: betslipGameType,
                    CompId: compId,
                    CompName: compName,
                    Offer: props.offers.defaultOffering,
                }),
            );
            setCurrentOffering(props.offers.defaultOffering.id);
            setShowMore(false);
        }
    };

    const LoadDesktop = (LoadNew: boolean): void => {
        if (LoadNew) {
            fetchWagers();
        }
        setShowWagers(LoadNew);
    };

    const LoadMobile = (LoadNew: boolean): void => {
        if (LoadNew) {
            fetchWagers();
        }
        // setShowWagersMobile(LoadNew);
        setShowWagers(LoadNew);
    };

    const AddedLines = betslipSelection[betslipGameType].filter(x => x.pick == x.numbers?.length);

    const [createWagersResponse, setCreateWagerResponse] = useState({});

    /**
     * Play now button has been selected.
     * Add betslip for purchase to wagers state
     * and redirect to payment page.
     */
    const onPressPlay = (): void => {
        console.log('create wagers');
        if (
            betslipSelection[betslipGameType]?.filter(x => x.pick != x.numbers?.length && x.numbers?.length != 0)
                .length > 0
        ) {
            dispatch(openPopup('error_on_change_betslip_line'));
            return;
        }

        dispatch(
            initialiseWagers({
                wagers: betslipSelection[betslipGameType],
                game: toGameType(betslipGameType),
                purchaseType: 'Subscription',
            }),
        );

        if (!userState.isLoggedIn) {
            dispatch(openPopup('login'));
            return;
        }

        setIsLoading(true);
        router.push('/games/payment');
    };

    const headerHeight = props.headerHeight ? props.headerHeight : 0;
    const getNumbers = (): Array<NumbersSelected[]> => {
        const wagers: BetSlip[] = wagersState.wagers as BetSlip[];
        if (wagers) {
            return wagers.map((wager: BetSlip) => {
                return wager.numbers as NumbersSelected[];
            });
        }
        return [];
    };

    return (
        <>
            <HeadComponent title={`${getGameTitle(props.game)}`} description={props.gameDescription} />
            <ThemeProvider theme={props.theme || theme}>
                <PopupsContainer
                    currentSlip={currentSlip as BetSlip}
                    GameType={betslipGameType}
                    betslipselection={betslipSelection[betslipGameType]}
                    offers={props.offers}
                    showHDA={showHDA}
                    ClearLine={Clear}
                    ChangeCurrentBets={ChangeCurrentBets}
                    addedLines={AddedLines}
                    competitions={props.competitions}
                    viewLinesWager={wagersForCompetitions}
                    pressPlay={onPressPlay}
                    hasCreatedWagersReponse={createWagersResponse != {}}
                    createdWagersResponse={createWagersResponse as CompetitionWagers[]}
                    setViewLinesCurrent={setViewLinesCurrent}
                    viewLinesCurrent={viewLinesCurrent}
                    canEdit={canEditLine}
                    viewLinesBetslip={betslipWager}
                    isClover={false}
                />
                <Popup
                    popupStyles={{
                        width: '50% !important',
                        padding: '20px 55px !important',
                        rounded: true,
                        headerStyles: {
                            textAlign: 'center',
                            color: '#010d68',
                        },
                        crossStyles: {
                            top: '5px',
                            right: '60px',
                        },
                    }}
                    title={'Confirmation'}
                    withCloseButton={true}
                    popupName={'paymentConfirmed'}
                    closeOnDocumentClick={false}
                    closeOnEscape={false}
                    handleOnCloseClicked={() => {
                        dispatch(ResetBetSlipSelections({ ItemKey: betslipGameType }));
                        dispatch(resetWagers({ game: props.game }));
                        return true;
                    }}
                >
                    <SubscriptionConfirmationPopup
                        gameTitle={getGameTitle(props.game)}
                        bets={betslipSelection[betslipGameType]}
                        game={props.game}
                        onClickConfirm={() => {
                            dispatch(ResetBetSlipSelections({ ItemKey: betslipGameType }));
                            dispatch(resetWagers({ game: props.game }));
                            dispatch(closePopup('paymentConfirmed'));
                        }}
                    />
                </Popup>
                <EditWagerErrorPopup error={editWagerError} onClose={onCloseEditWagerErrorPopup} />
                <Loader isLoading={isLoading} backgroundColour={'rgba(0,0,0,0.75)'} position={'fixed'} />
                <StyledMain>
                    {showWagers && wagersForCompetitions.length == 0 && (
                        <ViewLinesOverlay
                            onClick={(): void => {
                                setShowWagers(false);
                            }}
                        />
                    )}

                    {/* <StyledHeader isClassic={props.game === 'classic-pools'}>
                        {props.banner && props.banner.imgSrc && <img src={props.banner.imgSrc} />}
                        {props.banner && props.banner.text && (
                            <BannerText
                                textColor={props.theme?.colours.gameMainColourText || theme.colours.gameMainColourText}
                            >
                                {props.banner.text}
                            </BannerText>
                        )}
                        <ChevronText>Menu</ChevronText>
                        <Button
                            height={'10px'}
                            bgColor={'transparent !important'}
                            textColor={'#fff'}
                            noHover={true}
                            padding={'0'}
                            onClick={(): void => setMenuDropdownOpen(menuDropdownOpen => !menuDropdownOpen)}
                        >
                            <ChevronFigures color={'#fff'} width={'26px'} height={'26px'} />
                        </Button>
                    </StyledHeader> */}
                    {menuDropdownOpen && (
                        <>
                            <MenuDropdown>
                                <li>
                                    <a href="/results">RESULTS</a>
                                    <hr />
                                    <a href="/">LEADERBOARDS</a>
                                    <hr />
                                    <a href="/"> WINNERS</a>
                                </li>
                            </MenuDropdown>
                            <MenuDropdownOverlay onClick={(): void => setMenuDropdownOpen(false)} />
                        </>
                    )}
                    <NavStyle>
                        <LuckyDipButton
                            disabled={showWagers && !canEditLine}
                            textColor={'#000'}
                            bgColor={'#EAEAEA'}
                            rounded={'0'}
                            {...testId('Game_LuckyDipButton')}
                        >
                            <DiceFigures backgroundColour={theme.colours.gameMainColour} colour={'#fff'}></DiceFigures>
                            {isMobileOrTablet && <br />}
                            <div>Lucky Dip</div>
                        </LuckyDipButton>

                        <MediaQuery minDeviceWidth={theme.breakpoints.lg}>
                            <CurrentInfo>
                                <InfoDescription>
                                    {getGameInstructions(props.game, currentSlip?.pick || 0)}
                                </InfoDescription>
                                <p>
                                    NEXT GAME ENDS:{' '}
                                    <DateTimeFormatter
                                        format={'d MMM @ HH:mm'}
                                        input={
                                            props.competitions.find(x => x.id == currentSlip?.competitionId)
                                                ?.datumDateWithBuffer || props.competitions[0].datumDateWithBuffer
                                        }
                                    />
                                </p>
                            </CurrentInfo>
                        </MediaQuery>

                        <HowToPlayButton
                            textColor={'#000'}
                            bgColor={'#EAEAEA'}
                            rounded={'0'}
                            onClick={(): void => {
                                dispatch(openPopup(`how_to_play_${betslipGameType}`));
                            }}
                            {...testId('Game_HowToPlayButton')}
                        >
                            <img alt="information symbol" src="/little-i.svg" />
                            {isMobileOrTablet && <br />}
                            How to Play
                        </HowToPlayButton>

                        {props.showFutureGames && (!showWagers || (showWagers && wagersForCompetitions.length == 0)) && (
                            <StyledNavBarButtons
                                onClick={toggleFuture}
                                textColor={'#000'}
                                bgColor={'#EAEAEA'}
                                rounded={'0'}
                                padding={'5.6px 14px 0 14px'}
                                {...testId('Game_FutureGamesButton')}
                            >
                                <ToggleButton active={showFutureGames}></ToggleButton>
                                {isMobileOrTablet && <br />}
                                Future Games
                            </StyledNavBarButtons>
                        )}
                        {userState.isLoggedIn && (
                            <MediaQuery maxDeviceWidth={theme.breakpoints.lg}>
                                <StyledNavBarButtonsMobile
                                    textColor={'#000'}
                                    bgColor={'#EAEAEA'}
                                    rounded={'0'}
                                    onClick={(): void => {
                                        LoadMobile(true);
                                        dispatch(openPopup('your_placed_lines'));
                                    }}
                                    {...testId('Game_ViewLinesButtonMobile')}
                                >
                                    <img src="/view-lines.svg" />
                                    <br />
                                    View Lines
                                </StyledNavBarButtonsMobile>
                            </MediaQuery>
                        )}
                    </NavStyle>
                    <StyledBetSlipMobileContainer
                        style={
                            headerHeight > 0
                                ? { top: headerHeight, position: 'sticky', zIndex: 5 }
                                : { top: 0, position: 'relative', zIndex: 0 }
                        }
                    >
                        {showWagers && canEditLine && viewLinesCurrent.id > 0 && (
                            <FutureGamesToggleSectionMobile
                                onToggleFutureGames={() => {
                                    setEditLineAllFutureGames(!editLineAllFutureGames);
                                }}
                                allFutureGames={editLineAllFutureGames}
                                hasEdits={betslipWagerHasEdits}
                            />
                        )}
                        {showWagers && canEditLine && betslipWager !== undefined ? (
                            <StyledBetSlipMobileSelectionsContainer>
                                <BetSlipCircleList
                                    selection={betslipWager.numbers}
                                    displayId={!showHDA}
                                    row={0}
                                    amount={betslipWager.pick}
                                    handleOnClick={SelectMatch}
                                    isCurrent={betslipWager.current}
                                    isMobileBetslip={true}
                                    ballColor={'#38d8ff'}
                                />
                                <ClearContainer>
                                    <img onClick={(): void => Clear()} src="/close.png" />
                                </ClearContainer>
                            </StyledBetSlipMobileSelectionsContainer>
                        ) : currentSlip !== undefined ? (
                            <StyledBetSlipMobileSelectionsContainer>
                                <BetSlipCircleList
                                    selection={currentSlip.numbers}
                                    displayId={!showHDA}
                                    row={0}
                                    amount={currentSlip.pick}
                                    handleOnClick={SelectMatch}
                                    isCurrent={currentSlip.current}
                                    isMobileBetslip={true}
                                    ballColor={'#38d8ff'}
                                />
                                <ClearContainer>
                                    <img onClick={(): void => Clear()} src="/close.png" />
                                </ClearContainer>
                            </StyledBetSlipMobileSelectionsContainer>
                        ) : (
                            <></>
                        )}
                        {showWagers && canEditLine && viewLinesCurrent.id > 0 ? (
                            <BetslipEditLineMobile
                                onClickSave={async () => {
                                    // update line
                                    await handleUpdateWager();
                                }}
                                onClickCancel={() => {
                                    if (betslipWagerHasEdits) {
                                        // revert changes to selections
                                        resetBetslipWagerSelections();
                                    } else {
                                        // return to buy lines view:
                                        setShowWagers(false);
                                    }
                                    setEditLineAllFutureGames(false);
                                }}
                                onToggleFutureGames={() => {
                                    setEditLineAllFutureGames(!editLineAllFutureGames);
                                }}
                                allFutureGames={editLineAllFutureGames}
                                hasEdits={betslipWagerHasEdits}
                                betslip={betslipWager}
                                fixtureCountLabel={'FIXTURE COUNT'}
                            />
                        ) : (
                            <BetSlipMobile
                                ChangeBet={ChangeCurrentBets}
                                ClearLine={Clear}
                                AddLine={AddLines}
                                ShowHDA={!showHDA}
                                SelectAmountAction={SelectAmount}
                                betslipselection={betslipSelection[betslipGameType]}
                                offers={props.offers}
                                setCurrentOfferingId={setCurrentOffering}
                                currentOfferingId={currentOffering as number}
                                setShowMore={setShowMore}
                                showMoreValue={showMore}
                                addedLines={[]}
                                openAddLinesPopup={() => {
                                    dispatch(openPopup('added_lines'));
                                }}
                                pressPlay={onPressPlay}
                                canAddMultipleLines={props.canAddMultipleLines}
                                isViewLines={showWagers}
                                canEdit={canEditLine}
                                fixtureCountLabel={`FIXTURE COUNT:`}
                                isClover={false}
                            />
                        )}
                    </StyledBetSlipMobileContainer>
                    {!props.onlyDefaultOffer && (
                        <MediaQuery maxDeviceWidth={theme.breakpoints.lg}>
                            <OfferingList
                                setShowMore={setShowMore}
                                showMoreValue={showMore}
                                setCurrentOfferingId={setCurrentOffering}
                                currentOfferingId={currentOffering as number}
                                offerings={props.offers}
                                currentSlip={currentSlip as BetSlip}
                                selectAmount={SelectAmount}
                                isHda={showHDA}
                            />
                        </MediaQuery>
                    )}
                    <MediaQuery maxDeviceWidth={theme.breakpoints.lg}>
                        <CurrentInfo>
                            <InfoDescription>{getGameInstructions(props.game, currentSlip?.pick || 0)}</InfoDescription>
                            NEXT GAME ENDS:{' '}
                            <DateTimeFormatter
                                format={'d MMM @ HH:mm'}
                                input={
                                    props.competitions.find(x => x.id == currentSlip?.competitionId)
                                        ?.datumDateWithBuffer || props.competitions[0].datumDateWithBuffer
                                }
                            />
                        </CurrentInfo>
                    </MediaQuery>
                    {props.showFutureGames && (!showWagers || wagersForCompetitions.length == 0) && (
                        <CompetitionSelector
                            ChangeCompetitions={ChangeComp}
                            competitions={props.competitions}
                            currentCompetition={
                                showWagers && betslipWager
                                    ? (betslipWager?.competitionId as number)
                                    : currentSlip?.competitionId ?? 0
                            }
                            BetSlipSelection={betslipSelection[betslipGameType]}
                            openErrorOnBetslipLinePopup={() => {
                                dispatch(openPopup('error_on_change_betslip_line'));
                            }}
                        ></CompetitionSelector>
                    )}

                    <LotteryOfferingInfo
                        messages={[
                            {
                                headerText: `Match ${
                                    props.offers.offerings.find(o => o.id === currentOffering)?.maximumSelections
                                } =`,
                                featureText: `£55`,
                            },
                            {
                                headerText: `Match 6 =`,
                                featureText: `£1M`,
                                colour: `#c86c0e`,
                            },
                        ]}
                    />

                    <LotteringOfferingList
                        currentOfferingId={currentOffering || props.offers.defaultOffering.id}
                        offerings={props.offers.offerings}
                        onOfferingClicked={setCurrentOffering}
                    />

                    <LotteryGameSection
                        betslipSelection={currentSlip}
                        competition={props.competitions.find(x => x.id === currentSlip?.competitionId)}
                        currentOffering={props.offers.offerings.find(o => o.id === currentOffering)}
                        selectionInfoText={
                            isMobileOrTablet ? 'Tap to choose your own numbers.' : 'Click to choose your own numbers.'
                        }
                        showCostInfo={true} //isMobileOrTablet}
                        showCountdown={true}
                        showPlayButton={true} //isMobileOrTablet}
                        onClickPlay={onPressPlay}
                        onClickToggleBonus={onClickToggleBonus}
                        selections={props.offers.selectionsOffered as number[]}
                        onClickSelection={(id: number, type: string) => {
                            dispatch(openPopup('LotterySelectionsPopup'));
                        }}
                    />

                    <GameSection
                        action={SelectMatch}
                        isHda={showHDA}
                        fixtures={
                            showWagers && betslipWager
                                ? props.competitions.find(x => x.id === betslipWager.competitionId)?.fixtures
                                : props.competitions.find(x => x.id === currentSlip?.competitionId)?.fixtures
                        }
                        betslipSelection={showWagers && betslipWager ? betslipWager : currentSlip}
                        gameViewType={'match'}
                        isViewLines={showWagers && wagersForCompetitions.length > 0}
                        canEdit={!showWagers || canEditLine}
                    />
                </StyledMain>
                <StyledSidebar>
                    <BetSlipList
                        ChangeBet={ChangeCurrentBets}
                        ClearLine={Clear}
                        AddLine={AddLines}
                        ShowHDA={showHDA}
                        SelectAmountAction={SelectAmount}
                        betslipselection={betslipSelection[betslipGameType]}
                        offers={props.offers}
                        gameType={betslipGameType}
                        handleCircleNumberClick={SelectMatch}
                        setCurrentOfferingId={setCurrentOffering}
                        currentOfferingId={currentOffering as number}
                        setShowMore={setShowMore}
                        showMoreValue={showMore}
                        wagers={wagersForCompetitions.length > 0 ? wagersForCompetitions : undefined}
                        user={userState}
                        setViewLinesCurrent={setViewLinesCurrent}
                        viewLinesCurrent={viewLinesCurrent}
                        competitions={props.competitions}
                        showWagers={showWagers}
                        setShowWagers={LoadDesktop}
                        pressPlay={onPressPlay}
                        canEdit={canEditLine}
                        viewLinesBetslip={betslipWager}
                        showAddLinesButton={props.canAddMultipleLines}
                        showOfferingList={!props.onlyDefaultOffer}
                        isClover={false}
                    />
                    {showWagers && canEditLine && viewLinesCurrent.id > 0 && (
                        <BetslipEditLine
                            onClickSave={async () => {
                                // update line
                                await handleUpdateWager();
                            }}
                            onClickCancel={() => {
                                // revert changes to selections
                                resetBetslipWagerSelections();
                            }}
                            onToggleFutureGames={() => {
                                setEditLineAllFutureGames(!editLineAllFutureGames);
                            }}
                            allFutureGames={editLineAllFutureGames}
                            hasEdits={betslipWagerHasEdits}
                        />
                    )}
                    <PageLinkButtonsContainer
                        bgColor={theme.colours.gameMainColour}
                        textColor={theme.colours.gameMainColourText}
                    >
                        <a href={`/results/${props.game}`}>{`${getGameTitle(props.game).toUpperCase()} RESULTS`}</a>
                    </PageLinkButtonsContainer>
                </StyledSidebar>
            </ThemeProvider>
        </>
    );
};

// const getThemeForGameType = (game: GameType): DefaultTheme => {
//     let ret = theme;
//     switch (game) {
//         case 'goal-rush': {
//             ret = goalRushTheme;
//             break;
//         }
//         case 'lucky-clover': {
//             ret = luckyCloverTheme;
//             break;
//         }
//         default: {
//             ret = theme;
//             break;
//         }
//     }

//     return ret;
// };

// export const getServerSideProps: GetServerSideProps = async ({ req }) => {
//     const game = getGameFromPath(req.url);
//     const { getOpenCompetitionsAsync, getOfferingsAsync, initialise } = useApi();
//     initialise(useSubscriptionApiAdaptor());

//     const res = await Promise.all([getOpenCompetitionsAsync(game), getOfferingsAsync(game)]);

//     const competitions = res[0].data;
//     const offers = res[1].data;
//     const theme = getThemeForGameType(game);

//     return {
//         props: {
//             competitions,
//             offers,
//             game,
//             theme,
//             showFutureGames: false,
//             onlyDefaultOffer: false,
//             canAddMultipleLines: false,
//             banner: {
//                 text: getGameTitle(game),
//             },
//         },
//     };
// };

export const isGameType = (game: unknown): boolean => {
    return (
        game === 'classic-pools' ||
        game === 'goal-rush' ||
        game === 'jackpot-12' ||
        game === 'lucky-clover' ||
        game === 'premier-10' ||
        game === 'premier-6' ||
        game === 'soccer-6'
    );
};

export default withGameLayout(Game);
