/* eslint-disable import/named */
import { FunctionComponent, useEffect, useState } from 'react';
import styled, { useTheme } from 'styled-components';
import { CardForm } from '@fp/shared/src/components/Forms/Payment/CardForm';
import { DirectDebitForm, ExistingDirectDebitForm } from '@fp/shared/src/components/Forms/Payment/DirectDebitForm';
import { useSelector, useDispatch } from 'react-redux';
import {
    getWagersSelector,
    ConfirmWagers,
    confirmWagers,
    getBetSlipSelector,
    toBetSlipKey,
    createWagers,
    PurchaseType,
    AuthoriseCardForm,
    AuthoriseCardFormBms,
    ApiConfig,
    finaliseWagers,
    authorisedWagers,
    AuthoriseCardResponse,
    PoolsApiError,
    wagersError,
    WagersSlice,
    useApi,
    PaymentMethod,
    PaymentMethods,
    resetWagers,
    ResetBetSlipSelections,
    BetSlip,
    initialiseWagers,
    clearError,
} from '@sportech/pools-api';
import { AppDispatch } from '@fp/shared/src/store';
import { useRouter } from 'next/router';
import { useSubscriptionApiAdaptor } from '@fp/shared/src/api/subscriptionApi/useSubscriptionApiAdaptor';
import { getGameTitle, isHdaGame } from '@fp/shared/src/lib/utils';
import { Loader } from '@fp/shared/src/components/Loader/Loader';
import { PaymentDetailsV2 } from '@fp/shared/src/components/Forms/Payment/PaymentDetailsV2';
import { Banner } from '@fp/shared/src/components/Forms/Payment/Banner';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import { getAuthenticationSelector } from '@fp/shared/src/features/authentication/authenticationSelectors';
import { closePopup, getTotalPrice, openPopup, BetSelections, Popup, Button } from '@sportech/pools-components';
import { FundsCompliancePopup } from '@fp/shared/src/components/Popup/FundsCompliancePopup';
import { isAppError } from '@fp/shared/src/core/appError';
import { updateFundsCompliance } from '@fp/shared/src/api/account';
import { addUserDetails } from '@fp/shared/src/features/authentication/authenticationSlice';
import { useEcommerceTags } from '@fp/shared/src/core/ecommerceTags';
import { MaximumLinesReachedPopup } from '@fp/shared/src/components/Popup/MaximumLinesReachedPopup';
import { PaymentMethodsUnavailablePopup } from '@fp/shared/src/components/Popup/PaymentMethodsUnavailablePopup';
import { PaymentPageProps } from '@pages/games/payment';
import { PayPalCheckoutApi, PayPalForm } from '@fp/shared/src/components/Forms/Payment/PayPalForm';
import { PaymentTypesView } from '@fp/shared/src/components/PaymentTypesRadioGroup/PaymentTypesView';
import ProgressBar from '@fp/shared/src/components/ProgressBar/ProgressBar';
import { SetWeeklySubscriptionLimitForm } from '@fp/shared/src/containers/account/setWeeklySubscriptionLimit';
import { SlimPopup } from '@fp/shared/src/components/Popup/SlimPopup';
import { useBeforeUnloadHandler } from '@fp/shared/src/core/hooks';
import { AuthenticationHandler } from '@fp/shared/src/components/AuthenticationHandler/AuthenticationHandler';
import getConfig from 'next/config';

const { publicRuntimeConfig } = getConfig();

const Container = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 385px;
    @media (max-width: 385px) {
        width: 100%;
    }
`;

const FinancialLimitsContainer = styled.div`
    /* display: flex; */
    color: ${props => props.theme.colours.primaryFont};
    font-size: 0.9rem;
    font-weight: bold;
    margin: 1.2rem 0;
    a {
        text-decoration: none;
    }
`;

const SectionsContainer = styled.div`
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
`;

const SectionContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: #fff;
    border-radius: 10px;
    margin: 5px auto;
    padding: 5px;
    width: 100%;
    ${breakpoints.below('xs')} {
        width: 90%;
    }
    @media (max-width: 385px) {
        width: 95%;
    }
`;
const LoaderBackground = styled.div`
    @keyframes pulse {
        0% {
            box-shadow: 0 0 0 0 rgba(0, 195, 8, 0.4);
        }
        70% {
            box-shadow: 0 0 0 10px rgba(0, 195, 8, 0);
        }
        100% {
            box-shadow: 0 0 0 0 rgba(0, 195, 8, 0);
        }
    }
    box-shadow: 0 0 0 rgba(0, 195, 8, 0.4);
    animation: pulse 2s infinite;
    background: #7cda24; // rgba(0, 195, 8, 0.4);
    border-radius: 50px;
    width: 90%;
    height: 60px;
    position: absolute;
    z-index: -1;
`;
const ProgressEndContainer = styled.div<{ background?: string; borderColour?: string }>`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: ${props => props.background || '#fff '};
    border-radius: 10px;
    border: ${props => `1px solid ${props.borderColour || props.theme.colours.primary}`};
    margin: 5px auto;
    padding: 5px;
`;
const TitleText = styled.h3`
    color: ${props => props.theme.colours.primaryFont};
    font-size: 1rem;
    margin-top: 10px auto 5px;
`;
const SubtitleText = styled.h4<{ fontColour?: string; fontSize?: string }>`
    color: ${props => props.fontColour || props.theme.colours.primary};
    font-size: ${props => props.fontSize || '1rem'};
    margin: 10px;
`;
const PaymentStepBackContainer = styled.div`
    color: ${props => props.theme.colours.primaryFont};
    cursor: pointer;
    font-size: 0.9rem;
    font-weight: bold;
    margin: 0 0 5px 10px;
    width: 100%;
`;
const ProgressContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 0 5px;
    margin: 10px auto;
    width: 100%;
    ${breakpoints.below('xs')} {
        width: 92%;
    }
    @media (max-width: 385px) {
        width: 97%;
    }
`;
const SecurePaymentsContainer = styled.div`
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    justify-content: space-evenly;
    color: ${props => props.theme.colours.primaryFont};
    font-weight: bold;
    font-size: 0.8rem;
    margin: 5px auto 1.2rem auto;
    width: 100%;
`;
const DetailsText = styled.div<{ fontWeight?: string; fontSize?: string }>`
    font-size: ${props => props.fontSize};
    font-weight: ${props => props.fontWeight};
    color: ${props => props.theme.colours.primary};
    line-height: 1.2rem;
`;
const ConfirmationContainer = styled.div`
    display: flex;
    flex-direction: column;
    padding: 0 10px;
    width: 100%;
    margin-bottom: 10px;
`;

const BetSelectionsConfirmationContainer = styled.div`
    display: flex;
    flex-direction: column;
    margin: 10px 0;
`;

const validateWagers = (wagersState: WagersSlice): boolean => {
    let ret = true;
    if (!wagersState.wagers || wagersState.wagers.length <= 0) {
        ret = false;
    }
    return ret;
};

export const PaymentV2 = ({ paymentDetailsContent }: PaymentPageProps): JSX.Element => {
    const wagersState = useSelector(getWagersSelector);
    const betslipState = useSelector(getBetSlipSelector);
    const userState = useSelector(getAuthenticationSelector);
    const dispatch = useDispatch<AppDispatch>();
    const router = useRouter();
    /**
     * Helper function.
     * Determine whether user has returned to page from paypal portal.
     */
    // const isPayPalCallback = (): boolean => {
    //     const paypal = router.query.paypal as string;
    //     const token = router.query.token as string;
    //     return Boolean(paypal && token && (paypal === 'confirm' || paypal === 'cancel'));
    // };
    const [isPayPalCallback, setIsPayPalCallback] = useState<boolean>(() => {
        const paypal = router.query.paypal as string;
        const token = router.query.token as string;
        return Boolean(paypal && token && (paypal === 'confirm' || paypal === 'cancel'));
    });
    const theme = useTheme();
    const { getPaymentMethodsAsync } = useApi('backend');
    const [cardErrors, setCardErrors] = useState<PoolsApiError[] | undefined>(undefined);
    const [directDebitErrors, setDirectDebitErrors] = useState<PoolsApiError[] | undefined>(undefined);
    const [payPalErrors, setPayPalErrors] = useState<PoolsApiError[] | undefined>(undefined);
    const [confirmWagersData, setConfirmWagersData] = useState<ConfirmWagers | undefined>(undefined);
    const [paymentMethodOptions, setPaymentMethodOptions] = useState<PaymentMethods | undefined>(undefined);
    const [isLoading, setIsLoading] = useState<boolean>(wagersState.isFetching || false);
    const [fundsComplianceAccepted, setFundsComplianceAccepted] = useState<boolean>(false);
    const [paymentStep, setPaymentStep] = useState<'select' | 'details' | 'confirming' | 'confirm'>(
        isPayPalCallback ? 'confirming' : 'select',
    );
    const { checkoutOption, confirmPlay, purchase, paymentError } = useEcommerceTags(
        'football-pools',
        'The Football Pools',
    );

    const totalPrice = () =>
        getTotalPrice(
            isHdaGame(wagersState.game),
            wagersState.game === 'lucky-clover',
            betslipState[toBetSlipKey(wagersState.game)],
        ) * 100;

    useBeforeUnloadHandler(() => {
        if (wagersState.stage === 'confirmed') {
            dispatch(resetWagers({ game: wagersState.game }));
        }
    });

    useEffect(() => {
        // Redirect user if they are not logged in.
        if (!userState || !userState.isLoggedIn) {
            router.push(`/`);
        }
        // Redirect user to game page if wagers are invalid.
        if (!validateWagers(wagersState) && paymentStep !== 'confirm') {
            router.push(`/games/${wagersState.gameVariant || wagersState.game}/game`);
        }
    }, []);

    /**
     * Toggle payment method control.
     * Setting this triggers the create wagers action.
     */
    const [currentPaymentMethod, setCurrentPaymentMethod] = useState<PaymentMethod | undefined>(
        isPayPalCallback ? 'paypal' : undefined,
    );

    useEffect(() => {
        setIsLoading(wagersState.isFetching || false);
    }, [wagersState.isFetching, paymentMethodOptions]);

    /**
     * Set isPayPalCallback flag when redirected from PayPal portal.
     */
    useEffect(() => {
        if (isPayPalCallback) {
            const paypal = router.query.paypal as string;
            const token = router.query.token as string;

            if (wagersState.stage === 'created' && paypal === 'confirm' && token) {
                // User has confirmed agreement with PayPal, confirm the order:
                setPaymentStep('confirming');
                const data: ConfirmWagers = {
                    paypalDetails: {
                        token: token,
                    },
                };
                dispatch(confirmWagers(data, wagersState.game, totalPrice()));
            } else if (paypal === 'cancel') {
                // User has cancelled agreement with PayPal, show error message:
                dispatch(wagersError({ title: 'Not authorised with PayPal', code: 'paypal_cancel' }));
            }
            router.push('payment', undefined, { shallow: true });
        }
    }, [isPayPalCallback]);

    /**
     * Get available payment methods for this order on page load.
     */
    useEffect(() => {
        const fetchPaymentMethods = async (): Promise<void> => {
            if (paymentMethodOptions === undefined) {
                setIsLoading(true);
                const paymentMethodsRes = await getPaymentMethodsAsync(wagersState.game, wagersState.wagers.length);
                const paymentMethodOpts: PaymentMethods | undefined = paymentMethodsRes.data;
                if (paymentMethodOpts && paymentMethodOpts.paymentMethods && wagersState.game === 'lucky-clover') {
                    // TODO: move this to the api
                    // We cannot accept RT clover payments:
                    paymentMethodOpts.paymentMethods = paymentMethodOpts.paymentMethods.filter(p => p !== 'card');
                }
                if (paymentMethodOpts && paymentMethodOpts.paymentMethods) {
                    if (paymentMethodOpts.paymentMethods.length <= 0) {
                        // No payment types available, show popup:
                        dispatch(
                            wagersError({
                                title: 'No payment methods available',
                                code: 'payment_methods_unavailable',
                            }),
                        );
                    } else if (!paymentMethodOpts.paymentMethods.find(p => p === 'direct-debit')) {
                        // Only card payments are allowed.
                        if (wagersState.game === 'lucky-clover') {
                            // We cannot accept RT clover payments:
                            dispatch(
                                wagersError({
                                    title: 'Unsupported payment method',
                                    code: 'unsupported_payment_method',
                                }),
                            );
                        }
                    }
                }
                setPaymentMethodOptions(paymentMethodOpts);
            }
        };
        fetchPaymentMethods();
    }, []);

    /**
     * Create wagers order for selected payment type.
     * Triggered on payment method toggle updates.
     */
    useEffect(() => {
        if (currentPaymentMethod && !isPayPalCallback) {
            const betslipKey = toBetSlipKey(wagersState.game);
            const purchaseType: PurchaseType = currentPaymentMethod === 'direct-debit' ? 'Subscription' : 'ByGames';
            // console.log('updating payment method', betslipKey, purchaseType);
            dispatch(
                createWagers(
                    betslipState[betslipKey].filter(b => b.numbers && b.numbers.length === b.pick),
                    betslipKey,
                    purchaseType,
                    wagersState.competition,
                    currentPaymentMethod,
                ),
            );
            checkoutOption(
                wagersState.game,
                getTotalPrice(
                    isHdaGame(wagersState.game),
                    wagersState.game === 'lucky-clover',
                    betslipState[betslipKey],
                ),
                currentPaymentMethod === 'direct-debit'
                    ? 'subscription-direct-debit'
                    : 'card'
                    ? 'subscription-credit-card'
                    : 'subscription-paypal',
                wagersState.gameVariant,
            );
        }
    }, [currentPaymentMethod, paymentMethodOptions]);

    useEffect(() => {
        const handleCreated = (): void => {
            if (wagersState.stage === 'created' && paymentStep !== 'details' && currentPaymentMethod !== undefined) {
                setPaymentStep('details');
            }
        };
        handleCreated();
    }, [wagersState.stage, currentPaymentMethod]);

    /**
     * Triggered on wagersState.stage updates.
     */
    useEffect(() => {
        /**
         * Payment has been confirmed, navigate to game page to show confirm popup.
         */
        const handleConfirmed = (): void => {
            if (wagersState.stage === 'confirmed') {
                // dispatch(ResetBetSlipSelections({ ItemKey: 'ClassicPools' }));
                purchase(
                    betslipState[toBetSlipKey(wagersState.game)],
                    wagersState.game,
                    currentPaymentMethod === 'direct-debit'
                        ? 'subscription-direct-debit'
                        : 'card'
                        ? 'subscription-credit-card'
                        : 'subscription-paypal',
                    userState.userDetails && userState.userDetails.status && userState.userDetails?.status !== 'player'
                        ? 'FTS'
                        : 'RS',
                    wagersState.orderId,
                    wagersState.gameVariant,
                );
                // setIsLoading(true);
                // router.push(`/games/${wagersState.gameVariant || wagersState.game}/game`);
                setPaymentStep('confirm');
            }
        };
        /**
         * Card payment has been 3DS authorised, finalise wagers with api.
         */
        const handleFinalise = (): void => {
            if (wagersState.stage === 'authorised') {
                dispatch(finaliseWagers());
            }
        };
        /**
         * Handle api errors.
         * Pass any form specific errors to card / debit forms.
         */
        const handleError = (): void => {
            if (wagersState.stage === 'error') {
                const error = { ...(wagersState.error as PoolsApiError) };
                const setFormErrors = (err: PoolsApiError): void => {
                    if (currentPaymentMethod === 'card') {
                        setCardErrors([err]);
                    } else if (currentPaymentMethod === 'direct-debit') {
                        setDirectDebitErrors([err]);
                    } else {
                        setPayPalErrors([err]);
                    }
                };
                if (error) {
                    if (error.code) {
                        switch (error.code) {
                            // case 'pending_verification': {
                            //     if (wagersState.finaliseDetails) {
                            //         dispatch(confirmedWagers(wagersState.finaliseDetails as ConfirmedWagers));
                            //     }
                            //     break;
                            // }
                            case 'payment_failed': {
                                error.title =
                                    'Sorry, there was an error processing your payment. Please try again later.';
                                setFormErrors(error);
                                dispatch(openPopup('paymentFailed'));
                                break;
                            }
                            case 'unsupported_payment_method': {
                                error.title = 'Sorry you have reached the limit of purchasable lines for this game.';
                                setFormErrors(error);
                                dispatch(openPopup('maximumLinesReached'));
                                break;
                            }
                            case 'ValidationError': {
                                error.title =
                                    currentPaymentMethod === 'card'
                                        ? 'Please enter a valid Visa card number. If you do not have a Visa card, please select a different payment option.'
                                        : 'Please enter a valid direct debit number.';
                                setFormErrors(error);
                                break;
                            }
                            case 'payment_methods_unavailable': {
                                setFormErrors(error);
                                dispatch(openPopup('paymentMethodsUnavailable'));
                                break;
                            }
                            case 'limit_incompatibility':
                            case 'limit_incompatibility_within_cooling_off': {
                                setFormErrors(error);
                                dispatch(openPopup('exceededSubscriptionLimit'));
                                break;
                            }
                            default: {
                                setFormErrors(error);
                                break;
                            }
                        }
                    } else {
                        console.error('payment error', wagersState.stage, error);
                        setFormErrors(error);
                    }
                    paymentError(`pv2:${error.code}:${wagersState.game}`, `${error.title}`);
                }
            }
        };
        handleConfirmed();
        handleFinalise();
        handleError();
    }, [wagersState.stage]);

    const onPaymentTypeSelected = (paymentType: PaymentMethod): void => {
        setIsLoading(true);
        setCurrentPaymentMethod(paymentType);
    };
    const onSubmitCardForm = async (data: ConfirmWagers): Promise<void> => {
        // console.log('submit card', data);
        confirmPlay(
            wagersState.game,
            getTotalPrice(
                isHdaGame(wagersState.game),
                wagersState.game === 'lucky-clover',
                betslipState[toBetSlipKey(wagersState.game)],
            ),
            currentPaymentMethod === 'direct-debit'
                ? 'subscription-direct-debit'
                : currentPaymentMethod === 'card'
                ? 'subscription-credit-card'
                : 'subscription-paypal',
            wagersState.gameVariant,
        );

        if (!userState.userDetails?.consents?.fundsCompliance) {
            // User must confirm funds compliance:
            setConfirmWagersData(data);
            dispatch(openPopup('fundsCompliance'));
        } else {
            if (wagersState.error) {
                dispatch(clearError('created'));
            }
            dispatch(confirmWagers(data, wagersState.game, totalPrice()));
            setPaymentStep('confirming');
        }
    };
    const onSubmitDirectDebitForm = (data: ConfirmWagers): void => {
        // console.log('submit direct debit', data);
        confirmPlay(
            wagersState.game,
            getTotalPrice(
                isHdaGame(wagersState.game),
                wagersState.game === 'lucky-clover',
                betslipState[toBetSlipKey(wagersState.game)],
            ),
            currentPaymentMethod === 'direct-debit'
                ? 'subscription-direct-debit'
                : currentPaymentMethod === 'card'
                ? 'subscription-credit-card'
                : 'subscription-paypal',
            wagersState.gameVariant,
        );

        dispatch(confirmWagers(data, wagersState.game, totalPrice()));
        setPaymentStep('confirming');
    };
    const getTermUrl = (): string => {
        const adaptor = useSubscriptionApiAdaptor();
        const apiConfig: ApiConfig = { clientType: 'backend' };
        const ret = `${adaptor.getBaseUrl(apiConfig)}${
            adaptor.getAuthoriseCardEndpoint ? adaptor.getAuthoriseCardEndpoint(apiConfig) : ''
        }`;
        return ret;
    };
    const onAuthoriseSuccess = (res: AuthoriseCardResponse): void => {
        dispatch(authorisedWagers(res));
    };
    const onAuthoriseError = (error: unknown): void => {
        console.error('auth error', error);
        dispatch(wagersError({ title: '3ds auth error', code: '3ds_error' }));
    };
    const onSubmitPayPalForm = (): boolean => {
        let ret = false;
        confirmPlay(
            wagersState.game,
            getTotalPrice(
                isHdaGame(wagersState.game),
                wagersState.game === 'lucky-clover',
                betslipState[toBetSlipKey(wagersState.game)],
            ),
            currentPaymentMethod === 'direct-debit'
                ? 'subscription-direct-debit'
                : currentPaymentMethod === 'card'
                ? 'subscription-credit-card'
                : 'subscription-paypal',
            wagersState.gameVariant,
        );
        if (payPalErrors) {
            setPayPalErrors(undefined);
        }
        if (!userState.userDetails?.consents?.fundsCompliance) {
            // User must confirm funds compliance:
            dispatch(openPopup('fundsCompliance'));
        } else {
            // Redirect user to PayPal payment portal:
            setPaymentStep('confirming');
            setIsLoading(true);
            ret = true;
        }
        return ret;
    };
    const getAmount = (): string => {
        const ret = (
            getTotalPrice(
                isHdaGame(wagersState.game),
                wagersState.game === 'lucky-clover',
                betslipState[toBetSlipKey(wagersState.game)],
            ) * 10
        ).toLocaleStringCash();
        return ret;
    };
    const onFundsComplianceClickClose = (): void => {
        if (!fundsComplianceAccepted) {
            setConfirmWagersData(undefined);
            setIsLoading(true);
            setPaymentStep('select');
            router.push(`/games/${wagersState.gameVariant || wagersState.game}/game`);
        }
    };
    const onFundsComplianceClickConfirm = async (): Promise<void> => {
        setFundsComplianceAccepted(true);
        const res = await updateFundsCompliance({ fundsCompliance: true });
        if (!isAppError(res)) {
            dispatch(addUserDetails(res));
            if (currentPaymentMethod === 'card') {
                dispatch(confirmWagers(confirmWagersData as ConfirmWagers, wagersState.game, totalPrice()));
                setConfirmWagersData(undefined);
            } else if (currentPaymentMethod === 'paypal') {
                const paypal = window.paypal as {
                    checkout: PayPalCheckoutApi;
                };
                if (paypal && wagersState.payPalToken) {
                    try {
                        paypal.checkout.startFlow(wagersState.payPalToken);
                    } catch (error) {
                        paypal.checkout.closeFlow();
                    }
                }
            }
            setPaymentStep('confirming');
        } else {
            if (isAppError(res)) {
                dispatch(
                    wagersError({
                        title: res.apiError?.title || 'Error accepting funds compliance',
                        code: res.apiError?.code || 'funds_compliance',
                    }),
                );
            } else {
                router.push(`/games/${wagersState.gameVariant || wagersState.game}/game`);
            }
        }
        dispatch(closePopup('fundsCompliance'));
    };
    const onClickBack = (): void => {
        if (paymentStep === 'select') {
            setIsLoading(true);
            dispatch(resetWagers({ game: wagersState.game }));
            router.push(`/games/${wagersState.gameVariant || wagersState.game}/game`);
        } else if (paymentStep === 'details' || paymentStep === 'confirming') {
            dispatch(
                initialiseWagers({
                    wagers: wagersState.wagers as BetSlip[],
                    game: wagersState.game,
                    purchaseType: 'Subscription',
                    competition: wagersState.competition,
                    gameVariant: wagersState.gameVariant,
                }),
            );
            setCurrentPaymentMethod(undefined);
            setPaymentStep('select');
            setCardErrors(undefined);
            setDirectDebitErrors(undefined);
            setPayPalErrors(undefined);
            setIsPayPalCallback(false);
        } else {
        }
    };

    return (
        <Container>
            <AuthenticationHandler operator="footballpools" />
            <Popup
                popupStyles={{
                    width: '390px !important',
                    padding: '20px 55px !important',
                    mobileMargin: 'auto',
                    rounded: true,
                    headerStyles: {
                        textAlign: 'center',
                        color: theme.colours.primaryFont,
                    },
                    crossStyles: {
                        top: '5px',
                        right: '60px',
                    },
                    overflow: 'scroll',
                }}
                popupName="responsibleGambling"
                title="Responsible Gambling"
                withCloseButton={true}
            >
                <SubtitleText fontColour={theme.colours.primaryFont} fontSize="unset">
                    SET WEEKLY SUBSCRIPTION LIMIT
                </SubtitleText>
                <SetWeeklySubscriptionLimitForm
                    selectPosition="raised"
                    onUpdatedSuccess={() => dispatch(closePopup('responsibleGambling'))}
                />
            </Popup>
            <FundsCompliancePopup
                onClickClose={onFundsComplianceClickClose}
                onClickConfirm={onFundsComplianceClickConfirm}
            />
            <MaximumLinesReachedPopup
                onClickConfirm={() => {
                    dispatch(closePopup('maximumLinesReached'));
                    setIsLoading(true);
                    router.push(`/games/${wagersState.gameVariant || wagersState.game}/game`);
                    dispatch(ResetBetSlipSelections({ ItemKey: toBetSlipKey(wagersState.game) }));
                    dispatch(resetWagers({ game: wagersState.game }));
                }}
            />
            <PaymentMethodsUnavailablePopup
                onClickConfirm={() => {
                    setIsLoading(true);
                    dispatch(closePopup('paymentMethodsUnavailable'));
                    router.push(`/games/${wagersState.gameVariant || wagersState.game}/game`);
                    dispatch(ResetBetSlipSelections({ ItemKey: toBetSlipKey(wagersState.game) }));
                    dispatch(resetWagers({ game: wagersState.game }));
                }}
            />
            <SlimPopup
                popupName="exceededSubscriptionLimit"
                popupTitle="Subscription Limits"
                content={
                    wagersState &&
                    wagersState.error &&
                    wagersState.error.code &&
                    wagersState.error.code.includes('within_cooling_off')
                        ? 'The purchase you want to add, would exceed the Weekly Spend Limit you have currently set. You have asked us to increase your Weekly Spend Limit which you will need to confirm. After that, you will then be able to make a new purchase. If you have any questions about your Weekly Spend Limit, please contact us on  0800 953 9933'
                        : 'The purchase you want to add would exceed the Weekly Spend Limit you have set, We cannot therefore complete this transaction until you speak to our Contact Centre Agents. Please call our Contact Centre on 0800 953 9933'
                }
                allowClose={false}
                onClickConfirm={() => {
                    setIsLoading(true);
                    dispatch(closePopup('exceededSubscriptionLimit'));
                    router.push(`/games/${wagersState.gameVariant || wagersState.game}/game`);
                    dispatch(resetWagers({ game: wagersState.game }));
                }}
            />
            <SlimPopup
                popupName="paymentFailed"
                popupTitle="Payment Failed"
                content={'Sorry, there was an error processing your payment. Please try again.'}
                allowClose={false}
                onClickConfirm={() => {
                    setIsLoading(true);
                    const betslipKey = toBetSlipKey(wagersState.game);
                    const purchaseType: PurchaseType =
                        currentPaymentMethod === 'direct-debit' ? 'Subscription' : 'ByGames';
                    setCardErrors(undefined);
                    setDirectDebitErrors(undefined);
                    setPayPalErrors(undefined);
                    dispatch(
                        initialiseWagers({
                            wagers: wagersState.wagers as BetSlip[],
                            game: wagersState.game,
                            purchaseType: 'Subscription',
                            competition: wagersState.competition,
                            gameVariant: wagersState.gameVariant,
                            numberOfGames: wagersState.numberOfGames,
                        }),
                    );
                    dispatch(
                        createWagers(
                            betslipState[betslipKey].filter(b => b.numbers && b.numbers.length === b.pick),
                            betslipKey,
                            purchaseType,
                            wagersState.competition,
                            currentPaymentMethod,
                            wagersState.numberOfGames,
                        ),
                    );
                    setPaymentStep('details');
                    dispatch(closePopup('paymentFailed'));
                }}
            />
            <Banner
                preFeatureLines={['Two chances to win']}
                featureLines={['BIG CASH PRIZES']}
                postFeatureLines={['each week!']}
                fontColour="#fff"
                fontWeight="bold"
                margin="30px auto 10px"
            />
            <ProgressContainer>
                <ProgressBar
                    active={paymentStep === 'select' ? 1 : paymentStep === 'details' ? 2 : 3}
                    steps={3}
                    activeStyle={{ backgroundColour: '#4CA40C', fontColour: '#fff', border: '1px solid #fff' }}
                    completeStyle={{ backgroundColour: '#4CA40C', fontColour: '#fff', border: '1px solid #fff' }}
                    progressEndElement={
                        <ProgressEndContainer
                            background={paymentStep === 'confirm' ? '#4CA40C' : undefined}
                            borderColour={paymentStep === 'confirm' ? '#fff' : undefined}
                        >
                            <SubtitleText fontColour={paymentStep === 'confirm' ? '#fff' : undefined}>
                                FREE GAMES
                            </SubtitleText>
                        </ProgressEndContainer>
                    }
                />
            </ProgressContainer>

            <SectionsContainer>
                <Loader isLoading={isLoading} backgroundColour={'#000d68'} color="white" loaderType="ThreeDots">
                    <LoaderBackground />
                </Loader>
                {paymentStep === 'select' &&
                (paymentMethodOptions === undefined || paymentMethodOptions.paymentMethods) ? (
                    <SectionContainer>
                        <TitleText>SELECT PAYMENT TYPE</TitleText>
                        <PaymentTypesView
                            paymentTypes={paymentMethodOptions?.paymentMethods}
                            onClickPaymentType={onPaymentTypeSelected}
                        />
                        <FinancialLimitsContainer>
                            <PaymentStepBackContainer
                                onClick={() => {
                                    dispatch(openPopup('responsibleGambling'));
                                }}
                            >
                                Set Weekly Subscription Spend Limit
                            </PaymentStepBackContainer>
                        </FinancialLimitsContainer>
                        <PaymentStepBackContainer onClick={onClickBack}>Back</PaymentStepBackContainer>
                    </SectionContainer>
                ) : (
                    <></>
                )}
                {(paymentStep === 'details' || paymentStep === 'confirming') && (
                    <SectionContainer>
                        <TitleText>
                            {currentPaymentMethod === 'card'
                                ? 'DEBIT CARD'
                                : currentPaymentMethod === 'direct-debit'
                                ? 'DIRECT DEBIT'
                                : 'PAYPAL'}
                        </TitleText>
                        <SecurePaymentsContainer>
                            <img src="/padlock.svg" style={{ marginRight: '5px' }} />
                            SECURE PAYMENTS: We value your security
                        </SecurePaymentsContainer>
                        {wagersState.stage === 'authorising' && wagersState.finaliseDetails ? (
                            <AuthoriseCardFormBms
                                token={wagersState.finaliseDetails.cardConfirmToken}
                                url={wagersState.finaliseDetails.cardConfirmUrl}
                                onSuccess={onAuthoriseSuccess}
                                onError={onAuthoriseError}
                            />
                        ) : currentPaymentMethod === 'paypal' ? (
                            <PayPalForm
                                game={wagersState.game}
                                onSubmitForm={onSubmitPayPalForm}
                                apiErrors={payPalErrors}
                                setApiErrors={setPayPalErrors}
                                token={wagersState.payPalToken}
                            />
                        ) : currentPaymentMethod === 'card' ? (
                            <CardForm
                                game={wagersState.game}
                                onSubmitForm={onSubmitCardForm}
                                apiErrors={cardErrors}
                                setApiErrors={setCardErrors}
                            />
                        ) : paymentMethodOptions?.hasExistingDirectDebit ? (
                            <ExistingDirectDebitForm
                                game={wagersState.game}
                                onSubmitForm={onSubmitDirectDebitForm}
                                apiErrors={directDebitErrors}
                                setApiErrors={setDirectDebitErrors}
                            />
                        ) : (
                            <DirectDebitForm
                                game={wagersState.game}
                                onSubmitForm={onSubmitDirectDebitForm}
                                apiErrors={directDebitErrors}
                                setApiErrors={setDirectDebitErrors}
                            />
                        )}
                        <FinancialLimitsContainer>
                            <PaymentStepBackContainer
                                onClick={() => {
                                    dispatch(openPopup('responsibleGambling'));
                                }}
                            >
                                Set Weekly Subscription Spend Limit
                            </PaymentStepBackContainer>
                        </FinancialLimitsContainer>
                        <PaymentStepBackContainer onClick={onClickBack}>Back</PaymentStepBackContainer>
                    </SectionContainer>
                )}
                {paymentStep === 'select' && (
                    <SectionContainer>
                        {betslipState[toBetSlipKey(wagersState.game)][0] && (
                            <>
                                <SubtitleText>You can cancel at anytime</SubtitleText>
                                <BetSelections
                                    bet={betslipState[toBetSlipKey(wagersState.game)][0] as BetSlip}
                                    game={wagersState.game}
                                    displayId={!isHdaGame(wagersState.game)}
                                    justifyContent="center"
                                    betslipItemSize={'2.5em'}
                                    selectionsColour={wagersState.game === 'lucky-clover' ? '#00955C' : undefined}
                                    bonusSelectionsColour="#e0ac00"
                                    isCurrentSelectedLine={true}
                                />
                            </>
                        )}
                    </SectionContainer>
                )}
                {paymentStep !== 'confirm' && (
                    <SectionContainer>
                        <SubtitleText>Subscription details</SubtitleText>
                        <PaymentDetailsV2
                            amount={getAmount()}
                            numberOfGames={currentPaymentMethod === 'card' ? 10 : undefined}
                            numberOfFreeGames={currentPaymentMethod === 'direct-debit' ? 4 : undefined}
                            paymentMethodType={
                                currentPaymentMethod
                                    ? currentPaymentMethod
                                    : paymentMethodOptions &&
                                      paymentMethodOptions.paymentMethods &&
                                      paymentMethodOptions.paymentMethods.length === 1
                                    ? paymentMethodOptions?.paymentMethods[0]
                                    : paymentMethodOptions &&
                                      paymentMethodOptions.paymentMethods &&
                                      paymentMethodOptions.paymentMethods.includes('card')
                                    ? 'card'
                                    : paymentMethodOptions &&
                                      paymentMethodOptions.paymentMethods &&
                                      paymentMethodOptions.paymentMethods.includes('direct-debit')
                                    ? 'direct-debit'
                                    : 'card'
                            }
                            directDebitPaymentDetails={
                                currentPaymentMethod ? paymentDetailsContent?.directDebitPaymentDetails : undefined
                            }
                            directDebitPaymentMessages={paymentDetailsContent?.directDebitMessages}
                            cardPaymentDetails={
                                currentPaymentMethod ? paymentDetailsContent?.cardPaymentDetails : undefined
                            }
                            cardPaymentMessages={paymentDetailsContent?.cardPaymentMessages}
                            paypalPaymentDetails={
                                currentPaymentMethod ? paymentDetailsContent?.paypalPaymentDetails : undefined
                            }
                            paypalPaymentMessages={paymentDetailsContent?.paypalPaymentMessages}
                        />
                    </SectionContainer>
                )}
                {paymentStep === 'confirm' && (
                    <>
                        <SectionContainer>
                            <SubtitleText>CONGRATULATIONS!</SubtitleText>
                            <ConfirmationContainer>
                                <DetailsText fontSize="0.85rem">
                                    Your subscription to {getGameTitle(wagersState.game)} is confirmed.
                                </DetailsText>
                                <DetailsText fontSize="0.85rem">
                                    The following line
                                    {wagersState.wagers && wagersState.wagers.length > 1 ? 's have' : ' has'} been added
                                    to your subscription and you will be entered for All Games:
                                </DetailsText>
                                <BetSelectionsConfirmationContainer>
                                    <BetSelections
                                        bet={betslipState[toBetSlipKey(wagersState.game)][0] as BetSlip}
                                        game={wagersState.game}
                                        displayId={!isHdaGame(wagersState.game)}
                                        justifyContent="center"
                                        betslipItemSize={'2.5em'}
                                        selectionsColour={wagersState.game === 'lucky-clover' ? '#00955C' : undefined}
                                        bonusSelectionsColour="#e0ac00"
                                        isCurrentSelectedLine={true}
                                    />
                                </BetSelectionsConfirmationContainer>
                                <DetailsText fontSize="0.85rem">
                                    We will send an email to confirm all the details you have provided.
                                </DetailsText>
                            </ConfirmationContainer>
                        </SectionContainer>
                        <Button
                            role="button"
                            onClick={() => {
                                setIsLoading(true);
                                router.push('/');
                                dispatch(ResetBetSlipSelections({ ItemKey: toBetSlipKey(wagersState.game) }));
                                dispatch(resetWagers({ game: wagersState.game }));
                            }}
                            width="90%"
                            height="50px"
                            bgColor="#7cda24"
                            disabledBackgroundColour="#7cda24"
                            disabledOpacity="0.5"
                            hoverColor="#7cda24"
                            hoverOpacity="0.5"
                            padding="0.75em 1.25em"
                            textColor="#fff"
                            fontWeight="bold"
                            rounded="25px"
                            margin="10px"
                        >
                            {`Go to homepage`}
                        </Button>
                        <Button
                            title="Submit"
                            role="button"
                            onClick={() => {
                                setIsLoading(true);
                                router.push(
                                    `/games/${wagersState.gameVariant || wagersState.game}/game?view-lines=true`,
                                );
                                dispatch(ResetBetSlipSelections({ ItemKey: toBetSlipKey(wagersState.game) }));
                                dispatch(resetWagers({ game: wagersState.game }));
                            }}
                            width="90%"
                            height="50px"
                            bgColor="#7cda24"
                            disabledBackgroundColour="#7cda24"
                            disabledOpacity="0.5"
                            hoverColor="#7cda24"
                            hoverOpacity="0.5"
                            padding="0.75em 1.25em"
                            textColor="#fff"
                            fontWeight="bold"
                            rounded="25px"
                            margin="10px"
                        >
                            {`View your lines`}
                        </Button>
                    </>
                )}
            </SectionsContainer>
        </Container>
    );
};
