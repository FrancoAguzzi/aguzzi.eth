import styled from 'styled-components';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import { FunctionComponent } from 'react';
import { theme } from '@fp/shared/src/settings/theme';

export interface PaymentDetails {
    accountNumber: string;
    sortCode: string;
}

const Container = styled.div`
    width: 75%;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    p {
        color: ${theme.colours.primaryFont};
        margin: 1.5em 0 1.5em 0;
        ${breakpoints.below('sm')} {
            margin: 0;
        }
    }
    h5 {
        font-size: 0.875em;
    }
    ${breakpoints.below('sm')} {
        flex-direction: column;
    }
`;

export const BankDetails: FunctionComponent<PaymentDetails> = ({ accountNumber, sortCode }) => {
    return (
        <>
            <Container>
                <h5>Bank Account Number</h5>
                <p>{accountNumber}</p>
                <h5>Sort Code</h5>
                <p>{sortCode}</p>
            </Container>
            <hr />
        </>
    );
};
