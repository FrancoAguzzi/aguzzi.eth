import { useEffect, useRef, useState } from 'react';
import { useDispatch } from 'react-redux';
import styled from 'styled-components';
import { builder, BuilderComponent } from '@builder.io/react';
import { CouponBottomButtons } from '@fp/shared/src/components/Coupon/CouponBottomButtons';
import { CouponGameBoard } from '@fp/shared/src/components/Coupon/CouponGameBoard';
import { CouponTopButtons } from '@fp/shared/src/components/Coupon/CouponTopButtons';
import { CouponBetslip } from '@fp/shared/src/components/Coupon/CouponBetslip';
// eslint-disable-next-line import/named
import { GameType, Offering, toBetSlipKey } from '@sportech/pools-api';
import { DateTimeFormatter, openPopup } from '@sportech/pools-components';
import { StyledMain, MobileHeaderContainer } from './game.shared';
import { BuilderGamePageBanner } from '@fp/shared/src/core/gamePage.builder';
import { GameTemplate, GameTemplateProps } from './gameTemplate';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';

export const GameCouponTemplateComponent = ({
    competitions,
    offers,
    game,
    gameDescription,
    gameEnabled,
    gamePath,
    gameViewType,
    showFutureGames,
    headerHeight,
    onlyDefaultOffer,
    canAddMultipleLines,
    competitionTypeDescription,
    banner,
    howToManageLines,
    howToPlay,
    showMobilePrice,
    termsAndConditions,
    termsContent,
    viewLinesOffers,
    betslipGameType,
    betslipState,
    wagersState,
    userState,
    addLine,
    changeCompetition,
    changeCurrentBet,
    clearLine,
    selectAmount,
    selectLuckyDip,
    selectPlay,
    selectPrediction,
    setCanEditLine,
    setCurrentOfferingId,
    setEditLineAllFutureGames,
    setIsLoading,
    setNumberOfGames,
    setShowFutureCompetitions,
    setShowMore,
    setShowSlideBoard,
    setShowWagerFixtures,
    setShowWagers,
    setViewLinesCurrent,
    fetchWagers,
    handleUpdateWager,
    resetBetslipWagerSelections,
    betslipWager,
    betslipWagerHasEdits,
    canEditLine,
    currentOfferingId,
    editLineAllFutureGames,
    editWagerError,
    isLoading,
    isMobileOrTablet,
    numberOfGames,
    showFutureCompetitions,
    showHda,
    showMore,
    showSlideBoard,
    showWagerFixtures,
    showWagers,
    viewLinesCurrent,
    wagers,
    wagersForCompetitions,
    paymentTypeFlow,
    setPaymentTypeFlow,
    paymentTypes,
    maximumLines,
    costTypeDescription,
    minimumCost,
    currentGameViewType,
    setCurrentGameViewType,
    setManualBetSwitching,
    isOneTime,
}: GameTemplateProps) => {
    const dispatch = useDispatch();
    const currentBet = betslipState[betslipGameType].find(x => x.current == true);
    const currentOffer = currentBet ? offers.offerings.find(o => o.id === currentBet.priceID) : offers.defaultOffering;
    const currentCompetition =
        currentBet && competitions && competitions.length > 0
            ? competitions.find(c => c.id === currentBet.competitionId)
            : competitions[0];
    const onSelectPlay = () => selectPlay(undefined, undefined, isOneTime ? 'login' : 'registration');
    const getLabelForOffer = (offer?: Offering): string => {
        return `${offer?.description} - £${((offer?.pricePerEntry || 0) / 100).toLocaleStringCash()}`;
    };
    const sidebarRef = useRef<HTMLDivElement>(null);
    const [openDropdownOfferIds, setOpenDropdownOfferIds] = useState<number[]>(() => {
        const offerIds = [offers.defaultOffering.id];
        if (offers.defaultOffering.bonusId) offerIds.push(offers.defaultOffering.bonusId);
        return offerIds;
    });
    const [sidebarMaxHeight, setSidebarMaxHeight] = useState<number>(500);
    useEffect(() => {
        setSidebarMaxHeight(Math.max(sidebarRef?.current?.scrollHeight || 0, 500));
    }, [openDropdownOfferIds, betslipState, sidebarRef.current?.clientHeight]);

    useEffect(() => {
        if (currentOffer) {
            const offerIds = [currentOffer.id];
            if (currentOffer.bonusId) offerIds.push(currentOffer.bonusId);
            setOpenDropdownOfferIds(offerIds);
        }
    }, [currentOffer]);

    const getOffers = () => {
        return isOneTime
            ? offers.offerings
                  .map(o => {
                      return {
                          label: getLabelForOffer(o),
                          value: o.id,
                          isSelected: currentBet?.priceID === o.id,
                      };
                  })
                  .sort((a, b) => a.value - b.value)
            : [{ label: getLabelForOffer(offers.offerings[0]), value: offers.offerings[0].id, isSelected: true }];
    };

    return (
        <>
            <StyledMain>
                <DesktopStickyHeaderContainer height={headerHeight}>
                    <CouponTopButtons
                        showCompetitionSelectorButton={isOneTime}
                        showLuckyDipButton={true}
                        showOffersButton={isOneTime}
                        showViewToggleButton={true}
                        showGameInformationButton={true}
                        onClickLuckyDipButton={() => selectLuckyDip(false, false)}
                        onClickOfferDropdown={(id: number | string) => {
                            if (typeof id !== 'number') {
                                return;
                            }
                            selectAmount(
                                currentBet?.competitionId as number,
                                offers.offerings.find(o => o.id === id) as Offering,
                            );
                            setCurrentOfferingId(id as number);
                        }}
                        onClickViewToggleButton={() => {
                            setCurrentGameViewType(currentGameViewType === 'match' ? 'numbers' : 'match');
                        }}
                        onClickCompetitionDropdown={(id: number | string) => {
                            if (
                                typeof id === 'number' &&
                                currentBet &&
                                (currentBet.pick === currentBet.numbers?.length || currentBet?.numbers?.length === 0)
                            ) {
                                changeCompetition(id, competitions.find(c => c.id === id)?.description || '');
                            } else {
                                console.debug('line must be complete or empty before changing competitions');
                            }
                        }}
                        onClickGameInformationButton={() => dispatch(openPopup('gameInfo'))}
                        offersDropdownItems={getOffers()}
                        offerButtonText={getLabelForOffer(currentOffer)}
                        competitionsDropdownItems={competitions.map(c => {
                            return {
                                label: c.description,
                                value: c.id,
                                isSelected: currentBet?.competitionId === c.id,
                            };
                        })}
                        competitionButtonText={currentCompetition?.description as string}
                        gameViewType={currentGameViewType}
                    />
                </DesktopStickyHeaderContainer>
                <MobileHeaderContainer>
                    {isOneTime && (
                        <BuilderComponent
                            model="game-banner"
                            key={game}
                            options={{ query: { data: { footballPools: true } } }}
                        />
                    )}
                    <CouponTopButtons
                        showCompetitionSelectorButton={isOneTime}
                        showLuckyDipButton={true}
                        showOffersButton={isOneTime}
                        showViewToggleButton={true}
                        showGameInformationButton={true}
                        onClickLuckyDipButton={() => selectLuckyDip(false, false)}
                        onClickOfferDropdown={(id: number | string) => {
                            if (typeof id !== 'number') {
                                return;
                            }
                            selectAmount(
                                currentBet?.competitionId as number,
                                offers.offerings.find(o => o.id === id) as Offering,
                            );
                            setCurrentOfferingId(id as number);
                        }}
                        onClickViewToggleButton={() => {
                            setCurrentGameViewType(currentGameViewType === 'match' ? 'numbers' : 'match');
                        }}
                        onClickCompetitionDropdown={(id: number | string) => {
                            if (
                                typeof id === 'number' &&
                                currentBet &&
                                (currentBet.pick === currentBet.numbers?.length || currentBet?.numbers?.length === 0)
                            ) {
                                changeCompetition(id, competitions.find(c => c.id === id)?.description || '');
                            } else {
                                console.debug('line must be complete or empty before changing competitions');
                            }
                        }}
                        onClickGameInformationButton={() => dispatch(openPopup('gameInfo'))}
                        offersDropdownItems={getOffers()}
                        offerButtonText={getLabelForOffer(currentOffer)}
                        competitionsDropdownItems={competitions.map(c => {
                            return {
                                label: c.description,
                                value: c.id,
                                isSelected: currentBet?.competitionId === c.id,
                            };
                        })}
                        competitionButtonText={currentCompetition?.description as string}
                        gameViewType={currentGameViewType}
                    />
                </MobileHeaderContainer>
                <CompetitionInfo>
                    {`Game closes:`}{' '}
                    <DateTimeFormatter
                        format={'dddd D MMMM YYYY HH:mm'}
                        input={
                            competitions.find(x => x.id == currentBet?.competitionId)?.datumDateWithBuffer ||
                            competitions[0].datumDateWithBuffer
                        }
                    />
                </CompetitionInfo>

                <CouponGameBoard
                    competition={competitions.find(c => c.id === currentBet?.competitionId)}
                    bets={betslipState[toBetSlipKey(game)]}
                    game={game}
                    gameViewType={currentGameViewType}
                    gameInfoText={gameDescription}
                    maximumNumberOfLines={maximumLines || 10}
                    offers={offers}
                    canEdit={!showWagers || canEditLine}
                    onClickSelection={selectPrediction}
                    onClickChangeCurrentBet={(index: number) => {
                        const betIsComplete =
                            currentBet &&
                            currentBet.pick === currentBet.numbers?.length &&
                            (!currentBet.bonusPick ||
                                currentBet.bonusNumbers.length <= 0 ||
                                currentBet.bonusPick === currentBet.bonusNumbers.length);
                        const betIsEmpty = !currentBet || (currentBet.numbers && currentBet.numbers?.length <= 0);

                        // Determine whether we can change bet.

                        if (!betIsComplete && !betIsEmpty) {
                            console.debug('user cannot change bet, bet incomplete');
                            return;
                        }

                        // Determine whether to add a new line, or change to existing line.

                        const currentIndex = betslipState[betslipGameType].findIndex(x => x.current == true);
                        const addedLines = betslipState[betslipGameType].filter(b => b.pick == b.numbers?.length);

                        if (betIsEmpty && index >= currentIndex) {
                            console.debug('user cannot add empty line, bet incomplete');
                            return;
                        }

                        if (index > currentIndex && index >= addedLines.length) {
                            // Add a new line:
                            console.debug('adding new line', index);
                            if (setManualBetSwitching) setManualBetSwitching(false);
                            addLine();
                        } else {
                            // Change to existing line:
                            console.debug('changing to existing line', index);
                            changeCurrentBet(index);
                            if (setManualBetSwitching) setManualBetSwitching(true);
                        }
                    }}
                />
                <MobileStickyContainer>
                    <CouponBottomButtons
                        ClearLine={clearLine}
                        AddLine={addLine}
                        SelectAmountAction={selectAmount}
                        betslipselection={betslipState[toBetSlipKey(game)]}
                        offers={offers}
                        setCurrentOfferingId={setCurrentOfferingId}
                        currentOfferingId={currentOfferingId as number}
                        setShowMore={setShowMore}
                        showMoreValue={showMore}
                        addedLines={betslipState[toBetSlipKey(game)].filter(b => b.pick == b.numbers?.length)}
                        pressPlay={onSelectPlay}
                        maximumLines={maximumLines}
                        isHda={showHda}
                        isOneTime={isOneTime}
                        minimumCost={minimumCost}
                        showLuckyDipButton={true}
                        showOffersButton={true}
                        showViewToggleButton={true}
                        showViewLinesButton={true}
                        onClickLuckyDipButton={() => selectLuckyDip(false, false)}
                        onClickOfferDropdown={(id: number | string) => {
                            if (typeof id !== 'number') {
                                return;
                            }
                            selectAmount(
                                currentBet?.competitionId as number,
                                offers.offerings.find(o => o.id === id) as Offering,
                            );
                            setCurrentOfferingId(currentBet?.priceID as number);
                        }}
                        onClickViewToggleButton={() => {
                            setCurrentGameViewType(currentGameViewType === 'match' ? 'numbers' : 'match');
                        }}
                        onClickViewLinesButton={() => {
                            dispatch(openPopup('added_lines'));
                        }}
                        offersDropdownItems={getOffers()}
                        offerButtonText={getLabelForOffer(currentOffer)}
                        competitionsDropdownItems={competitions.map(c => {
                            return {
                                label: c.description,
                                value: c.id,
                                isSelected: currentBet?.competitionId === c.id,
                            };
                        })}
                        competitionButtonText={currentCompetition?.description as string}
                        gameViewType={currentGameViewType}
                        game={game}
                    />
                </MobileStickyContainer>
            </StyledMain>
            <Sidebar background="none" height={headerHeight} maxHeight={`${sidebarMaxHeight}px`}>
                <CouponBetslip
                    bets={betslipState[betslipGameType]}
                    offersToList={
                        isOneTime
                            ? offers.offerings.filter(o => o.saleable).sort((a, b) => a.id - b.id)
                            : [offers.offerings[0]]
                    }
                    offers={offers}
                    competitions={competitions}
                    game={game}
                    isOneTime={isOneTime}
                    onClickChangeBet={changeCurrentBet}
                    onClickClearLine={clearLine}
                    onClickGameInformation={() => dispatch(openPopup('gameInfo'))}
                    onClickPlay={onSelectPlay}
                    onClickSelection={selectPrediction}
                    isHda={showHda}
                    minimumCost={minimumCost}
                    maximumLines={maximumLines}
                    showGameInformationButton={true}
                    ref={sidebarRef}
                    setOpenDropdownOfferIds={setOpenDropdownOfferIds}
                    openDropdownOfferIds={openDropdownOfferIds}
                    setManualBetSwitching={setManualBetSwitching}
                />
            </Sidebar>
        </>
    );
};

export const useGameCouponTemplate = (): GameTemplate => {
    const renderBannerPanel = (
        game?: GameType,
        banner?: BuilderGamePageBanner,
        paymentTypes?: ('subscription' | 'one-time-payment')[],
        isMobileOrTablet?: boolean,
        headerHeight?: number,
        nextGameDate?: string,
        poolSize?: string,
        gameVariant?: string,
    ): JSX.Element => {
        return !isMobileOrTablet || !paymentTypes || !paymentTypes.includes('one-time-payment') ? (
            <BuilderComponent model="game-banner" key={game} options={{ query: { data: { footballPools: true } } }} />
        ) : (
            <></>
        );
    };

    return {
        renderBannerPanel,
    };
};

const MobileStickyContainer = styled.div`
    z-index: 9;
    display: flex;
    position: fixed;
    color: #fff;
    background: transparent;
    height: auto;
    bottom: 0;
    left: 0;
    right: 0;
    justify-content: space-around;
    align-items: center;
    flex-wrap: wrap;

    ${breakpoints.above('lg')} {
        display: none;
    }
`;

const CompetitionInfo = styled.h4`
    font-size: 16px;
    font-weight: bold;
    text-align: center;
    width: 100%;
    margin: 5px 0 0 0;
`;

const DesktopStickyHeaderContainer = styled.div<{ height?: number }>`
    background: #fff;
    top: ${props => (props.height && props.height > 0 ? `${props.height}px` : undefined)};
    position: ${props => (props.height && props.height > 0 ? 'sticky' : 'relative')};
    ${breakpoints.below('lg')} {
        display: none;
    }
    z-index: 5;
    padding: ${props => (props.height && props.height > 0 ? '5px 0' : undefined)};
`;

const Sidebar = styled.div<{ background?: string; maxHeight?: string; maxWidth?: string; height?: number }>`
    max-width: ${props => (props.maxWidth ? props.maxWidth : '335px')};
    overflow-y: auto;
    background: ${(props): string => (props.background ? props.background : '#fff')};
    flex: 1;
    ${breakpoints.below('lg')} {
        display: none;
    }
    top: ${props => (props.height && props.height > 0 ? `${props.height}px` : undefined)};
    position: ${props => (props.height && props.height > 0 ? 'sticky' : 'relative')};
    max-height: ${props => props.maxHeight};
    margin-bottom: 10px;
    ::-webkit-scrollbar {
        display: none;
    }
    ::-webkit-scrollbar-thumb {
        display: none;
    }
    scrollbar-width: none;
`;
