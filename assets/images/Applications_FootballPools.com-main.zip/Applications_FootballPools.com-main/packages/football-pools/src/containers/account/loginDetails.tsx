import { NextPage } from 'next';
import styled from 'styled-components';

import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import { ChangePasswordForm } from './changePasswordForm';
import { ChangeEmailForm } from './changeEmailForm';
import { useSelector } from 'react-redux';
import { getUpgradeStatusSelector } from '@fp/shared/src/features/authentication/authenticationSelectors';
import getConfig from 'next/config';

const { publicRuntimeConfig } = getConfig();

const LoginDetailsForm = styled.div`
    display: flex;
    ${breakpoints.below('md')} {
        flex-direction: column;
        max-width: 530px;
        margin: 0 auto;
    }
`;

const FormContainer = styled.div`
    display: flex;
    flex-direction: column;
    width: 30%;
    ${breakpoints.below('lg')} {
        width: 100%;
    }
`;

export const FormButton = styled.button`
    height: 3em;
    margin-top: auto;
    margin-bottom: 10px;
    background: #112093;
    color: #fff;
    font-size: inherit;
    border: none;
    border-radius: 2px;
    cursor: pointer;
    font-weight: 700;
    width: 100%;

    &:disabled {
        background: grey;
    }
`;

const Divider = styled.div`
    display: flex;
    flex-direction: column;
    width: 5px;
    border-left: 2px solid #707070;
    height: 441px;
    margin: 0 50px 0 55px;
    ${breakpoints.below('md')} {
        display: none;
    }
`;
const Section = styled.div`
    min-height: 200px;
`;
const UpgradedPlayerRedirect = (): JSX.Element => (
    <Section>
        Since you have upgraded your account, to change your login details please visit{' '}
        <a href={`${publicRuntimeConfig.THE_POOLS_URL}/change-password/`}>The Pools</a>.
    </Section>
);

const Page: NextPage = (): JSX.Element => {
    const upgradeStatus = useSelector(getUpgradeStatusSelector);
    const fullyUpgraded = upgradeStatus?.statusId === 5;

    if (fullyUpgraded) {
        return (
            <LoginDetailsForm>
                <UpgradedPlayerRedirect />
            </LoginDetailsForm>
        );
    }

    return (
        <div>
            <LoginDetailsForm>
                <FormContainer>
                    <ChangeEmailForm />
                </FormContainer>
                <Divider />
                <FormContainer>
                    <ChangePasswordForm />
                </FormContainer>
            </LoginDetailsForm>
        </div>
    );
};

export default Page;
