import '@fp/shared/src/testing/utils/mockBuilder';
import 'jest-styled-components';
import { ResultsPage, ResultsProps } from './results';
import { ThemeProvider } from 'styled-components';
import { RootState } from '@fp/shared/src/rootReducer';
import { renderWithRedux } from '@fp/shared/src/testing/utils/renderWithRedux';
import { theme } from '@fp/shared/src/settings/theme';
import {
    mockCompResults,
    mockDividends,
    mockLuckyCloverCompResults,
} from '@fp/shared/src/containers/results/MockResultsData';

const renderComponent = ({
    competitionResults,
    competitionDividends,
    activeGame,
    gameTitle,
    isClover,
    isHda,
    nextGameDate,
}: ResultsProps) => {
    const utils = renderWithRedux(
        <ThemeProvider theme={theme}>
            <ResultsPage
                competitionResults={competitionResults}
                competitionDividends={competitionDividends}
                activeGame={activeGame}
                gameTitle={gameTitle}
                isClover={isClover}
                isHda={isHda}
                nextGameDate={nextGameDate}
            />
            ,
        </ThemeProvider>,
        {} as RootState,
    );

    return { ...utils };
};

describe('Results', () => {
    it('should render Classic Pools results page without throwing an error and match snapshot', async () => {
        const props: ResultsProps = {
            competitionResults: mockCompResults,
            competitionDividends: mockDividends,
            activeGame: 'classic-pools',
            gameTitle: 'Classic Pools',
            isClover: false,
            isHda: false,
            nextGameDate: '',
        };
        const { container } = renderComponent(props);
        // expect(container).toMatchSnapshot();
        expect(container).toBeVisible();
    });
    it('should render Goal Rush results page without throwing an error and match snapshot', async () => {
        const props: ResultsProps = {
            competitionResults: mockCompResults,
            competitionDividends: mockDividends,
            activeGame: 'goal-rush',
            gameTitle: 'Goal Rush',
            isClover: false,
            isHda: false,
            nextGameDate: '',
        };
        const { container } = renderComponent(props);
        // expect(container).toMatchSnapshot();
        expect(container).toBeVisible();
    });

    it('should render Lucky Clover results page without throwing an error and match snapshot', async () => {
        const props: ResultsProps = {
            competitionResults: mockLuckyCloverCompResults,
            competitionDividends: [],
            activeGame: 'lucky-clover',
            gameTitle: 'Lucky Clover',
            isClover: true,
            isHda: false,
            nextGameDate: '',
        };
        const { container } = renderComponent(props);
        // expect(container).toMatchSnapshot();
        expect(container).toBeVisible();
    });
    it('should render Premier 6 results page without throwing an error and match snapshot', async () => {
        const props: ResultsProps = {
            competitionResults: mockCompResults,
            competitionDividends: mockDividends,
            activeGame: 'premier-6',
            gameTitle: 'Premier 6',
            isClover: false,
            isHda: true,
            nextGameDate: '',
        };
        const { container } = renderComponent(props);
        // expect(container).toMatchSnapshot();
        expect(container).toBeVisible();
    });
    it('should render Premier 6 results page without throwing an error and match snapshot', async () => {
        const props: ResultsProps = {
            competitionResults: mockCompResults,
            competitionDividends: mockDividends,
            activeGame: 'premier-10',
            gameTitle: 'Premier 10',
            isClover: false,
            isHda: true,
            nextGameDate: '',
        };
        const { container } = renderComponent(props);
        // expect(container).toMatchSnapshot();
        expect(container).toBeVisible();
    });
    it('should render Premier 12 results page without throwing an error and match snapshot', async () => {
        const props: ResultsProps = {
            competitionResults: mockCompResults,
            competitionDividends: mockDividends,
            activeGame: 'jackpot-12',
            gameTitle: 'Premier 12',
            isClover: false,
            isHda: true,
            nextGameDate: '',
        };
        const { container } = renderComponent(props);
        // expect(container).toMatchSnapshot();
        expect(container).toBeVisible();
    });
});
