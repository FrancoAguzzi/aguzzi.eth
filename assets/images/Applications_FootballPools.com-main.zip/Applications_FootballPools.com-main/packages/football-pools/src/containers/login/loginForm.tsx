/* eslint-disable @typescript-eslint/camelcase */
import { FunctionComponent, useState, useEffect } from 'react';
import { useForm, ErrorMessage } from 'react-hook-form';
import styled, { css } from 'styled-components';
import { useRouter } from 'next/router';
import { theme } from '@fp/shared/src/settings/theme';
import { PasswordRevealInput, StyledInput } from '@fp/shared/src/components/Forms/Inputs/index';
import { CustomLink } from '@fp/shared/src/components/CustomLink/CustomLink';
import { testId, closePopup, openPopup } from '@sportech/pools-components';
import { ContactInfo } from '@containers/registration/registrationForm';
import { Logo } from '@fp/shared/src/components/Header/Header';
import { useDispatch } from 'react-redux';
import getConfig from 'next/config';
import { FailedLoginRegPopup } from '@fp/shared/src/components/Popup/FailedLoginRegPopup';
import LoginiFrame from '@containers/login/loginiFrame';

const { publicRuntimeConfig } = getConfig();

const subsUrl = `${publicRuntimeConfig.SITE_URL}`;
const redirectUrl = `/Account/ForgotPassword?returnUrl=${subsUrl}/?loginPopup=true&isSiteRedirect=true&clientUrl=${subsUrl}&clientLogo=/img/footballpoolslogo.png`;
const ssoUrl = (path: string): string => publicRuntimeConfig.SSO_URL + path;

type FormData = {
    email: string;
    password: string;
};

const Form = styled.form`
    display: flex;
    flex-direction: column;
    align-items: center;
    max-width: 400px;
    margin: 0 auto;
    padding-top: 20px;

    > * {
        margin-bottom: 20px;
    }

    > :first-child {
        position: absolute;
        left: 0;
        top: 20px;
    }
`;

const FormButton = styled.button`
    border: none;
    border-radius: 24px;
    cursor: pointer;
    display: inline-block;
    font-size: inherit;
    height: 3em;
    margin: 30px 0 0 0;
    outline: none;
    width: 100%;

    &:disabled {
        background: ${theme.colours.buttonDisabled};
    }
`;

const LoginButton = styled(FormButton)`
    background: #7cda24;
    color: #fff;
    font-size: 20px;
    font-weight: bold;
    font-style: italic;
    max-width: 140px;
    border-radius: 25px;
    height: 45px;
    margin: 0 0 20px;
`;

const ForgottenPasswordLink = styled(CustomLink)`
    color: #fff;
    font-size: 14px;
`;

enum InputState {
    Default,
    Active,
    Error,
    Valid,
}

type InputProps = {
    state: InputState;
};

const getColourFromState = function (state: InputState): string {
    const defaultBorderColour = '#ccc';
    switch (state) {
        case InputState.Active:
            return theme.colours.inputActive;
        case InputState.Error:
            return theme.colours.inputError;
        case InputState.Valid:
            return theme.colours.inputValid;
        default:
            return defaultBorderColour;
    }
};

const InputMixin = css<{ state: InputState }>`
    border-color: ${props => `
        ${getColourFromState(InputState.Default)} 
        ${getColourFromState(InputState.Default)} 
        ${getColourFromState(props.state)} 
        ${getColourFromState(InputState.Default)}`};
    border-radius: 0px;
    border-style: solid;
    border-width: ${props => `1px 1px ${props.state !== InputState.Default ? '2px' : '1px'} 1px`};
    box-shadow: inset 0 1px 3px #ddd;
    outline: none;
    padding: 12px 20px;
    :focus {
        border-bottom: 2px solid
            ${props => getColourFromState(props.state == InputState.Error ? InputState.Error : InputState.Active)};
    }
`;

const EmailInput = styled(StyledInput)<InputProps>`
    ${InputMixin};
    height: 40px;
    padding: 0;
    margin: 6px 0 0;
`;

const LoginPasswordRevealInput = styled(PasswordRevealInput)<InputProps>`
    span {
        margin: 0;
    }
    img {
        top: 50%;
        cursor: pointer;
    }
    input {
        ${InputMixin};
        height: 40px;
        padding: 0;
        margin: 6px 0 0;
    }
`;

const PasswordResetText = styled.p`
    margin: 0;
    color: #fff;
    font-weight: 700;
`;

const CreateAccountText = styled.p`
    margin: 5px 0 0 0;
    color: #fff;
    font-weight: 600;
`;

const ContactUsText = styled.p`
    margin-top: 0;
    color: #fff;
    font-size: 14px;
    font-weight: 700;
`;

const Link = styled(CustomLink)`
    text-decoration: underline;
`;

const Error = styled.span`
    color: #ff0000;
    font-size: 12px;
    display: block;
    margin-top: -0.5rem;
    margin-bottom: 0.5rem;
`;

const GeneralError = styled(Error)`
    margin-top: 0.5rem;
    text-align: center;
`;

type Props = {
    loginHandler(data: FormData): Promise<boolean | string>;
};

const ErrorLookup: Record<string, string> = {
    invalid_credentials:
        'Sorry, we are unable to log you in.  Please check that both your email and password are correct.  Multiple login failures may result in your account being blocked.',
    invalid_credentials_last_attempt: 'One more failed login attempt will result in your account being locked',
    account_locked:
        'Sorry your Account has now been locked. We have sent you an email to allow you to reset your password. If you have any questions, please contact our Customer Services.',
    account_duplicate: `Sorry we believe you have multiple accounts. If this is not the case, please contact our customer services team. If you do have an alternative account, you should still be able to login using those details.`,
    defaultError: 'Something went wrong!',
};

export const LoginForm = ({ loginHandler }: Props) => {
    const { register, handleSubmit, errors, setError, clearError, formState, getValues, reset } = useForm<FormData>({
        mode: 'onChange',
    });

    const router = useRouter();
    const [apiErrorText, setApiErrorText] = useState<string | undefined>(undefined);
    const [passwordReset] = useState<number>(
        router.query.forgottenPassword === 'true' ? 1 : router.query.fpForgottenPassword === 'true' ? 2 : 0,
    );
    const passwordResetMsg =
        passwordReset == 1
            ? 'A new password has been sent to your registered email address. Please remember to check your Spam/Junk folder.'
            : passwordReset == 2
            ? 'A link to change your password has been sent to your registered email address. Please remember to check your Spam/Junk folder.'
            : '';

    const onSubmit = handleSubmit(async data => {
        const result = await loginHandler(data);

        if (typeof result === 'string') {
            const error = result as string;
            let msg = ErrorLookup[error];
            if (!msg || msg.length <= 0) {
                msg = ErrorLookup['defaultError'];
            }
            if (error === 'invalid_credentials') {
                clearError(['email', 'password']);
                setError('general', error, msg);
            } else if (error === 'account_locked') {
                setError(
                    'general',
                    error,
                    `Sorry your Account has now been locked. We have sent you an email to allow you to reset your password. If you have any questions, please contact our Customer Services.`,
                );
            } else if (error.includes('email')) {
                setError('email', error, msg);
            } else if (error.includes('password')) {
                setError('password', error, msg);
            } else {
                setError('general', 'general', msg);
            }
            if (error === 'account_locked' || error === 'account_duplicate') {
                setApiErrorText(msg);
                dispatch(openPopup('loginFailed'));
            }
            return;
        }

        reset();
    });

    const values = getValues();
    const dispatch = useDispatch();

    const onClickClosePopup = () => {
        dispatch(closePopup('login'));
    };

    const onFailedLoginPopupOk = async (): Promise<void> => {
        dispatch(closePopup('loginFailed'));
        dispatch(closePopup('login'));
        router.push('/contact-us');
    };

    return (
        <>
            <Form onSubmit={onSubmit} onChange={() => clearError('general')}>
                <Logo />
                <LoginiFrame />
                <ForgottenPasswordLink href={ssoUrl(redirectUrl)}>Forgotten Password?</ForgottenPasswordLink>
                {passwordReset > 0 && <PasswordResetText>{passwordResetMsg}</PasswordResetText>}
                <CreateAccountText>
                    Don&lsquo;t have an account?{' '}
                    <Link href="/registration" onClick={onClickClosePopup}>
                        Sign up
                    </Link>
                </CreateAccountText>
                <ContactInfo />
                <ContactUsText>
                    <Link href="/contact-us" onClick={onClickClosePopup}>
                        Contact Us
                    </Link>
                </ContactUsText>
            </Form>
            <FailedLoginRegPopup
                popupName="loginFailed"
                popupTitle="Login Failed!"
                onOkClick={onFailedLoginPopupOk}
                onPopupClose={() => dispatch(closePopup('loginFailed'))}
                apiError={
                    apiErrorText ||
                    'Sorry your login has been unsuccessful, please contact our customer services team for more information.'
                }
            />
        </>
    );
};

export default LoginForm;
