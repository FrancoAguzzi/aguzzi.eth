/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable import/named */
// eslint-disable-next-line import/default
import React, { useEffect, useContext, useState, useRef } from 'react';
import { NextPage } from 'next';
import { useSelector, useDispatch } from 'react-redux';
import styled, { DefaultTheme, ThemeContext, ThemeProvider } from 'styled-components';
import { useMediaQuery } from 'react-responsive';

import { openPopup } from '@fp/shared/src/features/popups/popupsSlice';
import { theme } from '@fp/shared/src/settings/theme';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import { Loader } from '@fp/shared/src/components/Loader/Loader';
import { SubscriptionConfirmationPopup } from '@fp/shared/src/components/Popup/SubscriptionConfirmationPopup';
import { BasicPopup } from '@fp/shared/src/components/Popup/BasicPopup';
import { Logo } from '@fp/shared/src/components/Header/Header';
import IconCrossWhite from 'public/svg/icon-cross-white.svg';

import {
    Popup,
    GameInfo,
    convertWagerToBetSlipSelection,
    ConvertStringToArray,
    PopupsContainer,
    convertNumbersSelectedToArray,
    closePopup,
    getGameCategory,
    isNumbers,
    getCompetitionFromId,
    isCurrentViewLines,
    ViewLinesCurrent,
    GameViewType,
    isPlayEnabled,
    getTotalPrice,
} from '@sportech/pools-components';
import {
    useApi,
    Competition,
    Offerings,
    Offering,
    UpdateAmount,
    UpdateClassicPoolsWithNumber,
    LuckyDip,
    ClearLine,
    AddLine,
    ChangeCurrentBet,
    AddNewLine,
    BetSlipSlice,
    BetSlip,
    GameType,
    getBetSlipSelector,
    getWagersSelector,
    Wagers,
    Wager,
    toGameType,
    initialiseWagers,
    resetWagers,
    toBetSlipKey,
    ResetBetSlipSelections,
    setGameViewPreference,
    CreateFirstSlipAndClearOld,
    CompetitionWagers,
    NumbersSelected,
    updateBetslipWithNumber,
    luckyDip,
    PoolsApiError,
} from '@sportech/pools-api';

import { RootState } from '@fp/shared/src/rootReducer';
import { AuthenticationState } from '@fp/shared/src/features/authentication/authenticationSlice';
import withGameLayout from '@fp/shared/src/components/Layouts/GameLayout/GameLayout';
import { useRouter } from 'next/router';
import { thunkShowToast } from '@fp/shared/src/features/notifications/notificationsSlice';
import { EditWagerErrorPopup } from '@fp/shared/src/components/Popup/EditWagerErrorPopup';
import { setRedirectUrl } from '@fp/shared/src/features/registration/registrationSlice';
import { getGameTitle, dictionaryHasValue, isHdaGame } from '@fp/shared/src/lib/utils';
import { useEcommerceTags } from '@fp/shared/src/core/ecommerceTags';
import { CompetitionClosedHandler } from '@fp/shared/src/components/Lottery/CompetitionClosedHandler';
import getConfig from 'next/config';
import { BuilderGamePageBanner, ContentItem } from '@fp/shared/src/core/gamePage.builder';
import { LuckyCloverBonusUpsell } from '@fp/shared/src/components/Popup/LuckyCloverBonusUpsell';
import { MinigameTemplate } from './minigame';
import { GameTemplateComponent } from './game.template';
import { HeadComponent } from '@fp/shared/src/settings/HeadComponent';
import { Payment } from './payment';
import { BuilderPaymentPageData, getPaymentPage } from '@fp/shared/src/core/paymentPage.builder';
import { TabbedContent } from '@fp/shared/src/components/Popup/TabbedContent';
import { GameCouponTemplateComponent } from './coupon.template';
import { getCookieFromDocument } from '@services/cookies';
import Button from '@fp/shared/src/components/Button/Button';
import IconCheckMark from 'public/svg/check-mark.svg';
import Link from 'next/link';

const { publicRuntimeConfig } = getConfig();

const editLCSelections = publicRuntimeConfig.EDIT_LC_SELECTIONS == 'true';

export const arrayEquals = (a1: Array<unknown>, a2: Array<unknown>): boolean => {
    return (
        Array.isArray(a1) &&
        Array.isArray(a2) &&
        a1.length === a2.length &&
        a1.every((val, index) => {
            const v1 = parseInt(val as string);
            const v2 = parseInt(a2[index] as string);
            return v1 == v2;
        })
    );
    // TODO: support hda.
};

const CurrentInfo = styled(GameInfo)<{ maxWidth?: string }>`
    color: ${props => props.theme.colours.primaryFont};
    width: 100%;
    justify-self: center;
    font-size: 0.875rem;
    padding: 0 10px;
    display: flex;
    flex-direction: column !important;
    max-width: ${props => props.maxWidth};

    ${breakpoints.below('lg')} {
        font-size: 0.75rem;
    }
`;

const InfoDescription = styled.span`
    font-weight: bold;
`;

export const MobileHeaderContainer = styled.div<{ headerHeight?: number }>`
    display: none;
    flex-direction: column;
    position: fixed;
    color: #fff;
    background: #fff;
    height: auto;
    bottom: 0;
    left: 0;
    right: 0;
    justify-content: space-around;
    align-items: center;
    flex-wrap: wrap;
    ${breakpoints.below('lg')} {
        display: flex;
    }
    top: ${(props): string => (props.headerHeight && props.headerHeight > 0 ? props.headerHeight + 'px' : '0')};
    position: ${(props): string => (props.headerHeight && props.headerHeight > 0 ? 'sticky' : 'relative')};
    z-index: ${(props): number => (props.headerHeight && props.headerHeight > 0 ? 5 : 0)};
`;

export const StyledBetSlipMobileSelectionsContainer = styled.div`
    display: none;
    flex-direction: row;
    background: #fff;
    width: 100%;
    ${breakpoints.below('lg')} {
        display: flex;
    }
    padding-bottom: 5px;
`;
export const DesktopHeaderContainer = styled.div`
    ${breakpoints.below('lg')} {
        display: none;
    }
`;
const MillionText = styled.p`
    margin-right: 3px !important;
    font-weight: bold;
    ${breakpoints.below('lg')} {
        margin-top: -10px !important;
        line-height: 1.5em;
        font-size: 1.5em;
    }
    ${breakpoints.below('sm')} {
        font-size: 1.4em;
        line-height: 1.4em;
        margin-top: -5px !important;
    }

    ${breakpoints.below('xs')} {
        font-size: 1.2em;
        line-height: 1.2em;
        margin-top: 0px !important;
    }
    ${breakpoints.below('xxs')} {
        font-size: 1.2em;
        line-height: 1.2em;
        margin-top: 3px !important;
    }
`;

const BetslipBonusText = styled.p`
    color: #000;
`;

export const StyledMain = styled.div`
    width: 100%;
    flex: 2;
    background: transparent;
    position: relative;

    ${breakpoints.below('lg')} {
        margin-right: 0px;
    }
`;

const SubTitleText = styled.h4`
    font-size: 1rem;
    color: #000000;
    margin: 10px;
`;

const SpanSubtext = styled.span`
    font-size: 0.9rem;
    color: #000000;
    margin: 8px;
`;

const SectionContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: #fff;
    margin: auto;
    padding: 5px;
    width: 100%;
    ${breakpoints.below('xs')} {
        width: 90%;
    }
    @media (max-width: 385px) {
        width: 95%;
    }
`;

const TooltipContainer = styled.div`
    font-size: 0.75rem;
    margin: 0.5rem 0;
`;
const TooltipHeader = styled.h4`
    margin: 0 0 0.5rem 0;
`;
const TooltipContent = styled.div`
    max-width: 250px;
`;
const PerMonthTooltip = (competitionTypeDescription?: string | undefined): JSX.Element => {
    const headerText = `Monthly ${
        competitionTypeDescription && competitionTypeDescription === 'draw' ? 'Draws' : 'Games'
    }`;
    const bodyText =
        competitionTypeDescription && competitionTypeDescription === 'draw'
            ? `The number of draws in a month can vary, but the maximum you will be charged in a month is shown.`
            : `The number of games in a month can vary, but on average there will be 10 games each month (120 games per
        year).`;
    return (
        <TooltipContainer>
            <TooltipHeader>{headerText}</TooltipHeader>
            <TooltipContent>{bodyText}</TooltipContent>
        </TooltipContainer>
    );
};

const EditSubscriptionText = styled.div`
    font-size: 1.2rem;
    text-align: center;
    margin: 20px 0 20px 0;
`;

const PaymentContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
    padding: 0 5px 5px 5px;
    background: ${props => props.theme.colours.gameMainColour};
`;
const HeaderBanner = styled.div`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    padding: 5px;
    background: ${props => props.theme.colours.primary};

    img {
        height: 20px;
    }
`;
const Icon = styled.img`
    height: 20px;
`;
const Close = styled.div`
    cursor: pointer;
`;
const MissingContentMessageContainer = styled.div`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    background: rgba(244, 244, 244, 0.9);
    border: 1px solid #707070;
    border-radius: 10px;
    width: 80%;
    margin: 20px;
    padding: 50px 10px;
    text-align: center;
    max-width: 950px;
    height: 200px;
`;
const PaymentPopup = styled(Popup)`
    &-content {
        // Chrome, Edge, Opera, Safari:
        ::-webkit-scrollbar {
            height: 5px;
            width: 5px;
            background: ${props => props.theme.colours.scrollTrackBackground};
        }
        ::-webkit-scrollbar-thumb {
            height: 5px;
            border-radius: 4px;
            background-color: ${props => props.theme.colours.scrollBarBackground};
        }

        // Firefox:
        scrollbar-color: ${props =>
            `${props.theme.colours.scrollBarBackground} ${props.theme.colours.scrollTrackBackground}`}; // bar, track
        scrollbar-width: thin;
    }
`;

const isServer = typeof window === 'undefined';

const Game: NextPage<GameProps> = props => {
    const router = useRouter();
    if (router.isFallback) {
        // Page has not been generated by the server.
        // Show loading UI until response generated.
        return <Loader isLoading={true} />;
    }

    const now = new Date();
    const futureComps = props.competitions?.filter(comp => new Date(comp.datumDateWithBuffer) > now);

    useEffect(() => {
        const previewCookie = getCookieFromDocument('_fpPreview');
        if ((!futureComps || futureComps.length <= 0 || !props.offers) && !previewCookie) {
            console.info('missing game data, redirecting to preview');
            router.push(`/api/preview-qa?returnurl=/games/${props.gamePath}/game`);
        }
    }, [props.competitions, props.offers]);

    if (!props.gameEnabled && !isServer) {
        if (typeof window !== 'undefined') {
            window.location.href = `${publicRuntimeConfig.SITE_URL}`;
        }
        return <Loader isLoading={true} />;
    }
    if (!props.competitions || !futureComps || futureComps.length <= 0 || !props.offers) {
        // Missing essential data, show error or loading spinner?
        return (
            <MissingContentMessageContainer>
                Oops, it looks like we don&apos;t have any competitions available at this time
            </MissingContentMessageContainer>
        );
    }

    const dispatch = useDispatch();
    const { getWagersAsync, updateWagerAsync } = useApi('backend');
    const [betslipGameType, setBetslipGameType] = useState<keyof BetSlipSlice>(toBetSlipKey(props.game));
    const [isLoading, setIsLoading] = useState(false);
    const gameCategory = getGameCategory(props.game);
    const isClover = gameCategory === 'clover';
    const themeContext = useContext(ThemeContext);
    const wagersState = useSelector(getWagersSelector);
    const betslipState = useSelector(getBetSlipSelector);
    const userState = useSelector<RootState>(state => state.authentication) as AuthenticationState;
    const { productView, lineSelection, lineCompleted, addToCart, checkout } = useEcommerceTags(
        'football-pools',
        'The Football Pools',
    );
    const [isAutoShowWagers, setIsAutoShowWagers] = useState<boolean>(router.query['view-lines'] === 'true');
    const [numberOfGames, setNumberOfGames] = useState<number | undefined>(() => {
        return props.paymentTypes && props.paymentTypes.includes('one-time-payment') ? 1 : undefined;
    });
    const [showSlideBoard, setShowSlideBoard] = useState<boolean>(false);
    // const TemplateComponent = getTemplateComponent(props.template);
    const [paymentTypeFlow, setPaymentTypeFlow] = useState<'subscription' | 'one-time-payment'>(
        props.paymentTypes && props.paymentTypes.length > 0 ? props.paymentTypes[0] : 'subscription',
    );
    const [paymentPopupData, setPaymentPopupData] = useState<BuilderPaymentPageData | undefined>(undefined);

    const headerRef = useRef<HTMLDivElement>(null);

    const [currentGameViewType, setGameViewState] = useState<GameViewType>(
        wagersState.gameViewPreference || props.gameViewType || 'match',
    );
    const setCurrentGameViewType = (type: GameViewType) => {
        dispatch(setGameViewPreference({ gameViewPreference: type }));
        setGameViewState(type);
    };

    const isOneTime = props.paymentTypes && props.paymentTypes.includes('one-time-payment');

    useEffect(() => {
        if (
            (betslipState[betslipGameType].length > 1 && !props.canAddMultipleLines) ||
            (props.offers &&
                currentSlip?.bonusPriceId !== 0 &&
                props.offers.defaultOffering.bonusId !== currentSlip?.bonusPriceId)
        ) {
            dispatch(ResetBetSlipSelections({ ItemKey: betslipGameType }));
        }
    }, [props.canAddMultipleLines, props.gamePath]);

    useEffect(() => {
        /**
         * Initialise state on page navigations.
         */
        const initialiseGamePage = async () => {
            // console.log('initialising game', props.game, props.gamePath, router.asPath);
            const currentBetslipGameType = toBetSlipKey(props.game);
            productView(betslipState[currentBetslipGameType], props.game, props.gamePath);
            setShowFutureGames(props.showFutureGames || false);
            setPaymentTypeFlow(
                props.paymentTypes && props.paymentTypes.length > 0 ? props.paymentTypes[0] : 'subscription',
            );
            setBetslipGameType(currentBetslipGameType);
            setShowHDA(
                currentBetslipGameType == 'Jackpot12' ||
                    currentBetslipGameType == 'Premier10' ||
                    currentBetslipGameType == 'Premier6',
            );
            setNumberOfGames(props.paymentTypes && props.paymentTypes.includes('one-time-payment') ? 1 : undefined);
            if (!paymentPopupData) {
                const paymentData = await getPaymentPage('paymentpagetest');
                setPaymentPopupData(paymentData);
            }
            setManualBetSwitch(props.template !== 'coupon');
            fetchWagers();
        };
        initialiseGamePage();
    }, [router.asPath]);

    useEffect(() => {
        if (router.query && router.query['payment']) {
            dispatch(openPopup('payment'));
            router.replace(`/games/${props.gamePath}/game`, undefined, { shallow: true });
        }
        if (
            (router.query && router.query['competitionId']) ||
            (props.featuredCompetitionId && props.featuredCompetitionId > 0)
        ) {
            const competitionId =
                router.query && router.query['competitionId']
                    ? parseInt(router.query['competitionId'] as string)
                    : props.featuredCompetitionId;
            if (competitionId && competitionId > 0) {
                const competitionToSelect = props.competitions?.find(c => c.id === competitionId);
                const closeDate = new Date(competitionToSelect ? competitionToSelect.datumDateWithBuffer : '');
                if (competitionToSelect && closeDate > new Date()) {
                    ChangeComp(competitionToSelect.id, competitionToSelect.description);
                }
            }
        }
    }, [router.query, props.featuredCompetitionId]);

    const isLineComplete = isPlayEnabled(betslipState[betslipGameType], props.offers);
    useEffect(() => {
        if (isLineComplete) {
            lineCompleted(props.game, props.gamePath);
        }
    }, [isLineComplete]);

    useEffect(() => {
        // Initialise betslip state:
        const currentSlip = betslipState[betslipGameType].find(x => x.current == true);
        const newBetslipGameType = toBetSlipKey(props.game);

        const clearSlip =
            !currentSlip ||
            betslipGameType !== newBetslipGameType ||
            futureComps?.find(c => c.id === currentSlip?.competitionId) === undefined ||
            (props.offers &&
                props.offers.offerings &&
                props.offers.offerings.find(o => o.id === currentSlip.priceID) === undefined);

        if (futureComps && props.offers && clearSlip) {
            // setIsLoading(true);
            dispatch(
                CreateFirstSlipAndClearOld({
                    ItemKey: newBetslipGameType,
                    Competitions: futureComps,
                    Offers: props.offers,
                    clearIfOfferUnavailable: true,
                    clearIfCompetitionUnavailable: true,
                }),
            );
            setBetslipGameType(newBetslipGameType);
        } else if (currentSlip) {
            setIsLoading(false);
        }
    }, [betslipState, props.offers]);

    const [showFutureGames, setShowFutureGames] = useState(props.showFutureGames || false);
    const [showHDA, setShowHDA] = useState(
        betslipGameType == 'Jackpot12' || betslipGameType == 'Premier10' || betslipGameType == 'Premier6',
    );

    const currentSlip = betslipState[betslipGameType].find(x => x.current == true);
    const [showWagers, setShowWagers] = useState(false);
    const [showWagerFixtures, setShowWagerFixtures] = useState(false);
    const [currentOffering, setCurrentOffering] = useState(currentSlip?.priceID);

    const [showMore, setShowMore] = useState(false);
    if (
        showMore == false &&
        props.offers != undefined &&
        props.offers.offerings.slice(0, 3).find(x => x.id == currentSlip?.priceID) == undefined
    ) {
        setShowMore(true);
    }

    const isMobileOrTablet = useMediaQuery({
        query: `(max-width: ${themeContext.breakpoints.lg}px )`,
    });

    if (showWagers && isMobileOrTablet && !props.offers?.gameType?.subscription) {
        setShowWagers(false);
    }

    /**
     * Get existing wagers for a logged in user.
     */
    const [wagers, setWagers] = useState<Wagers>({ competitions: [] });
    const fetchWagers = async (): Promise<void> => {
        const wagersRes = userState.isLoggedIn ? await getWagersAsync(props.game) : undefined;
        if (wagersRes && wagersRes.data) {
            setWagers(wagersRes.data);
        }
    };
    useEffect(() => {
        fetchWagers();
    }, [userState.isLoggedIn]);

    /**
     * Find upcoming wagers and current wager to display on game UI.
     */
    const [viewLinesCurrent, setViewLinesCurrent] = useState<ViewLinesCurrent>({ id: 0, competitionId: undefined });
    const [betslipWager, setBetslipWager] = useState<BetSlip | undefined>(undefined);
    const [canEditLine, setCanEditLine] = useState(false);
    const [betslipWagerHasEdits, setBetslipWagerHasEdits] = useState(false);
    const [editLineAllFutureGames, setEditLineAllFutureGames] = useState(false);
    const [wagersForCompetitions, setWagersForCompetitions] = useState<Wager[]>([]);
    const [viewLineId, setViewLineId] = useState<string | undefined>(
        router.query.lineId ? (router.query.lineId as string) : undefined,
    );

    useEffect(() => setViewLineId(router.query.lineId ? (router.query.lineId as string) : undefined), [
        router.query.lineId,
    ]);

    const getWagersForCompetitions = (): Wager[] => {
        const ret: Wager[] = [];
        if (wagers && wagers.competitions && wagers.competitions.length > 0) {
            const competitionWagers = wagers.competitions
                .filter(wc =>
                    props.competitions?.some(
                        c =>
                            c.id === wc.competitionId ||
                            (c.competitionIds && c.competitionIds[wc.wagers[0].offeringId]) ||
                            (c.competitionIds && dictionaryHasValue(c.competitionIds, wc.wagers[0].competitionId)),
                    ),
                )
                .flatMap(wc => wc.wagers);
            // .sort((a, b) => (b.lineId as number) - (a.lineId as number));
            for (let i = 0; i < competitionWagers.length; i++) {
                const w = competitionWagers[i];
                ret.push({
                    ...w,
                    selections: typeof w.selections === 'string' ? w.selections : [...w.selections],
                });
            }
        }
        return ret;
    };

    /**
     * Update betslip wagers when user wagers response received:
     */
    useEffect(() => {
        if (!betslipWagerHasEdits) {
            setWagersForCompetitions(getWagersForCompetitions());

            if (isAutoShowWagers && wagers && wagers.competitions && wagers.competitions.length) {
                setIsAutoShowWagers(false);
                setShowWagers(true);
            }
        }
        if (viewLineId) {
            const lineId = parseInt(viewLineId);
            const compId = wagers.competitions.reverse().find(c => c.wagers.filter(w => w.lineId == lineId).length > 0)
                ?.competitionId;
            if (compId) {
                setViewLinesCurrent({ id: lineId, competitionId: compId });
                setShowWagers(true);
            }
        }
    }, [wagers]);
    /**
     * Reset edit states when viewLinesCurrent changes:
     */
    useEffect(() => {
        setBetslipWagerHasEdits(false);
        setWagersForCompetitions(getWagersForCompetitions());
        const currentWager = wagersForCompetitions?.find(w =>
            isCurrentViewLines(w, props.competitions, viewLinesCurrent),
        );
        setCanEditLine(
            Boolean(
                (!isClover || editLCSelections) &&
                    currentWager &&
                    currentWager.paymentType &&
                    (currentWager.paymentType.includes('rt_card') ||
                        currentWager.paymentType.includes('direct_debit') ||
                        currentWager.paymentType.includes('paypal')),
            ),
        );
        setBetslipWager(
            currentWager
                ? convertWagerToBetSlipSelection(
                      getCompetitionFromId(currentWager.competitionId, props.competitions) as Competition,
                      props.viewLinesOffers?.offerings.find(o => o.id === currentWager?.offeringId) as Offering,
                      currentWager as Wager,
                      ConvertStringToArray(currentWager.selections, isNumbers(gameCategory)),
                      currentWager.bonusSelections
                          ? ConvertStringToArray(currentWager.bonusSelections, isNumbers(gameCategory))
                          : [],
                  )
                : undefined,
        );
    }, [viewLinesCurrent]);
    /**
     * Update wagersForCompetitions selections when edit made.
     * Update betslipWagerHasEdits when selections differ.
     * Required for UI on betslip
     */
    useEffect(() => {
        if (betslipWager) {
            // Determine if wager selections have been edited:
            const originalWager = wagers.competitions
                .find(
                    wc => wc.wagers.findIndex(w => isCurrentViewLines(w, props.competitions, viewLinesCurrent)) !== -1,
                )
                ?.wagers.find(w => isCurrentViewLines(w, props.competitions, viewLinesCurrent));
            if (originalWager) {
                setBetslipWagerHasEdits(
                    Boolean(
                        (betslipWager.numbers &&
                            !arrayEquals(
                                originalWager.selections as string[],
                                convertNumbersSelectedToArray(betslipWager?.numbers as NumbersSelected[]),
                            )) ||
                            (editLCSelections &&
                                betslipWager.bonusNumbers &&
                                !arrayEquals(
                                    originalWager.bonusSelections as string[],
                                    convertNumbersSelectedToArray(betslipWager?.bonusNumbers as NumbersSelected[]),
                                )),
                    ),
                );
            }
            if (wagersForCompetitions) {
                wagersForCompetitions[
                    wagersForCompetitions.findIndex(w => isCurrentViewLines(w, props.competitions, viewLinesCurrent))
                ].selections = convertNumbersSelectedToArray(betslipWager.numbers as NumbersSelected[], showHDA);
                wagersForCompetitions[
                    wagersForCompetitions.findIndex(w => isCurrentViewLines(w, props.competitions, viewLinesCurrent))
                ].bonusSelections = convertNumbersSelectedToArray(
                    betslipWager.bonusNumbers as NumbersSelected[],
                    showHDA,
                );
                setWagersForCompetitions([...wagersForCompetitions]);
            }
        }
    }, [betslipWager]);

    const [manualBetSwitch, setManualBetSwitch] = useState(props.template !== 'coupon');

    useEffect(() => {
        if (
            props.canAddMultipleLines &&
            betslipState[betslipGameType].length < (props.maximumLines || 10) &&
            !manualBetSwitch &&
            currentSlip &&
            currentSlip.numbers &&
            currentSlip.pick === currentSlip.numbers?.length
        ) {
            let currentOffer = props.offers?.offerings.find(o => o.id === currentSlip?.priceID);
            if (currentOffer?.additionalOffering && betslipState[betslipGameType].length > 0) {
                currentOffer = props.offers?.offerings.find(o => o.id === currentOffer?.bonusId);
            }
            if (
                currentOffer &&
                (!currentOffer.mustIncludeBonus ||
                    (currentOffer.mustIncludeBonus && currentSlip.bonusPick === currentSlip.bonusNumbers.length)) &&
                (!currentSlip.bonusNumbers ||
                    currentSlip.bonusNumbers.length <= 0 ||
                    currentSlip.bonusNumbers.length === currentSlip.bonusPick)
            ) {
                dispatch(
                    AddLine({
                        ItemKey: betslipGameType,
                        Default: currentOffer,
                    }),
                );
            }
        }
    }, [currentSlip?.numbers]);

    /**
     * Reset any existing edits when changing to buy lines view.
     */
    useEffect(() => {
        if (betslipWagerHasEdits) {
            resetBetslipWagerSelections();
        }
        if (!showWagers) {
            setShowWagerFixtures(false);
        }
    }, [showWagers]);

    const resetBetslipWagerSelections = (): void => {
        const originalWager = wagers.competitions
            .find(wc => wc.wagers.findIndex(w => isCurrentViewLines(w, props.competitions, viewLinesCurrent)) !== -1)
            ?.wagers.find(w => isCurrentViewLines(w, props.competitions, viewLinesCurrent));
        if (originalWager && betslipWager) {
            const updatedBetslipWager: BetSlip = {
                ...betslipWager,
                numbers: ConvertStringToArray(originalWager.selections, isNumbers(gameCategory)),
                bonusNumbers: originalWager.bonusSelections
                    ? ConvertStringToArray(originalWager.bonusSelections, isNumbers(gameCategory))
                    : betslipWager.bonusNumbers,
            };
            setBetslipWager(updatedBetslipWager);
        }
    };

    /**
     * Update an existing wager.
     */
    const [editWagerError, setEditWagerError] = useState<PoolsApiError | undefined>(undefined);
    const handleUpdateWager = async (): Promise<void> => {
        if (betslipWager) {
            if (betslipWager.pick != betslipWager.numbers?.length) {
                dispatch(openPopup('error_on_change_betslip_line'));
                return;
            }
            const currentWager = getWagersForCompetitions().find(w =>
                isCurrentViewLines(w, props.competitions, viewLinesCurrent),
            );
            const wager: Wager = {
                lineId: isClover && editLCSelections ? currentWager?.primaryLineId : currentWager?.lineId,
                competitionId: currentWager?.competitionId,
                selections: convertNumbersSelectedToArray(betslipWager.numbers as NumbersSelected[]),
                bonusLineId: isClover && editLCSelections ? currentWager?.lineId : undefined,
                bonusCompetitionId: isClover && editLCSelections ? currentWager?.bonusCompetitionId : undefined,
                bonusSelections:
                    isClover && editLCSelections
                        ? convertNumbersSelectedToArray(betslipWager.bonusNumbers as NumbersSelected[])
                        : undefined,
                offeringId: currentWager?.offeringId as number,
            };
            setIsLoading(true);
            const res = await updateWagerAsync(wager, props.game, editLineAllFutureGames);
            setIsLoading(false);
            if (res && res.data) {
                const message = editLineAllFutureGames
                    ? `Successfully updated line for all future games`
                    : `Successfully updated line`;
                dispatch(thunkShowToast({ message: message }));
            } else if (!res || res.error) {
                // Show popup
                setEditWagerError(res.error);
                dispatch(openPopup('editWagerError'));
                return;
            }

            // Reset edit lines:
            setEditLineAllFutureGames(false);
            setBetslipWagerHasEdits(false);
            await fetchWagers();
        }
    };
    const onCloseEditWagerErrorPopup = (): void => {
        dispatch(closePopup('editWagerError'));
        setEditWagerError(undefined);
    };

    /**
     * Show congratulation message when order confirmed.
     */
    // useEffect(() => {
    //     const handleConfirmed = (): void => {
    //         if (
    //             wagersState.stage === 'confirmed' &&
    //             wagersState.game === props.game &&
    //             (!wagersState.numberOfGames || wagersState.numberOfGames <= 0)
    //         ) {
    //             // Only old-style subscription payment flow should use this:
    //             dispatch(openPopup('paymentConfirmed'));
    //         }
    //     };
    //     handleConfirmed();
    // }, [wagersState.stage]);

    const toggleFuture = (): void => {
        setShowFutureGames(!showFutureGames);
    };

    /**
     * Change current offering.
     * @param id
     * @param amount the offering
     */
    const SelectAmount = (id: number, amount: Offering): void => {
        dispatch(UpdateAmount({ ItemKey: betslipGameType, id: id, Amount: amount }));
    };

    /**
     * Add selection to betslip.
     * @param id
     * @param type
     */
    const SelectMatch = (id: number, type: string): void => {
        if (showWagers && viewLinesCurrent.id > 0 && betslipWager !== undefined) {
            if (canEditLine) {
                const updatedWager = updateBetslipWithNumber(
                    { ...betslipWager },
                    {
                        ItemKey: betslipGameType,
                        id: id,
                        Type: type,
                    },
                );
                setBetslipWager(updatedWager);
            }
        } else {
            lineSelection(props.game, props.gamePath);
            dispatch(
                UpdateClassicPoolsWithNumber({
                    ItemKey: betslipGameType,
                    id: id,
                    Type: type,
                }),
            );
        }
    };

    /**
     * Lucky dip.
     */
    const Lucky = (isBonus?: boolean, noSelectionsMade?: boolean): void => {
        if (showWagers && viewLinesCurrent.id > 0 && canEditLine && betslipWager !== undefined) {
            // Updating existing wager.
            if (isBonus) {
                // No selections made, update standard and bonus selections.
                let updatedWager = luckyDip({ ...betslipWager }, betslipGameType, false);
                updatedWager = luckyDip({ ...updatedWager }, betslipGameType, isBonus);
                setBetslipWager(updatedWager);
            } else {
                const updatedWager = luckyDip({ ...betslipWager }, betslipGameType, false);
                setBetslipWager(updatedWager);
            }
        } else {
            // Updating new wager.
            lineSelection(props.game, props.gamePath);
            const currentOfferMustIncludeBonus = props.offers?.offerings.find(
                o => betslipState[betslipGameType].find(b => b.current)?.priceID === o.id,
            )?.mustIncludeBonus;
            if ((isBonus && noSelectionsMade) || currentOfferMustIncludeBonus) {
                // No selections made, update standard and bonus selections.
                dispatch(LuckyDip({ ItemKey: betslipGameType, isMillion: false }));
                dispatch(LuckyDip({ ItemKey: betslipGameType, isMillion: isBonus }));
            } else {
                dispatch(LuckyDip({ ItemKey: betslipGameType, isMillion: isBonus }));
            }
        }
    };

    /**
     * Clear selections.
     * @param index
     */
    const Clear = (index?: number, isCurrent?: boolean): void => {
        if (numberOfGames) {
            setNumberOfGames(undefined);
        }
        if (showWagers && betslipWager !== undefined) {
            if (!isCurrent) return;
            const updatedWager: BetSlip = {
                ...betslipWager,
                numbers: [],
                bonusNumbers: [],
            };
            setBetslipWager(updatedWager);
        } else {
            if (index !== undefined) {
                dispatch(
                    ClearLine({
                        ItemKey: betslipGameType,
                        id: index,
                        isCurrent: isCurrent,
                    }),
                );
            } else {
                dispatch(ClearLine({ ItemKey: betslipGameType, id: -1, isCurrent: isCurrent }));
            }
        }
    };

    const AddLines = (): void => {
        if (props.offers) {
            let offering = currentOffering
                ? props.offers.offerings.find(o => o.id === currentOffering)
                : props.offers.defaultOffering;
            if (offering?.additionalOffering && betslipState[betslipGameType].length > 0) {
                offering = props.offers.offerings.find(o => o.id === offering?.bonusId);
            }
            dispatch(
                AddLine({
                    ItemKey: betslipGameType,
                    Default: offering ? offering : props.offers.defaultOffering,
                }),
            );
        }
    };

    const ChangeCurrentBets = (index: number): void => {
        dispatch(ChangeCurrentBet({ ItemKey: betslipGameType, id: index }));
    };

    const ChangeComp = (compId: number, compName: string): void => {
        if (props.offers) {
            dispatch(
                AddNewLine({
                    ItemKey: betslipGameType,
                    CompId: compId,
                    CompName: compName,
                    Offer: props.offers.defaultOffering,
                }),
            );
            setCurrentOffering(props.offers.defaultOffering.id);
            setShowMore(false);
        }
    };

    const getAddedLines = (bets: BetSlip[]): BetSlip[] => {
        const ret = bets.filter(
            x =>
                x.pick == x.numbers?.length &&
                (x.bonusPick <= 0 ||
                    x.bonusPick == x.bonusNumbers?.length ||
                    (!props.offers?.offerings.find(o => o.id == x.priceID)?.mustIncludeBonus &&
                        x.bonusNumbers?.length == 0)),
        );
        return ret;
    };

    const AddedLines = getAddedLines(betslipState[betslipGameType]);

    const [createWagersResponse, setCreateWagerResponse] = useState({});

    /**
     * Play now button has been selected.
     * Add betslip for purchase to wagers state
     * and redirect to payment page.
     */
    const onPressPlay = async (ev?: Event, cloverUpsellOverride?: boolean, redirect?: 'registration' | 'login') => {
        if (
            betslipState[betslipGameType]?.filter(x => x.pick != x.numbers?.length && x.numbers?.length != 0).length > 0
        ) {
            dispatch(openPopup('error_on_change_betslip_line'));
            return;
        }

        const bet = betslipState[betslipGameType].find(b => b.current);
        if (
            props.game === 'lucky-clover' &&
            !cloverUpsellOverride &&
            bet &&
            bet.bonusPick > 0 &&
            bet.bonusNumbers &&
            bet.bonusNumbers.length < bet.bonusPick
        ) {
            // This is a clover bet without bonus selections, push upsell:
            dispatch(openPopup('luckyCloverBonusUpsell'));
            return;
        }

        addToCart(betslipState[betslipGameType], props.game, props.gamePath);
        checkout(betslipState[betslipGameType], props.game, props.gamePath);

        dispatch(
            initialiseWagers({
                wagers: betslipState[betslipGameType].filter(b => b.numbers && b.numbers.length === b.pick),
                game: toGameType(betslipGameType),
                purchaseType:
                    props.paymentTypes && props.paymentTypes.includes('one-time-payment')
                        ? 'OneOff'
                        : numberOfGames && numberOfGames > 0
                        ? 'ByGames'
                        : 'Subscription',
                competition: props.competitions
                    ? props.competitions.find(x => x.id === betslipState[betslipGameType][0].competitionId)
                    : undefined,
                gameVariant: props.gamePath,
                numberOfGames: numberOfGames,
            }),
        );

        const paymentUrl =
            props.paymentTypes && props.paymentTypes.includes('one-time-payment')
                ? `/games/${props.gamePath}/game?payment=oneTime`
                : numberOfGames && numberOfGames > 0
                ? '/games/one-time-payment'
                : `/games/payment`;

        if (!userState.isLoggedIn) {
            dispatch(setRedirectUrl(paymentUrl));
            if (redirect && redirect === 'login') {
                dispatch(openPopup('login'));
            } else {
                router.push('/registration');
            }
        } else if (userState.userDetails && userState.userDetails.firstName) {
            setIsLoading(true);
            if (paymentTypeFlow === 'one-time-payment') {
                dispatch(openPopup('payment'));
            } else {
                router.push(paymentUrl);
            }
        } else {
            dispatch(setRedirectUrl(paymentUrl));
            router.push('/registration/details');
        }
    };

    const headerHeight = props.headerHeight ? props.headerHeight : 0;

    const isLuckyDipButtonVisible = (): boolean => {
        let ret = canEditLine || !showWagers;
        if (ret) {
            const currentBet = betslipState[betslipGameType].find(b => b.current);
            const currentOffer = props.offers?.offerings.find(o => o.id === currentBet?.priceID);
            if (currentOffer) {
                ret = !currentOffer.mustIncludeBonus;
            }
        }
        return ret;
    };

    return (
        <>
            <HeadComponent
                title={getGameTitle(props.game)}
                description={props.gameDescription}
                keywords={props.gameKeywords}
            />
            <ThemeProvider theme={props.theme || theme}>
                <PopupsContainer
                    currentSlip={currentSlip as BetSlip}
                    GameType={betslipGameType}
                    betslipselection={betslipState[betslipGameType]}
                    offers={props.offers}
                    showHDA={showHDA}
                    ClearLine={Clear}
                    ChangeCurrentBets={ChangeCurrentBets}
                    addedLines={AddedLines}
                    competitions={props.competitions}
                    viewLinesWager={wagersForCompetitions}
                    pressPlay={onPressPlay}
                    hasCreatedWagersReponse={createWagersResponse != {}}
                    createdWagersResponse={createWagersResponse as CompetitionWagers[]}
                    setViewLinesCurrent={setViewLinesCurrent}
                    viewLinesCurrent={viewLinesCurrent}
                    canEdit={canEditLine}
                    viewLinesBetslip={betslipWager}
                    isClover={isClover}
                    setShowWagers={setShowWagers}
                    setShowWagerFixtures={setShowWagerFixtures}
                    showWagerFixtures={showWagerFixtures}
                    ballColor={props.theme?.colours.ballColour}
                    viewLinesOffers={props.viewLinesOffers || props.offers}
                    showAddedLinesBackButton={props.canAddMultipleLines}
                    showAddedLinesPlayButton={isOneTime || props.template !== 'coupon'}
                    showAddedLinesCost={props.canAddMultipleLines}
                    showAddedLinesCount={false}
                    showAddedLinesCountHeader={showHDA}
                    showAddedLinesPerLineCount={showHDA}
                    minimumCost={props.minimumCost}
                    addedLinesSelectionsFontStyle={showHDA ? 'italic' : 'normal'}
                    setManualBetSwitching={setManualBetSwitch}
                />
                <Popup
                    popupStyles={{
                        width: '350px !important',
                        padding: '0 !important',
                        mobileMargin: '0',
                        rounded: true,
                        overflow: 'scroll',
                        headerStyles: {
                            textAlign: 'center',
                            color: props.theme?.colours.gameMainColour,
                        },
                        backgroundColour: '#000d68',
                        crossStyles: {
                            top: '5px',
                            right: '60px',
                        },
                    }}
                    title={'Confirmation'}
                    withCloseButton={true}
                    popupName={'paymentConfirmed'}
                    closeOnDocumentClick={false}
                    closeOnEscape={false}
                    handleOnCloseClicked={() => {
                        dispatch(ResetBetSlipSelections({ ItemKey: betslipGameType }));
                        dispatch(resetWagers({ game: props.game }));
                        return true;
                    }}
                >
                    <SubscriptionConfirmationPopupContainer>
                        <SubscriptionConfirmationPopup
                            gameTitle={getGameTitle(props.game)}
                            bets={betslipState[betslipGameType]}
                            game={props.game}
                            onClickConfirm={() => {
                                dispatch(closePopup('paymentConfirmed'));
                                dispatch(ResetBetSlipSelections({ ItemKey: betslipGameType }));
                                dispatch(resetWagers({ game: props.game }));
                            }}
                        />
                    </SubscriptionConfirmationPopupContainer>
                </Popup>
                <Popup
                    popupStyles={{
                        width: 'auto',
                        padding: 'auto',
                        mobileMargin: 'auto',
                        mobileWidth: 'auto',
                        rounded: true,
                        overflow: 'scroll',
                        headerStyles: {
                            textAlign: 'center',
                            color: props.theme?.colours.gameMainColour,
                        },
                        crossStyles: {
                            top: '5px',
                            right: '60px',
                        },
                    }}
                    withCloseButton={true}
                    popupName={'spendLimitExceeded'}
                >
                    <SectionContainer style={{ minHeight: '500px', justifyContent: 'flex-start' }}>
                        <SubTitleText>SPEND LIMIT REACHED!</SubTitleText>
                        <IconCheckMark height="50px" />
                        <SpanSubtext>To set your limits please set them in your account.</SpanSubtext>
                        <Button
                            role="button"
                            onClick={() => {
                                router.push('/account/details/responsible-gambling');
                                dispatch(closePopup('spendLimitExceeded'));
                            }}
                            width="60%"
                            height="50px"
                            bgColor={'#ff0000'}
                            hoverBgColor={'#ff0000'}
                            color="#fff"
                            fontWeight="bold"
                            rounded={true}
                            margin="10px"
                            style={{ flexGrow: 0 }}
                        >
                            {`VIEW MY ACCOUNT`}
                        </Button>
                        <Button
                            role="button"
                            onClick={() => {
                                router.push('/home');
                                dispatch(closePopup('spendLimitExceeded'));
                            }}
                            width="60%"
                            height="50px"
                            bgColor={'#ff0000'}
                            hoverBgColor={'#ff0000'}
                            color="#fff"
                            fontWeight="bold"
                            rounded={true}
                            margin="10px"
                            style={{ flexGrow: 0 }}
                        >
                            {`RETURN TO HOME`}
                        </Button>
                    </SectionContainer>
                </Popup>
                <Popup
                    popupStyles={{
                        width: '50% !important',
                        padding: '20px 55px !important',
                        mobileMargin: 'auto',
                        rounded: true,
                        headerStyles: {
                            textAlign: 'center',
                            color: props.theme?.colours.gameMainColour,
                        },
                        crossStyles: {
                            top: '5px',
                            right: '60px',
                        },
                    }}
                    title={'Sorry'}
                    withCloseButton={true}
                    popupName={'luckyCloverEditSubscription'}
                    closeOnDocumentClick
                    closeOnEscape
                >
                    <EditSubscriptionText>
                        To edit your subscription please call customer services on: 0800 953 9933
                    </EditSubscriptionText>
                </Popup>
                <Popup
                    popupStyles={{
                        backgroundImage: "url('/clover-popup-desktop.jpg')",
                        width: '550px !important',
                        maxWidth: '550px !important',
                        height: '420px',
                        padding: '20px 55px !important',
                        mobileMargin: 'auto',
                        rounded: true,
                        headerStyles: {
                            textAlign: 'center',
                            color: props.theme?.colours.gameMainColour,
                        },
                        crossStyles: {
                            top: '5px',
                            right: '60px',
                        },
                    }}
                    title={''}
                    withCloseButton={true}
                    popupName={'luckyCloverBonusUpsell'}
                >
                    <LuckyCloverBonusUpsell
                        bonusPick={currentSlip?.bonusPick || 0}
                        onClickCancel={() => {
                            dispatch(closePopup('luckyCloverBonusUpsell'));
                            onPressPlay(undefined, true);
                        }}
                        onClickOk={() => {
                            dispatch(closePopup('luckyCloverBonusUpsell'));
                        }}
                    />
                </Popup>
                {props.howToPlay && (
                    <Popup
                        popupStyles={{
                            width: '50% !important',
                            padding: '20px 55px !important',
                            mobileMargin: 'auto',
                            rounded: true,
                            overflow: 'scroll',
                            headerStyles: {
                                textAlign: 'center',
                                color: props.theme?.colours.gameMainColour,
                            },
                            crossStyles: {
                                top: '5px',
                                right: '60px',
                            },
                        }}
                        title={props.howToPlay.heading}
                        withCloseButton={true}
                        popupName={'howToPlay'}
                        closeOnDocumentClick={true}
                        closeOnEscape={true}
                    >
                        <BasicPopup content={props.howToPlay.content} />
                    </Popup>
                )}
                {props.termsAndConditions && (
                    <Popup
                        popupStyles={{
                            width: '50% !important',
                            padding: '20px 55px !important',
                            mobileMargin: 'auto',
                            rounded: true,
                            overflow: 'scroll',
                            headerStyles: {
                                textAlign: 'center',
                                color: props.theme?.colours.gameMainColour,
                            },
                            crossStyles: {
                                top: '5px',
                                right: '60px',
                            },
                        }}
                        title={props.termsAndConditions.heading}
                        withCloseButton={true}
                        popupName={'termsAndConditions'}
                        closeOnDocumentClick={true}
                        closeOnEscape={true}
                    >
                        <BasicPopup content={props.termsAndConditions.content} />
                    </Popup>
                )}
                {props.howToManageLines && (
                    <Popup
                        popupStyles={{
                            width: '50% !important',
                            padding: '20px 55px !important',
                            mobileMargin: 'auto',
                            rounded: true,
                            overflow: 'scroll',
                            headerStyles: {
                                textAlign: 'center',
                                color: props.theme?.colours.gameMainColour,
                            },
                            crossStyles: {
                                top: '5px',
                                right: '60px',
                            },
                        }}
                        title={props.howToManageLines.heading}
                        withCloseButton={true}
                        popupName={'howToManageLines'}
                        closeOnDocumentClick={true}
                        closeOnEscape={true}
                    >
                        <BasicPopup content={props.howToManageLines.content} />
                    </Popup>
                )}
                {props.termsContent && (
                    <Popup
                        popupStyles={{
                            width: '50% !important',
                            padding: '0px 7px 20px 7px !important',
                            margin: '8vh auto auto !important',
                            mobileMargin: 'auto',
                            rounded: true,
                            overflow: 'scroll',
                            headerStyles: {
                                textAlign: 'center',
                                color: props.theme?.colours.gameMainColour,
                            },
                            backgroundColour: 'none',
                        }}
                        popupName={'gameInfo'}
                    >
                        <TabbedContent
                            content={[
                                {
                                    title: props.howToPlay?.heading || 'How to Play',
                                    body: props.howToPlay?.content || '',
                                },
                                {
                                    title: 'How to Win',
                                    body: props.prizeBreakdown || '',
                                },
                                { title: 'FAQ', body: props.faq || '' },
                            ]}
                            onClickClose={() => dispatch(closePopup('gameInfo'))}
                        />
                    </Popup>
                )}
                <EditWagerErrorPopup error={editWagerError} onClose={onCloseEditWagerErrorPopup} />
                <CompetitionClosedHandler
                    closeDate={props.competitions.find(c => c.id === currentSlip?.competitionId)?.datumDateWithBuffer}
                    onClickClose={() => setIsLoading(true)}
                />
                <PaymentPopup
                    popupStyles={{
                        width: '350px !important',
                        padding: '0 !important',
                        mobileMargin: '0',
                        rounded: false,
                        overflow: 'scroll',
                        backgroundColour: '#000d68',
                        headerStyles: {
                            textAlign: 'center',
                            color: props.theme?.colours.gameMainColour,
                            bgColor: '#000d68',
                        },
                        crossStyles: {
                            top: '5px',
                            right: '60px',
                        },
                    }}
                    title=""
                    withCloseButton={false}
                    popupName={'payment'}
                    closeOnDocumentClick={false}
                    closeOnEscape={false}
                    handleOnCloseClicked={() => {
                        if (wagersState.stage === 'confirmed') {
                            dispatch(ResetBetSlipSelections({ ItemKey: toBetSlipKey(wagersState.game) }));
                            dispatch(resetWagers({ game: wagersState.game }));
                        }
                        setIsLoading(false);
                        return true;
                    }}
                >
                    <>
                        <HeaderBanner>
                            <Logo />
                            <Icon src={`/logo_${wagersState.game || 'classic-pools'}.png`} />
                            <Close
                                onClick={() => {
                                    if (wagersState.stage === 'confirmed') {
                                        dispatch(ResetBetSlipSelections({ ItemKey: toBetSlipKey(wagersState.game) }));
                                        dispatch(resetWagers({ game: wagersState.game }));
                                    }
                                    dispatch(closePopup('payment'));
                                    setIsLoading(false);
                                }}
                            >
                                <IconCrossWhite height="20px" />
                            </Close>
                        </HeaderBanner>
                        <PaymentContainer>
                            <Payment
                                paymentDetailsContent={paymentPopupData}
                                oneTimePayment={Boolean(
                                    props.paymentTypes && props.paymentTypes.includes('one-time-payment'),
                                )}
                                competitions={props.competitions}
                                headerRef={headerRef?.current || undefined}
                            />
                        </PaymentContainer>
                    </>
                </PaymentPopup>
                <Popup
                    popupStyles={{
                        width: '390px !important',
                        padding: '20px 55px !important',
                        mobileMargin: 'auto',
                        rounded: true,
                        headerStyles: {
                            textAlign: 'center',
                            color: theme.colours.primaryFont,
                        },
                        crossStyles: {
                            top: '5px',
                            right: '60px',
                        },
                        overflow: 'scroll',
                    }}
                    popupName="betslipExceededLimit"
                    title="Spend Limit Warning"
                    withCloseButton={true}
                >
                    <div>
                        Due to your current spend limits you won&apos;t be able to complete this transaction. Please
                        visit the <Link href={`/account/details/responsible-gambling`}>Responsible Gambling</Link>{' '}
                        Section of your account to make changes, or contact our{' '}
                        <Link href={`/contact-us`}>Customer Support</Link> team.
                    </div>
                </Popup>
                <Loader isLoading={isLoading} backgroundColour={'rgba(0,0,0,0.75)'} position={'fixed'} />

                {props.template === 'minigame' ? (
                    <MinigameTemplate
                        competitions={props.competitions}
                        offers={props.offers}
                        game={props.game}
                        gameDescription={props.gameDescription}
                        gameKeywords={props.gameKeywords}
                        gameEnabled={props.gameEnabled}
                        gamePath={props.gamePath}
                        gameViewType={props.gameViewType}
                        competitionTypeDescription={props.competitionTypeDescription}
                        showFutureGames={props.showFutureGames}
                        showMobilePrice={props.showMobilePrice}
                        headerHeight={props.headerHeight}
                        onlyDefaultOffer={props.onlyDefaultOffer}
                        canAddMultipleLines={props.canAddMultipleLines}
                        banner={props.banner}
                        howToManageLines={props.howToManageLines}
                        howToPlay={props.howToPlay}
                        termsAndConditions={props.termsAndConditions}
                        termsContent={props.termsContent}
                        viewLinesOffers={props.viewLinesOffers}
                        betslipGameType={betslipGameType}
                        betslipState={betslipState}
                        wagersState={wagersState}
                        userState={userState}
                        changeCompetition={ChangeComp}
                        changeCurrentBet={ChangeCurrentBets}
                        clearLine={Clear}
                        addLine={AddLines}
                        selectAmount={SelectAmount}
                        selectLuckyDip={Lucky}
                        selectPlay={onPressPlay}
                        selectPrediction={SelectMatch}
                        setCanEditLine={setCanEditLine}
                        setCurrentOfferingId={setCurrentOffering}
                        setEditLineAllFutureGames={setEditLineAllFutureGames}
                        setIsLoading={setIsLoading}
                        setNumberOfGames={setNumberOfGames}
                        setShowFutureCompetitions={setShowFutureGames}
                        setShowMore={setShowMore}
                        setShowSlideBoard={setShowSlideBoard}
                        setShowWagerFixtures={setShowWagerFixtures}
                        setShowWagers={setShowWagers}
                        setViewLinesCurrent={setViewLinesCurrent}
                        fetchWagers={fetchWagers}
                        handleUpdateWager={handleUpdateWager}
                        resetBetslipWagerSelections={resetBetslipWagerSelections}
                        betslipWagerHasEdits={betslipWagerHasEdits}
                        betslipWager={betslipWager}
                        canEditLine={canEditLine}
                        currentOfferingId={currentOffering}
                        editLineAllFutureGames={editLineAllFutureGames}
                        editWagerError={editWagerError}
                        isLoading={isLoading}
                        isMobileOrTablet={isMobileOrTablet}
                        numberOfGames={numberOfGames}
                        showFutureCompetitions={showFutureGames}
                        showHda={showHDA}
                        showMore={showMore}
                        showSlideBoard={showSlideBoard}
                        showWagerFixtures={showWagerFixtures}
                        showWagers={showWagers}
                        viewLinesCurrent={viewLinesCurrent}
                        wagers={wagers}
                        wagersForCompetitions={wagersForCompetitions}
                        background={props.background}
                        paymentTypeFlow={paymentTypeFlow}
                        setPaymentTypeFlow={setPaymentTypeFlow}
                        paymentTypes={props.paymentTypes}
                        maximumLines={props.maximumLines}
                        costTypeDescription={props.costTypeDescription}
                        minimumCost={props.minimumCost}
                        currentGameViewType={currentGameViewType}
                        setCurrentGameViewType={setCurrentGameViewType}
                    />
                ) : props.template === 'coupon' ? (
                    <GameCouponTemplateComponent
                        competitions={props.competitions}
                        offers={props.offers}
                        game={props.game}
                        gameDescription={props.gameDescription}
                        gameKeywords={props.gameKeywords}
                        gameEnabled={props.gameEnabled}
                        gamePath={props.gamePath}
                        gameViewType={props.gameViewType}
                        competitionTypeDescription={props.competitionTypeDescription}
                        showFutureGames={showFutureGames}
                        showMobilePrice={props.showMobilePrice}
                        headerHeight={props.headerHeight}
                        onlyDefaultOffer={props.onlyDefaultOffer}
                        canAddMultipleLines={props.canAddMultipleLines}
                        banner={props.banner}
                        howToManageLines={props.howToManageLines}
                        howToPlay={props.howToPlay}
                        termsAndConditions={props.termsAndConditions}
                        termsContent={props.termsContent}
                        viewLinesOffers={props.viewLinesOffers}
                        betslipGameType={betslipGameType}
                        betslipState={betslipState}
                        wagersState={wagersState}
                        userState={userState}
                        changeCompetition={ChangeComp}
                        changeCurrentBet={ChangeCurrentBets}
                        clearLine={Clear}
                        addLine={AddLines}
                        selectAmount={SelectAmount}
                        selectLuckyDip={Lucky}
                        selectPlay={onPressPlay}
                        selectPrediction={SelectMatch}
                        setCanEditLine={setCanEditLine}
                        setCurrentOfferingId={setCurrentOffering}
                        setEditLineAllFutureGames={setEditLineAllFutureGames}
                        setIsLoading={setIsLoading}
                        setNumberOfGames={setNumberOfGames}
                        setShowFutureCompetitions={setShowFutureGames}
                        setShowMore={setShowMore}
                        setShowSlideBoard={setShowSlideBoard}
                        setShowWagerFixtures={setShowWagerFixtures}
                        setShowWagers={setShowWagers}
                        setViewLinesCurrent={setViewLinesCurrent}
                        fetchWagers={fetchWagers}
                        handleUpdateWager={handleUpdateWager}
                        resetBetslipWagerSelections={resetBetslipWagerSelections}
                        betslipWagerHasEdits={betslipWagerHasEdits}
                        betslipWager={betslipWager}
                        canEditLine={canEditLine}
                        currentOfferingId={currentOffering}
                        editLineAllFutureGames={editLineAllFutureGames}
                        editWagerError={editWagerError}
                        isLoading={isLoading}
                        isMobileOrTablet={isMobileOrTablet}
                        numberOfGames={numberOfGames}
                        showFutureCompetitions={showFutureGames}
                        showHda={showHDA}
                        showMore={showMore}
                        showSlideBoard={showSlideBoard}
                        showWagerFixtures={showWagerFixtures}
                        showWagers={showWagers}
                        viewLinesCurrent={viewLinesCurrent}
                        wagers={wagers}
                        wagersForCompetitions={wagersForCompetitions}
                        paymentTypeFlow={paymentTypeFlow}
                        setPaymentTypeFlow={setPaymentTypeFlow}
                        paymentTypes={props.paymentTypes}
                        maximumLines={props.maximumLines}
                        costTypeDescription={props.costTypeDescription}
                        minimumCost={props.minimumCost}
                        currentGameViewType={currentGameViewType}
                        setCurrentGameViewType={setCurrentGameViewType}
                        setManualBetSwitching={setManualBetSwitch}
                        isOneTime={isOneTime}
                    />
                ) : (
                    <GameTemplateComponent
                        competitions={props.competitions}
                        offers={props.offers}
                        game={props.game}
                        gameDescription={props.gameDescription}
                        gameKeywords={props.gameKeywords}
                        gameEnabled={props.gameEnabled}
                        gamePath={props.gamePath}
                        gameViewType={props.gameViewType}
                        competitionTypeDescription={props.competitionTypeDescription}
                        showFutureGames={showFutureGames}
                        showMobilePrice={props.showMobilePrice}
                        headerHeight={props.headerHeight}
                        onlyDefaultOffer={props.onlyDefaultOffer}
                        canAddMultipleLines={props.canAddMultipleLines}
                        banner={props.banner}
                        howToManageLines={props.howToManageLines}
                        howToPlay={props.howToPlay}
                        termsAndConditions={props.termsAndConditions}
                        termsContent={props.termsContent}
                        viewLinesOffers={props.viewLinesOffers}
                        betslipGameType={betslipGameType}
                        betslipState={betslipState}
                        wagersState={wagersState}
                        userState={userState}
                        changeCompetition={ChangeComp}
                        changeCurrentBet={ChangeCurrentBets}
                        clearLine={Clear}
                        addLine={AddLines}
                        selectAmount={SelectAmount}
                        selectLuckyDip={Lucky}
                        selectPlay={onPressPlay}
                        selectPrediction={SelectMatch}
                        setCanEditLine={setCanEditLine}
                        setCurrentOfferingId={setCurrentOffering}
                        setEditLineAllFutureGames={setEditLineAllFutureGames}
                        setIsLoading={setIsLoading}
                        setNumberOfGames={setNumberOfGames}
                        setShowFutureCompetitions={setShowFutureGames}
                        setShowMore={setShowMore}
                        setShowSlideBoard={setShowSlideBoard}
                        setShowWagerFixtures={setShowWagerFixtures}
                        setShowWagers={setShowWagers}
                        setViewLinesCurrent={setViewLinesCurrent}
                        fetchWagers={fetchWagers}
                        handleUpdateWager={handleUpdateWager}
                        resetBetslipWagerSelections={resetBetslipWagerSelections}
                        betslipWagerHasEdits={betslipWagerHasEdits}
                        betslipWager={betslipWager}
                        canEditLine={canEditLine}
                        currentOfferingId={currentOffering}
                        editLineAllFutureGames={editLineAllFutureGames}
                        editWagerError={editWagerError}
                        isLoading={isLoading}
                        isMobileOrTablet={isMobileOrTablet}
                        numberOfGames={numberOfGames}
                        showFutureCompetitions={showFutureGames}
                        showHda={showHDA}
                        showMore={showMore}
                        showSlideBoard={showSlideBoard}
                        showWagerFixtures={showWagerFixtures}
                        showWagers={showWagers}
                        viewLinesCurrent={viewLinesCurrent}
                        wagers={wagers}
                        wagersForCompetitions={wagersForCompetitions}
                        paymentTypeFlow={paymentTypeFlow}
                        setPaymentTypeFlow={setPaymentTypeFlow}
                        paymentTypes={props.paymentTypes}
                        maximumLines={props.maximumLines}
                        costTypeDescription={props.costTypeDescription}
                        minimumCost={props.minimumCost}
                        currentGameViewType={currentGameViewType}
                        setCurrentGameViewType={setCurrentGameViewType}
                        useCouponButtons={showHDA && betslipGameType != 'Jackpot12'}
                    />
                )}

                {/* <TemplateComponent
                    competitions={props.competitions}
                    offers={props.offers}
                    game={props.game}
                    gameDescription={props.gameDescription}
                    gameEnabled={props.gameEnabled}
                    gamePath={props.gamePath}
                    gameViewType={props.gameViewType}
                    competitionTypeDescription={props.competitionTypeDescription}
                    showFutureGames={props.showFutureGames}
                    showMobilePrice={props.showMobilePrice}
                    headerHeight={props.headerHeight}
                    onlyDefaultOffer={props.onlyDefaultOffer}
                    canAddMultipleLines={props.canAddMultipleLines}
                    banner={props.banner}
                    howToManageLines={props.howToManageLines}
                    howToPlay={props.howToPlay}
                    termsAndConditions={props.termsAndConditions}
                    termsContent={props.termsContent}
                    viewLinesOffers={props.viewLinesOffers}
                    betslipGameType={betslipGameType}
                    betslipState={betslipState}
                    wagersState={wagersState}
                    userState={userState}
                    changeCompetition={ChangeComp}
                    changeCurrentBet={ChangeCurrentBets}
                    clearLine={Clear}
                    addLine={AddLines}
                    selectAmount={SelectAmount}
                    selectLuckyDip={Lucky}
                    selectPlay={onPressPlay}
                    selectPrediction={SelectMatch}
                    setCanEditLine={setCanEditLine}
                    setCurrentOfferingId={setCurrentOffering}
                    setEditLineAllFutureGames={setEditLineAllFutureGames}
                    setIsLoading={setIsLoading}
                    setNumberOfGames={setNumberOfGames}
                    setShowFutureCompetitions={setShowFutureGames}
                    setShowMore={setShowMore}
                    setShowSlideBoard={setShowSlideBoard}
                    setShowWagerFixtures={setShowWagerFixtures}
                    setShowWagers={setShowWagers}
                    setViewLinesCurrent={setViewLinesCurrent}
                    fetchWagers={fetchWagers}
                    handleUpdateWager={handleUpdateWager}
                    resetBetslipWagerSelections={resetBetslipWagerSelections}
                    betslipWagerHasEdits={betslipWagerHasEdits}
                    betslipWager={betslipWager}
                    canEditLine={canEditLine}
                    currentOfferingId={currentOffering}
                    editLineAllFutureGames={editLineAllFutureGames}
                    editWagerError={editWagerError}
                    isLoading={isLoading}
                    isMobileOrTablet={isMobileOrTablet}
                    numberOfGames={numberOfGames}
                    showFutureCompetitions={showFutureGames}
                    showHda={showHDA}
                    showMore={showMore}
                    showSlideBoard={showSlideBoard}
                    showWagerFixtures={showWagerFixtures}
                    showWagers={showWagers}
                    viewLinesCurrent={viewLinesCurrent}
                    wagers={wagers}
                    wagersForCompetitions={wagersForCompetitions}
                /> */}
                {/* <StyledMain>
                    {showWagers && wagersForCompetitions.length === 0 && (
                        <ViewLinesOverlay
                            onClick={(): void => {
                                setShowWagers(false);
                            }}
                        />
                    )}

                    <DesktopHeaderContainer>
                        {template &&
                            template.renderHeaderPanel &&
                            template.renderHeaderPanel(
                                props.game,
                                betslipState,
                                betslipGameType,
                                fetchWagers,
                                setShowWagers,
                                ChangeCurrentBets,
                                Clear,
                                AddLines,
                                showHDA,
                                SelectAmount,
                                Lucky,
                                props.offers,
                                setCurrentOffering,
                                setShowMore,
                                showMore,
                                wagersForCompetitions,
                                onPressPlay,
                                props.canAddMultipleLines,
                                showWagers,
                                canEditLine,
                                isMobileOrTablet,
                                props.howToPlay,
                                currentOffering,
                            )}
                    </DesktopHeaderContainer>
                    <MobileHeaderContainer
                        style={
                            headerHeight > 0
                                ? { top: headerHeight, position: 'sticky', zIndex: 5 }
                                : { top: 0, position: 'relative', zIndex: 0 }
                        }
                    >
                        {template &&
                            template.renderMobileHeaderPanel &&
                            template.renderMobileHeaderPanel(
                                props.game,
                                betslipState,
                                betslipGameType,
                                userState,
                                fetchWagers,
                                setShowWagers,
                                ChangeCurrentBets,
                                Clear,
                                AddLines,
                                handleUpdateWager,
                                resetBetslipWagerSelections,
                                showHDA,
                                SelectAmount,
                                Lucky,
                                SelectMatch,
                                props.offers,
                                setCurrentOffering,
                                setEditLineAllFutureGames,
                                setShowMore,
                                betslipWagerHasEdits,
                                editLineAllFutureGames,
                                showMore,
                                viewLinesCurrent,
                                wagersForCompetitions,
                                onPressPlay,
                                props.canAddMultipleLines,
                                props.showMobilePrice,
                                showWagers,
                                canEditLine,
                                isMobileOrTablet,
                                props.howToPlay,
                                currentOffering,
                                betslipWager,
                                props.competitionTypeDescription,
                            )}
                    </MobileHeaderContainer>

                    {template &&
                        template.renderMainPanel &&
                        template.renderMainPanel(
                            props.game,
                            betslipState,
                            betslipGameType,
                            showHDA,
                            ChangeComp,
                            Clear,
                            SelectAmount,
                            Lucky,
                            onPressPlay,
                            SelectMatch,
                            props.competitions,
                            props.offers,
                            setCurrentOffering,
                            setNumberOfGames,
                            setShowMore,
                            setShowSlideBoard,
                            props.showFutureGames || false,
                            showSlideBoard,
                            wagersForCompetitions,
                            showWagers,
                            canEditLine,
                            currentOffering,
                            betslipWager,
                            props.competitionTypeDescription,
                            props.gameDescription,
                            props.gameViewType,
                            props.onlyDefaultOffer,
                            numberOfGames,
                        )}
                </StyledMain>
                <Sidebar background="none" maxWidth={template?.sidebarWidth}>
                    {template &&
                        template.renderSidePanel &&
                        template.renderSidePanel(
                            props.game,
                            betslipState,
                            betslipGameType,
                            userState,
                            fetchWagers,
                            setShowWagers,
                            ChangeCurrentBets,
                            Clear,
                            AddLines,
                            handleUpdateWager,
                            resetBetslipWagerSelections,
                            showHDA,
                            SelectAmount,
                            SelectMatch,
                            props.competitions,
                            props.offers,
                            setCurrentOffering,
                            setEditLineAllFutureGames,
                            setNumberOfGames,
                            setShowMore,
                            setShowSlideBoard,
                            setShowWagerFixtures,
                            setViewLinesCurrent,
                            betslipWagerHasEdits,
                            editLineAllFutureGames,
                            showMore,
                            showSlideBoard,
                            showWagers,
                            viewLinesCurrent,
                            wagersForCompetitions,
                            onPressPlay,
                            props.canAddMultipleLines,
                            canEditLine,
                            currentOffering,
                            betslipWager,
                            props.competitionTypeDescription,
                            numberOfGames,
                            props.onlyDefaultOffer,
                            props.termsContent,
                            showWagers ? props.viewLinesOffers : undefined,
                        )}
                </Sidebar> */}
            </ThemeProvider>
        </>
    );
};

const SubscriptionConfirmationPopupContainer = styled.div`
    padding: 0 50px 50px 50px;
    ${breakpoints.below('sm')} {
        padding: 0;
    }
`;

export const Sidebar = styled.div<{ background?: string; maxWidth?: string; margin?: string }>`
    max-width: ${props => (props.maxWidth ? props.maxWidth : '335px')};
    margin: ${props => (props.margin ? props.margin : undefined)};
    overflow-y: auto;
    background: ${(props): string => (props.background ? props.background : '#fff')};
    flex: 1;
    ${breakpoints.below('lg')} {
        display: none;
    }
`;

Game.displayName = 'gamePage';

export interface GameProps {
    competitions?: Competition[];
    offers?: Offerings;
    game: GameType;
    gameDescription?: string;
    gameKeywords?: string;
    gameViewType?: GameViewType;
    theme?: DefaultTheme;
    showFutureGames?: boolean;
    headerHeight?: number;
    onlyDefaultOffer?: boolean;
    canAddMultipleLines?: boolean;
    banner?: BuilderGamePageBanner;
    howToPlay?: ContentItem;
    termsAndConditions?: ContentItem;
    howToManageLines?: ContentItem;
    termsContent?: string;
    viewLinesOffers?: Offerings;
    gameEnabled?: boolean;
    gamePath?: string;
    showMobilePrice?: boolean;
    competitionTypeDescription?: string;
    background?: {
        colour?: string;
        img?: string;
        rightPanelImg?: string;
    };
    template?: string;
    paymentTypes: ('subscription' | 'one-time-payment')[];
    maximumLines?: number;
    costTypeDescription?: string;
    minimumCost?: number;
    faq?: string;
    featuredCompetitionId?: number;
    prizeBreakdown?: string;
    isFieldAcquisition?: boolean;
}

export default withGameLayout(Game);
