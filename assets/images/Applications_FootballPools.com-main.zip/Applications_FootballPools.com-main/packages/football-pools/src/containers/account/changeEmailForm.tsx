import { useForm, ErrorMessage } from 'react-hook-form';
import { useState } from 'react';

import { StyledInput, PasswordRevealInput } from '@fp/shared/src/components/Forms/Inputs';
import { FormButton } from './loginDetails';
import { updateEmail } from '@fp/shared/src/api/account';
import styled from 'styled-components';
import { isAppError } from '@fp/shared/src/core/appError';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '@fp/shared/src/rootReducer';
import { AppDispatch } from '@fp/shared/src/store';
import { addUserDetails } from '@fp/shared/src/features/authentication/authenticationSlice';
import { isPasswordValid } from '@fp/shared/src/containers/account/passwordValidation';

export interface ChangeEmailFormData {
    email: string;
    password: string;
}

export const ErrorMsg = styled.span`
    color: #ff0000;
    font-size: 12px;
    display: block;
    margin-top: -0.5rem;
    margin-bottom: 0.5rem;
    align-self: flex-start;
`;

type FormStatus = 'pending' | 'submitting' | 'success';

export const ChangeEmailForm = (): JSX.Element => {
    const { register, handleSubmit, formState, errors, setError, reset } = useForm<ChangeEmailFormData>({
        mode: 'onChange',
    });
    const [formStatus, setFormStatus] = useState<FormStatus>('pending');

    // Get user details from redux store:
    const auth = useSelector((state: RootState) => state.authentication);
    const userDetails = auth.userDetails;
    const dispatch: AppDispatch = useDispatch<AppDispatch>();

    const submitForm = handleSubmit(async ({ email, password }) => {
        if (formStatus === 'submitting') return;
        setFormStatus('submitting');

        const response = await updateEmail({
            email,
            password,
        });

        if (isAppError(response)) {
            if (response.message === 'email_exists') {
                setError('email', response.message, 'This email address is already registered to an account.');
            } else if (response.message === 'incorrect_password') {
                setError('password', response.message, 'Your password was incorrect. Please try again.');
            }
            setFormStatus('pending');
            return;
        }

        reset();
        setFormStatus('success');
        dispatch(addUserDetails(response));
    });

    const handleOnChange = (): void => {
        if (formStatus === 'success') {
            setFormStatus('pending');
        }
    };

    return (
        <form onSubmit={submitForm} onChange={handleOnChange}>
            {formStatus === 'success' && (
                <p role="alert">
                    <b>Email updated &#10003;</b>
                </p>
            )}
            <p>
                <b>Email</b>
            </p>
            <p>{userDetails?.email}</p>
            <p>
                <b>Change email address</b>
            </p>
            <p>
                To change the email address you use to login, please enter your new email address below.
                <br />
                You will need to enter your current password to confirm your change of email.
            </p>
            <StyledInput
                type="email"
                id="email"
                name="email"
                label="New Email"
                ref={register({
                    required: 'Please enter your new email.',
                    pattern: {
                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i,
                        message: 'Invalid email',
                    },
                })}
            />
            <ErrorMessage role="alert" errors={errors} name="email" as={ErrorMsg} />

            <PasswordRevealInput
                id="password"
                name="password"
                label="Confirm Password"
                ref={register({
                    required: 'Please enter your password.',
                    validate: value => isPasswordValid(value) || 'Invalid password',
                })}
                data-wc-ignore="true"
            />
            <ErrorMessage role="alert" errors={errors} name="password" as={ErrorMsg} />

            <FormButton type="submit" role="button" disabled={!formState.isValid}>
                Update Email
            </FormButton>
        </form>
    );
};
