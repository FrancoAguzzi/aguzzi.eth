/* eslint-disable @typescript-eslint/explicit-function-return-type */
import { render, fireEvent, waitFor } from '@testing-library/react';

import { ChangePasswordForm } from './changePasswordForm';
import { updatePassword } from '@fp/shared/src/api/account';

jest.mock('@fp/shared/src/api/account');

jest.mock('next/config', () => () => ({
    publicRuntimeConfig: {
        API_URL: 'api.url',
    },
}));

const fireInput = (element: Document | Element | Window | Node, value: unknown): boolean =>
    fireEvent.input(element, { target: { value } });

const renderComponent = () => {
    const utils = render(<ChangePasswordForm />);

    const currentPasswordField = utils.getByLabelText(/Current password/i);
    const newPasswordField = utils.getByLabelText(/New password/i);
    const confirmPasswordField = utils.getByLabelText(/Confirm password/i);
    const formButton = utils.getByRole(/button/);

    const successfulSubmit = async () => {
        const mockUpdatePassword = updatePassword as jest.MockedFunction<typeof updatePassword>;
        mockUpdatePassword.mockResolvedValue(true);

        fireInput(currentPasswordField, 'Testtest1');
        fireInput(newPasswordField, 'Testtest2');
        fireInput(confirmPasswordField, 'Testtest2');

        await waitFor(() => formButton);
        fireEvent.click(formButton);
        await waitFor(() => formButton);

        return { mockUpdatePassword };
    };

    return {
        ...utils,
        currentPasswordField,
        newPasswordField,
        confirmPasswordField,
        formButton,
        successfulSubmit,
    };
};

describe('changePasswordForm', () => {
    it('should match snapshot', async () => {
        const { container, formButton } = renderComponent();

        await waitFor(() => formButton);

        expect(container).toMatchSnapshot();
    });

    it('should only be able to be submitted if form is valid', async () => {
        const { currentPasswordField, newPasswordField, confirmPasswordField, formButton } = renderComponent();

        expect(formButton).toBeDisabled();

        fireInput(currentPasswordField, 'Testtest1');
        fireInput(newPasswordField, 'Testtest2');
        fireInput(confirmPasswordField, 'Testtest2');

        await waitFor(() => formButton);

        expect(formButton).toBeEnabled();
    });

    it('should call updatePassword on submit', async () => {
        const { successfulSubmit } = renderComponent();

        const { mockUpdatePassword } = await successfulSubmit();

        expect(mockUpdatePassword).toHaveBeenCalled();
    });

    it('should reset the form after a successful submit', async () => {
        const { successfulSubmit, currentPasswordField, newPasswordField, confirmPasswordField } = renderComponent();

        await successfulSubmit();

        expect(currentPasswordField).toHaveValue('');
        expect(newPasswordField).toHaveValue('');
        expect(confirmPasswordField).toHaveValue('');
    });

    it('should show success message on successful submit', async () => {
        const { successfulSubmit, findByRole } = renderComponent();

        await successfulSubmit();

        const successMessage = await findByRole('alert');

        expect(successMessage).toBeVisible();
        expect(successMessage).toHaveTextContent(/Password saved/);
    });

    it('should show password validation based on the new passworld field', async () => {
        const { newPasswordField, getByRole } = renderComponent();
        const validationField = getByRole('paragraph');

        const initialValidation = validationField.outerHTML;

        fireInput(newPasswordField, 'Testtest');
        await waitFor(() => newPasswordField);

        const updatedValidation = validationField.outerHTML;

        expect(updatedValidation).not.toEqual(initialValidation);
    });
});
