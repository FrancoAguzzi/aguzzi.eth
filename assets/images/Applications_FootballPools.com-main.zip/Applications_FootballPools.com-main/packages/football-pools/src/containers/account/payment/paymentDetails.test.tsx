import { PaymentDetailsPage } from './paymentDetails';
import { RenderResult, act, waitFor, screen } from '@testing-library/react';
import * as AccountAPI from '@fp/shared/src/api/account';
import { PaymentDetailsArray } from '@fp/shared/src/api/account';
import { RootState } from '@fp/shared/src/rootReducer';
import { renderWithRedux } from '@fp/shared/src/testing/utils/renderWithRedux';
import { RecursivePartial } from '@fp/shared/src/testing/utils/RecursivePartial';
import { UserDetails } from '@fp/shared/src/features/authentication/UserDetails';

jest.mock('@fp/shared/src/settings/breakpoints');

jest.mock('next/router', () => ({
    useRouter: () => ({
        route: '/',
        pathname: '/account/payment',
        asPath: '',
    }),
}));

jest.mock('next/config', () => () => ({
    publicRuntimeConfig: {
        API_URL: 'api.url',
    },
}));

jest.mock('@fp/shared/src/api/account');
const mockedAccountAPI = AccountAPI as jest.Mocked<typeof AccountAPI>;

const partialUser: RecursivePartial<UserDetails> = {
    email: 'test@test.com',
};

const userDetails: UserDetails = partialUser as UserDetails;

const renderComponent = (): RenderResult => {
    const utils = renderWithRedux(<PaymentDetailsPage />, { authentication: { userDetails } } as RootState);
    return { ...utils };
};

describe('payment details', () => {
    test('should match snapshot', async () => {
        const paymentDetails: PaymentDetailsArray = {
            directDebits: [{ accountNumber: '12345678', sortCode: '123456' }],
        };
        mockedAccountAPI.getPaymentDetails.mockResolvedValue(paymentDetails);

        await act(async () => {
            const { container } = renderComponent();

            await waitFor(() => {
                expect(container).toMatchSnapshot();
                expect(screen.getByText('12345678'));
                expect(screen.getByText('123456'));
            });
        });
    });
});

describe('payment details', () => {
    test('should render correctly when there are multiple details', async () => {
        const paymentDetails: PaymentDetailsArray = {
            directDebits: [
                { accountNumber: '12345678', sortCode: '123456' },
                { accountNumber: '24681012', sortCode: '141618' },
            ],
        };
        mockedAccountAPI.getPaymentDetails.mockResolvedValue(paymentDetails);

        await act(async () => {
            const { container } = renderComponent();

            await waitFor(() => {
                expect(container).toMatchSnapshot();
                expect(screen.getByText('12345678'));
                expect(screen.getByText('123456'));
                expect(screen.getByText('24681012'));
                expect(screen.getByText('141618'));
            });
        });
    });
});

describe('payment details', () => {
    test('should render correctly when there are no details', async () => {
        const paymentDetails: PaymentDetailsArray = {
            directDebits: [],
        };
        mockedAccountAPI.getPaymentDetails.mockResolvedValue(paymentDetails);

        await act(async () => {
            const { container } = renderComponent();

            await waitFor(() => {
                expect(container).toMatchSnapshot();
                expect(
                    screen.getByText(
                        'You have no bank details to show. Once details have been added they will be shown here.',
                    ),
                );
            });
        });
    });
});
