import styled from 'styled-components';
import Checkbox from '@fp/shared/src/components/Checkbox/Checkbox';
import { Button } from '@fp/shared/src/components/Button/Button';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import { useState } from 'react';
import { useForm, ErrorMessage } from 'react-hook-form';
import { updateContactPrefs } from '@fp/shared/src/api/account';
import { NextPage } from 'next';
import { AppDispatch } from '@fp/shared/src/store';
import { addUserDetails } from '@fp/shared/src/features/authentication/authenticationSlice';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '@fp/shared/src/rootReducer';
import { isAppError } from '@fp/shared/src/core/appError';

export interface ContactPrefsFormData {
    contactEmail: boolean;
    contactSms: boolean;
    contactPhone: boolean;
    contactPost: boolean;
}

const Container = styled.div`
    display: flex;
    flex-direction: column;
    width: 100%;
    margin: 0 auto;

    ${breakpoints.above('sm')} {
        width: 386px;
    }
`;

const CheckboxContainer = styled.div`
    display: flex;
    justify-content: space-between;
`;

const FormButton = styled(Button)`
    border-radius: 5px;
    height: 50px;
`;

const Error = styled.span`
    color: #ff0000;
    font-size: 12px;
    display: block;
    margin-top: -0.5rem;
    margin-bottom: 0.5rem;
`;

const GeneralError = styled(Error)`
    margin-top: 0.5rem;
    text-align: center;
`;

type FormStatus = 'pending' | 'submitting' | 'success';

export const ContactPrefsForm: NextPage = (): JSX.Element => {
    const { register, handleSubmit, formState, clearError, setError, errors, reset } = useForm<ContactPrefsFormData>({
        mode: 'onChange',
    });
    const [formStatus, setFormStatus] = useState<FormStatus>('pending');

    // Get user details from redux store:
    const userDetails = useSelector((state: RootState) => state.authentication.userDetails);
    const dispatch: AppDispatch = useDispatch<AppDispatch>();

    const submitForm = handleSubmit(async ({ contactEmail, contactSms, contactPost, contactPhone }) => {
        if (formStatus === 'submitting') return;
        setFormStatus('submitting');

        const response = await updateContactPrefs({
            contactEmail,
            contactSms,
            contactPost,
            contactPhone,
        });

        if (isAppError(response)) {
            setError('general', 'general', 'Something went wrong');
            setFormStatus('pending');
        } else {
            reset();
            setFormStatus('success');
            dispatch(addUserDetails(response));
        }
    });

    const handleOnChange = (): void => {
        clearError('general');
        if (formStatus === 'success') {
            setFormStatus('pending');
        }
    };

    return (
        <Container>
            <p>
                <b>How do you want to receive special offers?</b>
            </p>
            <p>
                Please tick the contact methods on which you&apos;d like to receive information about The Football
                Pools’ latest news, bonus and special offers plus competitions, features and games.
            </p>
            <form onSubmit={submitForm} onChange={handleOnChange}>
                <CheckboxContainer>
                    <Checkbox
                        name="contactEmail"
                        id="contactEmail"
                        ref={register}
                        defaultChecked={
                            userDetails?.preferences?.communication?.email && !formState.dirtyFields.has('contactEmail')
                        }
                    >
                        Email
                    </Checkbox>
                    <Checkbox
                        name="contactSms"
                        id="contactSms"
                        ref={register}
                        defaultChecked={
                            userDetails?.preferences?.communication?.sms && !formState.dirtyFields.has('contactSms')
                        }
                    >
                        Sms
                    </Checkbox>
                    <Checkbox
                        name="contactPost"
                        id="contactPost"
                        ref={register}
                        defaultChecked={
                            userDetails?.preferences?.communication?.post && !formState.dirtyFields.has('contactPost')
                        }
                    >
                        Post
                    </Checkbox>
                    <Checkbox
                        name="contactPhone"
                        id="contactPhone"
                        ref={register}
                        defaultChecked={
                            userDetails?.preferences?.communication?.telephone &&
                            !formState.dirtyFields.has('contactPhone')
                        }
                    >
                        Phone
                    </Checkbox>
                </CheckboxContainer>
                {formStatus === 'success' && (
                    <p role="alert">
                        <b>Contact Preferences updated &#10003;</b>
                    </p>
                )}
                <ErrorMessage role="alert" errors={errors} name="general" as={GeneralError} />
                <FormButton
                    bgColor={'#010d68'}
                    width={'100%'}
                    disabled={(!formState.isValid || !formState.dirty) && formStatus !== 'submitting'}
                >
                    Update Changes
                </FormButton>
            </form>
            <p>
                Please note The Football Pools reserves the right to contact you regarding important account
                information.
                <br />
                You can update your contact preferences at any time on this page.
            </p>
        </Container>
    );
};

export default ContactPrefsForm;
