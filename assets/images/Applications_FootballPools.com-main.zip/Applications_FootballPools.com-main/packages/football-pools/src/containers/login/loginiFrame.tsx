/* eslint-disable @typescript-eslint/camelcase */
import { FunctionComponent, useCallback, useEffect, useState } from 'react';
import styled from 'styled-components';
import { useDispatch, useSelector } from 'react-redux';
import getConfig from 'next/config';
import { AppDispatch } from '@fp/shared/src/store';
import { getAuthenticationSelector } from '@fp/shared/src/features/authentication/authenticationSelectors';
import { getCookieFromDocument, setCookie } from '@services/cookies';
import { useAuthToken } from '@fp/shared';
import { isAppError } from '@fp/shared/src/core/appError';
import { authenticateToken, getDetails, setAuthToken } from '@fp/shared/src/api/account';
import { addUserDetails, loginSuccess } from '@fp/shared/src/features/authentication/authenticationSlice';
import { redirectUrlSelector } from '@fp/shared/src/features/registration/registrationSelector';
import { useRouter } from 'next/router';
import { clearRedirectUrl } from '@fp/shared/src/features/registration/registrationSlice';

const { publicRuntimeConfig } = getConfig();

const IframeLogin = styled.iframe`
    border: none;
    height: 300px;
`;

export const LoginiFrame: FunctionComponent = () => {
    const dispatch: AppDispatch = useDispatch<AppDispatch>();
    const authenticationState = useSelector(getAuthenticationSelector);
    const returnurl = useSelector(redirectUrlSelector);
    const router = useRouter();
    const handleMessageEvent = useCallback((event: MessageEvent) => {
        if (event.data?.event == 'LoginDone') {
            const handleLoginWithTokenAsync = async (): Promise<void> => {
                const encryptedToken = getCookieFromDocument('_clubFpToken');
                // console.log('encrypted token', encryptedToken);
                if (encryptedToken !== '' && (!authenticationState || !authenticationState.isLoggedIn)) {
                    // Cookie exists, but user is not logged in with app, login using encrypted token:
                    // console.log('logging user in with token');
                    let success = false;
                    const { setToken } = useAuthToken();
                    const response = await authenticateToken(encryptedToken);
                    if (!isAppError(response)) {
                        const user = await getDetails(response.token);
                        if (!isAppError(user)) {
                            // console.log('logged user in with token', user);
                            setToken(response.token);
                            setAuthToken(response.token);
                            dispatch(loginSuccess({ token: response.token, hasDetails: user.firstName != null }));
                            dispatch(addUserDetails(user));
                            success = true;

                            if (!user.firstName) {
                                router.push('/registration/details');
                            }
                            if (
                                returnurl &&
                                !returnurl.includes(router.asPath) &&
                                !['/registration', '/registration/details'].includes(router.asPath)
                            ) {
                                router.push(returnurl);
                                if (returnurl) {
                                    dispatch(clearRedirectUrl());
                                }
                            }
                            if (returnurl?.includes(router.asPath)) {
                                router.push(returnurl, undefined, { shallow: true });
                                dispatch(clearRedirectUrl());
                            }
                        }
                    }
                    if (!success) {
                        // console.log('failed to login with cookie');
                        setCookie('_clubFpToken', '', -1);
                    }
                }
            };
            handleLoginWithTokenAsync();
        }
    }, []);

    useEffect(() => {
        window.addEventListener('message', handleMessageEvent);
        return () => {
            window.removeEventListener('message', handleMessageEvent);
        };
    }, [handleMessageEvent]);

    let url = returnurl ? `/api/auth/login?returnurl=${publicRuntimeConfig.SITE_URL}${returnurl}` : '/api/auth/login';

    // Set returnurls for dismissing iframe:

    if (returnurl && returnurl.includes('?payment=oneTime')) {
        url += `&cross_return_url=${publicRuntimeConfig.SITE_URL}${returnurl.replace('?payment=oneTime', '')}`;
    }
    if (returnurl && returnurl.includes('/payment')) {
        url += `&cross_return_url=${publicRuntimeConfig.SITE_URL}`;
    }

    return (
        <IframeLogin
            sandbox="allow-storage-access-by-user-activation allow-scripts allow-forms allow-top-navigation allow-popups-to-escape-sandbox allow-scripts allow-same-origin"
            src={url}
        />
    );
};

export default LoginiFrame;
