import { BankDetails } from './bankDetails';
import { RenderResult, render } from '@testing-library/react';

jest.mock('@fp/shared/src/settings/breakpoints');

jest.mock('next/router', () => ({
    useRouter: () => ({
        pathname: '/account/payment',
    }),
}));

const accountNumber = '11131397';
const sortCode = '400409';

const renderComponent = (): RenderResult => {
    const utils = render(<BankDetails accountNumber={accountNumber} sortCode={sortCode} />);
    return { ...utils };
};

describe('banking details', () => {
    test('should match snapshot', () => {
        const { container } = renderComponent();

        expect(container).toMatchSnapshot();
    });

    test('should be in the dom', () => {
        const { container } = renderComponent();

        expect(container).toBeInTheDOM();
    });
});
