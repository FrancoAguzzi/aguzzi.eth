import { FunctionComponent, useState } from 'react';
import { useForm, FormStateProxy, ErrorMessage } from 'react-hook-form';
import { updatePassword } from '@fp/shared/src/api/account';
import { PasswordRevealInput } from '@fp/shared/src/components/Forms/Inputs';
import { isAppError } from '@fp/shared/src/core/appError';
import { FormButton } from './loginDetails';
import { isPasswordValid, PasswordValidationText } from '@fp/shared/src/containers/account/passwordValidation';
import { ErrorMsg } from './changeEmailForm';

interface ChangePasswordFormData {
    currentPassword: string;
    newPassword: string;
    confirmPassword: string;
}

const isFormValid = (formState: FormStateProxy<ChangePasswordFormData>): boolean =>
    formState.isValid && formState.dirtyFields.has('newPassword') && formState.dirtyFields.has('confirmPassword');

type FormState = 'pending' | 'submitting' | 'success';

export const ChangePasswordForm = (): JSX.Element => {
    const { register, handleSubmit, formState, getValues, reset, watch, setError, errors, triggerValidation } = useForm<
        ChangePasswordFormData
    >({
        mode: 'onChange',
    });
    const [formStatus, setFormStatus] = useState<FormState>('pending');

    const submitForm = handleSubmit(async ({ currentPassword, newPassword, confirmPassword }) => {
        if (formStatus === 'submitting') return;
        setFormStatus('submitting');

        const response = await updatePassword({
            currentPassword,
            password: newPassword,
            passwordConfirmation: confirmPassword,
        });

        if (isAppError(response)) {
            setFormStatus('pending');
            if (response.apiError) {
                const apiError = response.apiError.title;
                if (apiError.includes('current_password')) {
                    setError('currentPassword', 'api', 'Your password was incorrect. Please try again.');
                }
            } else setError('general', 'general', 'Something went wrong');
            return;
        }

        reset();
        setFormStatus('success');
    });

    const handleOnChange = (): void => {
        if (formStatus === 'success') {
            setFormStatus('pending');
        }
    };

    const isNewPasswordValid = (value: string): boolean => {
        const confirmPassword = getValues().confirmPassword;
        const ret = isPasswordValid(value) && (confirmPassword ? confirmPassword === value : true);
        if (confirmPassword) {
            triggerValidation('confirmPassword');
        }
        return ret;
    };

    return (
        <form onSubmit={submitForm} onChange={handleOnChange}>
            {formStatus === 'success' && (
                <p role="alert">
                    <b>Password saved &#10003;</b>
                </p>
            )}
            <p>
                <b>Change password</b>
            </p>
            <p>
                To change the password you use to login, please enter the new password below.
                <br />
                You will need to enter your current password to confirm your change of password.
            </p>
            <PasswordRevealInput
                id="currentPassword"
                name="currentPassword"
                label="Current password"
                ref={register({
                    required: 'Please enter your current password',
                    validate: value => isPasswordValid(value) || 'Invalid password',
                })}
            />
            <ErrorMessage role="alert" errors={errors} name="currentPassword" as={ErrorMsg} />
            <PasswordRevealInput
                id="newPassword"
                name="newPassword"
                label="New password"
                data-wc-ignore="true"
                ref={register({
                    required: true,
                    validate: value => isNewPasswordValid(value) || 'Invalid password',
                })}
                aria-describedby="passwordValidationText"
            />
            <PasswordValidationText
                id="passwordValidationText"
                role="paragraph"
                aria-label="password validation text"
                password={watch('newPassword', '')}
            />

            <PasswordRevealInput
                id="confirmPassword"
                name="confirmPassword"
                label="Confirm password"
                data-wc-ignore="true"
                ref={register({
                    validate: value => value === getValues().newPassword || "Passwords don't match.",
                })}
            />
            <ErrorMessage role="alert" errors={errors} name="confirmPassword" as={ErrorMsg} />
            <FormButton type="submit" disabled={!isFormValid(formState)}>
                Update Password
            </FormButton>
        </form>
    );
};
