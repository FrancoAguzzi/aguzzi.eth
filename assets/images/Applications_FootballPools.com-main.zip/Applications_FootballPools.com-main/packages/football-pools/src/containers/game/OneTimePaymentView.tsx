/* eslint-disable import/named */
import { useRouter } from 'next/router';
import styled from 'styled-components';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import {
    AuthoriseCardForm,
    AuthoriseCardFormBms,
    BetSlip,
    Fixture,
    ResetBetSlipSelections,
    resetWagers,
    toBetSlipKey,
} from '@sportech/pools-api';
import {
    BetSelections,
    Button,
    closePopup,
    getTotalLines,
    getTotalPrice,
    openPopup,
    GameSection,
} from '@sportech/pools-components';
import { isHdaGame } from '@fp/shared/src/lib/utils';
import { PaymentTypesSlimView } from '@fp/shared/src/components/PaymentTypesRadioGroup/PaymentTypesSlimView';
import { CardForm } from '@fp/shared/src/components/Forms/Payment/CardForm';
import { DirectDebitForm, ExistingDirectDebitForm } from '@fp/shared/src/components/Forms/Payment/DirectDebitForm';
import { Loader } from '@fp/shared/src/components/Loader/Loader';
import { useDispatch } from 'react-redux';
import { AppDispatch } from '@fp/shared/src/store';
import { useState } from 'react';
import { PayPalForm } from '@fp/shared/src/components/Forms/Payment/PayPalForm';
import { PaymentViewProps } from './SubscriptionPaymentView';
import IconCheckMark from 'public/svg/check-mark.svg';
import getConfig from 'next/config';

const { publicRuntimeConfig } = getConfig();

const SectionsContainer = styled.div`
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
`;

const SectionContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: #fff;
    margin: auto;
    padding: 5px;
    width: 100%;
    ${breakpoints.below('xs')} {
        width: 90%;
    }
    @media (max-width: 385px) {
        width: 95%;
    }
`;

const LoaderBackground = styled.div`
    @keyframes pulse {
        0% {
            box-shadow: 0 0 0 0 rgba(0, 195, 8, 0.4);
        }
        70% {
            box-shadow: 0 0 0 10px rgba(0, 195, 8, 0);
        }
        100% {
            box-shadow: 0 0 0 0 rgba(0, 195, 8, 0);
        }
    }
    box-shadow: 0 0 0 rgba(0, 195, 8, 0.4);
    animation: pulse 2s infinite;
    background: #7cda24; // rgba(0, 195, 8, 0.4);
    border-radius: 50px;
    width: 90%;
    height: 60px;
    position: absolute;
    z-index: -1;
`;

const TitleText = styled.h3`
    color: ${props => props.theme.colours.primaryFont};
    font-size: 1rem;
    margin-top: 10px auto 5px;
`;

const PaymentStepBackContainer = styled.div`
    color: ${props => props.theme.colours.primaryFont};
    cursor: pointer;
    font-size: 0.9rem;
    font-weight: bold;
    margin: 15px 0 10px 15px;
    width: 100%;
`;

const SecurePaymentsContainer = styled.div`
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    justify-content: space-evenly;
    color: ${props => props.theme.colours.primaryFont};
    font-weight: bold;
    font-size: 0.8rem;
    margin: 5px auto 1.2rem auto;
    width: 100%;
`;

const ConfirmationContainer = styled.div`
    display: flex;
    flex-direction: column;
    padding: 0 10px;
    width: 100%;
    margin-bottom: 10px;
`;

const BetSelectionsConfirmationContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin: 10px 0;
    width: 100%;
    max-height: 200px;
    overflow-y: scroll;
    position: relative;
`;

const FinancialLimitsContainer = styled.div`
    color: ${props => props.theme.colours.primaryFont};
    font-size: 0.75rem;
    margin: 1.2rem 0;
    a {
        text-decoration: underline;
    }
`;

const SubtitleText = styled.h4<{ fontColour?: string; fontSize?: string }>`
    color: ${props => props.fontColour || props.theme.colours.primaryFont};
    font-size: ${props => props.fontSize || '1rem'};
    margin: 10px;
`;

export const OneTimePaymentView = ({
    wagersState,
    betslipState,
    paymentStep,
    isLoading,
    setIsLoading,
    currentPaymentMethod,
    paymentMethodOptions,
    cardErrors,
    directDebitErrors,
    payPalErrors,
    setCardErrors,
    setDirectDebitErrors,
    setPayPalErrors,
    onSubmitCardForm,
    onSubmitDirectDebitForm,
    onSubmitPayPalForm,
    getTermUrl,
    onAuthoriseError,
    onAuthoriseSuccess,
    competitions,
    setCurrentPaymentMethod,
    hasSpendLimit,
}: PaymentViewProps) => {
    const router = useRouter();
    const dispatch = useDispatch<AppDispatch>();
    const [showFixtures, setShowFixtures] = useState<number | undefined>(undefined);

    const getOneTimeAmount = () => {
        const ret = getTotalPrice(
            isHdaGame(wagersState.game),
            wagersState.game === 'lucky-clover',
            betslipState[toBetSlipKey(wagersState.game)],
        ).toLocaleStringCash();
        return ret;
    };

    const getFixturesForBet = (bet: BetSlip): Fixture[] => {
        let ret: Fixture[] = [];
        const competition = competitions?.find(c => c.id === bet.competitionId);
        if (competition) {
            ret = competition.fixtures.filter(f => bet.numbers?.find(n => n.Id === f.number));
            if (bet.bonusNumbers) {
                ret.push(...competition.fixtures.filter(f => bet.bonusNumbers?.find(n => n.Id === f.number)));
            }
        }
        return ret;
    };

    const onConfirm = (redirect: string) => {
        setIsLoading(true);
        router.push(redirect);
        dispatch(ResetBetSlipSelections({ ItemKey: toBetSlipKey(wagersState.game) }));
        dispatch(resetWagers({ game: wagersState.game }));
        dispatch(closePopup('payment'));
    };

    return (
        <SectionsContainer>
            <Loader
                isLoading={isLoading}
                backgroundColour={'#000d68'}
                color="white"
                loaderType="ThreeDots"
                position="absolute"
                borderRadius="0"
            >
                <LoaderBackground />
            </Loader>

            {paymentStep !== 'confirm' && betslipState[toBetSlipKey(wagersState.game)][0] && (
                <SectionContainer>
                    <SubtitleText>
                        Total Lines:{' '}
                        {getTotalLines(isHdaGame(wagersState.game), betslipState[toBetSlipKey(wagersState.game)])}
                    </SubtitleText>
                    <SubtitleText>Total Cost: £{getOneTimeAmount()}</SubtitleText>
                </SectionContainer>
            )}

            {paymentStep === 'details' && (paymentMethodOptions === undefined || paymentMethodOptions.paymentMethods) && (
                <SectionContainer>
                    <TitleText>SELECT PAYMENT TYPE</TitleText>
                    <PaymentTypesSlimView
                        defaultCheckedOption={currentPaymentMethod}
                        paymentTypes={paymentMethodOptions?.paymentMethods}
                        onClickPaymentType={type => {
                            if (currentPaymentMethod != type) {
                                setIsLoading(true);
                                setCurrentPaymentMethod(type);
                            }
                        }}
                    />
                </SectionContainer>
            )}

            {(paymentStep === 'details' || paymentStep === 'confirming') && (
                <SectionContainer>
                    <SecurePaymentsContainer>
                        <img src="/padlock.svg" style={{ marginRight: '5px' }} />
                        SECURE PAYMENTS: We value your security
                    </SecurePaymentsContainer>
                    {wagersState.stage === 'authorising' && wagersState.finaliseDetails ? (
                        <AuthoriseCardFormBms
                            token={wagersState.finaliseDetails.cardConfirmToken}
                            url={wagersState.finaliseDetails.cardConfirmUrl}
                            onSuccess={onAuthoriseSuccess}
                            onError={onAuthoriseError}
                        />
                    ) : currentPaymentMethod === 'paypal' ? (
                        <PayPalForm
                            game={wagersState.game}
                            onSubmitForm={onSubmitPayPalForm}
                            apiErrors={payPalErrors}
                            setApiErrors={setPayPalErrors}
                            token={wagersState.payPalToken}
                        />
                    ) : currentPaymentMethod === 'card' ? (
                        <CardForm
                            game={wagersState.game}
                            onSubmitForm={onSubmitCardForm}
                            apiErrors={cardErrors}
                            setApiErrors={setCardErrors}
                        />
                    ) : paymentMethodOptions?.hasExistingDirectDebit ? (
                        <ExistingDirectDebitForm
                            game={wagersState.game}
                            onSubmitForm={onSubmitDirectDebitForm}
                            apiErrors={directDebitErrors}
                            setApiErrors={setDirectDebitErrors}
                        />
                    ) : (
                        <DirectDebitForm
                            game={wagersState.game}
                            onSubmitForm={onSubmitDirectDebitForm}
                            apiErrors={directDebitErrors}
                            setApiErrors={setDirectDebitErrors}
                        />
                    )}
                    {!hasSpendLimit && (
                        <FinancialLimitsContainer>
                            <PaymentStepBackContainer
                                onClick={() => {
                                    dispatch(openPopup('spendLimit'));
                                }}
                            >
                                Set Spend Limit
                            </PaymentStepBackContainer>
                        </FinancialLimitsContainer>
                    )}
                    <PaymentStepBackContainer
                        onClick={() => {
                            dispatch(resetWagers({ game: wagersState.game }));
                            dispatch(closePopup('payment'));
                        }}
                    >
                        Back
                    </PaymentStepBackContainer>
                </SectionContainer>
            )}
            {paymentStep === 'confirm' && (
                <SectionContainer style={{ minHeight: '500px', justifyContent: 'flex-start' }}>
                    <SubtitleText fontSize="30px">YOU&apos;RE IN!</SubtitleText>
                    <IconCheckMark height="50px" />
                    <ConfirmationContainer></ConfirmationContainer>
                    {betslipState[toBetSlipKey(wagersState.game)][0] &&
                        !isHdaGame(wagersState.game) &&
                        wagersState.game != 'classic-pools' && (
                            <>
                                <SubtitleText>Your Selections</SubtitleText>
                                <BetSelectionsConfirmationContainer style={{ maxHeight: undefined, height: '250px' }}>
                                    <BetSelectionsScrollContent>
                                        {(betslipState[toBetSlipKey(wagersState.game)] as BetSlip[]).map(
                                            (b, index) =>
                                                b.numbers &&
                                                b.numbers.length > 0 && (
                                                    <>
                                                        <Button
                                                            role="button"
                                                            onClick={() => {
                                                                console.log('set show fixtures', index);
                                                                setShowFixtures(
                                                                    typeof showFixtures !== 'undefined' &&
                                                                        showFixtures === index
                                                                        ? undefined
                                                                        : index,
                                                                );
                                                            }}
                                                            width="40%"
                                                            height="20px"
                                                            bgColor="#861b1b"
                                                            disabledBackgroundColour="#861b1b"
                                                            disabledOpacity="0.5"
                                                            hoverColor="#861b1b"
                                                            hoverOpacity="0.5"
                                                            padding="0"
                                                            textColor="#fff"
                                                            fontWeight="bold"
                                                            rounded="25px"
                                                            margin="10px"
                                                            style={{ flexGrow: 0 }}
                                                        >
                                                            {typeof showFixtures !== 'undefined' &&
                                                            showFixtures === index
                                                                ? `View Numbers`
                                                                : `View Fixtures`}
                                                        </Button>
                                                        {typeof showFixtures !== 'undefined' &&
                                                        showFixtures === index ? (
                                                            <GameSection
                                                                isHda={false}
                                                                fixtures={getFixturesForBet(b)}
                                                                betslipSelection={b}
                                                                gameViewType={
                                                                    wagersState.game === 'lucky-clover'
                                                                        ? 'numbers'
                                                                        : 'match'
                                                                }
                                                                isViewLines={false}
                                                                isClover={wagersState.game === 'lucky-clover'}
                                                                matchCardWidth="45%"
                                                            />
                                                        ) : (
                                                            <BetSelections
                                                                key={`bet-selection-${index}`}
                                                                bet={b as BetSlip}
                                                                game={wagersState.game}
                                                                displayId={!isHdaGame(wagersState.game)}
                                                                justifyContent="center"
                                                                betslipItemSize={'2.5em'}
                                                                selectionsColour={
                                                                    wagersState.game === 'lucky-clover'
                                                                        ? '#00955C'
                                                                        : undefined
                                                                }
                                                                bonusSelectionsColour="#e0ac00"
                                                                isCurrentSelectedLine={true}
                                                            />
                                                        )}
                                                    </>
                                                ),
                                        )}
                                    </BetSelectionsScrollContent>
                                </BetSelectionsConfirmationContainer>
                            </>
                        )}
                    <Button
                        role="button"
                        onClick={() => onConfirm('/account/history')}
                        width="90%"
                        height="50px"
                        bgColor="#7cda24"
                        disabledBackgroundColour="#7cda24"
                        disabledOpacity="0.5"
                        hoverColor="#7cda24"
                        hoverOpacity="0.5"
                        padding="0.75em 1.25em"
                        textColor="#fff"
                        fontWeight="bold"
                        rounded="25px"
                        margin="10px"
                        style={{ flexGrow: 0 }}
                    >
                        {`VIEW MY ACCOUNT`}
                    </Button>
                    <Button
                        role="button"
                        onClick={() => onConfirm('/home')}
                        width="90%"
                        height="50px"
                        bgColor="#7cda24"
                        disabledBackgroundColour="#7cda24"
                        disabledOpacity="0.5"
                        hoverColor="#7cda24"
                        hoverOpacity="0.5"
                        padding="0.75em 1.25em"
                        textColor="#fff"
                        fontWeight="bold"
                        rounded="25px"
                        margin="10px"
                        style={{ flexGrow: 0 }}
                    >
                        {`RETURN TO HOME PAGE`}
                    </Button>
                </SectionContainer>
            )}
        </SectionsContainer>
    );
};

const BetSelectionsScrollContent = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
    position: absolute;
    top: 0;
`;
