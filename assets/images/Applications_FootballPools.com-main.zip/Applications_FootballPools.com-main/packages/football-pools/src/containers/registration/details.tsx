/* eslint-disable import/named */
import { useState, useEffect } from 'react';
import { useForm, Controller, ErrorMessage } from 'react-hook-form';
import { useSelector, useDispatch } from 'react-redux';
import { RadioGroup } from '@fp/shared/src/components/RadioGroup/RadioGroup';
import { titleOptions } from '@fp/shared/src/settings/titleOptions';
import { StateHighlightInput, getInputState } from '@fp/shared/src/components/Forms/Inputs/StateHighlightInput';
import { RecursivePartial } from '@fp/shared/src/testing/utils/RecursivePartial';
import { FormRow } from '@fp/shared/src/components/Forms/Inputs';
import styled, { DefaultTheme, ThemeProvider } from 'styled-components';
import { Button } from '@fp/shared/src/components/Button/Button';
import { countryCodes } from '@fp/shared/src/settings/countryCodes';
import { Select } from '@fp/shared/src/components/Forms/Inputs/Select';
import { numberPrefixes } from '@fp/shared/src/settings/numberPrefixes';
import { ErrorMsg } from '@containers/account/changeEmailForm';
import { isAppError } from '@fp/shared/src/core/appError';
import { UpdateDetailsRequest, updateUserDetails, logout as apiLogout } from '@fp/shared/src/api/account';
import { useRouter } from 'next/router';
import { AddressPickerPopup } from '@fp/shared/src/components/Popup/AddressPickerPopup';
import { Address } from '@api/addressFinder';
import { redirectUrlSelector } from '@fp/shared/src/features/registration/registrationSelector';
import { Loader } from '@fp/shared/src/components/Loader/Loader';
import { getWagersSelector, WagersSlice, resetWagers } from '@sportech/pools-api';
import {
    userDetailsSelector,
    getAuthenticationSelector,
} from '@fp/shared/src/features/authentication/authenticationSelectors';
import { addUserDetails, logout } from '@fp/shared/src/features/authentication/authenticationSlice';
import { clearRedirectUrl } from '@fp/shared/src/features/registration/registrationSlice';
import { useTags } from '@fp/shared/src/core/tags';
import { setCookie } from '@services/cookies';
import { testId, openPopup, closePopup } from '@sportech/pools-components';
import { CheckFindTooltip } from '@containers/registration/CheckFindTooltip';
import { FailedLoginRegPopup } from '@fp/shared/src/components/Popup/FailedLoginRegPopup';
import { getMonthName } from '@fp/shared/src/lib/utils';

// eslint-disable-next-line import/default
import dayjs from 'dayjs';

const Form = styled.form`
    display: flex;
    flex-direction: column;
    align-items: center;
    > * {
        margin-bottom: 1rem;
        margin-right: 0;
    }

    background: #000d68;
    color: #ffffff;
`;

const ManualAddressText = styled.span<{ show: boolean }>`
    display: ${props => (props.show === true ? '' : 'none')};
    cursor: pointer;
    align-self: flex-end;
    margin-top: -1.25rem;
    text-decoration: underline;
`;

const registrationTheme = (theme: DefaultTheme): DefaultTheme => ({
    ...theme,
    colours: { ...theme.colours, primary: '#fff' },
});

const StyledSelect = styled(Select)`
    height: auto;
    justify-content: flex-end;
    color: #000;
    margin: 0;
    min-width: 0;
    flex: 0 0 30%;

    label {
        font-weight: 800;
        margin-bottom: 6px;
    }

    .react-select__control {
        height: 40px;
    }
`;

const MobileNumberContainer = styled.div`
    width: 100%;
    * {
        margin: 0;
    }
`;

const InlineFormButton = styled(Button)`
    height: 40px;
    margin-bottom: 10px;
    margin-left: -20px;
    border-radius: 0;
    border: 1px solid #fff;
    border-left: 0;
`;

const SubmitButton = styled(Button)`
    height: 52px;
    width: 100%;
`;

const AddressDisplay = styled.p<{ show: boolean }>`
    display: ${props => (props.show === true ? '' : 'none')};
    width: 70%;
    text-transform: uppercase;
    font-weight: 700;
    margin: 20px 0px 20px 0px;
`;

const PostcodeRow = styled(FormRow)<{ show: boolean }>`
    display: ${props => (props.show === true ? '' : 'none')};
`;

const ManualAddressGroup = styled.div<{ show: boolean }>`
    display: ${props => (props.show === true ? '' : 'none')};
    width: 100%;
    margin-bottom: 0;

    > * {
        margin-bottom: 1rem;
    }
`;

const ButtonIcon = styled.img`
    height: 18px;
    width: auto;
`;

const DateOfBirthContainer = styled(FormRow)`
    justify-content: space-between;
`;

const AddressPickerContainer = styled.div`
    width: 100%;
    position: relative;
`;

const AddressPickerInputContainer = styled.div`
    display: flex;
    align-items: flex-end;
`;

const AddressPickerButtonContainer = styled.div`
    width: 100%;
    text-align: end;
`;
interface FormData {
    title: string;
    firstName: string;
    lastName: string;
    dateOfBirth: {
        day: { value: number; label: string };
        month: { value: number; label: string };
        year: { value: number; label: string };
        value: string;
    };
    address: {
        line1: string;
        line2: string;
        line3: string;
        countryCode: { value: string; label: string };
        manualPostcode: string;
        postcode: string;
        entered: boolean;
    };
    mobile: {
        prefix: { value: string; label: string };
        number: string;
    };
}

const defaultValues: RecursivePartial<FormData> = {
    title: titleOptions[0].id,
    address: { countryCode: countryCodes.find(cc => cc.value === 'GB') },
    mobile: { prefix: numberPrefixes.find(p => p.value === '44') },
};

const parseFormData = ({
    title,
    firstName,
    lastName,
    dateOfBirth,
    address,
    mobile,
}: FormData): UpdateDetailsRequest => ({
    title,
    firstName,
    lastName,
    dateOfBirth: new Date(dateOfBirth.value),
    mobileNumber: mobile.number,
    mobileNumberPrefix: mobile.prefix.value,
    postcode: address.manualPostcode,
    addressLine1: address.line1,
    addressLine2: address.line2,
    city: address.line3,
    countryCode: address.countryCode?.value,
});

function useDobValidation(values: FormData) {
    let isOver18 = true;

    if (values.dateOfBirth !== undefined) {
        const dobDay = values.dateOfBirth.day.value;
        const dobMonth = values.dateOfBirth.month.value;
        const dobYear = values.dateOfBirth.year.value;

        const eighteenthBirthday = new Date(dobYear + 18, dobMonth, dobDay);
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        if (yesterday < eighteenthBirthday) isOver18 = false;
    }

    return { isOver18 };
}

export const cameFromGamePage = (wagersSlice: WagersSlice) =>
    wagersSlice.stage === 'initialised' && wagersSlice.wagers.length > 0;

const StepCounter = styled.span`
    margin-bottom: 0;
    font-weight: 800;
`;

const Titles = styled(RadioGroup)`
    font-weight: 800;
    height: 40px;
    > * {
        color: #000d68;
        padding: 0;
        display: grid;
        place-items: center;
        cursor: pointer;
    }
`;

const Row = styled(FormRow)`
    align-items: flex-end;
`;

const MobileErrorMessage = styled.div`
    margin-top: 10px;
`;

const FullWidthContainer = styled.div`
    width: 100%;
`;

export const RegistrationDetails = () => {
    const router = useRouter();

    const auth = useSelector(getAuthenticationSelector);
    const userDetails = useSelector(userDetailsSelector);
    const redirectUrl = useSelector(redirectUrlSelector);
    const dispatch = useDispatch();
    const [redirectTriggered, setRedirectTriggered] = useState<boolean>(false);

    const handleLoginRedirect = (url?: string) => {
        if (url && !url.includes(router.asPath) && !redirectTriggered) {
            setRedirectTriggered(true);
            router.push(url);
            if (url) {
                dispatch(clearRedirectUrl());
            }
        }
    };

    useEffect(() => {
        if (auth.isFetching) return;
        if (!auth.isLoggedIn) {
            router.replace('/registration');
        }
        if (userDetails && userDetails.firstName) {
            console.debug('details1: handling login redirect useEffect', redirectUrl);
            handleLoginRedirect(redirectUrl ? redirectUrl : '/');
        }
    }, [userDetails]);

    const { register, errors, formState, watch, control, setValue, setError, clearError, handleSubmit } = useForm<
        FormData
    >({
        mode: 'onChange',
        defaultValues,
    });

    const values = watch({ nest: true });
    const wagersSlice = useSelector(getWagersSelector);
    const maxStep = cameFromGamePage(wagersSlice) ? '3' : '2';

    const [isEnteringAddressManually, setIsEnteringAddressManually] = useState<boolean>(false);
    const [tooltipOpen, setTooltipOpen] = useState<boolean>(false);
    const [addressDisplayText, setAddressDisplayText] = useState<string>('');
    const [toggleShakeTooltip, setToggleShakeTooltip] = useState<boolean>(false);
    const [apiErrorText, setApiErrorText] = useState<string | undefined>(undefined);
    const [apiErrorTitle, setApiErrorTitle] = useState<string>('');
    const [dayOptions, setDayOptions] = useState<
        {
            value: number;
            label: string;
        }[]
    >(dobDays);

    register('dateOfBirth.value', {
        required: { value: true, message: 'Please enter your date of birth' },
        validate: () => (validateDob() ? undefined : 'You must be 18 or over to register'),
    });
    register('address.entered', {
        required: { value: !values.address.entered, message: 'Please select your address' },
    });

    const validatePostcode = (value: string): boolean => {
        const postcode = value || '';
        const length = postcode.replace(/ /g, '').length;
        if (length < 5 || length > 7) {
            return false;
        }

        const postcodeRegExp = new RegExp(
            '([Gg][Ii][Rr] 0[Aa]{2})|((([A-Za-z][0-9]{1,2})|(([A-Za-z][A-Ha-hJ-Yj-y][0-9]{1,2})|\\s*|(([A-Za-z][0-9][A-Za-z])|([A-Za-z][A-Ha-hJ-Yj-y][0-9][A-Za-z]?))))s?[0-9][A-Za-z]{2})',
        );
        const isValidPostcode = postcodeRegExp.test(postcode);

        return isValidPostcode;
    };

    const getAddressDisplayText = (): string =>
        values.address.line1 && values.address.line2 && values.address.manualPostcode
            ? `${values.address.line1}, ${values.address.line2}, ${values.address.line3} ${values.address.manualPostcode}`
            : '';

    const onAddressPicked = (address: Address): void => {
        setTooltipOpen(false);
        setValue('address.entered', true, true);
        setValue('address.line1', address.addressLine1, true);
        setValue('address.line2', address.addressLine2, true);
        setValue('address.line3', address.addressLine3, true);
        setValue('address.manualPostcode', address.postcode, true);
        setValue(
            'address.countryCode',
            countryCodes.find(cc => cc.value === address.countryCode),
            true,
        );
    };

    const validateDob = (): boolean => {
        const dateOfBirth = values.dateOfBirth;
        if (!dateOfBirth) return false;
        const { day, month, year } = dateOfBirth;
        if (month !== undefined) {
            const daysInMonth = dayjs()
                .year(year?.value || 2000)
                .month(month.value)
                .daysInMonth();
            if (dayOptions.length != daysInMonth) {
                const newDayOptions = new Array(daysInMonth)
                    .fill(0)
                    .map((_, index) => ({ value: index + 1, label: (index + 1).toString() }));
                setDayOptions(newDayOptions);
                if (day !== undefined && day.value > daysInMonth) {
                    setValue('dateOfBirth.day', newDayOptions[daysInMonth - 1], false);
                }
            }
        }
        if (day === undefined || month === undefined || year === undefined) return false;
        if (errors.dateOfBirth && errors.dateOfBirth.value?.type == 'required') {
            clearError('dateOfBirth.value');
        }

        setValue(
            'dateOfBirth.value',
            new Date(dateOfBirth.year.value, dateOfBirth.month.value, dateOfBirth.day.value).toDateString(),
        );

        const { isOver18 } = useDobValidation(values);

        if (!isOver18 && !errors.dateOfBirth) {
            setError('dateOfBirth.day', 'dob');
            setError('dateOfBirth.month', 'dob');
            setError('dateOfBirth.year', 'dob');
            setError('dateOfBirth.value', 'dob', 'You must be 18 or over to register');
            return false;
        } else if (isOver18 && errors.dateOfBirth) {
            clearError('dateOfBirth');
        }
        return isOver18 && !errors.dateOfBirth;
    };

    useEffect(() => {
        setAddressDisplayText(getAddressDisplayText);
    }, [values.address]);

    const { isSubmitting } = formState;

    useEffect(() => {
        validateDob();
    }, [values.dateOfBirth?.day, values.dateOfBirth?.month, values.dateOfBirth?.year]);

    const onPopupOk = async (): Promise<void> => {
        setCookie('_clubFpToken', '', -1);
        await apiLogout();
        dispatch(logout());
        dispatch(resetWagers({}));
        router.push('/contact-us');
    };

    const onSubmit = async (formData: FormData): Promise<void> => {
        if (formState.isSubmitting) return;

        const requestData = parseFormData(formData);
        const response = await updateUserDetails(requestData);
        const { registrationSuccess, registrationDetailsError } = useTags();

        if (isAppError(response)) {
            const apiError = response.apiError;
            console.log('details error', apiError);
            if (apiError?.title?.includes('address')) {
                setError('address.postcode', 'api', apiError.detail);
                setError('address.manualPostcode', 'api', apiError.detail);
            }
            if (apiError?.code === 'invalid_postcode') {
                setError('address.postcode', 'api', 'Postcode is an invalid UK Postcode');
                setError('address.manualPostcode', 'api', 'Postcode is an invalid UK Postcode');
            }
            if (apiError) {
                const errorString = 'Please contact our Customer Services for more information.';
                setApiErrorText(errorString);
                const errorTitle = `You're almost there ${formData.firstName}! ID required to play.`;
                dispatch(openPopup('registrationFailed'));
                setApiErrorTitle(errorTitle);
            }
            registrationDetailsError(apiError?.detail || apiError?.title || apiError?.code);
        } else {
            dispatch(addUserDetails(response));
            registrationSuccess();
            setCookie('_fpSubsNewlyRegistered', 'true', 30);
        }
    };

    return (
        <>
            <Loader isLoading={isSubmitting} backgroundColour={'rgba(0,0,0,0.5)'} position={'fixed'} />
            <Form onSubmit={handleSubmit(onSubmit)}>
                <StepCounter>Sign up - Step 2 of {maxStep}</StepCounter>
                <Titles name="title" id="title" ref={register({ required: true })} options={titleOptions} />
                <StyledInput
                    name="firstName"
                    id="firstName"
                    label="First Name"
                    ref={register({
                        required: 'Please enter your First Name',
                        pattern: {
                            value: /^[a-zA-Z \-_']*$/,
                            message: 'Contains invalid characters',
                        },
                    })}
                    state={getInputState(values.firstName, errors.firstName)}
                    autoFocus
                />
                <ErrorMessage name="firstName" errors={errors} as={ErrorMsg} />
                <StyledInput
                    name="lastName"
                    id="lastName"
                    label="Last Name"
                    ref={register({
                        required: 'Please enter your Last Name',
                        pattern: {
                            value: /^[a-zA-Z \-_']*$/,
                            message: 'Contains invalid characters',
                        },
                    })}
                    state={getInputState(values.lastName, errors.lastName)}
                />
                <ErrorMessage name="lastName" errors={errors} as={ErrorMsg} />
                <PostcodeRow show={!isEnteringAddressManually}>
                    <FullWidthContainer>
                        <Row>
                            <AddressPickerContainer>
                                <AddressPickerInputContainer>
                                    <StyledInput
                                        width={'100%'}
                                        margin={'0 0 10px 0'}
                                        name="address.postcode"
                                        id="address.postcode"
                                        label="Postcode"
                                        ref={register}
                                        state={getInputState(values.address.postcode, errors?.address?.postcode)}
                                    />

                                    <AddressPickerButtonContainer>
                                        <CheckFindTooltip isOpen={tooltipOpen} shake={toggleShakeTooltip} />
                                        <AddressPickerPopup
                                            postcode={values.address.postcode}
                                            onSelected={onAddressPicked}
                                            trigger={
                                                <InlineFormButton
                                                    type="button"
                                                    width={'100%'}
                                                    bgColor="#010d68"
                                                    {...testId('registration-details_address-picker')}
                                                >
                                                    Find <ButtonIcon src="/search_magnify.png" />
                                                </InlineFormButton>
                                            }
                                        />
                                    </AddressPickerButtonContainer>
                                </AddressPickerInputContainer>
                            </AddressPickerContainer>
                        </Row>
                        <ErrorMessage name="address.entered" errors={errors} as={ErrorMsg} />
                    </FullWidthContainer>
                </PostcodeRow>
                <ManualAddressText
                    show={!isEnteringAddressManually}
                    onClick={() => {
                        setIsEnteringAddressManually(true);
                        setValue('address.entered', true, true);
                        setValue('address.countryCode', defaultValues.address?.countryCode, true);
                    }}
                >
                    Enter Address manually
                </ManualAddressText>
                <ManualAddressGroup show={isEnteringAddressManually}>
                    <StyledInput
                        name="address.line1"
                        id="address.line1"
                        label="Address Line 1"
                        ref={register({ required: { value: true, message: 'Please enter your 1st address line' } })}
                        state={getInputState(values.address.line1, errors?.address?.line1)}
                    />
                    <ErrorMessage name="address.line1" errors={errors} as={ErrorMsg} />
                    <StyledInput
                        name="address.line2"
                        id="address.line2"
                        label="Address Line 2"
                        ref={register({ required: { value: true, message: 'Please enter your 2nd address line' } })}
                        state={getInputState(values.address.line2, errors?.address?.line2)}
                    />
                    <ErrorMessage name="address.line2" errors={errors} as={ErrorMsg} />
                    <StyledInput
                        name="address.line3"
                        id="address.line3"
                        label="Address Line 3"
                        ref={register}
                        state={getInputState(values.address.line3, errors?.address?.line3)}
                    />
                    <StyledInput
                        name="address.manualPostcode"
                        id="address.manualPostcode"
                        label="Postcode"
                        ref={register({
                            required: 'Please enter your Postcode',
                            validate: value => (validatePostcode(value) ? undefined : 'Please enter a valid Postcode'),
                        })}
                        state={getInputState(values.address.manualPostcode, errors?.address?.manualPostcode)}
                    />
                    <ErrorMessage name="address.manualPostcode" errors={errors} as={ErrorMsg} />
                    <ThemeProvider theme={registrationTheme}>
                        <Controller
                            as={
                                <StyledSelect
                                    id="address.countryCode"
                                    label="Country"
                                    options={countryCodes}
                                    value={values.address.countryCode}
                                />
                            }
                            name="address.countryCode"
                            control={control}
                            onChange={([selected]) => selected}
                            rules={{ required: true }}
                        />
                    </ThemeProvider>
                </ManualAddressGroup>
                <AddressDisplay show={!isEnteringAddressManually && addressDisplayText.length > 0}>
                    {addressDisplayText}
                </AddressDisplay>
                <FullWidthContainer>
                    <Row>
                        <ThemeProvider theme={registrationTheme}>
                            <Controller
                                as={
                                    <StyledSelect
                                        id="mobile.prefix"
                                        options={numberPrefixes}
                                        label="Mobile number"
                                        width="60%"
                                        isClearable={false}
                                    />
                                }
                                name="mobile.prefix"
                                control={control}
                                onChange={([selected]) => selected}
                                rules={{ required: true }}
                            />
                        </ThemeProvider>
                        <MobileNumberContainer>
                            <StyledInput
                                id="mobile.number"
                                name="mobile.number"
                                type="tel"
                                ref={register({
                                    required: { value: true, message: 'Please enter your Mobile number' },
                                    pattern: {
                                        value: /^0?7[0-9]{9}$/,
                                        message: 'Invalid mobile number',
                                    },
                                })}
                                state={getInputState(values.mobile.number, errors.mobile?.number)}
                            />
                        </MobileNumberContainer>
                    </Row>
                    <MobileErrorMessage>
                        <ErrorMessage name="mobile.number" errors={errors} as={ErrorMsg} />
                    </MobileErrorMessage>
                </FullWidthContainer>
                <DateOfBirthContainer>
                    <ThemeProvider theme={registrationTheme}>
                        <Controller
                            as={
                                <StyledSelect
                                    id="dobDay"
                                    options={dayOptions}
                                    placeholder="DD"
                                    label="Date of Birth"
                                    isClearable={false}
                                    {...testId('registration-details_dob-day')}
                                    state={getInputState(values.dateOfBirth?.value, errors.dateOfBirth?.value)}
                                />
                            }
                            name="dateOfBirth.day"
                            control={control}
                            onChange={([selected]) => selected}
                            rules={{ required: true }}
                            {...testId('registration-details_dob-day')}
                        />
                        <Controller
                            as={
                                <StyledSelect
                                    id="dobMonth"
                                    options={dobMonths}
                                    placeholder="MM"
                                    isClearable={false}
                                    state={getInputState(values.dateOfBirth?.value, errors.dateOfBirth?.value)}
                                />
                            }
                            name="dateOfBirth.month"
                            control={control}
                            onChange={([selected]) => selected}
                            rules={{ required: true }}
                        />
                        <Controller
                            as={
                                <StyledSelect
                                    id="dobYear"
                                    options={dobYears}
                                    placeholder="YYYY"
                                    isClearable={false}
                                    state={getInputState(values.dateOfBirth?.value, errors.dateOfBirth?.value)}
                                />
                            }
                            name="dateOfBirth.year"
                            control={control}
                            onChange={([selected]) => selected}
                            rules={{ required: true }}
                        />
                    </ThemeProvider>
                </DateOfBirthContainer>
                <ErrorMessage name="dateOfBirth.value" errors={errors} as={ErrorMsg} />
                <SubmitButton
                    onClick={() => {
                        if (errors != null) {
                            if (values.address.postcode != '' && !values.address.entered) {
                                setTooltipOpen(true);
                                setToggleShakeTooltip(!toggleShakeTooltip);
                            }
                        }
                    }}
                    rounded
                    bgColor="#7CDA24"
                    {...testId('registration-details_submit-button')}
                >
                    Sign up
                </SubmitButton>
                <ErrorMessage name="general" errors={errors} as={ErrorMsg} />
            </Form>
            <FailedLoginRegPopup
                popupName="registrationFailed"
                popupTitle={apiErrorTitle}
                onOkClick={onPopupOk}
                onPopupClose={() => dispatch(closePopup('registrationFailed'))}
                apiError={
                    apiErrorText ||
                    'Sorry, your account registration has not been successful. Please contact our Customer Services for more information.'
                }
            />
        </>
    );
};

const StyledInput = styled(StateHighlightInput).attrs(() => ({
    labelTextColour: '#fff',
    labelFontWeight: 800,
    height: 'auto',
}))`
    height: 40px;
    margin-top: 6px;
`;

const maxYear = new Date().getFullYear() - 18;
const dobYears = new Array(82).fill(0).map((_, index) => {
    const year = maxYear - index;
    return { value: year, label: year.toString() };
});

const dobMonths = new Array(12).fill(0).map((_, index) => ({ value: index, label: getMonthName(index) }));

const dobDays = new Array(31).fill(0).map((_, index) => ({ value: index + 1, label: (index + 1).toString() }));
