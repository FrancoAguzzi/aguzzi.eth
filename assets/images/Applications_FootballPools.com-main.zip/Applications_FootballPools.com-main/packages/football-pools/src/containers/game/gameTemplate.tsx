/* eslint-disable import/named */
import {
    BetSlip,
    BetSlipSlice,
    Competition,
    GameType,
    Offering,
    Offerings,
    PoolsApiError,
    toBetSlipKey,
    Wager,
    Wagers,
    WagersSlice,
} from '@sportech/pools-api';
import { GameViewType, ViewLinesCurrent } from '@sportech/pools-components';
import { BuilderGamePageBanner, ContentItem } from '@fp/shared/src/core/gamePage.builder';
import { DefaultTheme } from 'styled-components';
import { useGameTemplate, GameTemplateComponent } from './game.template';
import { useMinigameTemplate, MinigameTemplate } from './minigame';
import { AuthenticationState } from '@fp/shared/src/features/authentication/authenticationSlice';
import { AppDispatch } from '@fp/shared/src/store';
import { Component, FunctionComponent, RefObject } from 'react';
import { useGameCouponTemplate } from './coupon.template';

export interface GameTemplateProps {
    competitions: Competition[];
    offers: Offerings;
    game: GameType;
    gameDescription?: string;
    gameKeywords?: string;
    gameViewType?: GameViewType;
    showFutureGames?: boolean;
    headerHeight?: number;
    onlyDefaultOffer?: boolean;
    canAddMultipleLines?: boolean;
    banner?: BuilderGamePageBanner;
    howToPlay?: ContentItem;
    termsAndConditions?: ContentItem;
    howToManageLines?: ContentItem;
    termsContent?: string;
    viewLinesOffers?: Offerings;
    gameEnabled?: boolean;
    gamePath?: string;
    showMobilePrice?: boolean;
    competitionTypeDescription?: string;
    background?: {
        colour?: string;
        img?: string;
        rightPanelImg?: string;
        mainPanelBackgroundImg?: string;
    };
    paymentTypes?: ('subscription' | 'one-time-payment')[];
    maximumLines?: number;
    costTypeDescription?: string;
    minimumCost?: number;
    // app state:
    // dispatch: AppDispatch;
    betslipState: BetSlipSlice;
    betslipGameType: keyof BetSlipSlice;
    wagersState: WagersSlice;
    userState: AuthenticationState;
    // actions:
    changeCompetition: (id: number, name: string) => void;
    changeCurrentBet: (index: number) => void;
    clearLine: (index?: number, isCurrent?: boolean) => void;
    addLine: () => void;
    selectAmount: (id: number, offer: Offering) => void;
    selectLuckyDip: (isBonus?: boolean, noSelectionsMade?: boolean) => void;
    selectPrediction: (id: number, type: string) => void;
    selectPlay: (ev?: Event, cloverUpsellOverride?: boolean, redirect?: 'registration' | 'login') => void;
    setCanEditLine: (canEdit: boolean) => void;
    setCurrentOfferingId: (id: number) => void;
    setEditLineAllFutureGames: (allGames: boolean) => void;
    setIsLoading: (loading: boolean) => void;
    setNumberOfGames: (noOfGames: number) => void;
    setShowFutureCompetitions: (show: boolean) => void;
    setShowMore: (show: boolean) => void;
    setShowSlideBoard: (show: boolean) => void;
    setShowWagerFixtures: (show: boolean) => void;
    setShowWagers: (show: boolean) => void;
    setViewLinesCurrent: (current: ViewLinesCurrent) => void;
    fetchWagers: () => void;
    handleUpdateWager: () => Promise<void>;
    resetBetslipWagerSelections: () => void;
    setPaymentTypeFlow: (flow: 'subscription' | 'one-time-payment') => void;
    setManualBetSwitching?: (manualSwitch: boolean) => void;
    // ui state:
    betslipWager?: BetSlip;
    betslipWagerHasEdits: boolean;
    canEditLine: boolean;
    currentOfferingId?: number;
    editLineAllFutureGames: boolean;
    editWagerError?: PoolsApiError;
    isLoading: boolean;
    isMobileOrTablet: boolean;
    numberOfGames?: number;
    showFutureCompetitions: boolean;
    showHda: boolean;
    showMore: boolean;
    showSlideBoard: boolean;
    showWagerFixtures: boolean;
    showWagers: boolean;
    viewLinesCurrent: ViewLinesCurrent;
    wagers: Wagers;
    wagersForCompetitions: Wager[];
    paymentTypeFlow: 'subscription' | 'one-time-payment';
    currentGameViewType: GameViewType;
    setCurrentGameViewType: (viewType: GameViewType) => void;
    useCouponButtons?: boolean;
    isOneTime?: boolean;
}

export interface GameTemplate {
    renderBackground?: () => JSX.Element;
    renderBannerPanel?: (
        game?: GameType,
        banner?: BuilderGamePageBanner,
        paymentTypes?: ('subscription' | 'one-time-payment')[],
        isMobileOrTablet?: boolean,
        headerHeight?: number,
        nextGameDate?: string,
        poolSize?: string,
        gameVariant?: string,
    ) => JSX.Element;
    renderHeaderPanel?: (
        game: GameType,
        betslipState: BetSlipSlice,
        betslipGameType: keyof BetSlipSlice,
        fetchWagers: () => void,
        setShowWagers: (show: boolean) => void,
        changeCurrentBet: (index: number) => void,
        clearLine: (index?: number) => void,
        addLine: () => void,
        showHda: boolean,
        selectAmount: (id: number, offer: Offering) => void,
        selectLuckyDip: (isBonus?: boolean, noSelectionsMade?: boolean) => void,
        offers: Offerings,
        setCurrentOfferingId: (id: number) => void,
        setShowMore: (show: boolean) => void,
        showMore: boolean,
        wagersForCompetitions: Wager[],
        selectPlay: (ev?: Event, cloverUpsellOverride?: boolean) => void,
        canAddMultipleLines?: boolean,
        showWagers?: boolean,
        canEditLine?: boolean,
        isMobileOrTablet?: boolean,
        howToPlay?: ContentItem,
        currentOfferingId?: number,
    ) => JSX.Element;
    renderMobileHeaderPanel?: (
        game: GameType,
        betslipState: BetSlipSlice,
        betslipGameType: keyof BetSlipSlice,
        userState: AuthenticationState,
        fetchWagers: () => void,
        setShowWagers: (show: boolean) => void,
        changeCurrentBet: (index: number) => void,
        clearLine: (index?: number) => void,
        addLine: () => void,
        handleUpdateWager: () => Promise<void>,
        resetBetslipWagerSelections: () => void,
        showHda: boolean,
        selectAmount: (id: number, offer: Offering) => void,
        selectLuckyDip: (isBonus?: boolean, noSelectionsMade?: boolean) => void,
        selectPrediction: (id: number, type: string) => void,
        offers: Offerings,
        setCurrentOfferingId: (id: number) => void,
        setEditLineAllFutureGames: (allGames: boolean) => void,
        setShowMore: (show: boolean) => void,
        betslipWagerHasEdits: boolean,
        editLineAllFutureGames: boolean,
        showMore: boolean,
        viewLinesCurrent: ViewLinesCurrent,
        wagersForCompetitions: Wager[],
        selectPlay: (ev?: Event, cloverUpsellOverride?: boolean) => void,
        canAddMultipleLines?: boolean,
        showMobilePrice?: boolean,
        showWagers?: boolean,
        canEditLine?: boolean,
        isMobileOrTablet?: boolean,
        howToPlay?: ContentItem,
        currentOfferingId?: number,
        betslipWager?: BetSlip,
        competitionTypeDescription?: string,
    ) => JSX.Element;
    renderMainPanel?: (
        game: GameType,
        betslipState: BetSlipSlice,
        betslipGameType: keyof BetSlipSlice,
        showHda: boolean,
        changeCompetition: (id: number, name: string) => void,
        clearLine: (index?: number) => void,
        selectAmount: (id: number, offer: Offering) => void,
        selectLuckyDip: (isBonus?: boolean, noSelectionsMade?: boolean) => void,
        selectPlay: (event?: Event, cloverUpsellOverride?: boolean) => void,
        selectPrediction: (id: number, type: string) => void,
        competitions: Competition[],
        offers: Offerings,
        setCurrentOfferingId: (id: number) => void,
        setNumberOfGames: (noOfGames: number) => void,
        setShowMore: (show: boolean) => void,
        setShowSlideBoard: (show: boolean) => void,
        showFutureGames: boolean,
        showSlideBoard: boolean,
        wagersForCompetitions: Wager[],
        showWagers?: boolean,
        canEditLine?: boolean,
        currentOfferingId?: number,
        betslipWager?: BetSlip,
        competitionTypeDescription?: string,
        gameDescription?: string,
        gameViewType?: GameViewType,
        onlyDefaultOffer?: boolean,
        numberOfGames?: number,
    ) => JSX.Element;
    renderSidePanel?: (
        game: GameType,
        betslipState: BetSlipSlice,
        betslipGameType: keyof BetSlipSlice,
        userState: AuthenticationState,
        fetchWagers: () => void,
        setShowWagers: (show: boolean) => void,
        changeCurrentBet: (index: number) => void,
        clearLine: (index?: number) => void,
        addLine: () => void,
        handleUpdateWager: () => Promise<void>,
        resetBetslipWagerSelections: () => void,
        showHda: boolean,
        selectAmount: (id: number, offer: Offering) => void,
        selectPrediction: (id: number, type: string) => void,
        competitions: Competition[],
        offers: Offerings,
        setCurrentOfferingId: (id: number) => void,
        setEditLineAllFutureGames: (allGames: boolean) => void,
        setNumberOfGames: (noOfGames: number) => void,
        setShowMore: (show: boolean) => void,
        setShowSlideBoard: (show: boolean) => void,
        setShowWagerFixtures: (show: boolean) => void,
        setViewLinesCurrent: (current: ViewLinesCurrent) => void,
        betslipWagerHasEdits: boolean,
        editLineAllFutureGames: boolean,
        showMore: boolean,
        showSlideBoard: boolean,
        showWagers: boolean,
        viewLinesCurrent: ViewLinesCurrent,
        wagersForCompetitions: Wager[],
        selectPlay: (event?: Event, cloverUpsellOverride?: boolean) => void,
        canAddMultipleLines?: boolean,
        canEditLine?: boolean,
        currentOfferingId?: number,
        betslipWager?: BetSlip,
        competitionTypeDescription?: string,
        numberOfGames?: number,
        onlyDefaultOffer?: boolean,
        termsContent?: string,
        viewLinesOffers?: Offerings,
    ) => JSX.Element;
    renderBottomPanel?: (props: GameTemplateProps) => JSX.Element;
    sidebarWidth?: string;
}

export const getTemplate = (name?: string): GameTemplate => {
    let ret: GameTemplate;
    switch (name) {
        case 'minigame': {
            ret = useMinigameTemplate();
            break;
        }
        case 'coupon': {
            ret = useGameCouponTemplate();
            break;
        }
        default: {
            ret = useGameTemplate();
        }
    }
    return ret;
};

export const renderTemplate = (name?: string) => (props: GameTemplateProps) => {
    let ret: JSX.Element;
    switch (name) {
        case 'minigame': {
            ret = <MinigameTemplate {...props} />;
            break;
        }
        default: {
            ret = <GameTemplateComponent {...props} />;
        }
    }
    return ret;
};

export const getTemplateComponent = (name?: string): FunctionComponent<GameTemplateProps> => {
    let ret: FunctionComponent<GameTemplateProps>;
    switch (name) {
        case 'minigame': {
            ret = MinigameTemplate;
            break;
        }
        default: {
            ret = GameTemplateComponent;
        }
    }
    return ret;
};

export const getCurrentOffer = (betslip: BetSlip[], offers: Offerings): Offering | undefined => {
    const ret = offers?.offerings.find(o => o.id === betslip?.find(b => b.current)?.priceID);
    return ret;
};

// export const getCurrentBet = (props: GameTemplateProps): BetSlip => {};
