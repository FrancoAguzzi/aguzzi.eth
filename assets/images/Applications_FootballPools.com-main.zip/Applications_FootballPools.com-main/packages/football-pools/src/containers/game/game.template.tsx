/* eslint-disable import/named */
import { FunctionComponent } from 'react';
import styled, { useTheme } from 'styled-components';
import { GameTemplate, GameTemplateProps } from './gameTemplate';
import {
    BetSelections,
    BetSlipList,
    Button,
    CompetitionSelector,
    DateTimeFormatter,
    GameActionButtons,
    GameCostInfo,
    GameInfo,
    GameSection,
    GameViewType,
    getTotalPrice,
    openPopup,
    SlideOfferingList,
    ViewLinesOverlay,
} from '@sportech/pools-components';
import {
    BetSlip,
    BetSlipSlice,
    Competition,
    GameType,
    Offering,
    Offerings,
    toBetSlipKey,
    Wager,
} from '@sportech/pools-api';
import { BetslipEditLine } from '@fp/shared/src/components/BetslipEditLine/BetslipEditLine';
import {
    BetslipEditLineMobile,
    FutureGamesToggleSectionMobile,
} from '@fp/shared/src/components/BetslipEditLine/BetslipEditLineMobile';
import { CouponTopButtons } from '@fp/shared/src/components/Coupon/CouponTopButtons';
import { CouponBottomButtons } from '@fp/shared/src/components/Coupon/CouponBottomButtons';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import { BuilderGamePageBanner } from '@fp/shared/src/core/gamePage.builder';
import { useDispatch } from 'react-redux';
import { StyledMain, Sidebar, DesktopHeaderContainer, MobileHeaderContainer } from './game.shared';
import { BuilderComponent } from '@builder.io/react';
import { BetSlipMobile } from '@fp/shared/src/components/Game/BetSlipMobile';
import { useMediaQuery } from 'react-responsive';
import { isHdaGame } from '@fp/shared/src/lib/utils';

const TooltipContainer = styled.div`
    font-size: 0.75rem;
    margin: 0.5rem 0;
`;
const TooltipHeader = styled.h4`
    margin: 0 0 0.5rem 0;
`;
const TooltipContent = styled.div`
    max-width: 250px;
`;
const PerMonthTooltip = (competitionTypeDescription?: string | undefined): JSX.Element => {
    const headerText = `Monthly ${
        competitionTypeDescription && competitionTypeDescription === 'draw' ? 'Draws' : 'Games'
    }`;
    const bodyText =
        competitionTypeDescription && competitionTypeDescription === 'draw'
            ? `The number of draws in a month can vary, but the maximum you will be charged in a month is shown.`
            : `The number of games in a month can vary, but on average there will be 10 games each month (120 games per
        year).`;
    return (
        <TooltipContainer>
            <TooltipHeader>{headerText}</TooltipHeader>
            <TooltipContent>{bodyText}</TooltipContent>
        </TooltipContainer>
    );
};
const MobileOfferingList = styled.div`
    display: none;
    ${breakpoints.below('lg')} {
        display: block;
    }
`;
const CurrentInfo = styled(GameInfo)<{ maxWidth?: string; margin?: string }>`
    color: ${props => props.theme.colours.primaryFont};
    width: 100%;
    justify-self: center;
    font-size: 0.875rem;
    font-weight: bold;
    padding: 0 10px;
    display: flex;
    flex-direction: column !important;
    max-width: ${props => props.maxWidth};
    margin: ${props => props.margin || '10px 0'};

    ${breakpoints.below('lg')} {
        font-size: 0.75rem;
    }
`;
const InfoDescription = styled.span`
    font-weight: bold;
`;

const MobileBetslipContainer = styled.div`
    z-index: 9;
    display: flex;
    position: fixed;
    color: #fff;
    background: transparent;
    height: auto;
    bottom: 0;
    left: 0;
    right: 0;
    justify-content: space-around;
    align-items: center;
    flex-wrap: wrap;

    ${breakpoints.above('lg')} {
        display: none;
    }
`;
const BetSelectionsRow = styled.div<{ justifyContent?: string }>`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: ${props => props.justifyContent || 'center'};
    width: 100%;
`;
const OneTimeLuckyDipButton = styled(Button)`
    border-radius: 0 20px 20px 0;
    height: 36px;
    margin: 10px 0;
    flex: 1 1 30%;
    font-weight: bold;
    text-transform: uppercase;
    padding: 0;
    ${breakpoints.below('lg')} {
        max-height: 32px;
        font-size: 16px;
    }
    ${breakpoints.below('sm')} {
        max-height: 28px;
        font-size: 14px;
    }
    max-width: 250px;
`;
const GameInformationButton = styled(Button)`
    border-radius: 20px 0 0 20px;
    height: 36px;
    margin: 10px 0 10px 5px;
    flex: 2 2 auto;
    font-weight: bold;
    text-transform: uppercase;
    padding: 0;
    background-color: ${props => props.theme.colours.gameSecondaryColour};
    color: #fff;
    ${breakpoints.below('lg')} {
        max-height: 32px;
        font-size: 16px;
    }
    ${breakpoints.below('sm')} {
        max-height: 28px;
        font-size: 14px;
    }
    max-width: 400px;
`;

const MobileCompetitionSelectorContainer = styled.div`
    padding: 0 15px;
    ${breakpoints.below('sm')} {
        padding: 0;
    }
`;

interface FixturesCountProps {
    count?: number;
    target: number;
    msg?: string;
    subTextSize?: string;
}
const PredictFixturesContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    justify-content: center;
    color: ${props => props.theme.colours.primaryFont};
    margin: 0 1px 0 0;
    flex: 2 2 auto;
`;
const Text = styled.div<{ size?: string; textAlign?: string }>`
    font-size: ${props => props.size};
    font-weight: bold;
    text-align: ${props => props.textAlign || 'right'};
    color: ${props => props.theme.colours.primaryFont};
`;
const PredictFixturesCount = ({ count, target, msg, subTextSize }: FixturesCountProps) => {
    return (
        <PredictFixturesContainer>
            <Text size={subTextSize || '12px'}>{msg || `Predict the outcome of the ${target} matches below`}</Text>
            <Text>{`You have predicted: ${count}/${target}`}</Text>
        </PredictFixturesContainer>
    );
};

const DesktopCompetitionSelectorContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
    > div {
        width: 100%;
        flex: 1 auto;
    }
`;

const isLuckyDipButtonVisible = (
    currentBet?: BetSlip,
    offers?: Offerings,
    canEditLine?: boolean,
    showWagers?: boolean,
): boolean => {
    let ret = canEditLine || !showWagers;
    if (ret && currentBet && offers) {
        const currentOffer = offers?.offerings.find(o => o.id === currentBet?.priceID);
        if (currentOffer) {
            ret = !currentOffer.mustIncludeBonus;
        }
    }
    return ret;
};
const getGameInstructions = (gameType: GameType, numberOfSelections: number): string => {
    let ret = `Pick ${numberOfSelections} matches you think will end in a score draw.`;
    switch (gameType) {
        case 'classic-pools': {
            ret = `Pick ${numberOfSelections} matches you think will end in a score draw.`;
            break;
        }
        case 'goal-rush': {
            ret = `Pick ${numberOfSelections} matches where both teams will score.`;
            break;
        }
        case 'lucky-clover': {
            ret = `Pick 5 win £65k, Pick 4 win £4.8k, Pick 3 win £400, Pick 2 win £55.`;
            break;
        }
        case 'jackpot-12':
        case 'premier-10':
        case 'premier-6': {
            ret = `Predict the outcome of the ${numberOfSelections} matches below.`;
            break;
        }
        default: {
            ret = `Pick ${numberOfSelections} matches you think will end in a score draw.`;
        }
    }
    return ret;
};

export const GameTemplateComponent = ({
    competitions,
    offers,
    game,
    gameDescription,
    gameEnabled,
    gamePath,
    gameViewType,
    showFutureGames,
    headerHeight,
    onlyDefaultOffer,
    canAddMultipleLines,
    competitionTypeDescription,
    banner,
    howToManageLines,
    howToPlay,
    showMobilePrice,
    termsAndConditions,
    termsContent,
    viewLinesOffers,
    betslipGameType,
    betslipState,
    wagersState,
    userState,
    addLine,
    changeCompetition,
    changeCurrentBet,
    clearLine,
    selectAmount,
    selectLuckyDip,
    selectPlay,
    selectPrediction,
    setCanEditLine,
    setCurrentOfferingId,
    setEditLineAllFutureGames,
    setIsLoading,
    setNumberOfGames,
    setShowFutureCompetitions,
    setShowMore,
    setShowSlideBoard,
    setShowWagerFixtures,
    setShowWagers,
    setViewLinesCurrent,
    fetchWagers,
    handleUpdateWager,
    resetBetslipWagerSelections,
    betslipWager,
    betslipWagerHasEdits,
    canEditLine,
    currentOfferingId,
    editLineAllFutureGames,
    editWagerError,
    isLoading,
    isMobileOrTablet,
    numberOfGames,
    showFutureCompetitions,
    showHda,
    showMore,
    showSlideBoard,
    showWagerFixtures,
    showWagers,
    viewLinesCurrent,
    wagers,
    wagersForCompetitions,
    paymentTypeFlow,
    setPaymentTypeFlow,
    paymentTypes,
    maximumLines,
    costTypeDescription,
    minimumCost,
    useCouponButtons,
}: GameTemplateProps): JSX.Element => {
    const dispatch = useDispatch();
    const theme = useTheme();
    const isClover = game === 'lucky-clover';
    const currentBet = betslipState[betslipGameType].find(x => x.current == true);
    const loadWagers = (load: boolean): void => {
        if (load) {
            fetchWagers();
        }
        setShowWagers(load);
    };
    const isOneTime = paymentTypes && paymentTypes.includes('one-time-payment');

    const onSelectPlay = () => selectPlay(undefined, undefined, isOneTime ? 'login' : 'registration');

    const currentOffer = currentBet ? offers.offerings.find(o => o.id === currentBet.priceID) : offers.defaultOffering;

    const getLabelForOffer = (offer?: Offering): string => {
        return `${showHda ? 'Stake' : offer?.description} - £${(
            (offer?.pricePerEntry || 0) / 100
        ).toLocaleStringCash()}`;
    };

    const isSmallMobile = useMediaQuery({
        query: `(max-width: ${theme.breakpoints.xs}px )`,
    });

    const hasEdits =
        isClover && currentOffer && currentOffer.mustIncludeBonus
            ? betslipWagerHasEdits &&
              betslipWager?.pick === betslipWager?.numbers?.length &&
              betslipWager?.bonusPick === betslipWager?.bonusNumbers?.length
            : betslipWagerHasEdits;

    const poolSize =
        (competitions?.find(c => c.id === currentBet?.competitionId)?.poolSize as {
            value: number;
        })?.value || 0;

    const StyledLink = styled.a`
        cursor: pointer;
        text-decoration: underline;
        margin: 10px;
        font-size: 12px;
        text-align: end;
        color: #fff;
        :hover {
            text-decoration: none;
        }
    `;
    const StyledTermsAndConditionsLink = styled.div`
        width: 100%;
        padding-bottom: 10px;
        text-align: end;
        background: ${theme.colours.gameMainColour};
    `;
    const TermsPanel = styled.div`
        margin-top: 5px;
        width: 100%;
        text-align: center;
        background: ${theme.colours.gameMainColour};
        color: #fff;
        ${breakpoints.above('lg')} {
            display: none;
        }
    `;
    const TermsContent = styled.div`
        padding: 10px;
        text-align: initial;
        font-size: 14px;
        ul {
            padding: 0 15px;
            li {
                margin-top: 5px;
            }
        }
        a {
            color: #fff;
        }
    `;

    return (
        <>
            <StyledMain>
                {showWagers && wagersForCompetitions.length === 0 && (
                    <ViewLinesOverlay
                        onClick={(): void => {
                            setShowWagers(false);
                        }}
                    />
                )}

                <DesktopHeaderContainer>
                    {useCouponButtons ? (
                        <CouponTopButtons
                            showCompetitionSelectorButton={true}
                            showLuckyDipButton={true}
                            showGameInformationButtonDesktop={true}
                            showGameInformationButton={true}
                            showOffersButton={true}
                            onClickOfferDropdown={(id: number | string) => {
                                if (typeof id !== 'number') {
                                    return;
                                }
                                selectAmount(
                                    currentBet?.competitionId as number,
                                    offers.offerings.find(o => o.id === id) as Offering,
                                );
                                setCurrentOfferingId(currentBet?.priceID as number);
                            }}
                            offersDropdownItems={offers.offerings
                                .map(o => {
                                    return {
                                        label: getLabelForOffer(o),
                                        value: o.id,
                                        isSelected: currentBet?.priceID === o.id,
                                    };
                                })
                                .sort((a, b) => a.value - b.value)}
                            offerButtonText={getLabelForOffer(currentOffer)}
                            onClickLuckyDipButton={() => selectLuckyDip(false, false)}
                            onClickCompetitionDropdown={(id: number | string) => {
                                if (
                                    typeof id === 'number' &&
                                    currentBet &&
                                    (currentBet.pick === currentBet.numbers?.length ||
                                        currentBet?.numbers?.length === 0)
                                ) {
                                    changeCompetition(id, competitions.find(c => c.id === id)?.description || '');
                                } else {
                                    console.debug('line must be complete or empty before changing competitions');
                                }
                            }}
                            onClickGameInformationButton={() => dispatch(openPopup('gameInfo'))}
                            competitionsDropdownItems={competitions.map(c => {
                                return {
                                    label: c.description,
                                    value: c.id,
                                    isSelected: currentBet?.competitionId === c.id,
                                };
                            })}
                            competitionButtonText={currentBet?.competitionName}
                        />
                    ) : (
                        <GameActionButtons
                            ChangeBet={changeCurrentBet}
                            ClearLine={clearLine}
                            AddLine={addLine}
                            ShowHDA={!showHda}
                            SelectAmountAction={selectAmount}
                            betslipselection={betslipState[betslipGameType]}
                            offers={offers}
                            setCurrentOfferingId={setCurrentOfferingId}
                            currentOfferingId={currentOfferingId as number}
                            setShowMore={setShowMore}
                            showMoreValue={showMore}
                            addedLines={betslipState[betslipGameType].filter(x => x.pick == x.numbers?.length)}
                            openAddLinesPopup={() => {
                                dispatch(openPopup('added_lines'));
                            }}
                            pressPlay={onSelectPlay}
                            showAddLinesButton={false}
                            showAddedLinesButton={false}
                            isViewLines={showWagers}
                            canEdit={canEditLine}
                            fixtureCountLabel={`FIXTURE COUNT:`}
                            onClickLuckyDip={() => selectLuckyDip(false)}
                            onClickLuckyDipBonus={() => selectLuckyDip(true, currentBet?.numbers?.length === 0)}
                            onClickHowToPlay={(): void => {
                                dispatch(openPopup('gameInfo'));
                            }}
                            showHowToPlayButton={true}
                            howToPlayButtonText="GAME INFO"
                            onClickViewLines={(): void => {
                                loadWagers(true);
                                dispatch(openPopup('your_placed_lines'));
                            }}
                            isClover={isClover}
                            isMobileOrTablet={isMobileOrTablet}
                            showLuckyDipButton={isLuckyDipButtonVisible(currentBet, offers, canEditLine, showWagers)}
                            showLuckyDipBonusButton={isClover}
                            showCompetitionSelector={
                                showFutureGames && (!showWagers || wagersForCompetitions.length == 0)
                            }
                            competitionSelectorElement={
                                <DesktopCompetitionSelectorContainer>
                                    <CompetitionSelector
                                        ChangeCompetitions={changeCompetition}
                                        competitions={competitions}
                                        currentCompetition={
                                            showWagers && betslipWager
                                                ? (betslipWager?.competitionId as number)
                                                : currentBet?.competitionId ?? 0
                                        }
                                        BetSlipSelection={betslipState[betslipGameType]}
                                        openErrorOnBetslipLinePopup={() => {
                                            dispatch(openPopup('error_on_change_betslip_line'));
                                        }}
                                        isCurved={true}
                                        height="52px"
                                    />
                                    <Text
                                        textAlign="center"
                                        size="14px"
                                    >{`Future ${competitionTypeDescription}s`}</Text>
                                </DesktopCompetitionSelectorContainer>
                            }
                            maximumLines={maximumLines}
                            minimumCost={minimumCost}
                        />
                    )}
                </DesktopHeaderContainer>
                <MobileHeaderContainer headerHeight={headerHeight}>
                    <>
                        {isOneTime && (
                            <BuilderComponent
                                model="game-banner"
                                key={game}
                                data={{
                                    poolSize: `£${poolSize.toLocaleString(undefined, {
                                        minimumFractionDigits: 0,
                                        maximumFractionDigits: 0,
                                    })}`,
                                }}
                                options={{ query: { data: { footballPools: true } } }}
                            />
                        )}
                        {!(showWagers && canEditLine && viewLinesCurrent.id > 0) &&
                            (!paymentTypes || !paymentTypes?.includes('one-time-payment')) && (
                                <GameActionButtons
                                    ChangeBet={changeCurrentBet}
                                    ClearLine={clearLine}
                                    AddLine={addLine}
                                    ShowHDA={!showHda}
                                    SelectAmountAction={selectAmount}
                                    betslipselection={betslipState[betslipGameType]}
                                    offers={offers}
                                    setCurrentOfferingId={setCurrentOfferingId}
                                    currentOfferingId={currentOfferingId as number}
                                    setShowMore={setShowMore}
                                    showMoreValue={showMore}
                                    addedLines={[]}
                                    openAddLinesPopup={() => {
                                        dispatch(openPopup('added_lines'));
                                    }}
                                    pressPlay={onSelectPlay}
                                    showAddLinesButton={canAddMultipleLines}
                                    showAddedLinesButton={false}
                                    isViewLines={showWagers}
                                    canEdit={canEditLine}
                                    fixtureCountLabel={`FIXTURE COUNT:`}
                                    onClickLuckyDip={() => selectLuckyDip(false)}
                                    onClickLuckyDipBonus={() => selectLuckyDip(true, currentBet?.numbers?.length === 0)}
                                    onClickHowToPlay={(): void => {
                                        dispatch(openPopup('gameInfo'));
                                    }}
                                    showHowToPlayButton={true}
                                    howToPlayButtonText="GAME INFO"
                                    onClickViewLines={(): void => {
                                        loadWagers(true);
                                        dispatch(openPopup('your_placed_lines'));
                                    }}
                                    isClover={isClover}
                                    isMobileOrTablet={isMobileOrTablet}
                                    showLuckyDipButton={isLuckyDipButtonVisible(
                                        currentBet,
                                        offers,
                                        canEditLine,
                                        showWagers,
                                    )}
                                    showLuckyDipBonusButton={isClover}
                                    user={userState}
                                    isViewLinesButtonEnabled={wagersForCompetitions && wagersForCompetitions.length > 0}
                                    showCompetitionSelector={false}
                                />
                            )}

                        {showWagers && canEditLine && betslipWager !== undefined ? (
                            <BetSelections
                                bet={betslipWager}
                                game={game}
                                displayId={!showHda}
                                justifyContent="center"
                                isCurrentSelectedLine={betslipWager.current}
                                selectionsColour={theme.colours.ballColour}
                                bonusSelectionsColour={game === 'lucky-clover' ? '#e0ac00' : undefined}
                                handleOnClick={selectPrediction}
                                handleOnClickClear={clearLine}
                            />
                        ) : currentBet !== undefined ? (
                            <>
                                {useCouponButtons ? (
                                    <CouponTopButtons
                                        showCompetitionSelectorButton={true}
                                        showLuckyDipButton={true}
                                        showGameInformationButton={true}
                                        onClickOfferDropdown={(id: number | string) => {
                                            if (typeof id !== 'number') {
                                                return;
                                            }
                                            selectAmount(
                                                currentBet?.competitionId as number,
                                                offers.offerings.find(o => o.id === id) as Offering,
                                            );
                                            setCurrentOfferingId(currentBet?.priceID as number);
                                        }}
                                        showOffersButton={true}
                                        offersDropdownItems={offers.offerings
                                            .map(o => {
                                                return {
                                                    label: getLabelForOffer(o),
                                                    value: o.id,
                                                    isSelected: currentBet?.priceID === o.id,
                                                };
                                            })
                                            .sort((a, b) => a.value - b.value)}
                                        offerButtonText={getLabelForOffer(currentOffer)}
                                        onClickLuckyDipButton={() => selectLuckyDip(false, false)}
                                        onClickCompetitionDropdown={(id: number | string) => {
                                            if (
                                                typeof id === 'number' &&
                                                currentBet &&
                                                (currentBet.pick === currentBet.numbers?.length ||
                                                    currentBet?.numbers?.length === 0)
                                            ) {
                                                changeCompetition(
                                                    id,
                                                    competitions.find(c => c.id === id)?.description || '',
                                                );
                                            } else {
                                                console.debug(
                                                    'line must be complete or empty before changing competitions',
                                                );
                                            }
                                        }}
                                        onClickGameInformationButton={() => dispatch(openPopup('gameInfo'))}
                                        competitionsDropdownItems={competitions.map(c => {
                                            return {
                                                label: c.description,
                                                value: c.id,
                                                isSelected: currentBet?.competitionId === c.id,
                                            };
                                        })}
                                        competitionButtonText={currentBet?.competitionName}
                                    />
                                ) : (
                                    <BetSelectionsRow
                                        justifyContent={isOneTime && showHda ? 'space-between' : 'center'}
                                    >
                                        {isOneTime && (
                                            <OneTimeLuckyDipButton
                                                bgColor="#4ca40c"
                                                fontSize="14px"
                                                textColor="#fff"
                                                onClick={() => selectLuckyDip(false)}
                                            >
                                                Lucky Dip
                                            </OneTimeLuckyDipButton>
                                        )}
                                        {showHda && (
                                            // <PredictFixturesCount
                                            //     count={
                                            //         currentBet.numbers?.filter(n => n.selections && n.selections.length > 0)
                                            //             .length
                                            //     }
                                            //     target={12}
                                            //     msg={gameDescription || getGameInstructions(game, currentBet?.pick || 0)}
                                            //     subTextSize={isSmallMobile ? '0.55em' : '12px'}
                                            // />
                                            <GameInformationButton
                                                onClick={() => {
                                                    dispatch(openPopup('gameInfo'));
                                                }}
                                            >
                                                Game Information
                                            </GameInformationButton>
                                        )}
                                        {!showHda && (
                                            <BetSelections
                                                bet={currentBet}
                                                game={game}
                                                displayId={!showHda}
                                                justifyContent="center"
                                                isCurrentSelectedLine={currentBet.current}
                                                selectionsColour={theme.colours.ballColour}
                                                bonusSelectionsColour={game === 'lucky-clover' ? '#e0ac00' : undefined}
                                                handleOnClick={selectPrediction}
                                                handleOnClickClear={clearLine}
                                                betslipItemSize={undefined}
                                            />
                                        )}
                                    </BetSelectionsRow>
                                )}
                                {showMobilePrice && (
                                    <GameCostInfo
                                        perDrawCost={
                                            isOneTime
                                                ? (offers.defaultOffering.pricePerEntry / 100).toLocaleStringCash()
                                                : `£${getTotalPrice(
                                                      showHda,
                                                      isClover,
                                                      betslipState[betslipGameType],
                                                      'pounds',
                                                      offers.offerings,
                                                  ).toLocaleStringCash()}`
                                        }
                                        perMonthCost={`£${getTotalPrice(
                                            showHda,
                                            isClover,
                                            betslipState[betslipGameType],
                                            'pounds',
                                            offers.offerings,
                                        ).toLocaleStringCash()}`}
                                        perMonthCostText={isOneTime ? 'TOTAL COST' : undefined}
                                        perMonthTooltipContent={
                                            !isOneTime ? PerMonthTooltip(competitionTypeDescription) : undefined
                                        }
                                        tooltipProps={{
                                            lockScroll: true,
                                        }}
                                        perDrawCostText={
                                            costTypeDescription
                                                ? `COST PER ${costTypeDescription.toLocaleUpperCase()}`
                                                : 'COST PER GAME'
                                        }
                                    />
                                )}
                                {!useCouponButtons && isOneTime && (
                                    <CurrentInfo margin="0 0 10px 0">
                                        <InfoDescription>
                                            {gameDescription || getGameInstructions(game, currentBet?.pick || 0)}
                                        </InfoDescription>
                                    </CurrentInfo>
                                )}
                            </>
                        ) : (
                            <></>
                        )}
                        {showWagers && canEditLine && viewLinesCurrent.id > 0 && (
                            <>
                                <FutureGamesToggleSectionMobile
                                    onToggleFutureGames={() => {
                                        setEditLineAllFutureGames(!editLineAllFutureGames);
                                    }}
                                    allFutureGames={editLineAllFutureGames}
                                    hasEdits={hasEdits}
                                />
                                <BetslipEditLineMobile
                                    onClickSave={async () => {
                                        // update line
                                        await handleUpdateWager();
                                    }}
                                    onClickCancel={() => {
                                        if (betslipWagerHasEdits) {
                                            // revert changes to selections
                                            resetBetslipWagerSelections();
                                        } else {
                                            // return to buy lines view:
                                            setShowWagers(false);
                                        }
                                        setEditLineAllFutureGames(false);
                                    }}
                                    onToggleFutureGames={() => {
                                        setEditLineAllFutureGames(!editLineAllFutureGames);
                                    }}
                                    allFutureGames={editLineAllFutureGames}
                                    hasEdits={hasEdits}
                                    betslip={betslipWager}
                                    fixtureCountLabel={'FIXTURE COUNT'}
                                />
                            </>
                        )}
                    </>
                </MobileHeaderContainer>

                <>
                    {!onlyDefaultOffer && (
                        <MobileOfferingList>
                            <SlideOfferingList
                                setShowMore={setShowMore}
                                showMoreValue={false}
                                setCurrentOfferingId={setCurrentOfferingId}
                                currentOfferingId={currentOfferingId as number}
                                offerings={offers}
                                currentSlip={currentBet as BetSlip}
                                selectAmount={selectAmount}
                                isHda={showHda}
                                isClover={isClover}
                                showCost={false}
                            />
                        </MobileOfferingList>
                    )}

                    {!useCouponButtons && (!isMobileOrTablet || !isOneTime) && (
                        <CurrentInfo>
                            <InfoDescription>
                                {gameDescription || getGameInstructions(game, currentBet?.pick || 0)}
                            </InfoDescription>
                        </CurrentInfo>
                    )}

                    {!useCouponButtons &&
                        isMobileOrTablet &&
                        showFutureGames &&
                        (!showWagers || wagersForCompetitions.length == 0) && (
                            <MobileCompetitionSelectorContainer>
                                <CompetitionSelector
                                    ChangeCompetitions={changeCompetition}
                                    competitions={competitions}
                                    currentCompetition={
                                        showWagers && betslipWager
                                            ? (betslipWager?.competitionId as number)
                                            : currentBet?.competitionId ?? 0
                                    }
                                    BetSlipSelection={betslipState[betslipGameType]}
                                    openErrorOnBetslipLinePopup={() => {
                                        dispatch(openPopup('error_on_change_betslip_line'));
                                    }}
                                />
                            </MobileCompetitionSelectorContainer>
                        )}
                    <CurrentInfo margin={'10px 0'}>
                        {isOneTime && useCouponButtons && (
                            <InfoDescription>
                                {gameDescription || getGameInstructions(game, currentBet?.pick || 0)}
                            </InfoDescription>
                        )}
                        <div>
                            {competitionTypeDescription
                                ? `${competitionTypeDescription.toLocaleUpperCase()} CLOSES:`
                                : 'GAME CLOSES:'}{' '}
                            <DateTimeFormatter
                                format={'D MMM @ HH:mm'}
                                input={
                                    competitions.find(x => x.id == currentBet?.competitionId)?.datumDateWithBuffer ||
                                    competitions[0].datumDateWithBuffer
                                }
                            />
                        </div>
                    </CurrentInfo>
                    <GameSection
                        action={selectPrediction}
                        isHda={showHda}
                        fixtures={
                            showWagers && betslipWager
                                ? competitions.find(x => x.id === betslipWager?.competitionId)?.fixtures
                                : competitions.find(x => x.id == currentBet?.competitionId)?.fixtures
                        }
                        betslipSelection={showWagers ? betslipWager : currentBet}
                        gameViewType={isClover ? 'numbers' : gameViewType || 'match'}
                        isViewLines={Boolean(showWagers && wagersForCompetitions.length > 0)}
                        canEdit={!showWagers || canEditLine}
                        isClover={isClover}
                        background={isClover ? 'rgba(244, 244, 244, 0.9)' : undefined}
                        border={isClover ? '1px solid #707070' : undefined}
                        borderRadius={isClover ? '10px' : undefined}
                        highlightBorderColour={
                            game === 'lucky-clover'
                                ? !showWagers &&
                                  currentBet?.numbers &&
                                  currentBet.numbers.length === currentBet.pick &&
                                  currentBet.bonusPick > 0
                                    ? '#e0ac00'
                                    : theme?.colours.gameButtonSelectedBackground
                                : undefined
                        }
                        margin="0"
                    />
                    {termsContent && game == 'lucky-clover' && paymentTypes && paymentTypes.includes('subscription') && (
                        <TermsPanel>
                            <StyledTermsAndConditionsLink>
                                <TermsContent
                                    dangerouslySetInnerHTML={{
                                        __html: termsContent,
                                    }}
                                />
                                <StyledLink onClick={() => dispatch(openPopup('termsAndConditions'))}>
                                    Terms and Conditions
                                </StyledLink>
                            </StyledTermsAndConditionsLink>
                        </TermsPanel>
                    )}

                    {paymentTypes && paymentTypes.includes('one-time-payment') && (
                        <MobileBetslipContainer>
                            {useCouponButtons ? (
                                <CouponBottomButtons
                                    ClearLine={clearLine}
                                    AddLine={addLine}
                                    addLineButtonText={'Add a Line'}
                                    SelectAmountAction={selectAmount}
                                    betslipselection={betslipState[toBetSlipKey(game)]}
                                    offers={offers}
                                    setCurrentOfferingId={setCurrentOfferingId}
                                    currentOfferingId={currentOfferingId as number}
                                    setShowMore={setShowMore}
                                    showMoreValue={showMore}
                                    addedLines={betslipState[toBetSlipKey(game)].filter(
                                        b => b.pick == b.numbers?.length,
                                    )}
                                    pressPlay={onSelectPlay}
                                    maximumLines={maximumLines}
                                    isHda={showHda}
                                    minimumCost={minimumCost}
                                    showAddLine={true}
                                    showLuckyDipButton={true}
                                    showViewLinesButton={true}
                                    onClickLuckyDipButton={() => selectLuckyDip(false, false)}
                                    onClickOfferDropdown={(id: number | string) => {
                                        if (typeof id !== 'number') {
                                            return;
                                        }
                                        selectAmount(
                                            currentBet?.competitionId as number,
                                            offers.offerings.find(o => o.id === id) as Offering,
                                        );
                                        setCurrentOfferingId(currentBet?.priceID as number);
                                    }}
                                    showOffersButton={true}
                                    offersDropdownItems={offers.offerings
                                        .map(o => {
                                            return {
                                                label: getLabelForOffer(o),
                                                value: o.id,
                                                isSelected: currentBet?.priceID === o.id,
                                            };
                                        })
                                        .sort((a, b) => a.value - b.value)}
                                    offerButtonText={getLabelForOffer(currentOffer)}
                                    onClickViewLinesButton={() => {
                                        dispatch(openPopup('added_lines'));
                                    }}
                                    competitionsDropdownItems={competitions.map(c => {
                                        return {
                                            label: c.description,
                                            value: c.id,
                                            isSelected: currentBet?.competitionId === c.id,
                                        };
                                    })}
                                    competitionButtonText={currentBet?.competitionName}
                                    game={game}
                                    isOneTime={isOneTime}
                                />
                            ) : (
                                <BetSlipMobile
                                    ChangeBet={changeCurrentBet}
                                    ClearLine={clearLine}
                                    AddLine={addLine}
                                    SelectAmountAction={selectAmount}
                                    betslipselection={betslipState[toBetSlipKey(game)]}
                                    offers={offers}
                                    setCurrentOfferingId={setCurrentOfferingId}
                                    currentOfferingId={currentOfferingId as number}
                                    setShowMore={setShowMore}
                                    showMoreValue={showMore}
                                    addedLines={betslipState[toBetSlipKey(game)].filter(
                                        b => b.pick == b.numbers?.length,
                                    )}
                                    pressPlay={onSelectPlay}
                                    isClover={game === 'lucky-clover'}
                                    openAddLinesPopup={() => {
                                        dispatch(openPopup('added_lines'));
                                    }}
                                    canAddMultipleLines={canAddMultipleLines}
                                    showFixtureCount={false}
                                    maximumLines={maximumLines}
                                    game={game}
                                    ShowHDA={showHda}
                                    minimumCost={minimumCost}
                                />
                            )}
                        </MobileBetslipContainer>
                    )}
                </>
            </StyledMain>
            <Sidebar background="none" margin={'0 0 20px 0'}>
                <>
                    <BetSlipList
                        ChangeBet={changeCurrentBet}
                        ClearLine={clearLine}
                        AddLine={addLine}
                        ShowHDA={showHda}
                        SelectAmountAction={selectAmount}
                        betslipselection={betslipState[betslipGameType]}
                        offers={offers}
                        gameType={betslipGameType}
                        handleCircleNumberClick={selectPrediction}
                        setCurrentOfferingId={setCurrentOfferingId}
                        currentOfferingId={currentOfferingId as number}
                        setShowMore={setShowMore}
                        showMoreValue={showMore}
                        wagers={wagersForCompetitions.length > 0 ? wagersForCompetitions : undefined}
                        user={userState.isLoggedIn ? userState : undefined}
                        setViewLinesCurrent={setViewLinesCurrent}
                        viewLinesCurrent={viewLinesCurrent}
                        competitions={competitions}
                        showWagers={showWagers}
                        setShowWagers={loadWagers}
                        pressPlay={onSelectPlay}
                        canEdit={canEditLine}
                        viewLinesBetslip={betslipWager}
                        showAddLinesButton={canAddMultipleLines}
                        showOfferingList={!onlyDefaultOffer}
                        isClover={isClover}
                        setShowWagerFixtures={setShowWagerFixtures}
                        betslipItemSize={game === 'jackpot-12' ? '20px' : '22px'}
                        maxCostPerMonth={
                            isOneTime
                                ? `£${getTotalPrice(
                                      showHda,
                                      isClover,
                                      betslipState[betslipGameType],
                                      'pounds',
                                      offers.offerings,
                                  ).toLocaleStringCash()}`
                                : `£${(
                                      getTotalPrice(
                                          showHda,
                                          isClover,
                                          betslipState[betslipGameType],
                                          'pounds',
                                          offers.offerings,
                                      ) * 10
                                  ).toLocaleStringCash()}`
                        }
                        termsContent={termsContent}
                        termsBackgroundColour={game === 'classic-pools' ? '#000d68' : undefined}
                        ballColor={isHdaGame(game) && !showWagers ? '#F2F2F2' : theme.colours.ballColour}
                        handleOnClickManageLinesInfo={
                            !isClover
                                ? () => {
                                      dispatch(openPopup('howToManageLines'));
                                  }
                                : undefined
                        }
                        perMonthTooltipContent={!isOneTime ? PerMonthTooltip(competitionTypeDescription) : undefined}
                        viewLinesOffers={viewLinesOffers || offers}
                        openPopupTermsAndConditions={() => dispatch(openPopup('termsAndConditions'))}
                        perDrawCostText={
                            costTypeDescription
                                ? `COST PER ${costTypeDescription.toLocaleUpperCase()}`
                                : 'COST PER GAME'
                        }
                        perMonthCostText={isOneTime ? 'TOTAL COST' : undefined}
                        perDrawCost={
                            isOneTime
                                ? (
                                      (currentOffer?.pricePerEntry || offers.defaultOffering.pricePerEntry) / 100
                                  ).toLocaleStringCash()
                                : undefined
                        }
                        addLineButtonPosition="afterLines"
                        betslipItemLabelling="perLine"
                        showTotalLinesLabel={false}
                        borderType={'whole'}
                        showBetslipCountHeader={isHdaGame(game)}
                        maximumLines={maximumLines}
                        showCostPerLine={!showWagers && paymentTypeFlow === 'one-time-payment'}
                        clearIconSrc={paymentTypeFlow === 'one-time-payment' ? '/icon-cross.png' : undefined}
                        showClearInBetslipCircle={paymentTypeFlow !== 'one-time-payment'}
                        showTermsAndConditionsLink={Boolean(
                            termsAndConditions?.content && termsAndConditions?.content != '',
                        )}
                        minimumCost={minimumCost}
                        countdownHeaderText={isHdaGame(game) ? 'NEXT GAME CLOSES IN:' : ''}
                        minimumStakeText={minimumCost && minimumCost > 0 ? `£${minimumCost} Minimum Stake` : undefined}
                        selectionFontColour={isHdaGame(game) ? '#222222' : undefined}
                    />
                    {showWagers && canEditLine && viewLinesCurrent.id > 0 && (
                        <BetslipEditLine
                            onClickSave={async () => {
                                // update line
                                await handleUpdateWager();
                            }}
                            onClickCancel={() => {
                                // revert changes to selections
                                resetBetslipWagerSelections();
                            }}
                            onToggleFutureGames={() => {
                                setEditLineAllFutureGames(!editLineAllFutureGames);
                            }}
                            allFutureGames={editLineAllFutureGames}
                            hasEdits={hasEdits}
                        />
                    )}
                </>
            </Sidebar>
        </>
    );
};

export const useGameTemplate = (): GameTemplate => {
    const renderBannerPanel = (
        game?: GameType,
        banner?: BuilderGamePageBanner,
        paymentTypes?: ('subscription' | 'one-time-payment')[],
        isMobileOrTablet?: boolean,
        headerHeight?: number,
        nextGameDate?: string,
        poolSize?: string,
        gameVariant?: string,
    ): JSX.Element => {
        return !isMobileOrTablet || !paymentTypes || !paymentTypes.includes('one-time-payment') ? (
            <BuilderComponent
                model="game-banner"
                key={game}
                data={{ poolSize: poolSize }}
                options={{ query: { data: { footballPools: true } } }}
            />
        ) : (
            <></>
        );
    };

    const renderMainPanel = (
        game: GameType,
        betslipState: BetSlipSlice,
        betslipGameType: keyof BetSlipSlice,
        showHda: boolean,
        changeCompetition: (id: number, name: string) => void,
        clearLine: (index?: number) => void,
        selectAmount: (id: number, offer: Offering) => void,
        selectLuckyDip: (isBonus?: boolean, noSelectionsMade?: boolean) => void,
        selectPlay: (event?: Event, cloverUpsellOverride?: boolean) => void,
        selectPrediction: (id: number, type: string) => void,
        competitions: Competition[],
        offers: Offerings,
        setCurrentOfferingId: (id: number) => void,
        setNumberOfGames: (noOfGames: number) => void,
        setShowMore: (show: boolean) => void,
        setShowSlideBoard: (show: boolean) => void,
        showFutureGames: boolean,
        showSlideBoard: boolean,
        wagersForCompetitions: Wager[],
        showWagers?: boolean,
        canEditLine?: boolean,
        currentOfferingId?: number,
        betslipWager?: BetSlip,
        competitionTypeDescription?: string,
        gameDescription?: string,
        gameViewType?: GameViewType,
        onlyDefaultOffer?: boolean,
        numberOfGames?: number,
    ): JSX.Element => {
        const isClover = game === 'lucky-clover';
        const currentSlip = betslipState[betslipGameType].find(x => x.current == true);
        const dispatch = useDispatch();
        const theme = useTheme();
        return (
            <>
                {!onlyDefaultOffer && (
                    <MobileOfferingList>
                        <SlideOfferingList
                            setShowMore={setShowMore}
                            showMoreValue={false}
                            setCurrentOfferingId={setCurrentOfferingId}
                            currentOfferingId={currentOfferingId as number}
                            offerings={offers}
                            currentSlip={currentSlip as BetSlip}
                            selectAmount={selectAmount}
                            isHda={showHda}
                            isClover={isClover}
                            showCost={false}
                        />
                    </MobileOfferingList>
                )}

                <CurrentInfo>
                    <InfoDescription>
                        {gameDescription || getGameInstructions(game, currentSlip?.pick || 0)}
                    </InfoDescription>
                    <p>
                        {competitionTypeDescription
                            ? `${competitionTypeDescription.toLocaleUpperCase()} CLOSES:`
                            : 'GAME CLOSES:'}{' '}
                        <DateTimeFormatter
                            format={'D MMM @ HH:mm'}
                            input={
                                competitions.find(x => x.id == currentSlip?.competitionId)?.datumDateWithBuffer ||
                                competitions[0].datumDateWithBuffer
                            }
                        />
                    </p>
                </CurrentInfo>

                {showFutureGames && (!showWagers || wagersForCompetitions.length == 0) && (
                    <CompetitionSelector
                        ChangeCompetitions={changeCompetition}
                        competitions={competitions}
                        currentCompetition={
                            showWagers && betslipWager
                                ? (betslipWager?.competitionId as number)
                                : currentSlip?.competitionId ?? 0
                        }
                        BetSlipSelection={betslipState[betslipGameType]}
                        openErrorOnBetslipLinePopup={() => {
                            dispatch(openPopup('error_on_change_betslip_line'));
                        }}
                    />
                )}

                <GameSection
                    action={selectPrediction}
                    isHda={showHda}
                    fixtures={
                        showWagers && betslipWager
                            ? competitions.find(x => x.id === betslipWager?.competitionId)?.fixtures
                            : competitions.find(x => x.id == currentSlip?.competitionId)?.fixtures
                    }
                    betslipSelection={showWagers ? betslipWager : currentSlip}
                    gameViewType={isClover ? 'numbers' : gameViewType || 'match'}
                    isViewLines={Boolean(showWagers && wagersForCompetitions.length > 0)}
                    canEdit={!showWagers || canEditLine}
                    isClover={isClover}
                    background={isClover ? 'rgba(244, 244, 244, 0.9)' : undefined}
                    border={isClover ? '1px solid #707070' : undefined}
                    borderRadius={isClover ? '10px' : undefined}
                    highlightBorderColour={
                        game === 'lucky-clover'
                            ? !showWagers &&
                              currentSlip?.numbers &&
                              currentSlip.numbers.length === currentSlip.pick &&
                              currentSlip.bonusPick > 0
                                ? '#e0ac00'
                                : theme?.colours.gameButtonSelectedBackground
                            : undefined
                    }
                />
            </>
        );
    };

    const renderBottomPanel = (props: GameTemplateProps): JSX.Element => {
        return <div>bottom</div>;
    };

    return {
        renderBannerPanel,
        renderMainPanel,
    };
};
