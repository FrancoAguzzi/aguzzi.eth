import { useRouter } from 'next/router';
import { FunctionComponent, useEffect } from 'react';
import { useForm, ErrorMessage, FormStateProxy } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import styled from 'styled-components';

import { createAccount, CreateAccountObject } from '@fp/shared/src/api/account';
import { ErrorMsg } from '@containers/account/changeEmailForm';
import { isPasswordValid, PasswordValidationText } from '@fp/shared/src/containers/account/passwordValidation';
import { Button } from '@fp/shared/src/components/Button/Button';
import Checkbox from '@fp/shared/src/components/Checkbox/Checkbox';
import { PasswordRevealInput } from '@fp/shared/src/components/Forms/Inputs/PasswordRevealInput';
import {
    StateHighlightInput,
    InputState,
    InputProps,
    HighlightMixin,
} from '@fp/shared/src/components/Forms/Inputs/StateHighlightInput';
import { loginSuccess } from '@fp/shared/src/features/authentication/authenticationSlice';
import { isAppError } from '@fp/shared/src/core/appError';
import { RootState } from '@fp/shared/src/rootReducer';
import { Loader } from '@fp/shared/src/components/Loader/Loader';
import { getWagersSelector } from '@sportech/pools-api';
import { cameFromGamePage } from './details';
import { openPopup, testId } from '@sportech/pools-components';
import { redirectUrlSelector, utmSelector } from '@fp/shared/src/features/registration/registrationSelector';
import { setCookie } from '@services/cookies';
import { useTags } from '@fp/shared/src/core/tags';
import { UtmData } from '@fp/shared/src/features/registration/registrationSlice';

const Login = styled.p`
    font-weight: 700;
    color: #fff;
    text-align: center;
`;

const EmailLink = styled.a`
    font-weight: 700;
    color: #fff;
    text-align: center;
    text-decoration: underline;
    display: block;
`;

const LoginLink = styled.span`
    cursor: pointer;
    text-decoration: underline;
`;

const Form = styled.form`
    display: flex;
    flex-direction: column;
    align-items: center;
    > * {
        margin: 0 0 1rem;
    }

    background: #000d68;
    color: #ffffff;
`;

const ContactPrefsContainer = styled.div`
    display: flex;
    justify-content: space-between;
    width: 100%;
`;

const TermsText = styled.span`
    display: inline-block;
    font-size: 10px;
`;

const Links = styled.a`
    color: inherit;
`;

const PasswordInput = styled(PasswordRevealInput)<InputProps>`
    > span {
        height: auto;
        margin: 0;
    }
    label {
        color: #fff;
        font-weight: 800;
    }
    input {
        margin: 6px 0 0 0;
        ${HighlightMixin};
        :focus {
            outline: none;
        }
        height: 40px;
    }
`;

const PasswordText = styled(PasswordValidationText)`
    font-size: 10px;
`;

const NextButton = styled(Button)`
    height: 50px;
    background: #7cda24;

    :hover {
        background: #000d68;
        border: 1px solid #fff;
    }
`;

interface RegistrationFormData {
    emailAddress: string;
    password: string;
    confirmPassword: string;
    contactEmail: boolean;
    contactSms: boolean;
    contactPhone: boolean;
    contactPost: boolean;
    showContactPrefs: boolean;
}

const isFormValid = (formState: FormStateProxy<RegistrationFormData>): boolean =>
    formState.isValid &&
    formState.dirtyFields.has('password') &&
    formState.dirtyFields.has('confirmPassword') &&
    formState.dirtyFields.has('emailAddress');

const mapFormDataToCreateAccount = (
    {
        emailAddress,
        password,
        confirmPassword,
        contactEmail,
        contactPhone,
        contactPost,
        contactSms,
    }: RegistrationFormData,
    utm?: UtmData,
): CreateAccountObject => ({
    email: emailAddress,
    password,
    passwordConfirmation: confirmPassword,
    contactPreferences: {
        email: contactEmail,
        phone: contactPhone,
        post: contactPost,
        sms: contactSms,
    },
    utm: utm,
    operator: 'footballpools',
});

const StepCounter = styled.span`
    font-weight: 800;
`;

const CheckboxContainer = styled.div`
    margin-right: auto;
    margin-bottom: 0;
`;

export const RegistrationForm: FunctionComponent = () => {
    const {
        register,
        watch,
        getValues,
        errors,
        formState,
        handleSubmit,
        setError,
        clearError,
        triggerValidation,
    } = useForm<RegistrationFormData>({
        mode: 'onChange',
        defaultValues: {
            showContactPrefs: false,
        },
    });

    const values = getValues();
    const dispatch = useDispatch();
    const router = useRouter();

    const { showContactPrefs } = watch();

    const { isSubmitting } = formState;

    const wagersSlice = useSelector(getWagersSelector);
    const maxStep = cameFromGamePage(wagersSlice) ? '3' : '2';

    const auth = useSelector((state: RootState) => state.authentication);
    const redirectUrl = useSelector(redirectUrlSelector);
    const utm = useSelector(utmSelector);
    const { startRegistration, registrationError } = useTags();

    useEffect(() => {
        startRegistration();
    }, []);

    useEffect(() => {
        if (auth.isFetching) return;
        if (auth.isLoggedIn) {
            const userDetails = auth.userDetails;
            if (!userDetails || !userDetails.firstName) {
                router.replace('/registration/details');
            } else if (userDetails) {
                router.replace(redirectUrl || '/');
            }
        }
    }, [auth.userDetails]);

    const onSubmit = async (data: RegistrationFormData): Promise<void> => {
        if (formState.isSubmitting) return;

        const response = await createAccount(mapFormDataToCreateAccount(data, utm));

        if (isAppError(response)) {
            const apiError = response.apiError;
            if (response.message === 'email_exists') {
                setError(
                    'emailAddress',
                    response.message,
                    "This email address is already registered to an account. Please login or click the 'forgotten password' link if you can't remember your login details.",
                );
            } else {
                setError(
                    'general',
                    'api',
                    apiError?.detail || apiError?.title || apiError?.code || 'Something went wrong',
                );
            }
            registrationError(apiError?.detail || apiError?.title || apiError?.code);
        } else {
            setCookie('_clubFpToken', response.fpToken, 1);
            dispatch(loginSuccess({ token: response.token, hasDetails: response.hasDetails }));
            router.replace('/registration/details');
        }
    };

    const clearManualError = (): void => {
        if (errors.emailAddress?.isManual) {
            clearError('emailAddress');
            triggerValidation('emailAddress');
        }
    };

    return (
        <>
            <Loader isLoading={isSubmitting} backgroundColour={'rgba(0,0,0,0.5)'} position={'fixed'} />

            <Form onSubmit={handleSubmit(onSubmit)} onChange={() => clearError('general')}>
                <StepCounter>Sign up - Step 1 of {maxStep}</StepCounter>

                <StyledInput
                    name="emailAddress"
                    id="emailAddress"
                    label="Email Address"
                    ref={register({
                        required: 'Please enter a valid email address.',
                        pattern: {
                            value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i,
                            message: 'Invalid email',
                        },
                    })}
                    state={
                        errors.emailAddress
                            ? InputState.Error
                            : values.emailAddress
                            ? InputState.Valid
                            : InputState.Default
                    }
                    onChange={clearManualError}
                />
                <ErrorMessage role="alert" errors={errors} name="emailAddress" as={ErrorMsg} />
                <PasswordInput
                    name="password"
                    id="password"
                    label="Password"
                    data-wc-ignore="true"
                    ref={register({
                        required: 'Please enter a password',
                        validate: value => isPasswordValid(value) || 'Invalid password',
                    })}
                    state={errors.password ? InputState.Error : values.password ? InputState.Valid : InputState.Default}
                    onChange={() => {
                        if (values.confirmPassword) triggerValidation('confirmPassword');
                    }}
                />
                <ErrorMessage role="alert" errors={errors} name="password" as={ErrorMsg} />
                <PasswordText
                    id="passwordValidationText"
                    role="paragraph"
                    aria-label="password validation text"
                    password={watch('password', '')}
                    data-wc-ignore="true"
                />
                <PasswordInput
                    name="confirmPassword"
                    id="confirmPassword"
                    label="Re-type Password"
                    ref={register({ validate: value => value === getValues().password || 'Passwords must match' })}
                    state={
                        errors.confirmPassword
                            ? InputState.Error
                            : values.confirmPassword
                            ? InputState.Valid
                            : InputState.Default
                    }
                    data-wc-ignore="true"
                />
                <ErrorMessage role="alert" errors={errors} name="confirmPassword" as={ErrorMsg} />
                <TermsText>
                    Do you want to receive special offers and keep up to date with our competitions, prize draws and
                    free bets?
                </TermsText>
                <CheckboxContainer>
                    <Checkbox id="showContactPrefs" ref={register} name="showContactPrefs">
                        Yes, Please!
                    </Checkbox>
                </CheckboxContainer>
                <ContactPrefsContainer hidden={!showContactPrefs}>
                    <Checkbox name="contactEmail" id="contactEmail" ref={register}>
                        Email
                    </Checkbox>
                    <Checkbox name="contactSms" id="contactSms" ref={register}>
                        Sms
                    </Checkbox>
                    <Checkbox name="contactPost" id="contactPost" ref={register}>
                        Post
                    </Checkbox>
                    <Checkbox name="contactPhone" id="contactPhone" ref={register}>
                        Phone
                    </Checkbox>
                </ContactPrefsContainer>
                <NextButton
                    width="100%"
                    rounded
                    disabled={!isFormValid(formState)}
                    {...testId('registration_submit-button')}
                >
                    Next
                </NextButton>
                <ErrorMessage role="alert" errors={errors} name="general" as={ErrorMsg} />
                <TermsText>
                    By selecting next I certify that I am over 18 years of age and have read and accepted the{' '}
                    <Links href={'/static/terms-and-conditions'}> Terms and Conditions</Links> and{' '}
                    <Links href={'/static/privacy-policy'}>Privacy Policy</Links>.
                </TermsText>
                <Login>
                    Already have an account?{' '}
                    <LoginLink onClick={() => dispatch(openPopup('login'))}>Log in here</LoginLink>
                </Login>
                <ContactInfo />
            </Form>
        </>
    );
};

export const ContactInfo = () => (
    <>
        <Login>Call us at 0800 500 000</Login>
        <EmailLink href="mailto:help@footballpools.com">Send Email</EmailLink>
    </>
);

const StyledInput = styled(StateHighlightInput).attrs(() => ({
    labelTextColour: '#fff',
    labelFontWeight: 800,
    height: 'auto',
}))`
    height: 40px;
    margin-top: 6px;
`;
