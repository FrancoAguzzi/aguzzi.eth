import { NextPage } from 'next';
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useMediaQuery } from 'react-responsive';
import styled, { ThemeProvider } from 'styled-components';
import {
    CompetitionDividends,
    CompetitionResult,
    CompetitionWagers,
    GameType,
    Offering,
    useApi,
    Wager,
} from '@sportech/pools-api';
import { userDetailsSelector } from '@fp/shared/src/features/authentication/authenticationSelectors';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import withResultsLayout from '@fp/shared/src/components/Layouts/ResultsLayout/ResultsLayout';
import { GameBanner } from '@fp/shared/src/components/Lottery/GameBanner';
import { FixtureList } from '@fp/shared/src/containers/results/FixtureList';
import { ResultsTabs } from '@fp/shared/src/containers/results/ResultsTabs';
import { GamesListSelector } from '@fp/shared/src/containers/results/GamesListSelector';
import { ActiveCompSelector } from '@fp/shared/src/containers/results/ActiveCompSelector';
import { getThemeForGameType } from '@fp/shared/src/lib/utils';

export const ResultsPage: NextPage<ResultsProps> = ({
    competitionResults,
    competitionDividends,
    offerings,
    activeGame,
    gameTitle,
    isClover,
    isHda,
    nextGameDate,
}: ResultsProps) => {
    const [activeComp, setActiveComp] = useState<number | undefined>(
        competitionResults.length > 0 ? competitionResults[0].id : undefined,
    );
    const [refetchWagers, setRefetchWagers] = useState<boolean>(true);
    const [wagers, setWagers] = useState<CompetitionWagers[]>([]);
    const [isAllGames, setIsAllGames] = useState(true);
    const userDetails = useSelector(userDetailsSelector);
    const isLoggedIn = !!userDetails;
    const [competitionWagers, setCompetitionWagers] = useState<Wager[]>([]);
    const [activeWager, setActiveWager] = useState<Wager | undefined>();
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [showPoints, setShowPoints] = useState<boolean>(false);
    const [classicPickOfferingIds, setClassicPickOfferingIds] = useState<number[]>(
        activeGame === 'classic-pools' && offerings ? offerings.map(o => o.id) : [],
    );

    const isMobile = useMediaQuery({
        query: `(max-width: 799px )`,
    });

    let bannerText = 'Results';
    if (isMobile) {
        bannerText = bannerText + ' - ' + gameTitle;
    }

    const { getWagerResultsAsync } = useApi('backend');

    const fetchWagers = async (activeCompOverride?: number): Promise<void> => {
        if (!refetchWagers && !activeCompOverride) return;
        const compId = activeCompOverride ? activeCompOverride : activeComp ? activeComp : undefined;
        setRefetchWagers(false);
        setIsLoading(true);
        const lcCompNumber =
            activeGame === 'lucky-clover' && compId
                ? competitionResults.find(comp => comp.id === compId)?.number
                : undefined;
        const wagersRes = isLoggedIn ? await getWagerResultsAsync(activeGame, lcCompNumber) : undefined;
        if (wagersRes && wagersRes.data) {
            setWagers(wagersRes.data.competitions);
            const compWagers = isClover
                ? wagersRes.data.competitions.flatMap(competition => competition.wagers)
                : wagersRes.data.competitions.find(w => w.competitionId === compId)?.wagers;
            setCompetitionWagers(compWagers ? compWagers : []);
            setActiveWager(compWagers ? compWagers[0] : undefined);
        } else {
            setIsAllGames(true);
            setCompetitionWagers([]);
            setActiveWager(undefined);
        }

        if (activeCompOverride) {
            setActiveComp(activeCompOverride);
        }
        setIsLoading(false);
    };

    const getCurrentCompetitionId = () =>
        activeComp
            ? activeComp
            : competitionResults && competitionResults.length > 0
            ? competitionResults[0].id
            : undefined;

    const updateActiveWagers = (): void => {
        const compWagers = wagers.find(w => w.competitionId === getCurrentCompetitionId())?.wagers;
        setCompetitionWagers(compWagers || []);
        setActiveWager(compWagers ? compWagers[0] : undefined);
        if (!isAllGames) setIsAllGames(!compWagers || compWagers.length === 0);
    };

    useEffect(() => {
        if (competitionResults.length > 0) {
            if (isLoggedIn) {
                fetchWagers(competitionResults[0].id);
            } else {
                setActiveComp(competitionResults[0].id);
                setRefetchWagers(false);
            }
        }
    }, [competitionResults, isLoggedIn]);

    useEffect(() => {
        if (isLoggedIn && activeComp) {
            isClover ? fetchWagers() : updateActiveWagers();
        }
    }, [activeComp]);

    useEffect(() => {
        setShowPoints(
            activeGame === 'classic-pools'
                ? activeWager && isLoggedIn
                    ? classicPickOfferingIds
                        ? classicPickOfferingIds.includes(activeWager.offeringId)
                        : false
                    : false
                : true,
        );
    }, [activeWager, isLoggedIn]);

    useEffect(() => {
        setClassicPickOfferingIds(activeGame === 'classic-pools' && offerings ? offerings.map(o => o.id) : []);
    }, [activeGame]);

    return (
        <ThemeProvider theme={getThemeForGameType(activeGame)}>
            {isMobile ? (
                <>
                    <MobileTabHeader>
                        <ResultsTabs activeGame={activeGame} />
                    </MobileTabHeader>
                    <BannerHeader transparentBackground={false}>{bannerText}</BannerHeader>
                </>
            ) : (
                <GameBanner isResults={true}>
                    <BannerChildContainer>
                        <BannerHeader transparentBackground={true}>{`${bannerText} - ${gameTitle}`}</BannerHeader>
                        <ResultsActionControls>
                            <ResultsTabs activeGame={activeGame} />
                            {competitionResults.length > 0 && (
                                <>
                                    {!isClover && !isHda && (
                                        <GamesListSelector
                                            isLoggedIn={isLoggedIn}
                                            isAllGames={isAllGames}
                                            compWagersLength={competitionWagers.length}
                                            setIsAllGames={setIsAllGames}
                                        />
                                    )}
                                    <ActiveCompSelector
                                        activeComp={getCurrentCompetitionId()}
                                        competitionResults={competitionResults}
                                        setActiveComp={(id: number) => {
                                            setRefetchWagers(true);
                                            setActiveComp(id);
                                        }}
                                    />
                                </>
                            )}
                        </ResultsActionControls>
                    </BannerChildContainer>
                </GameBanner>
            )}
            {competitionResults.length > 0 ? (
                <>
                    {isMobile && (
                        <FlexContainer hda={isHda}>
                            <ActiveCompSelector
                                activeComp={getCurrentCompetitionId()}
                                competitionResults={competitionResults}
                                setActiveComp={(id: number) => {
                                    setRefetchWagers(true);
                                    setActiveComp(id);
                                }}
                            />
                            {!isClover && !isHda && (
                                <GamesListSelector
                                    isLoggedIn={isLoggedIn}
                                    isAllGames={isAllGames}
                                    compWagersLength={competitionWagers.length}
                                    setIsAllGames={setIsAllGames}
                                />
                            )}
                        </FlexContainer>
                    )}
                    <FixtureList
                        competitionResults={competitionResults}
                        competitionWagers={competitionWagers}
                        competitionDividends={competitionDividends}
                        showPoints={showPoints}
                        activeComp={getCurrentCompetitionId()}
                        activeGame={activeGame}
                        gameTitle={gameTitle}
                        activeWager={activeWager}
                        isAllGames={isAllGames}
                        setActiveWager={(w: Wager | undefined) => setActiveWager(w)}
                        isClover={isClover}
                        isHda={isHda}
                        isMobile={isMobile}
                        isLoading={isLoading}
                        nextGameDate={nextGameDate}
                        isLoggedIn={isLoggedIn}
                    />
                </>
            ) : (
                <NoCompetitionsContainer>
                    Sorry, there are no results available for this game at the moment, please try again later.
                </NoCompetitionsContainer>
            )}
        </ThemeProvider>
    );
};

export interface ResultsProps {
    competitionResults: CompetitionResult[];
    competitionDividends: CompetitionDividends;
    offerings?: Offering[];
    activeGame: GameType;
    gameTitle: string;
    isClover: boolean;
    isHda: boolean;
    nextGameDate: string;
}

const MobileTabHeader = styled.div`
    background-color: ${props => props.theme.colours.gameMainColour};
`;

const BannerChildContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-self: flex-end;
    max-width: 100%;
`;

const BannerHeader = styled.h1<{ transparentBackground: boolean }>`
    color: #fff;
    background-color: ${props => (props.transparentBackground ? null : props.theme.colours.gameMainColour)};
    font-style: italic;
    font-size: 3em;
    margin: 0;
    padding: 5px;
    ${breakpoints.below('sm')} {
        font-size: 2em;
    }
    ${breakpoints.below('xs')} {
        font-size: 1.5em;
    }
`;

const ResultsActionControls = styled.div`
    display: inline-flex;
    > div {
        margin-right: 10px;
    }
`;

const FlexContainer = styled.div<{ hda?: boolean }>`
    display: flex;
    justify-content: ${props => (props.hda ? 'left' : 'space-evenly')};
    align-items: center;
    margin: ${props => (props.hda ? '10px 0 0 20px' : '10px 0')};
`;

const NoCompetitionsContainer = styled.div`
    justify-content: center;
    background: rgba(244, 244, 244, 0.9);
    border: 1px solid #707070;
    border-radius: 10px;
    width: 80%;
    margin: 20px auto;
    padding: 50px 0;
    text-align: center;
    max-width: 950px;
`;

export default withResultsLayout(ResultsPage);
