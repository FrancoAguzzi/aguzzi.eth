// /* eslint-disable import/named */
/* eslint-disable import/named */
import { FunctionComponent, useEffect, useRef, useState } from 'react';
import styled, { useTheme } from 'styled-components';
import { GameTemplate, GameTemplateProps, getCurrentOffer } from './gameTemplate';
import { BannerWithBorderContainer } from '@fp/shared/src/components/Game/BannerWithBorderContainer';
import { LuckyDipSelectionsView } from '@fp/shared/src/components/Game/LuckyDipSelectionsView';
import { PrizesListView } from '@fp/shared/src/components/Game/PrizesListView';
import { PurchaseSubscriptionDetailsView } from '@fp/shared/src/components/Game/PurchaseSubscriptionDetailsView';
import { MinigameActionButtons, ActionButton } from '@fp/shared/src/components/Game/MinigameActionButtons';
import { getTotalPrice, isPlayEnabled, openPopup, ViewLinesOverlay, Popup } from '@sportech/pools-components';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import { GameSelectionsBoard } from '@fp/shared/src/components/Game/GameSelectionsBoard';
import { BetSlip, GameType, Offering } from '@sportech/pools-api';
import { BuilderGamePageBanner } from '@fp/shared/src/core/gamePage.builder';
import { useDispatch } from 'react-redux';
import { AuthenticationState } from '@fp/shared/src/features/authentication/authenticationSlice';
import { SlideGameBoardBehaviour } from '@fp/shared/src/components/Game/SlideGameBoardBehaviour';
import { HowToPlayTooltip, getSteps, TourProps } from './minigameHowToPlay';
import { Countdown } from '@fp/shared/src/components/Game/MinigameCountdown';
import Joyride, { ACTIONS, CallBackProps, EVENTS, STATUS } from 'react-joyride';
import { isHdaGame } from '@fp/shared/src/lib/utils';
import dayjs from 'dayjs';

const Container = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    width: 100%;
    padding: 8px;
    margin-top: 2em;
    background: none;
    ${breakpoints.below('lg')} {
        flex-direction: row;
        justify-content: space-between;
        margin-top: auto;
        background: #003112;
    }
`;
const BannerText = styled.h1<{ colour?: string }>`
    font-size: 3.5rem;
    font-weight: 800;
    margin: 15px auto 0;
    color: ${props => props.colour};
    ${breakpoints.below('lg')} {
        font-size: 1.8rem;
        margin: auto 10px auto auto;
    }
    ${breakpoints.below('sm')} {
        font-size: 1.4rem;
    }
    ${breakpoints.below('xs')} {
        font-size: 1rem;
    }
    @media (max-width: 370px) {
        font-size: 0.8rem;
    }
`;
const BannerIcon = styled.img`
    width: 165px;
    height: 30px;
    ${breakpoints.below('lg')} {
        margin-left: 10px;
    }
    ${breakpoints.below('sm')} {
        width: 130px;
        height: 25px;
    }
`;

const Banner: FunctionComponent<{ text?: string; textColour?: string; img?: string }> = ({ text, textColour, img }) => {
    return (
        <Container>
            {img && <BannerIcon src={img} />}
            {text && <BannerText colour={textColour}>{text}</BannerText>}
        </Container>
    );
};
const GameContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
    max-width: 500px;
`;
const MobileContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    max-width: 375px;
    width: 95%;
    margin: 10px auto;
`;
const Background = styled.div`
    position: fixed;
    height: 100%;
    width: 100%;
    z-index: -1;
    background: url('https://cdn.builder.io/api/v1/image/assets%2Ff29f3876ae76471e8e6b1b7440eebcb4%2Feede1e82a0374c5dac00591136bc96c5?width=2000'),
        radial-gradient(circle, rgb(34, 83, 40) 0%, rgb(2, 55, 21) 100%);
    background-repeat: repeat, no-repeat;
    background-position: center center, center center;
    background-size: auto, cover;
`;

const GameBoardClearButtonListItem = styled.li`
    flex: 2;
    height: 45px;
    margin: 2px 5px 2px auto;
    @media (max-width: 342px) {
        margin: 2px auto;
    }
`;

const StyledMain = styled.div`
    width: 100%;
    flex: 2;
    background: transparent;
    position: relative;

    ${breakpoints.below('lg')} {
        margin-right: 0px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }
    ${breakpoints.above('overlay')} {
        min-width: 500px;
    }
`;
const Sidebar = styled.div<{ background?: string; maxWidth?: string }>`
    /* max-width: ${props => (props.maxWidth ? props.maxWidth : '335px')}; */
    /* overflow-y: auto; */
    background: ${(props): string => (props.background ? props.background : '#fff')};
    flex: 1;
    ${breakpoints.below('lg')} {
        display: none;
    }
    width: 400px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: flex-start;
`;
const TermsContainer = styled.div`
    font-weight: bold;
    color: #f0eddb;
    text-align: center;
    p {
        margin: 0 auto;
    }
    margin: 10px auto;
    ${breakpoints.below('lg')} {
        margin-top: 30px;
        padding: 0 10px;
    }
`;

const CountdownContainer = styled.div`
    margin: 5px 0 15px;
    ${breakpoints.below('lg')} {
        margin: 10px 0 10px;
    }
`;

const getOneOffTotal = (betslip: BetSlip[], game: GameType, offerings: Offering[], numberOfGames?: number): string => {
    return numberOfGames && numberOfGames > 0
        ? `£${(
              getTotalPrice(isHdaGame(game), game === 'lucky-clover', betslip, 'pounds', offerings) * numberOfGames
          ).toLocaleStringCash()}`
        : `£0.00`;
};
const getCost = (betslip: BetSlip[], game: GameType, offerings: Offering[]): string => {
    return getTotalPrice(isHdaGame(game), game === 'lucky-clover', betslip, 'pounds', offerings).toLocaleStringCash();
};

// https://day.js.org/docs/en/get-set/day
const DAYJS_DAY_WED = 3;
const DAYJS_DAY_SAT = 6;

export const MinigameTemplate: FunctionComponent<GameTemplateProps> = ({
    competitions,
    offers,
    game,
    gameDescription,
    gameEnabled,
    gamePath,
    gameViewType,
    showFutureGames,
    headerHeight,
    onlyDefaultOffer,
    canAddMultipleLines,
    competitionTypeDescription,
    banner,
    howToManageLines,
    howToPlay,
    showMobilePrice,
    termsAndConditions,
    termsContent,
    viewLinesOffers,
    betslipGameType,
    betslipState,
    wagersState,
    userState,
    addLine,
    changeCompetition,
    changeCurrentBet,
    clearLine,
    selectAmount,
    selectLuckyDip,
    selectPlay,
    selectPrediction,
    setCanEditLine,
    setCurrentOfferingId,
    setEditLineAllFutureGames,
    setIsLoading,
    setNumberOfGames,
    setShowFutureCompetitions,
    setShowMore,
    setShowSlideBoard,
    setShowWagerFixtures,
    setShowWagers,
    setViewLinesCurrent,
    fetchWagers,
    handleUpdateWager,
    resetBetslipWagerSelections,
    betslipWager,
    betslipWagerHasEdits,
    canEditLine,
    currentOfferingId,
    editLineAllFutureGames,
    editWagerError,
    isLoading,
    isMobileOrTablet,
    numberOfGames,
    showFutureCompetitions,
    showHda,
    showMore,
    showSlideBoard,
    showWagerFixtures,
    showWagers,
    viewLinesCurrent,
    wagers,
    wagersForCompetitions,
    background,
}) => {
    const dispatch = useDispatch();
    // const theme = useTheme();
    const currentBet = betslipState[betslipGameType].find(x => x.current == true);
    const offer = offers?.offerings.find(o => o.id === currentBet?.priceID);
    const currentCompetition = competitions.find(c => c.id === currentBet?.competitionId);
    const allSelectionsMade = isPlayEnabled(betslipState[betslipGameType], offers);
    const [tourProps, setTourProps] = useState<TourProps>({
        run: false,
        stepIndex: 0,
        inProgress: false,
    });
    const gamePanelRef = useRef<HTMLDivElement>(null);
    const actionButtonsPanelRef = useRef<HTMLDivElement>(null);

    /**
     * Get date for future clover competition.
     * Assumes draws every wednesday and saturday.
     * @param lastCompetitionStr - date of known clover competition.
     * @param numberOfCompetitionsInFuture.
     * @param dateFormat.
     * @returns formatted string of predicted future clover competition.
     */
    const getDateForFutureCompetition = (
        lastCompetitionStr: string,
        numberOfCompetitionsInFuture: number,
        dateFormat?: string,
    ): string => {
        const getDaysToNextCompetition = (competitionDate: dayjs.Dayjs): number =>
            competitionDate.day() === DAYJS_DAY_WED ? 3 : 4;

        let daysToFutureCompetition = 0;
        const lastCompetitionDate = dayjs(lastCompetitionStr);
        if (numberOfCompetitionsInFuture > 0) {
            for (let i = 0; i < numberOfCompetitionsInFuture; i++) {
                daysToFutureCompetition += getDaysToNextCompetition(
                    lastCompetitionDate.add(daysToFutureCompetition, 'day'),
                );
            }
        }
        const ret = lastCompetitionDate.add(daysToFutureCompetition, 'day').format(dateFormat ?? 'D MMM');
        return ret;
    };

    const draws = [1, 2, 4, 8]; //Available Draws
    // Number of draws to last competition we have details for:
    const lastAvailableDrawForCompetition = draws.filter(d => competitions && competitions.length >= d).pop() || 0;
    const availableDraws: { count: number; date: string }[] =
        competitions.length > 0
            ? draws.map((availableDraw, index) => {
                  const date = competitions[availableDraw - 1]
                      ? dayjs(competitions[availableDraw - 1].datumDate).format('D MMM')
                      : lastAvailableDrawForCompetition >= 0
                      ? getDateForFutureCompetition(
                            competitions[lastAvailableDrawForCompetition > 0 ? lastAvailableDrawForCompetition - 1 : 0]
                                ?.datumDate,
                            availableDraw - lastAvailableDrawForCompetition,
                            'D MMM',
                        )
                      : 'TBC';
                  return {
                      count: availableDraw,
                      date: date,
                  };
              })
            : [];

    const handleJoyrideCallback = (data: CallBackProps) => {
        const { status, type, index, action } = data;

        if (([STATUS.FINISHED, STATUS.SKIPPED] as string[]).includes(status) || action === ACTIONS.CLOSE) {
            // Need to set our running state to false, so we can restart if we click start again.
            setShowSlideBoard(false);
            setTourProps({ run: false, stepIndex: 0, inProgress: false });
            setTimeout(
                () =>
                    window.scroll({
                        top: 0,
                        left: 0,
                        behavior: 'smooth',
                    }),
                250,
            );
        } else if (([EVENTS.STEP_BEFORE] as string[]).includes(type)) {
            switch (index) {
                case 0: {
                    // Hide board at beginning of tour:
                    if (showSlideBoard) {
                        setShowSlideBoard(false);
                    }
                    break;
                }
            }
        } else if (([EVENTS.STEP_AFTER, EVENTS.TARGET_NOT_FOUND] as string[]).includes(type)) {
            const stepIndex = index + (action === ACTIONS.PREV ? -1 : 1);
            switch (index) {
                case 0: {
                    // Show board and progress next step after small delay:
                    setShowSlideBoard(true);
                    setTourProps({ run: false, stepIndex, inProgress: true });
                    setTimeout(
                        () => {
                            setTourProps({ run: true, stepIndex, inProgress: true });
                        },
                        isMobileOrTablet ? 750 : 250,
                    );
                    break;
                }
                case 1: {
                    // Hide board and progress to next step:
                    setShowSlideBoard(false);
                    setTourProps({ run: true, stepIndex, inProgress: true });
                    break;
                }
                default: {
                    // Progress to next step:
                    setTourProps({ run: true, stepIndex, inProgress: true });
                    break;
                }
            }
        }
        if (process.env.NODE_ENV === 'development') {
            console.groupCollapsed(type);
            console.log(data);
            console.groupEnd();
        }
    };

    return (
        <>
            <Joyride
                tooltipComponent={HowToPlayTooltip}
                callback={handleJoyrideCallback}
                continuous={true}
                showProgress={true}
                showSkipButton={true}
                steps={getSteps(isMobileOrTablet)}
                styles={{
                    options: {
                        zIndex: 10000,
                        primaryColor: '#000',
                        width: 900,
                    },
                }}
                stepIndex={tourProps.stepIndex}
                run={tourProps.run}
                scrollOffset={65}
            />
            <StyledMain>
                {showWagers && wagersForCompetitions.length === 0 && (
                    <ViewLinesOverlay
                        onClick={(): void => {
                            setShowWagers(false);
                        }}
                    />
                )}

                <GameContainer>
                    <BannerWithBorderContainer
                        className="step-1"
                        subtitle={offer ? `£${(offer.pricePerEntry / 100).toLocaleStringCash()}` : undefined}
                        ref={gamePanelRef}
                        backgroundImg={background?.mainPanelBackgroundImg}
                        isMobileOrTablet={isMobileOrTablet}
                    >
                        <LuckyDipSelectionsView
                            offer={offer}
                            currentSelections={currentBet?.numbers}
                            currentBonusSelections={currentBet?.bonusNumbers}
                            onClickItem={(index: number, isBonus?: boolean) => {
                                let selected = false;
                                let numberToToggle: number | undefined = undefined;
                                if (isBonus) {
                                    selected = Boolean(
                                        currentBet?.bonusNumbers && currentBet?.bonusNumbers.length > index,
                                    );
                                    numberToToggle = selected ? currentBet?.bonusNumbers[index]?.Id : -1;
                                } else {
                                    selected = Boolean(currentBet?.numbers && currentBet?.numbers.length > index);
                                    numberToToggle =
                                        selected && currentBet && currentBet.numbers
                                            ? currentBet?.numbers[index]?.Id
                                            : -1;
                                }
                                if (selected && numberToToggle) {
                                    selectPrediction(numberToToggle, 'D');
                                    setShowSlideBoard(true);
                                }
                                if (!selected) {
                                    setShowSlideBoard(!showSlideBoard);
                                }
                            }}
                        />
                    </BannerWithBorderContainer>
                    <MinigameActionButtons
                        ref={actionButtonsPanelRef}
                        showLuckyDipButton={true}
                        onClickLuckyDip={() => selectLuckyDip(true, true)}
                        showSelectNumbersButton={true}
                        onClickSelectNumbers={() => setShowSlideBoard(!showSlideBoard)}
                        showGameInfoButton={true}
                        onClickGameInfo={() => dispatch(openPopup('gameInfo'))}
                    />
                    {isMobileOrTablet && (
                        <MobileContainer className="step-2m">
                            <PurchaseSubscriptionDetailsView
                                className="step-3"
                                titleText="NUMBER OF DRAWS"
                                subtitleText={`£${(
                                    (offers.defaultOffering.pricePerEntry +
                                        (offers.defaultOffering.mustIncludeBonus &&
                                        offers.defaultOffering.bonusPricePerEntry
                                            ? offers?.defaultOffering?.bonusPricePerEntry
                                            : 0)) /
                                    100
                                ).toLocaleStringCash()} per draw`}
                                maximumNumberOfGames={8}
                                totalCost={getOneOffTotal(
                                    betslipState[betslipGameType],
                                    game,
                                    offers.offerings,
                                    numberOfGames,
                                )}
                                onSelectNumberOfGames={setNumberOfGames}
                                availableDraws={availableDraws}
                                onSelectPlay={() => selectPlay(undefined, undefined, 'login')}
                                textColour="#f0eddb"
                                currentSelection={numberOfGames}
                                isPlayEnabled={Boolean(
                                    isPlayEnabled(betslipState[betslipGameType], offers) &&
                                        numberOfGames &&
                                        numberOfGames > 0,
                                )}
                                onSelectPlayButtonClassName="step-4"
                            />
                            <Popup
                                popupStyles={{
                                    maxWidth: '390px !important',
                                    mobileMargin: 'auto',
                                    padding: '10px !important',
                                    backgroundImage: `url('https://cdn.builder.io/api/v1/image/assets%2Ff29f3876ae76471e8e6b1b7440eebcb4%2Feede1e82a0374c5dac00591136bc96c5?width=2000'), radial-gradient(circle, rgb(34, 83, 40) 0%, rgb(2, 55, 21) 100%) `,
                                    headerStyles: {
                                        textAlign: 'center',
                                        color: '#fff',
                                    },
                                    crossStyles: {
                                        iconImg: '/six_clovers_close_cross.svg',
                                        top: '-12px',
                                        right: '50px',
                                    },
                                }}
                                popupName="minigamePrizes"
                                withCloseButton={true}
                            >
                                <PrizesListView
                                    className="step-5"
                                    title="PRIZES"
                                    subtitle="Pick 5 & Millionaire Maker*"
                                    items={[
                                        {
                                            msg: 'Match 5 + Millionaire Maker = £1 Million',
                                            colour: '#fad600',
                                            fontWeight: 'bold',
                                        },
                                        { msg: 'Match 5 = £65,000' },
                                        { msg: 'Match 4 of 5 = £100' },
                                        { msg: 'Match 3 of 5 = £10' },
                                        { msg: 'Match 2 of 5 = £5' },
                                    ]}
                                    background="#023715"
                                    textColour="#f0eddb"
                                />
                                {termsContent && <TermsContainer dangerouslySetInnerHTML={{ __html: termsContent }} />}
                            </Popup>

                            <SlideGameBoardBehaviour
                                className="step-2a"
                                isOpen={showSlideBoard}
                                setIsOpen={setShowSlideBoard}
                                isDrawer={true}
                                background="#f0eddb"
                                scrollToElement={gamePanelRef}
                                topStartElement={actionButtonsPanelRef}
                                closeOnOutsideClick={!tourProps.inProgress}
                            >
                                <GameSelectionsBoard
                                    selections={currentCompetition?.fixtures}
                                    currentSelections={currentBet?.numbers}
                                    currentBonusSelections={currentBet?.bonusNumbers}
                                    onClickItem={(fixtureNumber: number) => selectPrediction(fixtureNumber, 'D')}
                                    endListItem={
                                        <GameBoardClearButtonListItem>
                                            <ActionButton
                                                bgColor={allSelectionsMade ? `#ffc048` : `transparent`}
                                                border="3px solid #235348"
                                                hoverBorder="3px solid #235348"
                                                hoverColor={allSelectionsMade ? `#ffc048` : `transparent`}
                                                textColor={allSelectionsMade ? `#235348` : `rgba(35,83,72,0.4)`}
                                                onClick={() => {
                                                    console.log('closing game board');
                                                    setShowSlideBoard(false);
                                                }}
                                            >
                                                DONE
                                            </ActionButton>
                                        </GameBoardClearButtonListItem>
                                    }
                                />
                            </SlideGameBoardBehaviour>
                        </MobileContainer>
                    )}
                </GameContainer>
            </StyledMain>
            {!isMobileOrTablet && (
                <Sidebar className="step-2" background="none">
                    <>
                        <PurchaseSubscriptionDetailsView
                            className="step-3"
                            titleText="NUMBER OF DRAWS"
                            subtitleText={`£${(
                                (offers.defaultOffering.pricePerEntry +
                                    (offers.defaultOffering.mustIncludeBonus &&
                                    offers.defaultOffering.bonusPricePerEntry
                                        ? offers?.defaultOffering?.bonusPricePerEntry
                                        : 0)) /
                                100
                            ).toLocaleStringCash()} per draw`}
                            maximumNumberOfGames={8}
                            totalCost={getOneOffTotal(
                                betslipState[betslipGameType],
                                game,
                                offers.offerings,
                                numberOfGames,
                            )}
                            onSelectNumberOfGames={setNumberOfGames}
                            availableDraws={availableDraws}
                            onSelectPlay={() => selectPlay(undefined, undefined, 'login')}
                            textColour="#f0eddb"
                            currentSelection={numberOfGames}
                            isPlayEnabled={Boolean(
                                isPlayEnabled(betslipState[betslipGameType], offers) &&
                                    numberOfGames &&
                                    numberOfGames > 0,
                            )}
                            onSelectPlayButtonClassName="step-4"
                        />
                        {termsContent && <TermsContainer dangerouslySetInnerHTML={{ __html: termsContent }} />}
                        <SlideGameBoardBehaviour
                            className="step-2a"
                            isOpen={showSlideBoard}
                            isDrawer={false}
                            setIsOpen={setShowSlideBoard}
                            closeOnOutsideClick={!tourProps.inProgress}
                        >
                            <GameSelectionsBoard
                                selections={currentCompetition?.fixtures}
                                currentSelections={currentBet?.numbers}
                                currentBonusSelections={currentBet?.bonusNumbers}
                                onClickItem={(fixtureNumber: number) => selectPrediction(fixtureNumber, 'D')}
                                endListItem={
                                    <GameBoardClearButtonListItem>
                                        <ActionButton
                                            bgColor={allSelectionsMade ? `#ffc048` : `transparent`}
                                            border="3px solid #235348"
                                            hoverBorder="3px solid #235348"
                                            hoverColor={allSelectionsMade ? `#ffc048` : `transparent`}
                                            textColor={allSelectionsMade ? `#235348` : `rgba(35,83,72,0.4)`}
                                            onClick={() => {
                                                setShowSlideBoard(false);
                                            }}
                                        >
                                            DONE
                                        </ActionButton>
                                    </GameBoardClearButtonListItem>
                                }
                            />
                        </SlideGameBoardBehaviour>
                    </>
                </Sidebar>
            )}
        </>
    );
};

export const useMinigameTemplate = (): GameTemplate => {
    // const getOneOffTotal = (
    //     betslip: BetSlip[],
    //     game: GameType,
    //     offerings: Offering[],
    //     numberOfGames?: number,
    // ): string => {
    //     return numberOfGames && numberOfGames > 0
    //         ? `£${(
    //               getTotalPrice(false, game === 'lucky-clover', betslip, 'pounds', offerings) * numberOfGames
    //           ).toLocaleStringCash()}`
    //         : `£0.00`;
    // };
    // const getCost = (betslip: BetSlip[], game: GameType, offerings: Offering[]): string => {
    //     return getTotalPrice(false, game === 'lucky-clover', betslip, 'pounds', offerings).toLocaleStringCash();
    // };

    const sidebarWidth = '400px';

    const renderBackground = (): JSX.Element => {
        return <Background />;
    };

    const renderBannerPanel = (
        game?: GameType,
        banner?: BuilderGamePageBanner,
        paymentTypes?: ('subscription' | 'one-time-payment')[],
        isMobileOrTablet?: boolean,
        headerHeight?: number,
        nextGameDate?: string,
    ): JSX.Element => {
        return (
            <>
                <Banner text={banner?.headerText} textColour="#fff" img={'/logo-six-clovers.png'} />
                {nextGameDate && (
                    <CountdownContainer>
                        <Countdown headerText="NEXT GAME STARTS:" target={nextGameDate} />
                    </CountdownContainer>
                )}
            </>
        );
    };

    // const renderMainPanel = (
    //     game: GameType,
    //     betslipState: BetSlipSlice,
    //     betslipGameType: keyof BetSlipSlice,
    //     showHda: boolean,
    //     changeCompetition: (id: number, name: string) => void,
    //     clearLine: (index?: number) => void,
    //     selectAmount: (id: number, offer: Offering) => void,
    //     selectLuckyDip: (isBonus?: boolean, noSelectionsMade?: boolean) => void,
    //     selectPlay: (event?: Event, cloverUpsellOverride?: boolean) => void,
    //     selectPrediction: (id: number, type: string) => void,
    //     competitions: Competition[],
    //     offers: Offerings,
    //     setCurrentOfferingId: (id: number) => void,
    //     setNumberOfGames: (noOfGames: number) => void,
    //     setShowMore: (show: boolean) => void,
    //     setShowSlideBoard: (show: boolean) => void,
    //     showFutureGames: boolean,
    //     showSlideBoard: boolean,
    //     wagersForCompetitions: Wager[],
    //     showWagers?: boolean,
    //     canEditLine?: boolean,
    //     currentOfferingId?: number,
    //     betslipWager?: BetSlip,
    //     competitionTypeDescription?: string,
    //     gameDescription?: string,
    //     gameViewType?: GameViewType,
    //     onlyDefaultOffer?: boolean,
    //     numberOfGames?: number,
    // ): JSX.Element => {
    //     const currentBet = betslipState[betslipGameType].find(x => x.current == true);
    //     const offer = offers?.offerings.find(o => o.id === currentBet?.priceID);
    //     const currentCompetition = competitions.find(c => c.id === currentBet?.competitionId);
    //     const allSelectionsMade = isPlayEnabled(betslipState[betslipGameType], offers);
    //     const dispatch = useDispatch();
    //     return (
    //         <GameContainer>
    //             <BannerWithBorderContainer
    //                 title="ST. PATRICK'S DAY"
    //                 subtitle={offer ? `£${(offer.pricePerEntry / 100).toLocaleStringCash()}` : undefined}
    //             >
    //                 <LuckyDipSelectionsView
    //                     offer={offer}
    //                     currentSelections={currentBet?.numbers}
    //                     currentBonusSelections={currentBet?.bonusNumbers}
    //                     onClickItem={(index, isBonus) => {
    //                         console.log('click selections');
    //                         let selected = false;
    //                         let numberToToggle: number | undefined = undefined;
    //                         if (isBonus) {
    //                             selected = Boolean(
    //                                 currentBet?.bonusNumbers && currentBet?.bonusNumbers.length >= index,
    //                             );
    //                             numberToToggle = selected ? currentBet?.bonusNumbers[index]?.Id : -1;
    //                         } else {
    //                             selected = Boolean(currentBet?.numbers && currentBet?.numbers.length >= index);
    //                             numberToToggle =
    //                                 selected && currentBet && currentBet.numbers ? currentBet?.numbers[index]?.Id : -1;
    //                         }
    //                         if (selected && numberToToggle) {
    //                             selectPrediction(numberToToggle, 'D');
    //                         }
    //                         if (!selected) {
    //                             setShowSlideBoard(!showSlideBoard);
    //                         }
    //                     }}
    //                 />
    //             </BannerWithBorderContainer>
    //             <MinigameActionButtons
    //                 showClearButton={true}
    //                 showLuckyDipButton={true}
    //                 onClickClear={() => clearLine()}
    //                 onClickLuckyDip={() => selectLuckyDip(true, true)}
    //                 onClickHowToPlay={() => dispatch(openPopup('miniGameHowToPlay'))}
    //             />
    //             <MobileContainer>
    //                 <PurchaseSubscriptionDetailsView
    //                     titleText="NUMBER OF DRAWS"
    //                     subtitleText={`£${getCost(betslipState[betslipGameType], game, offers.offerings)} per draw`}
    //                     maximumNumberOfGames={8}
    //                     totalCost={getOneOffTotal(betslipState[betslipGameType], game, offers.offerings, numberOfGames)}
    //                     onSelectNumberOfGames={setNumberOfGames}
    //                     onSelectPlay={selectPlay}
    //                     textColour="#f0eddb"
    //                     currentSelection={numberOfGames}
    //                     isPlayEnabled={allSelectionsMade}
    //                 />
    //                 <PrizesListView
    //                     title="PRIZES"
    //                     subtitle="Correctly Predict"
    //                     items={[
    //                         { msg: 'Match All 6 Numbers WIN: £1 Million', colour: '#fad600', fontWeight: 'bold' },
    //                         { msg: 'Match Your First 5 Numbers WIN: £65,000' },
    //                         { msg: 'Match ANY 4 Numbers WIN: £100' },
    //                         { msg: 'Match ANY 3 Numbers WIN: £10' },
    //                         { msg: 'Match ANY 2 Numbers WIN: £5' },
    //                     ]}
    //                     background="#023715"
    //                     textColour="#f0eddb"
    //                 />
    //                 <GameSelectionsBoard
    //                     selections={currentCompetition?.fixtures}
    //                     currentSelections={currentBet?.numbers}
    //                     currentBonusSelections={currentBet?.bonusNumbers}
    //                     onClickItem={(fixtureNumber: number) => selectPrediction(fixtureNumber, 'D')}
    //                     endListItem={
    //                         <GameBoardClearButtonListItem>
    //                             <ActionButton
    //                                 bgColor={allSelectionsMade ? `#ffc048` : `transparent`}
    //                                 border="3px solid #235348"
    //                                 hoverBorder="3px solid #235348"
    //                                 hoverColor={allSelectionsMade ? `#ffc048` : `transparent`}
    //                                 textColor={allSelectionsMade ? `#235348` : `rgba(35,83,72,0.4)`}
    //                                 onClick={() => {
    //                                     console.log('closing game board');
    //                                     setShowSlideBoard(false);
    //                                 }}
    //                             >
    //                                 DONE
    //                             </ActionButton>
    //                         </GameBoardClearButtonListItem>
    //                     }
    //                 />
    //             </MobileContainer>
    //         </GameContainer>
    //     );
    // };

    // const renderSidePanel = (
    //     game: GameType,
    //     betslipState: BetSlipSlice,
    //     betslipGameType: keyof BetSlipSlice,
    //     userState: AuthenticationState,
    //     fetchWagers: () => void,
    //     setShowWagers: (show: boolean) => void,
    //     changeCurrentBet: (index: number) => void,
    //     clearLine: (index?: number) => void,
    //     addLine: () => void,
    //     handleUpdateWager: () => Promise<void>,
    //     resetBetslipWagerSelections: () => void,
    //     showHda: boolean,
    //     selectAmount: (id: number, offer: Offering) => void,
    //     selectPrediction: (id: number, type: string) => void,
    //     competitions: Competition[],
    //     offers: Offerings,
    //     setCurrentOfferingId: (id: number) => void,
    //     setEditLineAllFutureGames: (allGames: boolean) => void,
    //     setNumberOfGames: (noOfGames: number) => void,
    //     setShowMore: (show: boolean) => void,
    //     setShowSlideBoard: (show: boolean) => void,
    //     setShowWagerFixtures: (show: boolean) => void,
    //     setViewLinesCurrent: (current: ViewLinesCurrent) => void,
    //     betslipWagerHasEdits: boolean,
    //     editLineAllFutureGames: boolean,
    //     showMore: boolean,
    //     showSlideBoard: boolean,
    //     showWagers: boolean,
    //     viewLinesCurrent: ViewLinesCurrent,
    //     wagersForCompetitions: Wager[],
    //     selectPlay: (event?: Event, cloverUpsellOverride?: boolean) => void,
    //     canAddMultipleLines?: boolean,
    //     canEditLine?: boolean,
    //     currentOfferingId?: number,
    //     betslipWager?: BetSlip,
    //     competitionTypeDescription?: string,
    //     numberOfGames?: number,
    //     onlyDefaultOffer?: boolean,
    //     termsContent?: string,
    //     viewLinesOffers?: Offerings,
    // ): JSX.Element => {
    //     const currentBet = betslipState[betslipGameType].find(x => x.current == true);
    //     const offer = offers?.offerings.find(o => o.id === currentBet?.priceID);
    //     const currentCompetition = competitions.find(c => c.id === currentBet?.competitionId);
    //     const allSelectionsMade = isPlayEnabled(betslipState[betslipGameType], offers);
    //     return (
    //         <>
    //             <PrizesListView
    //                 title="PRIZES"
    //                 subtitle="Correctly Predict"
    //                 items={[
    //                     { msg: 'Match All 6 Numbers WIN: £1 Million', colour: '#fad600', fontWeight: 'bold' },
    //                     { msg: 'Match Your First 5 Numbers WIN: £65,000' },
    //                     { msg: 'Match ANY 4 Numbers WIN: £100' },
    //                     { msg: 'Match ANY 3 Numbers WIN: £10' },
    //                     { msg: 'Match ANY 2 Numbers WIN: £5' },
    //                 ]}
    //                 background="#023715"
    //                 textColour="#f0eddb"
    //             />
    //             <PurchaseSubscriptionDetailsView
    //                 titleText="NUMBER OF DRAWS"
    //                 subtitleText={`£${getCost(betslipState[betslipGameType], game, offers.offerings)} per draw`}
    //                 maximumNumberOfGames={8}
    //                 totalCost={getOneOffTotal(betslipState[betslipGameType], game, offers.offerings, numberOfGames)}
    //                 onSelectNumberOfGames={setNumberOfGames}
    //                 onSelectPlay={selectPlay}
    //                 textColour="#f0eddb"
    //                 currentSelection={numberOfGames}
    //                 isPlayEnabled={Boolean(
    //                     isPlayEnabled(betslipState[betslipGameType], offers) && numberOfGames && numberOfGames > 0,
    //                 )}
    //             />
    //             <SlideGameBoardBehaviour isOpen={showSlideBoard}>
    //                 <GameSelectionsBoard
    //                     selections={currentCompetition?.fixtures}
    //                     currentSelections={currentBet?.numbers}
    //                     currentBonusSelections={currentBet?.bonusNumbers}
    //                     onClickItem={(fixtureNumber: number) => selectPrediction(fixtureNumber, 'D')}
    //                     endListItem={
    //                         <GameBoardClearButtonListItem>
    //                             <ActionButton
    //                                 bgColor={allSelectionsMade ? `#ffc048` : `transparent`}
    //                                 border="3px solid #235348"
    //                                 hoverBorder="3px solid #235348"
    //                                 hoverColor={allSelectionsMade ? `#ffc048` : `transparent`}
    //                                 textColor={allSelectionsMade ? `#235348` : `rgba(35,83,72,0.4)`}
    //                                 onClick={() => {
    //                                     console.log('closing game board');
    //                                     setShowSlideBoard(false);
    //                                 }}
    //                             >
    //                                 DONE
    //                             </ActionButton>
    //                         </GameBoardClearButtonListItem>
    //                     }
    //                 />
    //             </SlideGameBoardBehaviour>
    //         </>
    //     );
    // };

    // const renderBottomPanel = (props: GameTemplateProps): JSX.Element => {
    //     return <div>bottom</div>;
    // };

    return {
        renderBackground,
        renderBannerPanel,
        // renderHeaderPanel,
        // renderMobileHeaderPanel,
        // renderMainPanel,
        // renderSidePanel,
        // renderBottomPanel,
        sidebarWidth,
    };
};
