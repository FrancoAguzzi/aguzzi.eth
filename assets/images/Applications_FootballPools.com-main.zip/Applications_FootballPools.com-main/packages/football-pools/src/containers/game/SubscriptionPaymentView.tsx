/* eslint-disable import/named */
import { useRouter } from 'next/router';
import styled from 'styled-components';

import { breakpoints } from '@fp/shared/src/settings/breakpoints';

import {
    AuthoriseCardForm,
    AuthoriseCardFormBms,
    AuthoriseCardResponse,
    BetSlip,
    BetSlipSlice,
    Competition,
    ConfirmWagers,
    PaymentMethod,
    PaymentMethods,
    PoolsApiError,
    ResetBetSlipSelections,
    resetWagers,
    toBetSlipKey,
    WagersSlice,
} from '@sportech/pools-api';
import { BetSelections, Button } from '@sportech/pools-components';
import { getGameTitle, isHdaGame } from '@fp/shared/src/lib/utils';

import ProgressBar from '@fp/shared/src/components/ProgressBar/ProgressBar';
import { PaymentTypesRadioGroup } from '@fp/shared/src/components/PaymentTypesRadioGroup/PaymentTypesRadioGroup';
import { CardForm } from '@fp/shared/src/components/Forms/Payment/CardForm';
import { DirectDebitForm, ExistingDirectDebitForm } from '@fp/shared/src/components/Forms/Payment/DirectDebitForm';
import { Loader } from '@fp/shared/src/components/Loader/Loader';
import { PaymentDetailsV2 } from '@fp/shared/src/components/Forms/Payment/PaymentDetailsV2';
import { Banner } from '@fp/shared/src/components/Forms/Payment/Banner';
import { AuthenticationState } from '@fp/shared/src/features/authentication/authenticationSlice';
import { useDispatch } from 'react-redux';
import { AppDispatch } from '@fp/shared/src/store';
import { ChangeEvent } from 'react';
import { PayPalForm } from '@fp/shared/src/components/Forms/Payment/PayPalForm';
import { BuilderPaymentPageData } from '@fp/shared/src/core/paymentPage.builder';
import { RecommendedProduct } from '@fp/shared/src/components/RecommendedProduct/RecommendedProduct';
import getConfig from 'next/config';

const { publicRuntimeConfig } = getConfig();

const SectionsContainer = styled.div`
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
`;

const SectionContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: #fff;
    border-radius: 10px;
    margin: 5px auto;
    padding: 5px;
    width: 100%;
    ${breakpoints.below('xs')} {
        width: 90%;
    }
    @media (max-width: 385px) {
        width: 95%;
    }
`;

const LoaderBackground = styled.div`
    @keyframes pulse {
        0% {
            box-shadow: 0 0 0 0 rgba(0, 195, 8, 0.4);
        }
        70% {
            box-shadow: 0 0 0 10px rgba(0, 195, 8, 0);
        }
        100% {
            box-shadow: 0 0 0 0 rgba(0, 195, 8, 0);
        }
    }
    box-shadow: 0 0 0 rgba(0, 195, 8, 0.4);
    animation: pulse 2s infinite;
    background: #7cda24; // rgba(0, 195, 8, 0.4);
    border-radius: 50px;
    width: 90%;
    height: 60px;
    position: absolute;
    z-index: -1;
`;

const ProgressEndContainer = styled.div<{ background?: string; borderColour?: string }>`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: ${props => props.background || '#fff '};
    border-radius: 10px;
    border: ${props => `1px solid ${props.borderColour || props.theme.colours.primary}`};
    margin: 5px auto;
    padding: 5px;
`;

const TitleText = styled.h3`
    color: ${props => props.theme.colours.primaryFont};
    font-size: 1rem;
    margin-top: 10px auto 5px;
`;

const PaymentStepBackContainer = styled.div`
    color: ${props => props.theme.colours.primaryFont};
    cursor: pointer;
    font-size: 0.9rem;
    font-weight: bold;
    margin: 15px 0 10px 15px;
    width: 100%;
`;

const ProgressContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 0 5px;
    margin: 10px auto;
    width: 100%;
    ${breakpoints.below('xs')} {
        width: 92%;
    }
    @media (max-width: 385px) {
        width: 97%;
    }
`;

const SecurePaymentsContainer = styled.div`
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    justify-content: space-evenly;
    color: ${props => props.theme.colours.primaryFont};
    font-weight: bold;
    font-size: 0.8rem;
    margin: 5px auto 1.2rem auto;
    width: 100%;
`;

const Header = styled.h2`
    color: ${props => props.theme.colours.primary};
    margin-top: 0px;
    text-align: center;
    width: 100%;
    margin: 1.2rem 0;
`;

const DetailsText = styled.div<{ fontWeight?: string; fontSize?: string }>`
    font-size: ${props => props.fontSize};
    font-weight: ${props => props.fontWeight};
    color: ${props => props.theme.colours.primary};
    line-height: 1.2rem;
    margin-bottom: 10px;
`;

const ConfirmationContainer = styled.div`
    display: flex;
    flex-direction: column;
    padding: 0 10px;
    width: 100%;
    margin-bottom: 10px;
`;

const BetSelectionsConfirmationContainer = styled.div`
    display: flex;
    flex-direction: column;
    margin: 10px 0;
    width: 100%;
    max-height: 200px;
    overflow-y: scroll;
`;

const FinancialLimitsContainer = styled.div`
    /* display: flex; */
    color: ${props => props.theme.colours.primaryFont};
    font-size: 0.75rem;
    margin: 1.2rem 0;
    a {
        text-decoration: underline;
    }
`;

const SubtitleText = styled.h4<{ fontColour?: string; fontSize?: string }>`
    color: ${props => props.fontColour || props.theme.colours.primary};
    font-size: ${props => props.fontSize || '1rem'};
    margin: 10px;
`;

export interface PaymentViewProps {
    wagersState: WagersSlice;
    betslipState: BetSlipSlice;
    userState: AuthenticationState;
    paymentStep: 'details' | 'confirming' | 'confirm';
    isLoading: boolean;
    setIsLoading: (loading: boolean) => void;
    onPaymentMethodToggleChange: (event: ChangeEvent<HTMLInputElement>) => void;
    currentPaymentMethod?: PaymentMethod;
    paymentMethodOptions?: PaymentMethods;
    cardErrors?: PoolsApiError[];
    directDebitErrors?: PoolsApiError[];
    payPalErrors?: PoolsApiError[];
    setCardErrors: (errors?: PoolsApiError[]) => void;
    setDirectDebitErrors: (errors?: PoolsApiError[]) => void;
    setPayPalErrors: (errors?: PoolsApiError[]) => void;
    onSubmitCardForm: (data: ConfirmWagers) => Promise<void>;
    onSubmitDirectDebitForm: (data: ConfirmWagers) => void;
    onSubmitPayPalForm: () => boolean;
    setCurrentPaymentMethod: (type?: PaymentMethod) => void;
    onClickBack: () => void;
    paymentDetailsContent?: BuilderPaymentPageData;
    getTermUrl: () => string;
    onAuthoriseSuccess: (res: AuthoriseCardResponse) => void;
    onAuthoriseError: (error: unknown) => void;
    getAmount: () => string;
    competitions?: Competition[];
    hasSpendLimit?: boolean;
}

export const SubscriptionPaymentView = ({
    wagersState,
    betslipState,
    userState,
    paymentStep,
    isLoading,
    setIsLoading,
    onPaymentMethodToggleChange,
    currentPaymentMethod,
    paymentMethodOptions,
    cardErrors,
    directDebitErrors,
    payPalErrors,
    setCardErrors,
    setDirectDebitErrors,
    setPayPalErrors,
    onSubmitCardForm,
    onSubmitDirectDebitForm,
    onSubmitPayPalForm,
    onClickBack,
    paymentDetailsContent,
    getTermUrl,
    onAuthoriseError,
    onAuthoriseSuccess,
    getAmount,
    competitions,
}: PaymentViewProps): JSX.Element => {
    const router = useRouter();
    const dispatch = useDispatch<AppDispatch>();
    const getFeatureLineText = (game: string) => {
        let featureLineText = '';
        switch (game) {
            case 'classic-pools':
                featureLineText = '£3 MILLION CASH';
                break;
            case 'lucky-clover':
            case 'goal-rush':
                featureLineText = 'BIG CASH PRIZES';
                break;
            default:
                break;
        }
        return featureLineText;
    };
    return (
        <>
            <Banner
                preFeatureLines={['Two chances to win']}
                featureLines={[getFeatureLineText(`${wagersState.game}`)]}
                postFeatureLines={['each week!']}
                fontColour="#fff"
                fontWeight="bold"
                margin="30px auto 10px"
            />

            <ProgressContainer>
                <ProgressBar
                    active={paymentStep === 'details' ? 1 : 2}
                    steps={2}
                    activeStyle={{ backgroundColour: '#4CA40C', fontColour: '#fff', border: '1px solid #fff' }}
                    completeStyle={{ backgroundColour: '#4CA40C', fontColour: '#fff', border: '1px solid #fff' }}
                    progressEndElement={
                        <ProgressEndContainer
                            background={paymentStep === 'confirm' ? '#4CA40C' : undefined}
                            borderColour={paymentStep === 'confirm' ? '#fff' : undefined}
                        >
                            <SubtitleText fontColour={paymentStep === 'confirm' ? '#fff' : undefined}>
                                FREE GAMES
                            </SubtitleText>
                        </ProgressEndContainer>
                    }
                />
            </ProgressContainer>
            <SectionsContainer>
                <Loader isLoading={isLoading} backgroundColour={'#000d68'} color="white" loaderType="ThreeDots">
                    <LoaderBackground />
                </Loader>

                {paymentStep === 'details' &&
                (paymentMethodOptions === undefined || paymentMethodOptions.paymentMethods) ? (
                    <SectionContainer>
                        <TitleText>SELECT PAYMENT TYPE</TitleText>
                        {/* <PaymentTypesView
                            paymentTypes={paymentMethodOptions?.paymentMethods}
                            onClickPaymentType={onPaymentTypeSelected}
                        /> */}
                        <PaymentTypesRadioGroup
                            onChange={onPaymentMethodToggleChange}
                            defaultCheckedOption={currentPaymentMethod}
                            paymentMethods={paymentMethodOptions?.paymentMethods}
                        ></PaymentTypesRadioGroup>
                    </SectionContainer>
                ) : (
                    <></>
                )}
                {(paymentStep === 'details' || paymentStep === 'confirming') && (
                    <SectionContainer>
                        <TitleText>
                            {currentPaymentMethod === 'card'
                                ? 'DEBIT CARD'
                                : currentPaymentMethod === 'direct-debit'
                                ? 'DIRECT DEBIT'
                                : 'PAYPAL'}
                        </TitleText>
                        <SecurePaymentsContainer>
                            <img src="/padlock.svg" style={{ marginRight: '5px' }} />
                            SECURE PAYMENTS: We value your security
                        </SecurePaymentsContainer>
                        {wagersState.stage === 'authorising' && wagersState.finaliseDetails ? (
                            <AuthoriseCardFormBms
                                token={wagersState.finaliseDetails.cardConfirmToken}
                                url={wagersState.finaliseDetails.cardConfirmUrl}
                                onSuccess={onAuthoriseSuccess}
                                onError={onAuthoriseError}
                            />
                        ) : currentPaymentMethod === 'paypal' ? (
                            <PayPalForm
                                game={wagersState.game}
                                onSubmitForm={onSubmitPayPalForm}
                                apiErrors={payPalErrors}
                                setApiErrors={setPayPalErrors}
                                token={wagersState.payPalToken}
                            />
                        ) : currentPaymentMethod === 'card' ? (
                            <CardForm
                                game={wagersState.game}
                                onSubmitForm={onSubmitCardForm}
                                apiErrors={cardErrors}
                                setApiErrors={setCardErrors}
                            />
                        ) : paymentMethodOptions?.hasExistingDirectDebit ? (
                            <ExistingDirectDebitForm
                                game={wagersState.game}
                                onSubmitForm={onSubmitDirectDebitForm}
                                apiErrors={directDebitErrors}
                                setApiErrors={setDirectDebitErrors}
                            />
                        ) : (
                            <DirectDebitForm
                                game={wagersState.game}
                                onSubmitForm={onSubmitDirectDebitForm}
                                apiErrors={directDebitErrors}
                                setApiErrors={setDirectDebitErrors}
                            />
                        )}
                        <PaymentStepBackContainer onClick={onClickBack}>Back</PaymentStepBackContainer>
                    </SectionContainer>
                )}
                <SectionContainer>
                    {betslipState[toBetSlipKey(wagersState.game)][0] && (
                        <>
                            <SubtitleText>You can cancel at anytime</SubtitleText>
                            <BetSelectionsConfirmationContainer>
                                {(betslipState[toBetSlipKey(wagersState.game)] as BetSlip[]).map(
                                    (b, index) =>
                                        b.numbers &&
                                        b.numbers.length > 0 && (
                                            <BetSelections
                                                key={`bet-selection-${index}`}
                                                bet={b as BetSlip}
                                                game={wagersState.game}
                                                displayId={!isHdaGame(wagersState.game)}
                                                justifyContent="center"
                                                betslipItemSize={'2.5em'}
                                                selectionsColour={
                                                    wagersState.game === 'lucky-clover' ? '#00955C' : undefined
                                                }
                                                bonusSelectionsColour="#e0ac00"
                                                isCurrentSelectedLine={true}
                                            />
                                        ),
                                )}
                            </BetSelectionsConfirmationContainer>
                        </>
                    )}
                </SectionContainer>
                {paymentStep !== 'confirm' && (
                    <SectionContainer>
                        <SubtitleText>Subscription details</SubtitleText>
                        <PaymentDetailsV2
                            amount={getAmount()}
                            numberOfGames={currentPaymentMethod ? 10 : undefined}
                            numberOfFreeGames={currentPaymentMethod === 'direct-debit' ? 4 : undefined}
                            paymentMethodType={
                                currentPaymentMethod
                                    ? currentPaymentMethod
                                    : paymentMethodOptions &&
                                      paymentMethodOptions.paymentMethods &&
                                      paymentMethodOptions.paymentMethods.length === 1
                                    ? paymentMethodOptions?.paymentMethods[0]
                                    : paymentMethodOptions &&
                                      paymentMethodOptions.paymentMethods &&
                                      paymentMethodOptions.paymentMethods.includes('card')
                                    ? 'card'
                                    : paymentMethodOptions &&
                                      paymentMethodOptions.paymentMethods &&
                                      paymentMethodOptions.paymentMethods.includes('direct-debit')
                                    ? 'direct-debit'
                                    : 'card'
                            }
                            directDebitPaymentDetails={
                                currentPaymentMethod ? paymentDetailsContent?.directDebitPaymentDetails : undefined
                            }
                            directDebitPaymentMessages={paymentDetailsContent?.directDebitMessages}
                            cardPaymentDetails={
                                currentPaymentMethod ? paymentDetailsContent?.cardPaymentDetails : undefined
                            }
                            cardPaymentMessages={paymentDetailsContent?.cardPaymentMessages}
                            paypalPaymentDetails={
                                currentPaymentMethod ? paymentDetailsContent?.paypalPaymentDetails : undefined
                            }
                            paypalPaymentMessages={paymentDetailsContent?.paypalPaymentMessages}
                        />
                    </SectionContainer>
                )}
                {paymentStep === 'confirm' && (
                    <>
                        <SectionContainer>
                            <SubtitleText>CONGRATULATIONS!</SubtitleText>
                            <ConfirmationContainer>
                                <DetailsText fontSize="0.85rem">
                                    {`You have successfully subscribed to ${getGameTitle(
                                        wagersState.game,
                                    )} and have qualified for 4 FREE games!`}
                                </DetailsText>
                                <RecommendedProduct activeGame={wagersState.game} />
                            </ConfirmationContainer>
                        </SectionContainer>
                        <Button
                            role="button"
                            onClick={() => {
                                setIsLoading(true);
                                router.push('/');
                                dispatch(ResetBetSlipSelections({ ItemKey: toBetSlipKey(wagersState.game) }));
                                dispatch(resetWagers({ game: wagersState.game }));
                            }}
                            width="90%"
                            height="50px"
                            bgColor="#7cda24"
                            disabledBackgroundColour="#7cda24"
                            disabledOpacity="0.5"
                            hoverColor="#7cda24"
                            hoverOpacity="0.5"
                            padding="0.75em 1.25em"
                            textColor="#fff"
                            fontWeight="bold"
                            rounded="25px"
                            margin="10px"
                        >
                            {`Go to the homepage`}
                        </Button>
                        <Button
                            title="Submit"
                            role="button"
                            onClick={() => {
                                setIsLoading(true);
                                router.push(`/account/details/contact-preferences`);
                                dispatch(ResetBetSlipSelections({ ItemKey: toBetSlipKey(wagersState.game) }));
                                dispatch(resetWagers({ game: wagersState.game }));
                            }}
                            width="90%"
                            height="50px"
                            bgColor="#7cda24"
                            disabledBackgroundColour="#7cda24"
                            disabledOpacity="0.5"
                            hoverColor="#7cda24"
                            hoverOpacity="0.5"
                            padding="0.75em 1.25em"
                            textColor="#fff"
                            fontWeight="bold"
                            rounded="25px"
                            margin="10px"
                        >
                            {`Update contact preferences`}
                        </Button>
                    </>
                )}
            </SectionsContainer>
        </>
    );
};
