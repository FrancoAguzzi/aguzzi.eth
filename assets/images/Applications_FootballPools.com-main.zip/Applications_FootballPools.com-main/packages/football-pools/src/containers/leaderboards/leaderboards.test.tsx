import { AuthenticationState } from '@fp/shared/src/features/authentication/authenticationSlice';
import { RootState } from '@fp/shared/src/rootReducer';
import { act } from '@testing-library/react';
import { RecursivePartial } from '@fp/shared/src/testing/utils/RecursivePartial';
import { withApiProvider } from '@fp/shared/src/testing/utils/renderWithApiProvider';
import { renderWithRedux } from '@fp/shared/src/testing/utils/renderWithRedux';
import { withTheme } from '@fp/shared/src/testing/utils/renderWithTheme';
import { Leaderboards } from './leaderboards';

jest.mock('next/router', () => ({
    useRouter() {
        return {
            route: '/',
            pathname: '',
            query: '',
            asPath: '',
            isFallback: false,
        };
    },
}));

const enabledLeaderboards: Record<string, boolean> = {};
enabledLeaderboards['leaderboards-classic-pools'] = true;
enabledLeaderboards['leaderboards-goal-rush'] = true;
enabledLeaderboards['leaderboards-premier-6'] = true;
enabledLeaderboards['leaderboards-premier-10'] = true;
enabledLeaderboards['leaderboards-jackpot-12'] = true;

const renderComponent = (initialState: RecursivePartial<RootState>) => {
    const utils = renderWithRedux(
        withApiProvider(withTheme(<Leaderboards game="classic-pools" enabledLeaderboards={enabledLeaderboards} />)),
        initialState as RootState,
    );
    return { ...utils };
};

const mockAuthentication: AuthenticationState = {
    isLoggedIn: true,
    isFetching: false,
    authToken: 'abcd1234',
    userDetails: {
        authToken: 'abcd1234',
        firstName: 'Jimbo',
        lastName: 'Jones',
        id: '1',
    },
};

describe('leaderboards', () => {
    it('renders without error', async () => {
        await act(async () => {
            const { container } = renderComponent({
                authentication: mockAuthentication,
            });
            expect(container).toMatchSnapshot();
        });
    });
});
