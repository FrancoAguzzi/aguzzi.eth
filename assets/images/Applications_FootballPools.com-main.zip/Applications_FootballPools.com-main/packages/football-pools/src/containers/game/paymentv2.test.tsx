import { RootState } from '@fp/shared/src/rootReducer';
// eslint-disable-next-line import/named
import { BetSlip, BetSlipSlice, WagersSlice } from '@sportech/pools-api';
import { AuthenticationState } from '@fp/shared/src/features/authentication/authenticationSlice';
import { RecursivePartial } from '@fp/shared/src/testing/utils/RecursivePartial';
import { withApiProvider } from '@fp/shared/src/testing/utils/renderWithApiProvider';
import { renderWithRedux } from '@fp/shared/src/testing/utils/renderWithRedux';
import { withTheme } from '@fp/shared/src/testing/utils/renderWithTheme';
import { PaymentV2 } from './paymentv2';

jest.mock('next/router', () => ({
    useRouter() {
        return {
            route: '/',
            pathname: '',
            query: '',
            asPath: '',
        };
    },
}));

const renderComponent = (initialState: RecursivePartial<RootState>) => {
    // TODO: use mock adaptor!
    const utils = renderWithRedux(withApiProvider(withTheme(<PaymentV2 />)), initialState as RootState);
    return { ...utils };
};

const mockWagers: WagersSlice = {
    stage: 'created',
    purchaseType: 'ByGames',
    game: 'classic-pools',
    wagers: [
        {
            competitionId: 1234,
            competitionName: 'test comp',
            pick: 10,
            current: true,
            price: 100,
            priceID: 5,
            numbers: [
                {
                    Id: 1,
                    rows: 1,
                    selections: [],
                },
                {
                    Id: 2,
                    rows: 1,
                    selections: [],
                },
                {
                    Id: 3,
                    rows: 1,
                    selections: [],
                },
                {
                    Id: 4,
                    rows: 1,
                    selections: [],
                },
                {
                    Id: 5,
                    rows: 1,
                    selections: [],
                },
                {
                    Id: 6,
                    rows: 1,
                    selections: [],
                },
                {
                    Id: 7,
                    rows: 1,
                    selections: [],
                },
                {
                    Id: 8,
                    rows: 1,
                    selections: [],
                },
                {
                    Id: 9,
                    rows: 1,
                    selections: [],
                },
                {
                    Id: 10,
                    rows: 1,
                    selections: [],
                },
            ],
            bonusNumbers: [],
            bonusPick: 0,
            bonusPrice: 0,
            bonusPriceId: 0,
        },
    ],
};
const mockWager = mockWagers.wagers[0] as BetSlip;
const mockBetslip: BetSlipSlice = {
    ClassicPools: [
        {
            competitionId: mockWager.competitionId,
            competitionName: mockWager.competitionName,
            pick: mockWager.pick,
            current: true,
            price: mockWager.price,
            priceID: mockWager.priceID,
            highestRow: mockWager.highestRow,
            numbers: mockWager.numbers,
            bonusNumbers: mockWager.bonusNumbers,
            bonusPick: mockWager.bonusPick,
            bonusPrice: mockWager.bonusPrice,
            bonusPriceId: mockWager.bonusPriceId,
        },
    ],
    GoalRush8: [],
    Jackpot12: [],
    Premier6: [],
    Premier10: [],
    LuckyClover: [],
};
const mockAuthentication: AuthenticationState = {
    isLoggedIn: true,
    isFetching: false,
    authToken: 'abcd1234',
    userDetails: {
        authToken: 'abcd1234',
        firstName: 'Jimbo',
        lastName: 'Jones',
        id: '1',
    },
};

describe('paymentv2', () => {
    it('renders without error', () => {
        const { container } = renderComponent({
            wagers: mockWagers,
            betSlip: mockBetslip,
            authentication: mockAuthentication,
        });
        expect(container).toMatchSnapshot();
    });
});
