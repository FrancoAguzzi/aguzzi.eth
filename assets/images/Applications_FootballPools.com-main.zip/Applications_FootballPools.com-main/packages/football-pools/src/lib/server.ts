import { ServerResponse } from 'http';

export const redirect = (res: ServerResponse, url: string) => {
    res.setHeader('location', url);
    res.statusCode = 302;
    res.end();
};
