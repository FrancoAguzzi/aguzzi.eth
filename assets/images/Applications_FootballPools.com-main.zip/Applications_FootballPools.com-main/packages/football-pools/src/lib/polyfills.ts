// polyfill flatmap for older browsers:
if (!Array.prototype.flatMap) {
    Object.defineProperty(Array.prototype, 'flatMap', {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        value: function (callback: any, thisArg: any) {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            return this.map(callback, thisArg).reduce((a: string | any[], b: any) => a.concat(b), []);
        },
        configurable: true,
        writable: true,
    });
}

export {};
