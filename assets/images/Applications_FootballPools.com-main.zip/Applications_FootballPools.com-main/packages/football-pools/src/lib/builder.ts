import { HttpLink } from '@apollo/client';
import getConfig from 'next/config';

const { publicRuntimeConfig } = getConfig();

const BUILDER_API_KEY = process.env.BUILDER_API_KEY || publicRuntimeConfig.BUILDER_API_KEY;
const graphQlUrl = `https://cdn.builder.io/api/v1/graphql/${BUILDER_API_KEY}`;

export const builderLink = () => new HttpLink({ uri: graphQlUrl });

export type BuilderData<T extends {}> = Record<'data', T>;
export type BuilderDataWithName<T extends {}> = { data: T; name: string };
