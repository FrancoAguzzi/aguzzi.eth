import { ServerError, ServerParseError, from, HttpLink } from '@apollo/client';
import { setContext } from '@apollo/client/link/context';
import { onError } from '@apollo/client/link/error';
import fetch from 'node-fetch';

const clientID = process.env.SQUIDEX_CLIENT_ID || '';
const clientSecret = process.env.SQUIDEX_CLIENT_SECRET || '';
const squidexUrl = process.env.SQUIDEX_URL || '';
const squidexTokenUrl = process.env.SQUIDEX_TOKEN_URL || '';

let _token: string | null;

const clearToken = (): void => {
    _token = null;
};

const getToken = async (): Promise<string> => {
    const formBody = new URLSearchParams();
    formBody.append('client_id', clientID);
    formBody.append('client_secret', clientSecret);
    formBody.append('scope', 'squidex-api');
    formBody.append('grant_type', 'client_credentials');

    let response;
    try {
        /* eslint-disable */
        response = await fetch(squidexTokenUrl, {
            method: 'POST',
            body: formBody,
            insecureHTTPParser: true,
        });
        /* eslint-enable */
    } catch (err) {
        console.log('HUGE ERROR' + err);
    }
    const json = (await response?.json()) as { access_token: string };

    if (response) return json.access_token;
    return '';
};

const withToken = setContext(async () => {
    if (_token) return { token: _token };

    const token = await getToken();
    _token = token;

    return { token };
});

const isServerError = (networkError: Error | ServerError | ServerParseError | undefined): networkError is ServerError =>
    !!networkError && networkError.name === 'ServerError';

const refreshToken = onError(({ networkError, operation, forward }) => {
    if (isServerError(networkError) && networkError.statusCode) {
        clearToken();
        return forward(operation);
    }
});

export const authFlow = withToken.concat(refreshToken);

export const setAuthorizationLink = setContext((_, previousContext) => ({
    headers: { authorization: `Bearer ${previousContext.token}` },
}));

const previewHeader = setContext((_, { headers }) => ({ headers: { ...headers, 'X-Unpublished': true } }));

const generateLink = (preview: boolean) =>
    from([
        authFlow,
        setAuthorizationLink,
        ...(preview ? [previewHeader] : []),
        new HttpLink({
            uri: squidexUrl,
        }),
    ]);

export const squidexLink = generateLink(false);

export const squidexPreviewLink = generateLink(true);

export type FlatData<T extends {}> = Record<'flatData', T>;
