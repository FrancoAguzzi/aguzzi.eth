import { IncomingMessage, ServerResponse } from 'http';

const hasGameNameInPath = (path?: string): boolean => {
    return Boolean(
        path &&
            (path.includes('classic-pools') ||
                path.includes('goal-rush') ||
                path.includes('lucky-clover') ||
                path.includes('jackpot-12') ||
                path.includes('premier-10') ||
                path.includes('premier-6') ||
                path.includes('soccer-6')),
    );
};

export const gameNamePathValidation = (req: IncomingMessage, res: ServerResponse) => {
    if (!hasGameNameInPath(req.url)) {
        res.writeHead(302, { Location: '/' });
        res.end();
    }
};
