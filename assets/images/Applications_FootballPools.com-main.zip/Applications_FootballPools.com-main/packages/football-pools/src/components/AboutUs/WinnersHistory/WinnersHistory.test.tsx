import { WinnersHistory } from './WinnersHistory';
import { render } from '@testing-library/react';

describe('WinnersHistory', () => {
    it('should render correctly', () => {
        const { container } = render(
            <WinnersHistory
                titleText={'A History of Winners'}
                ctaText={'View Winners'}
                winnerImageProps={[
                    {
                        src:
                            'https://squidex-admin.uat.tfpsrvs.local/api/assets/67d39c43-20bb-43d0-a8ff-a9c49de67f34?version=0',
                        caption: 'Caption Text',
                        subtext: 'Subtext text',
                    },
                    {
                        src:
                            'https://squidex-admin.uat.tfpsrvs.local/api/assets/67d39c43-20bb-43d0-a8ff-a9c49de67f34?version=0',
                        caption: 'Caption Text',
                        subtext: 'Subtext text',
                    },
                    {
                        src:
                            'https://squidex-admin.uat.tfpsrvs.local/api/assets/67d39c43-20bb-43d0-a8ff-a9c49de67f34?version=0',
                        caption: 'Caption Text',
                        subtext: 'Subtext text',
                    },
                ]}
            />,
        );

        expect(container).toMatchSnapshot();
    });
});
