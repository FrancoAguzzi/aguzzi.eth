import { FunctionComponent } from 'react';
import styled from 'styled-components';
// eslint-disable-next-line import/named
import { GameType, LeaderboardResultMember } from '@sportech/pools-api';

const Container = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #fff;
    width: 100%;
`;

export interface LeaderboardResultWinners {
    name: string;
    game: GameType;
    startDate?: Date;
    type?: string;
    winners: LeaderboardWinner[];
}

type LeaderboardWinner = Partial<LeaderboardResultMember & { winAmount?: string }>;

interface LeaderboardWinnersProps {
    winners?: LeaderboardWinner[];
}

export const LeaderboardWinners: FunctionComponent<LeaderboardWinnersProps> = ({ winners }) => {
    return (
        <Container>
            {winners && winners.map((winner, index) => <WinnerRow key={`leaderboard-winner_${index}`} {...winner} />)}
        </Container>
    );
};

const WinnerContainer = styled.div`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    width: 95%;
    background: ${props => props.theme.colours.gameMainColour};
    margin: 5px auto;
    border-radius: 8px;
    padding: 5px;
`;
const UsernameContainer = styled.div`
    flex: 3;
    font-weight: bold;
    align-self: flex-end;
    padding-bottom: 2px;
`;
const DetailsContainer = styled.div`
    flex: 5;
    display: flex;
    flex-direction: row;
    align-items: end;
    justify-content: space-between;
`;
const HeadingDetail = styled.p`
    font-size: 0.75rem;
    margin: 5px auto 1px auto;
`;
const WinDetail = styled.p`
    font-size: 1.2rem;
    font-weight: bold;
    margin: 2px auto;
`;

const DetailContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex: 1;
`;

const WinnerRow = (winner: LeaderboardWinner): JSX.Element => {
    return (
        <WinnerContainer>
            <UsernameContainer>{winner.nickname}</UsernameContainer>
            <DetailsContainer>
                <DetailContainer>
                    <HeadingDetail>Position</HeadingDetail>
                    <WinDetail>{winner.rank}</WinDetail>
                </DetailContainer>
                <DetailContainer>
                    <WinDetail>/</WinDetail>
                </DetailContainer>
                <DetailContainer>
                    <HeadingDetail>Points</HeadingDetail>
                    <WinDetail>{winner.totalPoints}</WinDetail>
                </DetailContainer>
                <DetailContainer>
                    <WinDetail>/</WinDetail>
                </DetailContainer>
                <DetailContainer>
                    <HeadingDetail>Prize</HeadingDetail>
                    <WinDetail>{winner.winAmount}</WinDetail>
                </DetailContainer>
            </DetailsContainer>
        </WinnerContainer>
    );
};
