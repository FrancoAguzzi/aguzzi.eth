import styled from 'styled-components';

import { CustomLink } from '@fp/shared/src/components/CustomLink/CustomLink';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import { NewsItem } from '@fp/shared/src/core/news';

const Container = styled(CustomLink)<{ span: number }>`
    background-color: black;
    position: relative;
    border-radius: 5px;
    max-width: 100%;
    max-height: 100%;
    height: 100%;
    overflow: hidden;

    ${breakpoints.above('md')} {
        grid-column-end: span ${({ span }) => span || 1};
    }
`;

const TextContainer = styled.div`
    color: white;
    position: absolute;
    bottom: 0;
    padding: 10px;
    width: 100%;
`;

const Title = styled.h4`
    font-size: 2rem;
    margin: 0;
    font-weight: 900;
    text-transform: uppercase;
`;

const DateLine = styled.h5`
    font-size: 0.875rem;
    margin: 10px 0;
    font-weight: 500;
`;

const SubTitle = styled.h5`
    font-size: 0.875rem;
    margin: 10px 0;
    font-weight: 500;
    line-height: 1.25rem;
`;

const Image = styled.img`
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 5px;
`;

export const formatDate = (date: string): string =>
    Intl.DateTimeFormat('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(date));

type Props = NewsItem;

export const NewsTile = ({ slug, date, span, image, excerpt, title }: Props) => (
    <Container href="/news/[slug]" linkAs={`/news/${slug}`} span={span}>
        <Image src={image[0].url} alt={excerpt} />
        <TextContainer>
            <Title>{title}</Title>
            <DateLine>{formatDate(date)}</DateLine>
            <SubTitle>{excerpt}</SubTitle>
        </TextContainer>
    </Container>
);
