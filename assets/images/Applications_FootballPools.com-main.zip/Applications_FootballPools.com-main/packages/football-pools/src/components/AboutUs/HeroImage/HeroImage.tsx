import styled from 'styled-components';

const Image = styled.img<HeroImageProps>`
    width: 100%;
    object-fit: cover;
    max-height: 450px;
`;

export interface HeroImageProps {
    imageUrl?: string;
    alt?: string;
}
export const HeroImage: React.FC<HeroImageProps> = ({ imageUrl, alt }) => {
    return <Image src={imageUrl} alt={alt}></Image>;
};

export default HeroImage;
