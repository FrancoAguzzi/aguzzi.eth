import { useEffect, useState, useRef } from 'react';
import { getAuthenticationSelector } from '@fp/shared/src/features/authentication/authenticationSelectors';
import { getThemeForGameType } from '@fp/shared/src/lib/utils';
import { api } from '@fp/shared/src/services/api';
import { isAppError } from '@fp/shared/src/core/appError';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import { GameType } from '@sportech/pools-api';
// eslint-disable-next-line import/no-unresolved
import { useStreaks, StreakProgress, StreakLine, Streak, getPrizeLevels, Prize } from '@api/streaks';
import { StreakDetails, StreakHistory } from '../Streaks';
import Link from 'next/link';
import Head from 'next/head';
import styled, { ThemeProvider } from 'styled-components';
import { useSelector } from 'react-redux';
import { BuilderComponent } from '@builder.io/react';
// eslint-disable-next-line import/default
import dayjs from 'dayjs';
import { HeadComponent } from '@fp/shared/src/settings/HeadComponent';

const TopContainer = styled.div<{ gameName: string }>`
    background-color: '#fff';
    text-align: center;
    margin-top: 0;
    padding-top: 0;
    color: '#000';
    padding: ${({ gameName }) => (gameName === 'lucky-clover' ? '0' : '10px 0px 0')};
    ${breakpoints.above('sm')} {
        padding: ${({ gameName }) => (gameName === 'lucky-clover' ? '0' : '10px 50px 0')};
    }
    > p {
        font-weight: ${({ gameName }) => (gameName === 'lucky-clover' ? '600' : 'inherit')};
    }
`;

const BottomContainer = styled.div<{ gameName?: string }>`
    color: #383838;
    padding: 20px 0;
    border-top: ${({ gameName }) => (gameName === 'classic-pools' ? '2px solid #000d68' : '')};
`;

const StreaksIconContainer = styled.div`
    display: flex;
    text-transform: uppercase;
    font-weight: bold;
    font-style: italic;
    justify-content: center;
`;

const StreaksIcon = styled.div`
    background-color: white;
    border-radius: 50px;
    padding: 5px 10px;
    z-index: 1;
    border: 1px solid white;
`;

const StreaksIcon2 = styled.div`
    background-color: red;
    color: white;
    border-radius: 50px;
    padding: 5px 15px 5px 30px;
    margin-left: -25px;
    border: 1px solid white;
`;

const BallList = styled.div<{ gameName?: string; winningNumbers?: boolean }>`
    display: flex;
    justify-content: center;
    flex-wrap: nowrap;
    overflow-x: auto;
    width: ${({ gameName, winningNumbers }) => (gameName === 'lucky-clover' && !winningNumbers ? '275px' : '520px')};
    margin: auto;
    padding-bottom: ${({ gameName }) => (gameName === 'lucky-clover' ? '0' : '10px')};
    ${breakpoints.below('sm')} {
        width: ${({ gameName }) => (gameName === 'lucky-clover' ? '275px' : '320px')};
    }
`;

const Ball = styled.div<{
    faded?: boolean;
    gameName?: string;
    winningNumbers?: boolean;
}>`
    width: ${({ gameName, winningNumbers }) => (gameName == 'lucky-clover' && winningNumbers ? '60px' : '40px')};
    height: ${({ gameName, winningNumbers }) => (gameName == 'lucky-clover' && winningNumbers ? '60px' : '40px')};
    margin: ${({ gameName, winningNumbers }) =>
        gameName === 'lucky-clover' ? (winningNumbers ? '1px 5px' : '1px 3px') : '1px'};
    font-size: ${({ gameName, winningNumbers }) =>
        gameName === 'lucky-clover' ? (winningNumbers ? '32px' : '24px') : ''};
    font-weight: ${({ gameName }) => (gameName === 'lucky-clover' ? '600' : '')};
    color: ${props => ({ faded, gameName }) =>
        gameName === 'lucky-clover'
            ? '#fff'
            : faded
            ? props.theme.colours.streaksBallColourNotSelected
            : props.theme.colours.streaksBallColour};
    border: 2px solid;
    border-color: ${props => ({ faded }) =>
        faded ? props.theme.colours.streaksBallColourNotSelected : props.theme.colours.streaksBallColour};
    background: ${props =>
        props.gameName === 'lucky-clover'
            ? props.faded
                ? props.theme.colours.streaksBallColourNotSelected
                : props.theme.colours.streaksBallColour
            : ''};
    border-radius: ${({ gameName }) => (gameName === 'lucky-clover' ? '100%' : '5px')};
    display: grid;
    place-items: center;
    ${breakpoints.below('sm')} {
        width: ${({ gameName }) => (gameName === 'lucky-clover' ? '40px' : '25px')};
        height: ${({ gameName }) => (gameName === 'lucky-clover' ? '40px' : '25px')};
        margin: ${({ gameName }) => (gameName === 'lucky-clover' ? '1px 3px' : '1px')};
        font-size: ${({ gameName }) => (gameName === 'lucky-clover' ? '24px' : '')};
    }
    flex: 0 0 auto;
`;

const LineSelector = styled.div`
    justify-content: center;
    overflow-x: auto;
    overflow-y: hidden;
    white-space: nowrap;
    max-width: 100%;
`;

const LineSelect = styled.div<{ active?: boolean; gameName: string }>`
    border-top-left-radius: 15px;
    border-top-right-radius: 15px;
    background-color: ${props => ({ active, gameName }) =>
        gameName === 'lucky-clover'
            ? '#fff'
            : active
            ? props.theme.colours.streaksLineSelectActive
            : props.theme.colours.streaksLineSelectNotActibe};
    border: ${({ gameName }) => (gameName === 'lucky-clover' ? '0' : '1px')};
    border-bottom: 0;
    border-style: solid;
    border-color: ${props => props.theme.colours.streaksLineSelectActive};
    color: ${({ active, gameName }) => (gameName === 'lucky-clover' ? '#000' : active ? 'white' : 'grey')};
    font-weight: ${({ active, gameName }) => (gameName === 'lucky-clover' && active ? '600' : 'inherit')};
    width: 100px;
    padding-top: 10px;
    margin: 0 2px;
    cursor: pointer;
    display: inline-block;
`;

const StreaksContainer = styled.div<{ gameName: string }>`
    background-color: ${({ gameName }) => (gameName === 'lucky-clover' ? '#238D36' : '#000D68')};
    color: white;
    width: calc(100% - 10px);
    border-radius: 10px;
    margin: 20px 15px;
    text-align: center;
    padding: 20px 5px;
    flex-shrink: 0;
    @media (max-width: 749px) {
        margin: 20px auto;
    }
    ${breakpoints.above('sm')} {
        width: 355px;
    }
`;

const PrizeLevelContainer = styled.ul<{ gameName: string }>`
    margin: ${({ gameName }) => (gameName === 'lucky-clover' ? '10px' : '10px 40px')};
    padding: 0;
    background-color: ${props => props.theme.colours.streaksPrizeLevelBackground};
    height: 200px;
    overflow-y: scroll;
`;

const PrizeLevel = styled.li<{ active: boolean; gameName: string }>`
    color: ${props => ({ active }) =>
        active ? props.theme.colours.streaksPrizeLevelTextHighlight : props.theme.colours.streaksPrizeLevelText};
    display: flex;
    justify-content: space-between;
    font-size: 24px;
    list-style: none;
    padding: 0 10px;
    line-height: 2em;

    font-style: ${({ active }) => (active ? 'italic' : '')};
    font-weight: ${({ active, gameName }) => (active || gameName === 'lucky-clover' ? 'bold' : '')};
    font-size: ${({ active, gameName }) =>
        gameName === 'lucky-clover' ? (active ? '20px' : '14px') : active ? '1.75em' : ''};
    text-decoration: ${({ active, gameName }) => (gameName === 'lucky-clover' && active ? 'underline' : 'none')};
    ${breakpoints.above('xs')} {
        padding: 0 50px;
    }
`;
const DetailsAnchorGroup = styled.div`
    cursor: pointer;
`;

const DetailsAnchor = styled.p`
    text-decoration: underline;
`;

const StreaksDetailsContainer = styled.div`
    @media (min-width: 750px) {
        display: flex;
        justify-content: center;
    }
`;

const Caret = styled.div`
    margin: -10px;
`;

const InfoLink = styled(Link)`
    font: #000;
    text-decoration: none;
    :hover {
        text-decoration: underline;
    }
`;

const CTAContainer = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    ${breakpoints.above('sm')} {
        flex-direction: row;
    }
`;

const PlayLuckyCloverCTA = styled.a<{ invert?: boolean }>`
    border-radius: 10px;
    padding: 15px 0;
    font-size: 18px;
    cursor: pointer;
    text-decoration: none;
    color: ${props => (props.invert ? '#238D36' : '#fff')};
    background-color: ${props => (props.invert ? '#fff' : '#238D36')};
    border: ${props => (props.invert ? '1px solid #238D36' : '')};
    font-weight: bold;
    display: inline-block;
    text-align: center;
    margin: 10px auto;
    width: 80%;
    max-width: 350px;
    @media (max-width: 375px) {
        font-size: 16px;
    }
    ${breakpoints.above('sm')} {
        margin: 10px;
    }
    :hover {
        background-color: ${props => (props.invert ? '#238D36' : '#fff')};
        color: ${props => (props.invert ? '#fff' : '#238D36')};
        border: ${props => (props.invert ? '' : '1px solid #238D36')};
    }
`;

const PlayPara = styled.p<{ gameName?: string }>`
    font-size: 24px;
    text-align: center;
    font-style: italic;
    font-weight: bold;
    padding: 0 20px;
    color: ${({ gameName }) => (gameName === 'lucky-clover' ? '#000000' : '#000D68')};
`;

type Props = {
    streakProgressSSR: StreakProgress;
    gameName: GameType;
};

export const StreaksProgressContent = ({ streakProgressSSR, gameName }: Props) => {
    const { streaks: streakHistory, getStreaks } = useStreaks();
    const [activeLine, setActiveLine] = useState<StreakLine | null>(
        streakProgressSSR.streakLines.length > 0 ? streakProgressSSR.streakLines[0] : null,
    );
    const [isDetailsShowing, setDetailsShowing] = useState(false);
    const [isHistoryShowing, setIsHistoryShowing] = useState(false);
    const [activeStreakHistory, setActiveStreakHistory] = useState<Streak[]>();
    const [streakProgress, setStreakProgress] = useState(streakProgressSSR);
    const { isLoggedIn, authToken } = useSelector(getAuthenticationSelector);
    const [prizeLevels] = useState<Prize[]>(getPrizeLevels(gameName));
    const [backgroundColor] = useState('white');

    useEffect(() => {
        const getStreakProgress = async () => {
            const response = await api.send<StreakProgress>({
                method: 'get',
                endpoint: `/streaks?gameName=${gameName}`,
                authToken,
            });

            if (!isAppError(response)) {
                setStreakProgress(response);
                if (response.streakLines.length > 0) {
                    setActiveLine(response.streakLines[0]);
                }
            } else {
                location.reload();
            }
        };

        if (isLoggedIn && streakProgress.streakLines.length === 0) {
            getStreakProgress();
        }
    }, [isLoggedIn]);

    useEffect(() => {
        const workingStreakHistory: Streak[] = [];
        streakHistory.forEach((streak, index) => {
            const previousStreak = streakHistory[index - 1];
            if (previousStreak && streak.tally === 0 && previousStreak.tally !== 0) {
                workingStreakHistory.push(previousStreak);
            }
        });
        setActiveStreakHistory(workingStreakHistory);
    }, [streakHistory]);

    const PrizeList = ({ currentPrizeLevel }: { currentPrizeLevel: number }) => {
        return (
            <ThemeProvider theme={getThemeForGameType(gameName)}>
                <PrizeLevelContainer gameName={gameName}>
                    {prizeLevels.map(prize => (
                        <PrizeLevel
                            ref={currentPrizeLevel === prize.level ? prizeRef : null}
                            active={currentPrizeLevel === prize.level}
                            gameName={gameName}
                            key={prize.level}
                        >
                            <span>{prize.level === 16 ? `${prize.level}` : prize.level}</span>
                            <span>{prize.amount}</span>
                        </PrizeLevel>
                    ))}
                </PrizeLevelContainer>
            </ThemeProvider>
        );
    };

    const prizeRef = useRef<HTMLLIElement>(document.createElement('li'));

    useEffect(() => {
        prizeRef.current.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }, [activeLine]);

    const changeActiveLine = (line: StreakLine) => {
        if (line !== activeLine) {
            setActiveLine(line);
            setDetailsShowing(false);
            setIsHistoryShowing(false);
            setActiveStreakHistory([]);
        }
    };

    const streakTitle =
        gameName === 'lucky-clover' ? 'Lucky Clover' : gameName === 'classic-pools' ? 'Classic Pools' : '';

    const streakDescription =
        gameName === 'lucky-clover'
            ? 'Check out your Lucky Clover Streaks progress to see if you have won.'
            : 'Check out your Classic Pools Streaks progress to see if you have won.';

    return (
        <ThemeProvider theme={getThemeForGameType(gameName)}>
            <HeadComponent
                title={`${streakTitle} Streaks`}
                description={`${streakDescription}`}
                keywords={'Progress, winning streak, have I won'}
                operator={'footballpools'}
            />
            <div style={{ background: backgroundColor, minHeight: '80vh' }}>
                <TopContainer gameName={gameName}>
                    {gameName === 'lucky-clover' ? (
                        <BuilderComponent model="banners" name="LuckyCloverStreaks" />
                    ) : (
                        <>
                            <StreaksIconContainer>
                                <StreaksIcon>
                                    <span style={{ color: '#1D71B8' }}>Classic </span>
                                    <span style={{ color: '#2D2E83' }}>Pools</span>
                                </StreaksIcon>

                                <StreaksIcon2>
                                    <span>Streaks</span>
                                </StreaksIcon2>
                            </StreaksIconContainer>
                            <p>Welcome to Classic Pools Streaks.</p>
                        </>
                    )}
                    <p>
                        Each line you play can ‘go on a Streak’, so you could have multiple streaks live at the same
                        time. The longer your Streak the more you win!
                    </p>
                    {gameName === 'lucky-clover' && <InfoLink href="/lucky-clover-streaks">More Information</InfoLink>}
                    <p>{`Winning ${gameName === 'lucky-clover' ? 'Lucky Clover ' : ''}Numbers ${dayjs(
                        streakProgress.competitionDate,
                    ).format('DD-MM-YY')}`}</p>
                    <BallList gameName={gameName} winningNumbers>
                        {streakProgress.winningNumbers.map(number => (
                            <Ball key={number} gameName={gameName} winningNumbers>
                                {number}
                            </Ball>
                        ))}
                    </BallList>
                    {streakProgress.streakLines.length > 0 && activeLine && (
                        <>
                            <p>Your Lines</p>
                            <LineSelector>
                                {streakProgress.streakLines.map((line, index) => (
                                    <LineSelect
                                        key={index}
                                        gameName={gameName}
                                        active={line.lineId === activeLine.lineId}
                                        onClick={() => changeActiveLine(line)}
                                    >
                                        Line {index + 1} ({line.tally})
                                    </LineSelect>
                                ))}
                            </LineSelector>
                        </>
                    )}
                </TopContainer>
                <BottomContainer gameName={gameName}>
                    {activeLine && (
                        <>
                            <BallList gameName={gameName}>
                                {activeLine.selections.map(num => (
                                    <Ball
                                        key={num}
                                        faded={!streakProgress.winningNumbers.includes(num)}
                                        gameName={gameName}
                                    >
                                        {num}
                                    </Ball>
                                ))}
                            </BallList>
                            <StreaksDetailsContainer>
                                <StreaksContainer gameName={gameName}>
                                    <p>Your Current Streaks Total</p>
                                    <PrizeList currentPrizeLevel={activeLine.tally} />
                                    <span>You&apos;re on a roll!</span>
                                    <DetailsAnchorGroup onClick={() => setDetailsShowing(!isDetailsShowing)}>
                                        <DetailsAnchor>Show Details</DetailsAnchor>
                                        <Caret>
                                            <img src={isDetailsShowing ? '/caret-up.png' : '/caret-down.png'}></img>
                                        </Caret>
                                    </DetailsAnchorGroup>
                                    <StreakDetails
                                        lineId={activeLine.lineId}
                                        visible={isDetailsShowing}
                                        gameName={gameName}
                                    />
                                </StreaksContainer>

                                <StreaksContainer gameName={gameName}>
                                    <DetailsAnchor
                                        onClick={() => {
                                            getStreaks(activeLine.lineId, gameName);
                                            setIsHistoryShowing(!isHistoryShowing);
                                        }}
                                    >
                                        Show History
                                    </DetailsAnchor>
                                    <Caret>
                                        <img src={isHistoryShowing ? '/caret-up.png' : '/caret-down.png'}></img>
                                    </Caret>
                                    {activeStreakHistory && isHistoryShowing && (
                                        <StreakHistory
                                            streaks={activeStreakHistory}
                                            gameName={gameName}
                                            activeLine={activeLine}
                                        />
                                    )}
                                </StreaksContainer>
                            </StreaksDetailsContainer>
                        </>
                    )}
                    {gameName === 'lucky-clover' && (
                        <CTAContainer>
                            <PlayLuckyCloverCTA href="/results/lucky-clover" invert>
                                View All Lucky Clover Results
                            </PlayLuckyCloverCTA>
                            <PlayLuckyCloverCTA href="/games/lucky-clover/game">Play Lucky Clover</PlayLuckyCloverCTA>
                        </CTAContainer>
                    )}
                    {!activeLine && gameName !== 'lucky-clover' && (
                        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                            <PlayPara gameName={gameName}>Play Classic Pools to get your streaks started!</PlayPara>
                        </div>
                    )}
                </BottomContainer>
            </div>
        </ThemeProvider>
    );
};
