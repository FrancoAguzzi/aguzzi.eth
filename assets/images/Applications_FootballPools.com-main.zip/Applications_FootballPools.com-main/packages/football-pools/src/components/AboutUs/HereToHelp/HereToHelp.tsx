import styled from 'styled-components';

const SectionContainer = styled.div`
    display: flex;
    width: 100%;
    height: auto;
    background-color: #010d68;
    flex-direction: column;
    justify-content: center;
    align-content: center;
    align-items: center;
    color: #fff;
`;

const ButtonsContainer = styled.div`
    width: 100%;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: space-between;
    max-width: 1270px;
    @media (max-width: 1270px) {
        padding-left: 10px;
        padding-right: 10px;
    }
    @media (max-width: 768px) {
        flex-direction: column;
        align-items: center;
    }
`;

const ButtonContainer = styled.div`
    display: flex;
    width: 100%;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    margin-bottom: 10px;
`;

const ButtonContainerTitle = styled.h2`
    width: 100%;
    font-size: 14px;
    max-width: 1270px;
    margin-bottom: 1px;
    font-weight: 800;
`;

const ButtonContainerSubtext = styled.p`
    width: 100%;
    font-size: 14px;
    max-width: 1270px;
    margin-bottom: 5px;
`;

const Title = styled.h1`
    width: 100%;
    font-size: 30px;
    max-width: 1270px;
    margin-bottom: 5px;
    @media (max-width: 1270px) {
        padding-left: 10px;
        padding-right: 10px;
    }
`;

const Body = styled.p`
    width: 100%;
    font-size: 14px;
    max-width: 1270px;
    @media (max-width: 1270px) {
        padding-left: 10px;
        padding-right: 10px;
    }
`;

const AddressTitle = styled.h2`
    width: 100%;
    font-size: 14px;
    max-width: 1270px;
    margin-bottom: 1px;
    font-weight: 800;
    @media (max-width: 1270px) {
        padding-left: 10px;
        padding-right: 10px;
    }
`;

const AddressContainer = styled.p`
    width: 100%;
    font-size: 14px;
    max-width: 1270px;
    margin-bottom: 40px;
    @media (max-width: 1270px) {
        padding-left: 10px;
        padding-right: 10px;
    }
`;

export interface HereToHelpButtonProps {
    buttonColour?: string;
    buttonTextColour?: string;
}

export const HereToHelpButton = styled.a<HereToHelpButtonProps>`
    width: 244px;
    height: 45px;
    font-size: 16px;
    text-decoration: none;
    text-transform: uppercase;
    margin: 20px 0;
    border: 2px solid ${props => props.buttonColour};
    background: ${props => props.buttonColour};
    color: ${props => props.buttonTextColour};
    border-radius: 25px;
    font-weight: 700;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    align-self: flex-start;

    @media (max-width: 768px) {
        width: 100%;
    }
`;

export interface HereToHelpProps {
    email: string;
    telephoneUK: string;
    telephoneInternational: string;
}
export const HereToHelp: React.FC<HereToHelpProps> = ({ email, telephoneUK, telephoneInternational }) => {
    return (
        <SectionContainer>
            <Title>We&apos;re here to help!</Title>
            <Body>
                Don’t know how to do something on our website? Can’t find the information you’re looking for? Our team
                is always here to help. Please see below for our contact details.
            </Body>
            <ButtonsContainer>
                <ButtonContainer>
                    <ButtonContainerTitle>Email</ButtonContainerTitle>
                    <ButtonContainerSubtext>{email}</ButtonContainerSubtext>
                    <HereToHelpButton
                        buttonColour="#fff"
                        buttonTextColour="#010D68"
                        href="mailto:help@footballpools.com"
                    >
                        EMAIL US
                    </HereToHelpButton>
                </ButtonContainer>
                <ButtonContainer>
                    <ButtonContainerTitle>Telephone (UK)</ButtonContainerTitle>
                    <ButtonContainerSubtext>Freephone {telephoneUK}</ButtonContainerSubtext>
                    <HereToHelpButton buttonColour="#fff" buttonTextColour="#010D68" href="tel:08009539933">
                        CALL {telephoneUK}
                    </HereToHelpButton>
                </ButtonContainer>
                <ButtonContainer>
                    <ButtonContainerTitle>Telephone (International)</ButtonContainerTitle>
                    <ButtonContainerSubtext>International {telephoneInternational}</ButtonContainerSubtext>
                    <HereToHelpButton buttonColour="#fff" buttonTextColour="#010D68" href="tel:+4408456055567">
                        CALL {telephoneInternational}
                    </HereToHelpButton>
                </ButtonContainer>
            </ButtonsContainer>
            <AddressTitle>Post</AddressTitle>
            <AddressContainer>The Football Pools, Walton House, 55 Charnock Road, Liverpool L67 1AA</AddressContainer>
        </SectionContainer>
    );
};

export default HereToHelp;
