import { FunctionComponent, useRef, Children, useState } from 'react';
import styled from 'styled-components';

const Container = styled.div<{ width: string; num: number }>`
    display: flex;
    width: ${({ width }) => width};
    overflow: hidden;
    text-align: center;
    justify-content: ${({ num }) => (num < 3 ? 'center' : 'normal')};
`;

export const HorizontalScroll: FunctionComponent = ({ children }) => {
    const navRef = useRef(document.createElement('div'));
    const [position, setPosition] = useState(0);

    const minPos = 0;
    const maxPos = (Children.count(children) - 3) * 104;

    const handleNav = (direction: string) => {
        if (direction === 'left' && position > minPos) {
            const newPos = position - 104;
            setPosition(newPos);
            navRef ? navRef.current.scrollTo({ top: 0, left: newPos, behavior: 'smooth' }) : null;
        } else if (direction === 'right' && position < maxPos) {
            const newPos = position + 104;
            setPosition(newPos);
            navRef ? navRef.current.scrollTo({ top: 0, left: newPos, behavior: 'smooth' }) : null;
        }
    };

    return (
        <div style={{ display: 'flex', alignItems: 'center', height: '500px' }}>
            <div style={{ cursor: 'pointer' }}>
                <a onClick={() => handleNav('left')}>&lt;</a>
            </div>
            <Container num={Children.count(children)} width={'312px'} ref={navRef}>
                {children}
            </Container>
            <div style={{ cursor: 'pointer' }}>
                <a onClick={() => handleNav('right')}>&gt;</a>
            </div>
        </div>
    );
};
