import styled from 'styled-components';

export interface HeroButtonProps {
    buttonColour?: string;
    buttonTextColour?: string;
    buttonText?: string;
    buttonHref?: string;
}

export const HeroButton = styled.a<HeroButtonProps>`
    width: 244px;
    height: 45px;
    font-size: 16px;
    text-decoration: none;
    text-transform: uppercase;
    margin: 20px 0;
    border: 2px solid ${props => props.buttonColour};
    background: ${props => props.buttonColour};
    color: ${props => props.buttonTextColour};
    border-radius: 25px;
    font-weight: 700;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    align-self: flex-start;

    @media (max-width: 768px) {
        background: ${props => props.buttonColour};
        color: ${props => props.buttonTextColour};
        width: 80%;
    }
`;

export default HeroButton;
