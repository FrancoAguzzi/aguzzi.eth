import styled from 'styled-components';

const Container = styled.div`
    display: flex;
    flex: 1;
    flex-direction: row;
    font-style: italic;
    justify-content: center;
    max-width: 1080px;
    background-color: #f2f2f2;

    @media (max-width: 980px) {
        flex-direction: column;
    }
`;

const ChildContainer = styled.div`
    display: flex;
    flex-direction: column;
    width: 50%;
    margin-bottom: 30px;
    @media (max-width: 980px) {
        width: 100%;
    }
`;

const PromotionImage = styled.img`
    width: 100%;
    object-fit: cover;
`;

const FreePlayContainer = styled.div`
    display: flex;
    flex: 1;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    background-color: #e09900;
    padding-top: 15px !important;
    padding-right: 10px !important;
    padding-bottom: 10px !important;
    padding-left: 10px !important;
    margin-bottom: 10px !important;
`;

const Emoji = styled.img`
    width: 25px;
    max-height: 25px;
`;

const FreeToPlayHeading = styled.div`
    color: #fff;
    text-transform: uppercase;
    font-weight: 600;
    line-height: 1em;
`;

const Text = styled.div`
    font-size: 14px;
    text-align: center;
`;

const GreenText = styled.div`
    color: #7cda24;
    font-size: 20px;
    font-weight: 800;
`;

const BlueHedingText = styled.div`
    color: #094f96;
    font-size: 46px;
    font-weight: 800;
    text-transform: uppercase;
`;

const RotatedGreenContainer = styled.div`
    margin-left: 12%;
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    font-weight: 600;
    text-transform: uppercase;
    line-height: 1em;
    background-color: #7cda24;
    padding-top: 10px !important;
    padding-right: 10px !important;
    padding-bottom: 10px !important;
    padding-left: 10px !important;
    margin-top: 40px !important;
    margin-bottom: 10px !important;
    transform: rotateZ(2deg);
    width: 73%;
`;

const ThreeMillionHeading = styled.div`
    color: #fff;
    text-transform: uppercase;
    font-weight: 800;
    font-size: 41px;
    margin: 10px;
    text-shadow: 0.08em 0.08em 0em rgba(0, 0, 0, 0.4);
    @media (max-width: 980px) {
        font-size: 31px;
    }
    @media (max-width: 768px) {
        font-size: 22px;
    }
`;

const RotatedText = styled.div`
    font-size: 14px;
    text-align: center;
    transform: rotateZ(2deg);
`;

type Props = {
    imageUrl: string;
    alt: string;
};

export const PromotionComponent = ({ imageUrl }: Props) => {
    return (
        <Container>
            <ChildContainer>
                <PromotionImage src={imageUrl} />
                <FreePlayContainer>
                    <Emoji src="https://s.w.org/images/core/emoji/13.0.0/svg/1f193.svg"></Emoji>{' '}
                    <FreeToPlayHeading>claim your 4 free plays</FreeToPlayHeading>
                </FreePlayContainer>
                <Text>* Terms & Conditions Apply</Text>
            </ChildContainer>
            <ChildContainer>
                <GreenText>DID YOU KNOW? WE PAY THE</GreenText>
                <BlueHedingText>BIGGEST ONLINE FOOTBALL JACKPOT</BlueHedingText>
                <RotatedGreenContainer>
                    <Emoji src="https://s.w.org/images/core/emoji/13.0.0/svg/1f911.svg"></Emoji>
                    <ThreeMillionHeading>£3 MILLION</ThreeMillionHeading>
                </RotatedGreenContainer>
                <RotatedText>to be won every single week from a £1 stake</RotatedText>
            </ChildContainer>
        </Container>
    );
};
