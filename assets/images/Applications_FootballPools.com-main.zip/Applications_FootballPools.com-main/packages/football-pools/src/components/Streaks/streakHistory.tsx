import { getPrizeLevels, Streak, StreakLine } from '@api/streaks';
// eslint-disable-next-line import/default
import dayjs from 'dayjs';
import styled from 'styled-components';

type Props = {
    streaks: Streak[];
    gameName: string;
    activeLine: StreakLine;
};

const PrizeDetails = styled.div<{ gameName: string }>`
    background-color: ${({ gameName }) => (gameName === 'lucky-clover' ? '#238D36' : '#fff')};
    color: ${({ gameName }) => (gameName === 'lucky-clover' ? '#fff' : '#2b2b2b')};
    display: flex;
    justify-content: space-between;
    padding: 0 10px;
    width: 95%;
    margin: 0 auto;
    height: 25px;
    align-items: center;
    border-radius: 25px;
    font-weight: bold;
`;

const DetailsList = styled.div<{ gameName: string }>`
    overflow-y: scroll;
    max-height: 500px;
    margin: ${({ gameName }) => (gameName === 'lucky-clover' ? '10px' : '20px 0 0')};
    padding-bottom: ${({ gameName }) => (gameName === 'lucky-clover' ? '20px' : '0')};
    background-color: ${({ gameName }) => (gameName === 'lucky-clover' ? '#fff' : '')};
    color: ${({ gameName }) => (gameName === 'lucky-clover' ? '#000' : '')};
    font-weight: ${({ gameName }) => (gameName === 'lucky-clover' ? 'bold' : '')};
    > div > p {
        margin: ${({ gameName }) => (gameName === 'lucky-clover' ? '20px 0 5px' : '')};
    }
`;

const prizeAmount = (tally: number, gameName: string) => {
    const prizeLevels = getPrizeLevels(gameName);
    const prize = prizeLevels.find(prize => prize.level === tally);
    if (prize?.amount.startsWith('£')) {
        return prize?.amount;
    }
    return '£0.00';
};

export const StreakHistory = ({ streaks, gameName, activeLine }: Props) => {
    return (
        <DetailsList gameName={gameName}>
            {streaks.map(streak => (
                <div key={streak.lineId}>
                    <p>Date: {dayjs(streak.createdAt).format('DD-MM-YY')}</p>
                    <PrizeDetails gameName={gameName}>
                        <p>Streak: {streak.tally}</p>
                        <p>Prize: {prizeAmount(streak.tally, gameName)}</p>
                    </PrizeDetails>
                </div>
            ))}
            {streaks.length === 0
                ? activeLine
                    ? 'Keep going to EARN even BIGGER CASH PRIZES!'
                    : "You haven't been on a streak for this line yet, keep trying!"
                : ''}
        </DetailsList>
    );
};
