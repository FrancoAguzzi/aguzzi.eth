import styled from 'styled-components';
import { ImageTile } from '@fp/shared/src/components/ImageTile/ImageTile';
import { TileList } from '@fp/shared/src/components/TileList/TileList';

const Container = styled.div`
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
    background-color: #010d68;
`;

const Title = styled.h1`
    width: 100%;
    font-size: 30px;
    color: #fff;
    max-width: 1200px;
    margin-bottom: 5px;
    text-align: center;
`;

const TileContainer = styled.div`
    width: 100%;
    max-width: 1200px;

    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: space-between;
    margin: 20px;
`;

const CtaButton = styled.a`
    margin: 0 auto;
    color: #fff;
    background-color: #010d68;
    border: 1px solid #fff;
    border-radius: 25px;
    margin-top: 10px;
    margin-bottom: 30px;
    width: 388px;
    height: 50px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    text-decoration: none;

    @media (max-width: 390px) {
        width: 90%;
    }
`;

interface WinnersHistoryProps {
    titleText: string;
    ctaText: string;
    winnerImageProps: WinnerImageProps[];
}

export interface WinnerImageProps {
    src: string;
    caption: string;
    subtext: string;
}

export const WinnersHistory = (props: WinnersHistoryProps) => {
    return (
        <Container>
            <Title>{props.titleText}</Title>
            <TileContainer>
                <TileList>
                    {props.winnerImageProps &&
                        props.winnerImageProps.map((Winner, index) => (
                            <ImageTile
                                key={`${Winner.src}-${index}`}
                                src={Winner.src}
                                caption={Winner.caption}
                                subtext={Winner.subtext}
                            />
                        ))}
                </TileList>
            </TileContainer>
            <CtaButton href="/winners">{props.ctaText}</CtaButton>
        </Container>
    );
};

export default WinnersHistory;
