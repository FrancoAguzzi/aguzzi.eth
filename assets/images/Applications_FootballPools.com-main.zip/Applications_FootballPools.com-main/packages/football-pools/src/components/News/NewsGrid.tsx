import styled from 'styled-components';
import { FunctionComponent } from 'react';

import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import { NewsTile } from './NewsTile';
import { NewsItem } from '@fp/shared/src/core/news';

const Container = styled.div`
    max-width: 100%;
    display: grid;
    margin: 0 auto;
    grid-auto-rows: 400px;
    grid-auto-flow: row dense;
    gap: 10px;
    margin-top: 10px;

    ${breakpoints.above('md')} {
        grid-template-columns: repeat(3, 1fr);
    }

    ${breakpoints.above('lg')} {
        margin: 10px auto;
    }
`;

type Props = {
    newsItems: NewsItem[];
};

const NewsGrid: FunctionComponent<Props> = ({ newsItems }) => {
    const tiles = newsItems.map(article => <NewsTile key={article.slug} {...article}></NewsTile>);
    return <Container>{tiles}</Container>;
};

export default NewsGrid;
