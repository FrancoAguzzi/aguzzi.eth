import styled from 'styled-components';

const BreadcrumbWrapper = styled.div`
    display: flex;
    flex-direction: row;
`;

const BreadcrumbItem = styled.div`
    display: flex;
    flex-direction: row;
    margin: 5px 0 0;
    a,
    p {
        text-decoration: none;
        text-transform: capitalize;
        margin: 0;
        color: inherit;

        :hover:not(p) {
            color: #d3d3d3;
        }
    }
    div {
        margin: 0 5px;
    }
`;

type Props = {
    prevPageUrl: string;
    prevPageTitle: string;
    currentPageTitle: string;
};

export const Breadcrumb = ({ prevPageUrl, prevPageTitle, currentPageTitle }: Props) => (
    <BreadcrumbWrapper>
        <BreadcrumbItem>
            <a href={prevPageUrl}>{prevPageTitle}</a>
        </BreadcrumbItem>
        <BreadcrumbItem>
            <div> / </div>
            <p>{currentPageTitle}</p>
        </BreadcrumbItem>
    </BreadcrumbWrapper>
);
