import { render } from '@testing-library/react';
import { LeaderboardTable } from './Leaderboard';

describe('Leaderboard', () => {
    it('should render correctly', () => {
        const { container } = render(
            <LeaderboardTable
                leaderboard={{
                    members: [
                        {
                            nickname: 'test',
                            rank: 1,
                            previousRank: 1,
                            totalPoints: 100,
                            playerId: 1234,
                            customerMember: false,
                        },
                        {
                            nickname: 'test2',
                            rank: 2,
                            previousRank: 3,
                            totalPoints: 90,
                            playerId: 2345,
                            customerMember: false,
                        },
                        {
                            nickname: 'test3',
                            rank: 3,
                            previousRank: 2,
                            totalPoints: 80,
                            playerId: 3456,
                            customerMember: false,
                        },
                    ],
                    totalPages: 80,
                    page: 0,
                    pageSize: 3,
                }}
                isLoading={false}
            />,
        );

        expect(container).toMatchSnapshot();
    });
});
