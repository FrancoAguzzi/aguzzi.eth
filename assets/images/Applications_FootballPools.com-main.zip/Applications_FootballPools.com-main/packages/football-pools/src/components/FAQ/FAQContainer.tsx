import { FAQItem } from '@fp/shared/src/core/faq';
import styled from 'styled-components';
import { FAQ } from './FAQ';

const Container = styled.div<{ backgroundColor?: string; column?: boolean }>`
    display: flex;
    width: 100%;
    height: auto;
    flex-direction: column;
`;
const Title = styled.h1`
    width: 100%;
    font-size: 30px;
    color: #010d68;
    max-width: 1200px;
    margin-bottom: 5px;
    @media (max-width: 1200px) {
        margin-left: 10px;
        margin-right: 10px;
    }
`;

type Props = {
    sections: FAQItem[];
};

const FAQContainer = ({ sections }: Props) => {
    return (
        <Container>
            <Title>Frequently Asked Questions</Title>
            {sections.map((section, index) => (
                <FAQ key={index} title={section.heading} content={section.content}></FAQ>
            ))}
        </Container>
    );
};

export default FAQContainer;
