import { render } from '@testing-library/react';
import { TitleContentImageSection } from './TitleContentImageSection';

describe('TitleContentImageSection', () => {
    it('should render correctly ', () => {
        const { container } = render(
            <TitleContentImageSection
                titleText={'About Us'}
                bodyText={
                    'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Pretium viverra suspendisse potenti nullam ac tortor. Pulvinar neque laoreet suspendisse interdum consectetur. Id eu nisl nunc mi ipsum. Gravida quis blandit turpis cursus in. Porttitor eget dolor morbi non arcu risus. Mauris pharetra et ultrices neque. Ac placerat vestibulum lectus mauris ultrices eros in cursus turpis. Nunc mattis enim ut tellus elementum sagittis. Massa massa ultricies mi quis hendrerit. Rhoncus dolor purus non enim praesent elementum facilisis leo. Quisque sagittis purus sit amet volutpat consequat mauris. Tellus at urna condimentum mattis pellentesque id. Consectetur purus ut faucibus pulvinar elementum integer enim neque. Non tellus orci ac auctor augue mauris augue. Dolor magna eget est lorem. Quisque id diam vel quam elementum pulvinar etiam. Tortor aliquam nulla facilisi cras fermentum. In egestas erat imperdiet sed euismod nisi porta. Pulvinar neque laoreet suspendisse interdum consectetur libero id faucibus. Turpis egestas integer eget aliquet. Tortor dignissim convallis aenean et tortor at risus viverra. Imperdiet nulla malesuada pellentesque elit eget. Eu consequat ac felis donec et odio pellentesque diam. Arcu dui vivamus arcu felis bibendum ut tristique. Vel orci porta non pulvinar neque laoreet suspendisse interdum consectetur. Orci eu lobortis elementum nibh tellus molestie.'
                }
                imageUrl={'https://source.unsplash.com/random/590x363?Athletics'}
            />,
        );

        expect(container).toMatchSnapshot();
    });
});
