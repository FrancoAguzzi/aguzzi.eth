import { render } from '@testing-library/react';
import { FAQ } from './FAQ';

jest.mock('@fp/shared/src/settings/breakpoints');

describe('FAQ Section', () => {
    it('should render correctly ', () => {
        const { container } = render(
            <FAQ
                title={'What is Classic Pools?'}
                content={
                    'Classic Pools is a subscription based game playable either via a Monthly Direct Debit or using a Recurring Card transaction.'
                }
            />,
        );

        expect(container).toMatchSnapshot();
    });
});
