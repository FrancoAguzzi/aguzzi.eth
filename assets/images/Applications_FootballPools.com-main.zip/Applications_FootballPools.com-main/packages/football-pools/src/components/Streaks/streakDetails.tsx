// eslint-disable-next-line import/default
import dayjs from 'dayjs';
import { useEffect } from 'react';
import styled from 'styled-components';

import { useStreaks } from '@api/streaks';

const Table = styled.table`
    text-align: left;
    width: 100%;
    font-size: 0.75rem;
    margin-top: 10px;
`;

const Row = styled.tr`
    width: 100%;
    display: flex;
    margin-top: 5px;
    :not(:first-of-type) {
        margin-top: 5px;
        padding-top: 5px;
        position: relative;
        &:before {
            content: '';
            position: absolute;
            top: 0;
            border-bottom: 1px white solid;
            width: 100%;
        }
    }
`;

const Header = styled(Row)`
    > * {
        text-align: center;
        display: block !important;
        font-weight: 700;
    }
`;

const Date = styled.td`
    flex: 0 0 80px;
    min-width: 80px;
`;

const Numbers = styled.td`
    display: flex;
    justify-content: space-between;
    width: 100%;
    margin: 0 10px;
`;

const Number = styled.div<{ matching?: boolean }>`
    color: ${({ matching }) => (matching ? '#FFE202' : 'white')};
`;

const TotalColumn = styled.td`
    text-align: center;
    flex: 0 0 85px;
    min-width: 85px;
`;

const Total = styled(TotalColumn)`
    color: #ffe202;
    font-weight: bold;
`;

const formatDate = (date: Date) => dayjs(date).format('DD/MM/YYYY');

const formatNumber = (num: number) => num.toString().padStart(2, '0');

type Props = {
    lineId: number;
    visible: boolean;
    gameName: string;
};

export const StreakDetails = ({ lineId, visible, gameName }: Props) => {
    const { streakDetails, getStreakDetails, loading, clearStreakDetails } = useStreaks();

    useEffect(() => {
        if (!streakDetails.length && visible && !loading) {
            getStreakDetails(lineId, gameName);
        }
    }, [visible]);

    useEffect(() => {
        clearStreakDetails();
    }, [lineId]);

    if (!visible) return null;
    if (loading) return <div>Loading...</div>;
    if (!streakDetails.length) return <div>No streak details found</div>;

    const rows = streakDetails.map((details, index) => (
        <Row key={index}>
            <Date>{formatDate(details.competitionDate)}</Date>
            <Numbers>
                {details.selections.map(num => (
                    <Number key={num} matching={details.winningNumbers.includes(num)}>
                        {formatNumber(num)}
                    </Number>
                ))}
            </Numbers>
            <Total>{details.tally}</Total>
        </Row>
    ));

    return (
        <Table>
            <Header as="thead">
                <Date>Date</Date>
                <Numbers>Your Numbers</Numbers>
                <TotalColumn>Streaks Total</TotalColumn>
            </Header>
            {rows}
        </Table>
    );
};
