// eslint-disable-next-line import/named
import { LeaderboardResultMember, LeaderboardResultMembers } from '@sportech/pools-api';
import { FunctionComponent } from 'react';
import styled from 'styled-components';

const Container = styled.table`
    width: 100%;
    max-height: 945px;
`;

interface LeaderboardTableProps {
    leaderboard?: LeaderboardResultMembers;
    isLoading?: boolean;
}

export const LeaderboardTable: FunctionComponent<LeaderboardTableProps> = ({ leaderboard, isLoading }) => {
    return (
        <Container>
            <thead>
                <tr>
                    <th>Position</th>
                    <th>Nickname</th>
                    <th>Points</th>
                </tr>
            </thead>
            <TableBody>
                {isLoading && (!leaderboard || leaderboard?.members || leaderboard?.members.length === 0) && (
                    <LoadingCells />
                )}
                {leaderboard &&
                    leaderboard.members &&
                    leaderboard.members.map((member, index) => (
                        <LeaderboardRow key={`LeaderboardEntry${index}`} {...member} />
                    ))}
            </TableBody>
        </Container>
    );
};

const TableBody = styled.tbody`
    position: relative;
    > tr:nth-child(2n) {
        background: rgba(0, 0, 0, 0.09);
    }
    min-height: 200px;
`;
const ItemRow = styled.tr`
    min-height: 20px;
`;
const CellData = styled.td<{ colour?: string }>`
    text-align: center;
    padding: 0.8em;
    color: ${props => props.colour};
`;
const StatusUp = styled.div`
    width: 0;
    height: 0;
    padding: 0;
    border-left: 11px solid transparent;
    border-right: 11px solid transparent;
    border-bottom: 13px solid #197b30;
    font-size: 0;
    line-height: 0;
`;
const StatusDown = styled.div`
    width: 0;
    height: 0;
    padding: 0;
    border-left: 11px solid transparent;
    border-right: 11px solid transparent;
    border-top: 13px solid #cb2a20;
    font-size: 0;
    line-height: 0;
`;
const StatusEqual = styled.div`
    width: 20px;
    height: 6px;
    padding: 0;
    border: none;
    background-color: #8b8b8b;
`;
const RankContainer = styled.div`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-evenly;
`;

const LeaderboardRow = (item: LeaderboardResultMember) => {
    const status: 'up' | 'down' | 'equal' =
        item.previousRank && item.previousRank > item.rank
            ? 'up'
            : !item.previousRank || item.previousRank === item.rank
            ? 'equal'
            : 'down';
    return (
        <ItemRow>
            <CellData>
                <RankContainer>
                    {status === 'up' ? <StatusUp /> : status === 'down' ? <StatusDown /> : <StatusEqual />}
                    {item.rank}
                </RankContainer>
            </CellData>
            <CellData colour={item.customerMember ? '#3b5ff3' : undefined}>{item.nickname}</CellData>
            <CellData>{item.totalPoints}</CellData>
        </ItemRow>
    );
};

const LoadingCells = () => (
    <>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
        <ItemRow>
            <CellData />
        </ItemRow>
    </>
);
