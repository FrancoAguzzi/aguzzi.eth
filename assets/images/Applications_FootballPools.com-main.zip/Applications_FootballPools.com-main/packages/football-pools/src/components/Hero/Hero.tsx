import { FunctionComponent } from 'react';
import styled from 'styled-components';
import { HeroButton, HeroButtonProps } from './HeroButton/HeroButton';

interface HeroContainerProps {
    imageUrl: string;
    backgroundColour: string;
    reverse: boolean;
}
const HeroContainer = styled.div<HeroContainerProps>(props => {
    const { imageUrl, backgroundColour, reverse } = props;

    const background = reverse
        ? `background: url(${imageUrl}),
        linear-gradient(
            101deg,
            ${backgroundColour} 0%,
            ${backgroundColour} 50%,
            rgba(255, 255, 255, 1) 50.09%,
            rgba(255, 255, 255, 1) 100%
        );
        background-position-x: left;`
        : `background: url(${imageUrl}),
        linear-gradient(
            101deg,
            rgba(255, 255, 255, 1) 0%,
            rgba(255, 255, 255, 1) 50%,
            ${backgroundColour} 50.09%,
            ${backgroundColour} 100%
        );
        background-position-x: right;`;

    return `
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    justify-content: center;
    align-content: stretch;
    align-items: flex-start;
    width: 100%;
    margin: 0 0 30px 0;
    ${background}
    background-repeat: no-repeat;
    background-size: contain;
    padding: 30px 0;
    color: #fff;

    @media (max-width: 768px) {
        flex-direction: column;
        background: ${backgroundColour};
        padding: 30px 0;
        margin: 0;
    }
    `;
});

const HeroWrapper = styled.div<{ reverse: boolean }>(props => {
    const flexDirection = props.reverse ? 'row-reverse' : 'row';

    return `
    max-width: 1270px;
    width: 100%;
    display: flex;
    flex-direction: ${flexDirection};
    align-items: center;
    justify-content: space-evenly;

    @media (max-width: 768px) {
        width: 80%;
        flex-direction: column-reverse;
        justify-content: center;
        align-self: center;
        padding: 20px 0 0 0;
    }
    `;
});

const HeroFlexContainer = styled.div<{ reverse: boolean }>(props => {
    const alignItems = props.reverse ? null : 'flex-end';

    return `
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    justify-content: center;
    align-content: stretch;
    align-items: flex-start;
    width: 50%;
    margin: 0 30px;
    max-width: 600px;

    @media (max-width: 768px) {
        width: 100%;
        margin: 0;
        padding: 0 10px;
        align-items: ${alignItems};
    }`;
});

const ButtonContainer = styled.div`
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    width: 100%;
`;

const HeroHeading = styled.h2`
    font-size: 3vw;
    font-weight: 800;
    font-style: italic;
    text-transform: uppercase;

    @media (max-width: 768px) {
        font-size: 25px;
    }
`;

const HeroSubtitle = styled.h2<{ subtitleColour: string }>`
    font-size: 2vw;
    font-weight: 800;
    font-style: italic;
    max-width: 70vw;
    text-transform: uppercase;
    color: ${props => props.subtitleColour};

    @media (max-width: 768px) {
        font-size: 20px;
    }
`;

const HeroDescriptionHeader = styled.div<{ headerColour: string }>`
    font-size: 25px;
    font-weight: 700;
    font-style: italic;
    margin: 15px 0;
    color: ${props => props.headerColour};

    @media (max-width: 768px) {
        color: #fff;
        font-size: 18px;
    }
`;

const HeroDescriptionText = styled.div`
    color: #000;
    font-style: italic;

    @media (max-width: 768px) {
        display: none;
    }
`;

interface HeroProps {
    title?: string;
    subtitle?: string;
    subtitleColour?: string;
    backgroundColour?: string;
    imageUrl?: string;
    descriptionHeader?: string;
    descriptionHeaderColour: string;
    descriptionText?: string;
    reverse?: boolean;
    buttons: HeroButtonProps[];
}

export const Hero: FunctionComponent<HeroProps> = ({
    title,
    subtitle,
    subtitleColour = '#fff',
    backgroundColour = 'rgba(0, 89, 255, 1)',
    imageUrl = '',
    descriptionHeader,
    descriptionHeaderColour = 'rgba(0, 89, 255, 1)',
    descriptionText,

    reverse = false,
    buttons,
}) => {
    return (
        <HeroContainer backgroundColour={backgroundColour} imageUrl={imageUrl} reverse={reverse}>
            <HeroWrapper reverse={reverse}>
                <HeroFlexContainer reverse={reverse}>
                    {descriptionHeader && (
                        <HeroDescriptionHeader headerColour={descriptionHeaderColour}>
                            {descriptionHeader}
                        </HeroDescriptionHeader>
                    )}
                    {descriptionText && <HeroDescriptionText>{descriptionText}</HeroDescriptionText>}

                    {buttons && (
                        <ButtonContainer>
                            {buttons.map(button => (
                                <HeroButton
                                    buttonTextColour={button.buttonTextColour}
                                    buttonColour={button.buttonColour}
                                    key={button.buttonText}
                                    href={button.buttonHref}
                                >
                                    {button.buttonText}
                                </HeroButton>
                            ))}
                        </ButtonContainer>
                    )}
                </HeroFlexContainer>

                <HeroFlexContainer reverse={reverse}>
                    {title && <HeroHeading>{title}</HeroHeading>}
                    {subtitle && <HeroSubtitle subtitleColour={subtitleColour}>{subtitle}</HeroSubtitle>}
                </HeroFlexContainer>
            </HeroWrapper>
        </HeroContainer>
    );
};
