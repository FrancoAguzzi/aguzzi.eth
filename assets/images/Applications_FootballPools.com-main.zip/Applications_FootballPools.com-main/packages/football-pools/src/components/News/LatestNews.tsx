import { gql, useQuery } from '@apollo/client';

import { NewsItem } from '@fp/shared/src/core/news';
import { FlatData } from '@src/lib/squidex';
import { NewsTile } from './NewsTile';

const LATEST_NEWS_QUERY = gql`
    {
        queryNewsItemContents(top: 4, orderby: "data/date/iv desc") {
            flatData {
                content
                date
                nonNewsUrl
                slug
                except: subtitle
                title
                image {
                    url
                }
            }
        }
    }
`;

type Response = {
    queryNewsItemContents: FlatData<NewsItem>[];
};

type Props = {
    excludeSlug?: string;
};

export const LatestNews = ({ excludeSlug }: Props) => {
    const { data } = useQuery<Response>(LATEST_NEWS_QUERY);

    if (data) {
        const articles = data.queryNewsItemContents.filter(a => a.flatData.slug !== excludeSlug).slice(0, 3);
        const tiles = articles.map(({ flatData }) => <NewsTile key={flatData.slug} {...flatData} />);
        return <>{tiles}</>;
    }
    return null;
};
