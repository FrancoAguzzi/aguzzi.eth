import { render } from '@testing-library/react';
import Footer from './Footer';

describe('Footer', () => {
    test('should match snapshot', () => {
        const { container } = render(<Footer />);

        expect(container).toMatchSnapshot();
    });
});
