import { render } from '@testing-library/react';
import { Breadcrumb } from './Breadcrumb';

const prevPageUrl = '/prevPage';
const prevPageTitle = 'Previous Page';
const currentPageTitle = "This is the Current Page's Title";
describe('Breadcrumb', () => {
    it('should render correctly', () => {
        const { container } = render(
            <Breadcrumb prevPageUrl={prevPageUrl} prevPageTitle={prevPageTitle} currentPageTitle={currentPageTitle} />,
        );

        expect(container).toMatchSnapshot();
    });
});
