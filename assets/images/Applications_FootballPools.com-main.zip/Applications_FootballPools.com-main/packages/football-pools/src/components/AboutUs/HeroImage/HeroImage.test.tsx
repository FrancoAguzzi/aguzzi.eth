import { render } from '@testing-library/react';
import { HeroImage } from './HeroImage';

describe('HeroImage', () => {
    it('should render correctly', () => {
        const { container } = render(
            <HeroImage imageUrl={'https://source.unsplash.com/random/1920x450?Athletics'} alt={'AboutUsHero'} />,
        );

        expect(container).toMatchSnapshot();
    });
});
