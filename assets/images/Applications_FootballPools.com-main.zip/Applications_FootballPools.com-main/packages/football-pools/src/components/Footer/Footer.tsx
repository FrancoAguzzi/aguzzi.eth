import styled from 'styled-components';

import { ExternalLink } from '@fp/shared/src/components/ExternalLink/ExternalLink';
import getConfig from 'next/config';
import { theme } from '@fp/shared/src/settings/theme';

const { publicRuntimeConfig } = getConfig();

const Container = styled.footer`
    text-align: center;
    padding: 20px 0 0;
    font-size: 0.813rem;
    line-height: 20px;
    background-color: ${theme.colours.footerBackground};
    font-family: Neo Sans;
    font-weight: 500;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
`;

const Section = styled.div`
    ${Container} > &:not(:last-child) {
        margin-bottom: 10px;
    }
    ${Container} > &:last-child {
        margin-bottom: 20px;
    }
    color: ${theme.colours.footerNote};
`;

const Link = styled.a`
    text-decoration: none;
    color: ${theme.colours.footerFont};

    &:hover {
        text-decoration: underline;
    }

    ${Section} > &:not(:last-child) {
        margin-right: 5px;

        &::after {
            content: '';
            margin-left: 5px;
            border-left: 0.5px solid;
        }
    }
`;

type ImageProps = { small?: boolean };
const Image = styled.img<ImageProps>`
    height: ${({ small }) => (small ? 20 : 30)}px;
    width: auto;

    margin: 0 2.5px;
`;

const RedExternalLink = styled(ExternalLink)`
    text-decoration: none;
    color: #d32703;

    &:hover {
        text-decoration: underline;
    }
`;

const Footer = (props: any): JSX.Element => (
    <Container {...props}>
        <Section>
            <Link href="/contact-us">Contact us</Link>
            <Link href="/about-us">About us</Link>
            <Link href="/announcements">Announcements</Link>
            <Link href="/games/classic-pools/rules">Game rules</Link>
            <Link href="/static/terms-and-conditions">Terms and conditions</Link>
            <Link href="/static/privacy-policy">Privacy and cookie policy</Link>
            <Link href="/static/play-responsibly">Responsible play</Link>
            <Link as={ExternalLink} href="http://www.begambleaware.org/">
                Gamble aware
            </Link>
        </Section>
        <Section>
            <Image alt="18+" src="/18plus.svg" />
            <ExternalLink href="https://www.gamcare.org.uk/">
                <Image alt="gamcare" src="/game-care-logo.gif" />
            </ExternalLink>
            <ExternalLink href="https://www.gamstop.co.uk/">
                <Image small alt="gamstop" src="/gamstop.png" />
            </ExternalLink>
            <Image alt="action reuters" src="/action_reuters.jpg" />
            <ExternalLink href="https://www.begambleaware.org/">
                <Image small alt="begambleaware" src="/begambleawareorg.png" />
            </ExternalLink>
        </Section>
        <Section>
            &copy; The Football Pools Limited is licensed and regulated by the{' '}
            <RedExternalLink href="https://secure.gamblingcommission.gov.uk/PublicRegister/Search/Detail/48272">
                Gambling Commission
            </RedExternalLink>
            <br />
            (licence numbers: 000-048272-R-326339-003 and 000-048272-N-326340-003)
        </Section>
    </Container>
);

export default Footer;
