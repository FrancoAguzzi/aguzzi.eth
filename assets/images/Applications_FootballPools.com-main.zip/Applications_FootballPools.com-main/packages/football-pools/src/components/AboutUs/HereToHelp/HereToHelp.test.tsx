import { render } from '@testing-library/react';
import { HereToHelp } from './HereToHelp';

describe('Here To Help', () => {
    it('should render correctly', () => {
        const { container } = render(
            <HereToHelp
                email={'About Us'}
                telephoneUK={'(0800) 953 9933'}
                telephoneInternational={'+44(0)845 6055567'}
            />,
        );

        expect(container).toMatchSnapshot();
    });
});
