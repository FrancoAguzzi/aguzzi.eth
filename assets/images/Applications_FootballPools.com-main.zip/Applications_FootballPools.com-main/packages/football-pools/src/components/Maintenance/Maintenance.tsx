// eslint-disable-next-line import/named
import { GameType } from '@sportech/pools-api';
import { BuilderComponent } from '@builder.io/react';
import styled from 'styled-components';

const ComponentContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
`;

const NewsContainer = styled.div`
    width: 40vw;
`;

const Container = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 60%;
    justify-content: center;
`;

const Message = styled.h3`
    font-size: 1.2rem;
    font-weight: 500;
    text-align: center;
`;

type Props = {
    alt?: string;
    game: GameType;
};

const maintenanceMessage = (game: GameType) => {
    let message = `There are currently no ${game} games available.`;
    switch (game) {
        case 'classic-pools':
        case 'lucky-clover':
        case 'goal-rush': {
            message = `There are currently no ${game} games available.`;
            break;
        }
        default: {
            message = `There are currently no games available.`;
        }
    }
    return message;
};

export const Maintenance = ({ game }: Props) => {
    return (
        <>
            <Container>
                <ComponentContainer>
                    <Message>{maintenanceMessage(game)}</Message>
                    <NewsContainer>
                        <BuilderComponent model="latest-news" />
                    </NewsContainer>
                </ComponentContainer>
            </Container>
        </>
    );
};

export default Maintenance;
