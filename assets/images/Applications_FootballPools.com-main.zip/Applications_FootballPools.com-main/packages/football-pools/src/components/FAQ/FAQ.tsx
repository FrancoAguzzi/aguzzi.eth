import styled from 'styled-components';
import { Collapse } from '@fp/shared/src/components/Collapse/Collapse';

const Container = styled.div`
    width: 100%;
    padding-left: 10px;
    padding-right: 10px;
`;

const Content = styled.div`
    font-size: 14px;
    color: #383838;
`;

type Props = {
    title: string;
    content: string;
};
export const FAQ = ({ title, content }: Props) => {
    return (
        <Container>
            <Collapse title={title}>
                <Content>{content}</Content>
            </Collapse>
        </Container>
    );
};

export default FAQ;
