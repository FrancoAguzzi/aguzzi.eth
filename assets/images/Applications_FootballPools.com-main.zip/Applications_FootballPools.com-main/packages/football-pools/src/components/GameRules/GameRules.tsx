import styled from 'styled-components';
import ReactMarkdown from 'react-markdown';
import { useState } from 'react';

const Container = styled.div`
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    max-width: 1270px;
    margin-top: 20px;
`;

const SelectionContainer = styled.div`
    width: 100%;
    display: flex;
    flex: 1;
    flex-direction: row;
`;

const ButtonContainer = styled.div`
    width: 100%;
    display: flex;
    flex: 1;
    flex-direction: column;
    justify-content: center;
    height: 59px;
`;

const SelectionButton = styled.div<{ selected?: boolean }>`
    display: flex;
    flex: 1;
    background-color: ${({ selected }) => (selected ? '#010d68' : '#919191')};
    color: #fff;
    height: 50px;
    font-size: 16px;
    justify-content: center;
    align-items: center;
`;

const TriangleDown = styled.div<{ selected?: boolean }>`
    width: 0;
    height: 0;
    border-left: 25px solid transparent;
    border-right: 25px solid transparent;
    border-top: 9px solid ${({ selected }) => (selected ? '#010d68' : 'transparent')};
    align-self: center;
`;

const RulesContainer = styled.div`
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
`;

const Title = styled.h1`
    width: 100%;
    font-size: 30px;
    color: #383838;
    max-width: 1200px;
    margin-bottom: 5px;
    text-align: center;
`;

const Body = styled.div`
    width: 100%;
    max-width: 600px;
    font-size: 14px;
    color: #383838;
`;

type Props = {
    classicHeader: string;
    classicRules: string;
    threeMillionHeader: string;
    threeMillionRules: string;
};

export const GameRules = ({ classicHeader, classicRules, threeMillionHeader, threeMillionRules }: Props) => {
    const [ruleDisplay, setRuleDisplay] = useState(true);
    return (
        <Container>
            <SelectionContainer>
                <ButtonContainer>
                    <SelectionButton onClick={() => setRuleDisplay(true)} selected={ruleDisplay}>
                        Classic Pools
                    </SelectionButton>
                    <TriangleDown selected={ruleDisplay}></TriangleDown>
                </ButtonContainer>
                <ButtonContainer>
                    <SelectionButton onClick={() => setRuleDisplay(false)} selected={!ruleDisplay}>
                        Win £3 Million Top Prize
                    </SelectionButton>
                    <TriangleDown selected={!ruleDisplay}></TriangleDown>
                </ButtonContainer>
            </SelectionContainer>
            <RulesContainer>
                <Title>{ruleDisplay ? classicHeader : threeMillionHeader}</Title>
                <Body>
                    <ReactMarkdown>{ruleDisplay ? classicRules : threeMillionRules}</ReactMarkdown>
                </Body>
            </RulesContainer>
        </Container>
    );
};

export default GameRules;
