import { render } from '@testing-library/react';
import { Hero } from './Hero';

describe('Hero', () => {
    it('should render correctly', () => {
        const { container } = render(
            <Hero
                title={'Fantastic cash prizes and more chances to win!'}
                subtitle={'August Enhanced Super Prize Draw'}
                subtitleColour={'rgb(255, 226, 0)'}
                imageUrl={
                    'https://cms.thepools.com/api/assets/clubfootballpools/d8663fb5-a86b-43cf-9d03-363af4c5645d/cfp-angled-money.png?version=1'
                }
                backgroundColour={'rgb(232, 104, 0)'}
                descriptionHeader={'Top prize of £75,000 1000+ £25 cash wins'}
                descriptionHeaderColour={'rgb(232, 104, 0)'}
                descriptionText={
                    'The Classic Pools Monthly Prize Draw gives you even more chances to win, with thousands of cash prizes on offer. Just play Classic pools for a chance to win.'
                }
                buttons={[
                    {
                        buttonText: 'Check Results',
                        buttonTextColour: '#fff',
                        buttonColour: 'rgba(0, 89, 255, 1)',
                        buttonHref: '/results',
                    },
                ]}
                reverse={true}
            />,
        );

        expect(container).toMatchSnapshot();
    });
});
