import styled from 'styled-components';
import ReactMarkdown from 'react-markdown';
import { ImageTile } from '@fp/shared/src/components/ImageTile/ImageTile';

const SectionContainer = styled.div<{ backgroundColor?: string; column?: boolean }>`
    display: flex;
    height: auto;
    background-color: ${({ backgroundColor }) => backgroundColor};
    flex-direction: ${({ column }) => (column ? 'column' : 'row')};
    justify-content: center;
    @media (max-width: 768px) {
        flex-direction: column-reverse;
    }
`;

const Container = styled.div<{ width: string; maxWidth: string }>`
    width: ${props => props.width};
    max-width: ${props => props.maxWidth};
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    margin-top: 20px;
    margin-bottom: 20px;
    @media (max-width: 1270px) {
        padding-left: 10px;
        padding-right: 10px;
        width: 100%;
        max-width: 1270px;
    }
`;

const Title = styled.h1<{ altText: boolean }>`
    width: 100%;
    font-size: 30px;
    color: ${props => (props.altText === true ? '#fff' : '#010d68')};
    margin-bottom: 5px;
    margin-top: 0;
`;
const Body = styled.div<{ altText: boolean }>`
    width: 100%;
    font-size: 14px;
    color: ${props => (props.altText === true ? '#fff' : '#383838')};
`;

export interface TitleContentImageSectionProps {
    titleText: string;
    bodyText: string;
    imageUrl?: string;
    imageCaption?: string;
    imageSubtext?: string;
    alternateBackground?: boolean;
}
export const TitleContentImageSection = ({
    titleText,
    bodyText,
    imageUrl,
    imageCaption,
    imageSubtext,
    alternateBackground = false,
}: TitleContentImageSectionProps): JSX.Element => {
    const bgColour = alternateBackground ? '#010d68' : '#fff';
    return (
        <SectionContainer column={false} backgroundColor={bgColour}>
            <Container width={imageUrl ? '50%' : '100%'} maxWidth={imageUrl ? '635px' : '1270px'}>
                <Title altText={alternateBackground}>{titleText}</Title>
                <Body altText={alternateBackground}>
                    <ReactMarkdown>{bodyText}</ReactMarkdown>
                </Body>
            </Container>
            {imageUrl && (
                <Container width={imageUrl ? '50%' : '100%'} maxWidth={imageUrl ? '635px' : '1270px'}>
                    <ImageTile caption={imageCaption} subtext={imageSubtext} src={imageUrl}></ImageTile>
                </Container>
            )}
        </SectionContainer>
    );
};

export default TitleContentImageSection;
