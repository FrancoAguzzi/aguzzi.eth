import { useOutsideElementClickHandler } from '@fp/shared/src/core/hooks';
import { useRef, useState } from 'react';
import styled from 'styled-components';

export interface DropdownSelectorProps {
    onClick: (id: string | number) => void;
    title?: string;
    items?: { label: string; value: string | number }[];
    styles?: {
        titleFontSize?: string;
    };
}

export const DropdownSelector = (props: DropdownSelectorProps): JSX.Element => {
    const [isOpen, setIsOpen] = useState(false);
    const SelectOption = (event: string | number): void => {
        setIsOpen(false);
        props.onClick(event);
    };
    const ref = useRef<HTMLDivElement>(null);
    useOutsideElementClickHandler(
        ref,
        () => {
            if (isOpen) {
                setIsOpen(false);
            }
        },
        [isOpen],
    );
    return (
        <DropDownContainer ref={ref}>
            <DropDownHeader
                onClick={(): void => {
                    setIsOpen(!isOpen);
                }}
                fontSize={props.styles?.titleFontSize || ''}
            >
                <span>{props.title}</span>
            </DropDownHeader>
            {isOpen && props.items && (
                <DropDownListContainer>
                    <DropDownList>
                        {props.items.map((item, index) => (
                            <ListItem onClick={(): void => SelectOption(item.value)} key={index} value={item.value}>
                                {item.label}
                            </ListItem>
                        ))}
                    </DropDownList>
                </DropDownListContainer>
            )}
        </DropDownContainer>
    );
};

const DropDownContainer = styled.div`
    padding-top: 10px;
    background: white;
`;

const DropDownHeader = styled.div<{ fontSize: string }>`
    padding: 0.4em 0 0.4em 0;
    font-weight: 500;
    font-size: ${props => props.fontSize ?? '1.3rem'};
    color: #fff;
    background: ${(props): string => props.theme.colours.gameMainColour};
    width: 100%;
    cursor: pointer;
    > span {
        margin-right: -30px;
    }
`;

const DropDownListContainer = styled.div`
    position: relative;
`;

const DropDownList = styled.div`
    position: absolute;
    z-index: 300;
    padding: 0;
    margin: 0;
    overflow: scroll;
    background: #eaeaea;
    box-sizing: border-box;
    color: #000;
    font-size: 1.3rem;
    font-weight: 500;
    width: 100%;
    &:first-child {
        padding-top: 0.8em;
    }

    // Chrome, Edge, Opera, Safari:
    ::-webkit-scrollbar {
        display: none;
    }
    ::-webkit-scrollbar-thumb {
        display: none;
    }
    // Firefox:
    scrollbar-width: none;
`;

const ListItem = styled.li`
    list-style: none;
    margin-bottom: 0.8em;
    cursor: pointer;
`;
