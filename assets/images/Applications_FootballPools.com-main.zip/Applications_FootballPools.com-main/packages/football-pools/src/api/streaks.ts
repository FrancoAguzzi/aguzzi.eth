import getConfig from 'next/config';
import { useState } from 'react';
import { api } from '@services/api';
import { isAppError } from '@fp/shared/src/core/appError';
import { useAuthToken } from '@fp/shared/src/api/subscriptionApi/useAuthToken';

export interface StreakProgress {
    competitionId: number;
    competitionDate: Date;
    winningNumbers: number[];
    streakLines: StreakLine[];
}

export interface StreakLine {
    lineId: number;
    tally: number;
    selections: number[];
}

export interface Streak {
    competitionId: number;
    sequence: number;
    lineId: number;
    tally: number;
    wagerId: number;
    createdAt: string;
}

export interface StreakDetails {
    tally: number;
    sequence: number;
    selections: number[];
    winningNumbers: number[];
    competitionDate: Date;
}

export interface Prize {
    level: number;
    amount: string;
}

export const getPrizeLevels = (gameName: string): Prize[] => {
    if (gameName === 'lucky-clover') {
        return cloverPrizeLevels;
    } else if (gameName === 'classic-pools') {
        return classicPrizeLevels;
    }
    return [];
};

export const cloverPrizeLevels: Prize[] = [
    { level: 16, amount: '£100.00' },
    { level: 15, amount: '£75.00' },
    { level: 14, amount: '£50.00' },
    { level: 13, amount: '£25.00' },
    { level: 12, amount: '£20.00' },
    { level: 11, amount: '£15.00' },
    { level: 10, amount: '£10.00' },
    { level: 9, amount: '£7.00' },
    { level: 8, amount: '£5.00' },
    { level: 7, amount: '£3.00' },
    { level: 6, amount: '£2.00' },
    { level: 5, amount: '£1.50' },
    { level: 4, amount: '£1.00' },
    { level: 3, amount: '1 to go' },
    { level: 2, amount: '2 to go' },
    { level: 1, amount: '3 to go' },
    { level: 0, amount: '4 to go' },
];

export const classicPrizeLevels: Prize[] = [
    { level: 16, amount: '£120.00' },
    { level: 15, amount: '£75.00' },
    { level: 14, amount: '£50.00' },
    { level: 13, amount: '£25.00' },
    { level: 12, amount: '£15.00' },
    { level: 11, amount: '£10.00' },
    { level: 10, amount: '£7.50' },
    { level: 9, amount: '£5.00' },
    { level: 8, amount: '£4.00' },
    { level: 7, amount: '£3.00' },
    { level: 6, amount: '£2.00' },
    { level: 5, amount: '£1.50' },
    { level: 4, amount: '£1.00' },
    { level: 3, amount: '1 to go' },
    { level: 2, amount: '2 to go' },
    { level: 1, amount: '3 to go' },
    { level: 0, amount: '4 to go' },
];

const mapDetails = (detail: StreakDetails): StreakDetails => ({
    ...detail,
    competitionDate: new Date(detail.competitionDate),
});

export const useStreaks = () => {
    const { getToken } = useAuthToken();

    const [streakDetails, setStreakDetails] = useState<StreakDetails[]>([]);
    const [streaks, setStreaks] = useState<Streak[]>([]);
    const [loading, setLoading] = useState(false);

    const getStreakDetails = async (lineId: number, gameName: string) => {
        setLoading(true);
        const response = await api.send<StreakDetails[]>({
            method: 'get',
            endpoint: `/streaks/details?gameName=${gameName}&lineId=${lineId}`,
            authToken: getToken(),
        });

        if (!isAppError(response)) {
            const details = response.map(mapDetails);
            setStreakDetails(details);
        }
        setLoading(false);
    };

    const clearStreakDetails = () => setStreakDetails([]);

    const getStreaks = async (lineId: number, gameName: string) => {
        setLoading(true);
        const response = await api.send<Streak[]>({
            method: 'get',
            endpoint: `/streaks/line?gameName=${gameName}&lineId=${lineId}`,
            authToken: getToken(),
        });

        if (!isAppError(response)) {
            setStreaks(response);
        }
        setLoading(false);
    };

    return { streakDetails, getStreakDetails, streaks, getStreaks, loading, clearStreakDetails };
};
