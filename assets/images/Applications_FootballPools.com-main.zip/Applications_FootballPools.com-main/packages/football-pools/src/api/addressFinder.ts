import { api } from '@src/services/api';
import { ApiResponse } from '@src/services/apiResponse';

export type Address = {
    addressLine1: string;
    addressLine2: string;
    addressLine3: string;
    countryCode: string;
    postcode: string;
};

export type Suggestion = {
    code: string;
    value: string;
};

export type Places = {
    query: string;
    suggestions: Suggestion[];
};

export const getPlaceSuggestions = async (
    partialPostcode: string,
    countryCode = 'GB',
): Promise<ApiResponse<Places>> => {
    const endpoint = `/address-finder/places?postcode=${partialPostcode}&countryCode=${countryCode}`;
    const response = await api.send<Places>({ method: 'get', endpoint });
    return response;
};

export const getAddressFromCode = async (code: string): Promise<ApiResponse<Address>> => {
    const endpoint = `/address-finder/place?code=${code}`;
    const response = await api.send<Address>({ method: 'get', endpoint });
    return response;
};
