import { DefaultTheme } from 'styled-components';
import {
    colourValues as mainColourValues,
    goalRushColourValues as mainGoalRushColourValues,
    luckyCloverColourValues as mainLuckyCloverColourValues,
    premier10ColourValues as mainPremier10ColourValues,
    premier12ColourValues as mainPremier12ColourValues,
    premier6ColourValues as mainPremier6ColourValues,
} from '@fp/shared/src/settings/colours';

type PropType<TObj, TProp extends keyof TObj> = TObj[TProp];

type Colours = PropType<DefaultTheme, 'colours'>;

export const colourValues: Colours = {
    ...mainColourValues,
};

export const goalRushColourValues: Colours = {
    ...colourValues,
    ...mainGoalRushColourValues,
};

export const luckyCloverColourValues: Colours = {
    ...colourValues,
    ...mainLuckyCloverColourValues,
};

export const premier12ColourValues: Colours = {
    ...colourValues,
    ...mainPremier10ColourValues,
};

export const premier10ColourValues: Colours = {
    ...colourValues,
    ...mainPremier12ColourValues,
};

export const premier6ColourValues: Colours = {
    ...colourValues,
    ...mainPremier6ColourValues,
};
