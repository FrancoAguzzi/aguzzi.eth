import * as nextRouter from 'next/router';

export const mockUseRouter = ({ route, pathname, query, asPath }: Partial<nextRouter.NextRouter>) => {
    const actions = {
        push: jest.fn(() => Promise.resolve(true)),
        replace: jest.fn(() => Promise.resolve(true)),
    };

    (nextRouter.useRouter as jest.Mock) = jest.fn(() => ({
        route,
        pathname,
        query,
        asPath,
        ...actions,
    }));

    return actions;
};
