import { RenderResult, render } from '@testing-library/react';
import { Provider } from 'react-redux';
import { RootState } from '@fp/shared/src/rootReducer';
import { AppStore, makeStore } from '@fp/shared/src/store';

type renderResult = RenderResult & { store: AppStore };
export const renderWithRedux = (
    ui: React.ReactElement,
    initialState: RootState,
    store: AppStore = makeStore(initialState),
): renderResult => ({ ...render(<Provider store={store}>{ui}</Provider>), store });
