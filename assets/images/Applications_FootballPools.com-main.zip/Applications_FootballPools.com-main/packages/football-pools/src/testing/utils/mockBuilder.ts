jest.mock('@builder.io/react', () => ({
    builder: {
        editingModel: false,
    },
    BuilderComponent: () => null,
}));

export {};
