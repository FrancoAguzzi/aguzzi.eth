export default 'svgr';
export const ReactComponent = 'div';
