import { render, RenderResult } from '@testing-library/react';
// eslint-disable-next-line import/named
import { Adaptor, ApiProvider } from '@sportech/pools-api';
import { useSubscriptionApiAdaptor } from '@fp/shared/src/api/subscriptionApi/useSubscriptionApiAdaptor';

// TODO: update to use mockAdaptor from @sportech/pools-api when published!

export const withApiProvider = (ui: React.ReactElement, adaptor?: Adaptor): JSX.Element => (
    <ApiProvider adaptor={adaptor || useSubscriptionApiAdaptor()} config={{ clientType: 'backend' }}>
        {ui}
    </ApiProvider>
);

export const renderWithApiProvider = (ui: React.ReactElement, adaptor?: Adaptor): RenderResult =>
    render(withApiProvider(ui, adaptor));
