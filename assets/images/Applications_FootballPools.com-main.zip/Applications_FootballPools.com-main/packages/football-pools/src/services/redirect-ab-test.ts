import { builder } from '@builder.io/react';
import { Response } from 'express';
import { IncomingMessage, ServerResponse } from 'http';

import { getCookieFromCookieString } from '@services/cookies';
import { redirect } from '@src/lib/server';

type Redirects = {
    name: string;
    redirects: Redirect[];
    clubFpGameDisplay?: 'fixtures' | 'numbers';
};

type Redirect = {
    link: string;
    percentage: number;
};

const getTestCookieString = (name: string) => `FPSUBS_AB_${name}`;

let expiryTime: Date;
let refetching = false;
let cachedRedirects: Redirects[] = [];

export const handleABRedirect = async (req: IncomingMessage, res: ServerResponse) => {
    const now = new Date();

    cachedRedirects.forEach(redirects => handleRedirectTest(req, res as Response)({ data: redirects }));

    if (!refetching && (!expiryTime || expiryTime < now)) {
        fetchRedirects(now);
    }
};

const fetchRedirects = async (now: Date) => {
    refetching = true;
    expiryTime = new Date();
    expiryTime.setMinutes(now.getMinutes() + 1);

    builder.init(process.env.BUILDER_API_KEY || '');
    const response = await builder.getAll('redirect-ab-test');
    const redirects = response.map(value => value.data as Redirects);

    refetching = false;
    cachedRedirects = redirects;
};

const handleRedirectTest = (req: IncomingMessage, res: Response) => (response: any) => {
    const path = req.url || '/';
    const [pathname, query] = path.split('?');
    const data = response.data as Redirects;

    for (const redirectObj of data.redirects) {
        if (redirectObj.link === pathname) {
            const cookieName = getTestCookieString(data.name);
            const existingCookie = getCookieFromCookieString(req.headers.cookie || '')(cookieName);

            if (existingCookie && existingCookie.includes('clubfp.footballpools.com')) {
                return redirect(res, existingCookie);
            } else if (!existingCookie) {
                const chosenRedirect = choseRedirect(data.redirects);
                res.cookie(cookieName, chosenRedirect.link, { domain: '.footballpools.com' });

                if (chosenRedirect.link.includes('clubfp.footballpools.com')) {
                    return redirect(res, buildUrl(chosenRedirect.link, query));
                }
            }
        }
    }
};

const buildUrl = (pathname: string, query?: string) => (query ? `${pathname}?${query}` : pathname);

const choseRedirect = (redirects: Redirect[]): Redirect => {
    const randomNumber = Math.random() * 100;
    let acc = 0;
    for (const redirect of redirects) {
        acc += redirect.percentage;
        if (randomNumber <= acc) return redirect;
    }
    return redirects[0];
};
