import { useRouter } from 'next/router';
import { useEffect } from 'react';
import { ApplicationInsights, IConfiguration } from '@microsoft/applicationinsights-web';

declare global {
    interface Window {
        ai?: ApplicationInsights;
    }
}

let ai: ApplicationInsights;

export const useApplicationInsights = (config: IConfiguration) => {
    const router = useRouter();
    useEffect(() => {
        const initApplicationInsights = () => {
            if (typeof window !== 'undefined' && !window.ai) {
                try {
                    ai = new ApplicationInsights({ config });
                    ai.loadAppInsights();
                    window.ai = ai;
                } catch (err) {
                    console.debug('error initialising appinsights', err);
                }
            }
        };
        initApplicationInsights();
        trackPageView();
    }, [router.asPath]);

    const trackPageView = () => {
        if (ai) {
            const name = router.asPath;
            const properties: { [key: string]: string } = {
                route: router.route,
            };
            if (router.query) {
                try {
                    for (const key in router.query) {
                        properties[`query.${key}`] = router.query[key] as string;
                    }
                } catch {}
            }
            ai.trackPageView({ name, properties });
        }
    };
};

const log = (event: string, msg: string) => {
    if (ai) {
        ai.trackEvent({ name: event, properties: { message: msg } });
    }
};

export const logger = {
    log,
};
