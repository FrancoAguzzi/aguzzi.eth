import axios, { Method, AxiosRequestConfig, AxiosError } from 'axios';
import { ApiError } from '../services/apiError';
import { createError } from '@fp/shared/src/core/appError';
import { ApiResponse } from './apiResponse';
import getConfig from 'next/config';

const { publicRuntimeConfig } = getConfig();

interface Request {
    method: Method;
    endpoint: string;
    data?: unknown;
    authToken?: string;
}

interface AuthorizationHeader {
    Authorization: string;
}

const getAuthorizationHeader = (authToken: string): AuthorizationHeader => {
    return { Authorization: `Bearer ${authToken}` };
};

const send = async <T = never>(request: Request): Promise<ApiResponse<T>> => {
    const requestConfig: AxiosRequestConfig = {
        method: request.method,
        url: publicRuntimeConfig.API_URL + request.endpoint,
        data: request.data,
    };

    if (request.authToken) {
        requestConfig.headers = getAuthorizationHeader(request.authToken);
    }

    try {
        const response = await axios.request<T>(requestConfig);
        return response.data;
    } catch (error) {
        console.log('Api call errored', request.endpoint, error.response, request);
        if (error.response) {
            const axiosError = error as AxiosError<ApiError>;
            console.log('axios error as follows', axiosError.response?.data);
            const errorCode = axiosError.response?.data.code;
            return createError(errorCode || 'Something went wrong!', axiosError.response?.data);
        }
        return createError('Something went wrong!');
    }
};

export const api = {
    send,
};
