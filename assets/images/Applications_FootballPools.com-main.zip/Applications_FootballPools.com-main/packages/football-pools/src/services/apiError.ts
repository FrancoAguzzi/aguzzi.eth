export interface ApiError {
    id: number;
    status: number;
    code: string;
    links: string;
    title: string;
    detail: string;
}
