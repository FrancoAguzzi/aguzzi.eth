import { getCookieFromCookieString } from './cookies';

describe('getCookieFromCookieString', () => {
    test('returns cookie value', () => {
        const cookieValue = getCookieFromCookieString('cookieTest=cookieValue12;secondCookie=thisValue3;')(
            'cookieTest',
        );

        expect(cookieValue).toBe('cookieValue12');
    });

    test('returns empty string if no cookie', () => {
        const cookieValue = getCookieFromCookieString('secondCookie=thisValue3;')('cookieTest');

        expect(cookieValue).toBe('');
    });
});
