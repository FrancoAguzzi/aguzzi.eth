import { AppError } from '@fp/shared/src/core/appError';

export type ApiResponse<T> = T | AppError;
