import { StreakProgress } from '@api/streaks';
import { StreaksProgressContent } from '@components/Streaks/streaksProgressContent';
import withFullWidthLayout from '@fp/shared/src/components/Layouts/FullWidthLayout/FullWidthLayout';
import { getCookieFromCookieString } from '@services/cookies';
import { GetServerSideProps } from 'next';
import { ApiResponse } from '@services/apiResponse';
import { authenticateToken } from '@fp/shared/src/api/account';
import { LoginResponse } from '@fp/shared/src/features/authentication/LoginResponse';
import { api } from '@services/api';
import { isAppError } from '@fp/shared/src/core/appError';

type Props = {
    streakProgressSSR: StreakProgress;
};
const StreaksProgress = ({ streakProgressSSR }: Props) => {
    return (
        <StreaksProgressContent streakProgressSSR={streakProgressSSR} gameName="lucky-clover"></StreaksProgressContent>
    );
};

export const getServerSideProps: GetServerSideProps = async ({ req }) => {
    const encryptedToken = getCookieFromCookieString(req.headers.cookie || '')('_clubFpToken');

    if (!encryptedToken) {
        console.log('no encrypted token');
    }
    let tokenResponse: ApiResponse<LoginResponse> | undefined;
    if (encryptedToken) {
        tokenResponse = await authenticateToken(encryptedToken);
        if (isAppError(tokenResponse)) {
            console.log('token response failed');
        }
    }

    const response = await api.send<StreakProgress>({
        method: 'get',
        endpoint: '/streaks?gameName=lucky-clover',
        authToken: tokenResponse && !isAppError(tokenResponse) ? tokenResponse?.token : undefined,
    });

    if (!isAppError(response)) {
        console.log('there is streak progress', response);

        return {
            props: { streakProgressSSR: response },
        };
    }

    console.log('no streak progress');

    return {
        props: {},
    };
};

export default withFullWidthLayout(StreaksProgress);
