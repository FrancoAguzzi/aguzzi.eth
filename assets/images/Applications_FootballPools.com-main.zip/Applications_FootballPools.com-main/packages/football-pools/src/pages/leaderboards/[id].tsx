import { GetStaticPaths, GetStaticProps } from 'next';
import leaderboards from '@containers/leaderboards/leaderboards';
import { getGameFromPath } from '@fp/shared/src/lib/utils';
import { isEnabled, keysEnabled } from '@fp/shared/src/core/toggle.builder';

export const getStaticProps: GetStaticProps = async context => {
    const path = context.params && context.params['id'] ? context.params['id'] : 'classic-pools';
    const showCommunityTabs = await isEnabled('leaderboard-community-tabs');
    const game = getGameFromPath(path as string);
    const enabledLeaderboards = await keysEnabled([
        `leaderboards-classic-pools`,
        `leaderboards-goal-rush`,
        `leaderboards-premier-6`,
        `leaderboards-premier-10`,
        `leaderboards-jackpot-12`,
    ]);
    const pageProps = {
        game,
        enabledLeaderboards,
        count: 20,
        showCommunityTabs,
    };

    return {
        props: pageProps,
        revalidate: 60 * 5,
    };
};

export const getStaticPaths: GetStaticPaths = async () => {
    return {
        paths: [
            { params: { id: 'classic-pools' } },
            { params: { id: 'goal-rush' } },
            { params: { id: 'premier-6' } },
            { params: { id: 'premier-10' } },
            { params: { id: 'premier-12' } },
        ],
        fallback: false,
    };
};

export default leaderboards;
