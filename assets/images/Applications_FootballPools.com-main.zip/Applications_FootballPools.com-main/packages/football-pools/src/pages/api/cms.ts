import { gql } from '@apollo/client';
import { NextApiRequest, NextApiResponse } from 'next';

import { initializeApollo } from '@src/lib/apolloClient';

export default async (req: NextApiRequest, res: NextApiResponse) => {
    if (req.method !== 'POST') res.status(404).end();

    try {
        const client = initializeApollo(undefined, true, !!req.preview);

        const query = !!req.preview ? rewriteQuery(req.body.query) : req.body.query;

        const response = await client.query({
            ...req.body,
            query: gql(query),
        });
        res.status(200).json(response);
    } catch (e) {
        res.status(500).json(e);
    }
};

const rewriteQuery = (query: unknown) => {
    const bodyString = JSON.stringify(query);

    const newBodyString = bodyString.replace('flatData', 'flatData: flatDataDraft');

    return JSON.parse(newBodyString);
};
