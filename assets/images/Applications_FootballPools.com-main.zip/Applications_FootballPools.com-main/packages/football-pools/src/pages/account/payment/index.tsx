import { GetServerSideProps } from 'next';

import payment from '@containers/account/payment/paymentDetails';
import { requiredAuthPage } from '@fp/shared/src/lib/requiredAuthPage';

export default payment;

export const getServerSideProps: GetServerSideProps = async ({ req, res }) => {
    requiredAuthPage(req, res, 'footballPools');

    return { props: {} };
};
