import { NextApiRequest, NextApiResponse } from 'next';

export default async (req: NextApiRequest, res: NextApiResponse) => {
    const { returnurl } = req.query;
    const isProd = process.env.STAGING_ENVIRONMENT === 'production';
    const maxAge = isProd ? 60 * 10 : 60 * 60 * 24;
    setCookie(res, '_fpPreview', true, maxAge);
    res.setPreviewData({}, { maxAge: maxAge });
    res.redirect((returnurl as string) || '/');
};

export const setCookie = (res: NextApiResponse, name: string, value: unknown, maxAgeSeconds: number): void => {
    const stringValue = typeof value === 'object' ? 'j:' + JSON.stringify(value) : String(value);
    const d = new Date();
    d.setTime(d.getTime() + maxAgeSeconds * 1000);
    const expires = 'expires=' + d.toUTCString();
    const isDev = process.env.NODE_ENV === 'development';
    res.setHeader(
        'Set-Cookie',
        `${name}=${stringValue};${expires}; path=/;${isDev ? '' : `domain=.footballpools.com`}`,
    );
};
