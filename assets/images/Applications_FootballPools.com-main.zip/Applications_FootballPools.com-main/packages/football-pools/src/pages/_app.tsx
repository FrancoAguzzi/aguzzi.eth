import { ApolloProvider } from '@apollo/client';
import { AppContext } from 'next/app';
import getConfig from 'next/config';
import withRedux, { ReduxWrapperAppProps } from 'next-redux-wrapper';
import { Provider } from 'react-redux';
import 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import { createGlobalStyle, ThemeProvider } from 'styled-components';
import { Normalize } from 'styled-normalize';
import { theme } from '@fp/shared/src/settings/theme';
import { makeStore } from '@fp/shared/src/store';
import { useApollo } from '../lib/apolloClient';
import { AuthenticationHandler } from '@fp/shared/src/components/AuthenticationHandler/AuthenticationHandler';
import { handleABRedirect } from '@services/redirect-ab-test';
import { ApiProvider } from '@sportech/pools-api';
import { useSubscriptionApiAdaptor } from '@fp/shared/src/api/subscriptionApi/useSubscriptionApiAdaptor';
import '@src/lib/polyfills';
import { useUtmHandler } from '@fp/shared/src/core/hooks';
import { builder } from '@builder.io/react';
import { SubscriptionLimitHandler } from '@fp/shared/src/components/SubscriptionLimitHandler/SubscriptionLimitHandler';
import { SessionLimitHandler } from '@fp/shared/src/components/SessionLimitHandler/SessionLimitHandler';
import { HeadComponent } from '@fp/shared/src/settings/HeadComponent';
import { UserProvider } from '@auth0/nextjs-auth0';
import { useApplicationInsights } from '@services/appInsights';
import { keysEnabled } from '@fp/shared/src/core/toggle.builder';
import { HeaderProps } from '@fp/shared/src/components/Header/Header';
import { getDynamicString } from '@fp/shared/src/core/dynamicString.builder';
import { Shared } from '@fp/shared/src/components/Shared';

const GlobalStyles = createGlobalStyle`
    * {
        box-sizing: border-box;
    }
    body {
        font-family: 'Montserrat', sans-serif;
        overflow-x: hidden;

        // Chrome, Edge, Opera, Safari:
        ::-webkit-scrollbar {
            height: 5px;
            width: 5px;
            background: ${props => props.theme.colours.scrollTrackBackground};
        }
        ::-webkit-scrollbar-thumb {
            height: 5px;
            border-radius: 4px;
            background-color: ${props => props.theme.colours.scrollBarBackground};
        }

        // Firefox:
        scrollbar-color: ${props =>
            `${props.theme.colours.scrollBarBackground} ${props.theme.colours.scrollTrackBackground}`}; // bar, track
        scrollbar-width: thin;
    }

    @font-face {
        font-family: 'Neo Sans';
        src: url('/fonts/neo_sans_medium.woff');
        font-weight: 500;
    }
`;

const { publicRuntimeConfig } = getConfig();

builder.init(publicRuntimeConfig.BUILDER_API_KEY);

const MyApp = ({ Component, pageProps, store, ...props }: ReduxWrapperAppProps) => {
    const isServer = typeof window === 'undefined';
    const isiFrame = !isServer && window.self !== window.top;
    const apolloClient = useApollo(pageProps?.initialApolloState || {});
    useUtmHandler(store);
    useApplicationInsights({
        instrumentationKey: publicRuntimeConfig.APPINSIGHTS_INSTRUMENTATIONKEY,
    });

    return (
        <Provider store={store}>
            {/* eslint-disable-next-line @typescript-eslint/no-explicit-any*/}
            <PersistGate loading={null} persistor={(store as any).__persistor}>
                <ApolloProvider client={apolloClient}>
                    {!isiFrame && <AuthenticationHandler operator="footballpools" />}
                    <ApiProvider
                        adaptor={useSubscriptionApiAdaptor()}
                        config={{ clientType: isServer ? 'api' : 'backend' }}
                    >
                        <ThemeProvider theme={theme}>
                            <HeadComponent />
                            <GlobalStyles />
                            <Normalize />
                            <UserProvider>
                                <Shared />
                                <Component {...pageProps} {...((props as unknown) as { headerProps: HeaderProps })} />
                            </UserProvider>
                            <SubscriptionLimitHandler />
                            <SessionLimitHandler operator="footballPools" />
                        </ThemeProvider>
                    </ApiProvider>
                </ApolloProvider>
            </PersistGate>
        </Provider>
    );
};

MyApp.getInitialProps = async () => {
    const tasks = await Promise.all([
        keysEnabled([
            'header-minigame',
            'leaderboards-page',
            'the-pools-nav',
            'header-goal-rush-otp',
            'tips-page',
            'blog-page',
            'premier-6',
        ]),
        getDynamicString('minigame-header'),
    ]);
    const toggles = tasks[0];
    const minigameHeader = tasks[1];
    const headerProps = {
        showMinigame: toggles && toggles['header-minigame'],
        showLeaderboards: toggles && toggles['header-minigame'],
        showThePools: toggles && toggles['header-minigame'],
        showGoalRushOtp: toggles && toggles['header-minigame'],
        minigameHeaderText: minigameHeader,
        showTipsPage: toggles && toggles['tips-page'],
        showBlogPage: toggles && toggles['blog-page'],
        showPremierSix: toggles && toggles['premier-6'],
    };

    return { headerProps };
};

export default withRedux(makeStore)(MyApp);
