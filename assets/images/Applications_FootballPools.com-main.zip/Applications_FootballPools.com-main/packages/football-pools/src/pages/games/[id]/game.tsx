import game, { GameProps } from '@containers/game/game.shared';
import { GetStaticPaths, GetStaticProps } from 'next';
import { filterOffersFromGamePageData } from '@fp/shared/src/core/gamePage';
import { getGamePage, getGamePages } from '@fp/shared/src/core/gamePage.builder';
import { useSubscriptionApiAdaptor } from '@fp/shared/src/api/subscriptionApi/useSubscriptionApiAdaptor';
import { getThemeForGameType, getGameTitle } from '@fp/shared/src/lib/utils';
// eslint-disable-next-line import/named
import { Competition, Offerings, useApi } from '@sportech/pools-api';

const defaultOfferings: Offerings = {
    offerings: [],
    defaultOffering: { id: 0, pricePerEntry: 0, description: '', maximumSelections: 0 },
};

export const getStaticProps: GetStaticProps = async context => {
    const path = context.params && context.params['id'] ? context.params['id'] : 'classic-pools';
    const pageProps = await getGamePageProps(path as string);

    return {
        props: pageProps,
        revalidate: 90,
    };
};

export const defaultGames = [
    'classic-pools',
    'goal-rush',
    'lucky-clover',
    'lucky-clover-£700-offer',
    'lucky-clover-700-offer',
    'classic-pools-half-price-fixtures',
    'classic-pools-half-price-numbers',
    'acquisition-journey-numbers',
    'field-based-acquisition-journey-numbers',
    'classic-pools-fb',
    'acquisition-journey-clover-2',
    'classic-pools-play',
    'goal-rush-play',
    'lucky-clover-minigame',
    'premier-12',
    'premier-10',
    'premier-6',
    'classic-pools-max',
    'classic-pools-tw',
];

export const getStaticPaths: GetStaticPaths = async () => {
    const gamePages = await getGamePages('footballPools');
    const gameNames = gamePages && gamePages.length > 0 ? gamePages.map(gamePage => gamePage.url) : defaultGames;

    return {
        paths: gameNames.map(gameName => ({ params: { id: gameName } })),
        fallback: false,
    };
};

const getGamePageProps = async (path: string): Promise<GameProps> => {
    const gamePageData = await getGamePage(path as string);

    // Check game pages enabled in cms:
    const game = gamePageData?.gameType || 'classic-pools';

    const { getOpenCompetitionsAsync, getOfferingsAsync, initialise } = useApi();
    initialise(useSubscriptionApiAdaptor());

    let competitions: Competition[] = [];
    let offers: Offerings | undefined = undefined;
    let viewLinesOffers: Offerings | undefined = undefined;

    try {
        const res = await Promise.all([getOpenCompetitionsAsync(game), getOfferingsAsync(game)]);
        competitions = res[0] && res[0].data ? res[0].data : competitions;
        offers = res[1].data;
        if (offers) {
            viewLinesOffers = {
                defaultOffering: offers?.defaultOffering,
                offerings: [...offers?.offerings],
                gameType: offers.gameType,
                productId: offers.productId,
                selectionType: offers.selectionType,
                selectionsOffered: offers.selectionsOffered,
            };
        }
        if (
            offers &&
            gamePageData &&
            gamePageData.offerings &&
            gamePageData.offerings.length > 0 &&
            gamePageData.offerings.some(o => o.enabled)
        ) {
            offers = filterOffersFromGamePageData(offers, gamePageData.offerings);
        }
    } catch (e) {
        console.error('exception getting game data', e);
    }

    const theme = getThemeForGameType(game);

    return {
        competitions: competitions ?? [],
        offers: offers ?? defaultOfferings,
        game,
        gameDescription: gamePageData?.gameDescription || '',
        gameKeywords: gamePageData?.gameKeywords || '',
        gameViewType: gamePageData?.gameViewType || 'match',
        theme,
        showFutureGames: gamePageData?.showFutureGames || false,
        onlyDefaultOffer: game !== 'lucky-clover',
        canAddMultipleLines: gamePageData?.canAddMultipleLines || false,
        banner: gamePageData?.banner || { headerText: getGameTitle(game) },
        howToPlay: gamePageData?.howToPlay || { heading: 'How to Play', content: '' },
        termsAndConditions: gamePageData?.termsAndConditions || { heading: 'Terms and Conditions', content: '' },
        howToManageLines: gamePageData?.howToManageLines || { heading: 'How to Manage Your Lines', content: '' },
        termsContent: gamePageData?.terms || '',
        viewLinesOffers: viewLinesOffers ?? defaultOfferings,
        gameEnabled: process.env.OVERRIDE_GAME_TOGGLE === 'true' || gamePageData?.isEnabled || false,
        gamePath: path,
        showMobilePrice: gamePageData?.showMobilePrice || false,
        competitionTypeDescription:
            gamePageData?.competitionTypeDescription || (game === 'lucky-clover' ? 'draw' : 'game'),
        template: gamePageData?.template ? gamePageData.template : path.includes('minigame') ? 'minigame' : 'default',
        background: gamePageData?.background || {},
        paymentTypes: gamePageData?.paymentTypes ? gamePageData.paymentTypes.map(p => p.type) : ['subscription'],
        maximumLines: gamePageData?.maximumLines || 0,
        costTypeDescription: gamePageData?.costTypeDescription || 'game',
        minimumCost: gamePageData?.minimumCost || 0,
        faq: gamePageData?.faq || '',
        featuredCompetitionId: gamePageData?.featuredCompetitionId || 0,
        prizeBreakdown: gamePageData?.prizeBreakdown || '',
        isFieldAcquisition: gamePageData?.isFieldAcquisition || false,
    };
};

export default game;
