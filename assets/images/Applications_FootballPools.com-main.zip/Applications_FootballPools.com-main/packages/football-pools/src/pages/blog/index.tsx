import { builder, BuilderComponent, BuilderContent, Image } from '@builder.io/react';
import { GetStaticProps, GetStaticPropsContext } from 'next';
import getConfig from 'next/config';
import styled from 'styled-components';
import withFullWidthLayout from '@fp/shared/src/components/Layouts/FullWidthLayout/FullWidthLayout';
import BlogTile from '@fp/shared/src/components/Blog/BlogTile';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import { useEffect, useState } from 'react';

const { publicRuntimeConfig } = getConfig();

const BUILDER_API_KEY = process.env.BUILDER_API_KEY || publicRuntimeConfig.BUILDER_API_KEY;

builder.init(BUILDER_API_KEY);

const BlogHeader = styled.div`
    width: 100vw;
    background-color: rgb(0, 31, 144);
    margin-bottom: 20px;
`;
const BlogHeaderText = styled.p`
    color: #fff;
    padding: 10px 20px;
    font-size: 40px;
    font-weight: bolder;
    margin: 0 auto;
    max-width: 1200px;
`;

const FirstArticleContainer = styled.div`
    display: grid;
    grid-template-columns: 1fr;
    margin: 0 auto;
    width: 100vw;
    max-width: 1200px;
    margin-bottom: 20px;
`;

const BlogGrid = styled.div`
    display: grid;
    column-gap: 8px;
    grid-template-columns: 1fr 1fr 1fr;
    position: relative;
    row-gap: 12px;
    margin: 0 auto 20px auto;
    max-width: 1200px;

    ${breakpoints.below('md')} {
        grid-template-columns: 1fr;
        width: 100%;
    }
`;

const MoreBlogsButton = styled.button`
    color: #fff;
    background-color: #0f1e7c;
    margin: 0 auto 20px auto;
    border-radius: 33px;
    font-size: 25px;
    font-weight: 700;
    font-style: italic;
    max-width: 300px;
    min-height: 65px;
    border: 2px solid #fff;
    padding: 15px 25px;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    transition: all 0.5s ease;

    :hover {
        color: #0f1e7c;
        background-color: #fff;
        border: 2px solid #0f1e7c;
    }
`;

type Props = { articles: BuilderContent[] };

function Blog({ articles }: Props) {
    const firstArticle = articles[0];
    const [articlesToDisplayCount, setArticlesToDisplayCount] = useState(6);
    const articlesToDisplay = articles.slice(1, articlesToDisplayCount + 1);
    const [displayMoreBlogsButton, setDisplayMoreBlogsButton] = useState(false);

    useEffect(() => {
        articlesToDisplayCount < articles.length - 1
            ? setDisplayMoreBlogsButton(true)
            : setDisplayMoreBlogsButton(false);
    }, [articlesToDisplayCount]);

    return (
        <>
            <BuilderComponent model="community-tabs" />
            <BlogHeader>
                <BlogHeaderText>Blog</BlogHeaderText>
            </BlogHeader>
            <FirstArticleContainer>
                <BlogTile
                    isFirstTile={true}
                    linkUrl={`/blog/${firstArticle.data.slug}`}
                    mainImage={firstArticle.data.mainImage}
                    title={firstArticle.data.title}
                    excerpt={firstArticle.data.excerpt}
                    readTime={firstArticle.data.readTime}
                    date={firstArticle.data.date}
                />
            </FirstArticleContainer>
            <BlogGrid>
                {articlesToDisplay &&
                    articlesToDisplay.map((item: any) => (
                        <BlogTile
                            key={item.data.slug}
                            isFirstTile={false}
                            linkUrl={`/blog/${item.data.slug}`}
                            mainImage={item.data.mainImage}
                            title={item.data.title}
                            excerpt={item.data.excerpt}
                            readTime={item.data.readTime}
                            date={item.data.date}
                        />
                    ))}
            </BlogGrid>
            {displayMoreBlogsButton && (
                <MoreBlogsButton
                    onClick={() => {
                        setArticlesToDisplayCount(articlesToDisplayCount + 6);
                    }}
                >
                    More Blogs
                </MoreBlogsButton>
            )}
        </>
    );
}

export const getStaticProps: GetStaticProps = async context => {
    const props = await getContent();
    return { props, revalidate: 90 };
};

const getContent = async () => {
    // Don't target on url and device for better cache efficiency
    const targeting = { urlPath: '/blog', device: '_' } as any;

    const articles = await builder.getAll('blogs', {
        apiKey: BUILDER_API_KEY,
        fields: 'data.mainImage,data.slug,data.title,data.excerpt,data.date,data.readTime',
        userAttributes: targeting,
        options: {
            noTargeting: true,
        },
        query: {
            'data.hideFromList': { $ne: true },
            'data.footballPools': { $eq: true },
        },
    });
    return {
        articles: articles,
    };
};

export default withFullWidthLayout(Blog);
