import getConfig from 'next/config';
import { GetServerSideProps } from 'next';
import { BuilderContent, getSitePaths } from '@fp/shared/src/core/getUrlQuery';

const SiteMap = () => {
    return;
};

const { publicRuntimeConfig } = getConfig();

const baseUrl = process.env.SITE_URL || publicRuntimeConfig.SITE_URL;

export const getServerSideProps: GetServerSideProps = async ({ res }) => {
    const paths = await getSitePaths();
    const path = paths?.page?.map((t: BuilderContent) => t?.data?.url);

    const urlArray = [...Array.from(new Set<string>(path as string[]))];

    const staticPages = ['announcements', 'blog', 'leaderboards', 'registration', 'tips'].map(staticPagePath => {
        return `${baseUrl}/${staticPagePath}`;
    });

    const genericGamePaths = ['classic-pools', 'lucky-clover', 'goal-rush', 'premier-6', 'premier-10', 'premier-12'];

    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
    <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" >
    ${staticPages
        .map(url => {
            return `
        <url>
         <loc>${url}</loc>
            <lastmod>${new Date().toISOString()}</lastmod>
            <changefreq>monthly</changefreq>
            <priority>0.9</priority>
        </url>`;
        })
        .join('')}
    ${urlArray
        .map(url => {
            return `
        <url>
         <loc>${baseUrl}${url}</loc>
            <lastmod>${new Date().toISOString()}</lastmod>
            <changefreq>monthly</changefreq>
            <priority>${url === '/home' ? '1.0' : '0.9'}</priority>
        </url>`;
        })
        .join('')}
    ${paths?.announcements
        ?.map(url => {
            return `
        <url>
         <loc>${baseUrl}/announcements/${url.data?.slug}</loc>
            <lastmod>${new Date().toISOString()}</lastmod>
            <changefreq>monthly</changefreq>
            <priority>1.0</priority>
        </url>`;
        })
        .join('')}
    ${paths?.tips
        ?.map((url: BuilderContent) => {
            return `
        <url>
         <loc>${baseUrl}/tips/${url.data?.slug}</loc>
            <lastmod>${new Date().toISOString()}</lastmod>
            <changefreq>monthly</changefreq>
            <priority>1.0</priority>
        </url>`;
        })
        .join('')}
    ${paths?.blogs
        ?.map((url: BuilderContent) => {
            return `
        <url>
         <loc>${baseUrl}/blog/${url.data?.slug}</loc>
            <lastmod>${new Date().toISOString()}</lastmod>
            <changefreq>monthly</changefreq>
            <priority>1.0</priority>
        </url>`;
        })
        .join('')}
    ${paths?.gamePageData
        //Games
        ?.map((url: BuilderContent) => {
            return `
        <url>
         <loc>${baseUrl}/games/${url.data?.url}/game</loc>
            <lastmod>${new Date().toISOString()}</lastmod>
            <changefreq>monthly</changefreq>
            <priority>0.8</priority>
        </url>`;
        })
        .join('')}
    ${genericGamePaths
        //Results
        .map(url => {
            return `
        <url>
         <loc>${baseUrl}/results/${url}</loc>
            <lastmod>${new Date().toISOString()}</lastmod>
            <changefreq>monthly</changefreq>
            <priority>0.8</priority>
        </url>`;
        })
        .join('')}
    ${genericGamePaths
        //Leaderbaords
        ?.map(url => {
            return url === 'lucky-clover'
                ? null
                : `
        <url>
         <loc>${baseUrl}/leaderboards/${url}</loc>
            <lastmod>${new Date().toISOString()}</lastmod>
            <changefreq>monthly</changefreq>
            <priority>0.8</priority>
        </url>`;
        })
        .join('')}
    </urlset>
    `;

    res.setHeader('Content-Type', 'text/xml');
    res.write(sitemap);
    res.end();

    return {
        props: {},
    };
};

export default SiteMap;
