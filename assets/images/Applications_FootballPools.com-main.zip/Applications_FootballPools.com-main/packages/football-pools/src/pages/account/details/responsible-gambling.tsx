import { NextPage, GetServerSideProps } from 'next';
import { HeadComponent } from '@fp/shared/src/settings/HeadComponent';

import { Container } from '@fp/shared/src/containers/account/responsibleGambling';
import { AccountDetailsLayout } from '@fp/shared/src/components/Layouts/AccountDetailsLayout/AccountDetailsLayout';
import withLayout from '@fp/shared/src/components/Layouts/Layout/Layout';
import { requiredAuthPage } from '@fp/shared/src/lib/requiredAuthPage';

const Page: NextPage = () => (
    <>
        <HeadComponent title={'Account | Personal Details'} />
        <AccountDetailsLayout operator="footballpools">
            <Container />
        </AccountDetailsLayout>
    </>
);

export default withLayout(Page);

export const getServerSideProps: GetServerSideProps = async ({ req, res }) => {
    requiredAuthPage(req, res, 'footballPools');

    return { props: {} };
};
