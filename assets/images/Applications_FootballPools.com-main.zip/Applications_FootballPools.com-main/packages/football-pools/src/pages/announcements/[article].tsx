import { builder, BuilderComponent, BuilderContent, Image } from '@builder.io/react';
import { GetStaticPaths, GetStaticProps, GetStaticPropsContext } from 'next';
import getConfig from 'next/config';
import styled from 'styled-components';
import withFullWidthLayout from '@fp/shared/src/components/Layouts/FullWidthLayout/FullWidthLayout';
import BlogTile from '@fp/shared/src/components/Blog/BlogTile';
import router from 'next/router';
import { Loader } from '@fp/shared/src/components/Loader/Loader';
import { PageRedirect } from '@fp/shared/src/components/PageNotFound/PageNotFound';

const { publicRuntimeConfig } = getConfig();

const BUILDER_API_KEY = process.env.BUILDER_API_KEY || publicRuntimeConfig.BUILDER_API_KEY;

builder.init(BUILDER_API_KEY);

const RecentPostContainer = styled.div`
    max-width: 1200px;
    background: #fff;
    display: flex;
    flex-direction: row;
    align-items: center;
    width: 100vw;
    margin: 0 auto;
    margin-bottom: 50px;
`;

const RecentPostScrollContainer = styled.div`
    display: flex;
    overflow-x: scroll;
    width: 100%;
`;

const TileContainer = styled.div`
    max-width: 390px;
    min-width: 320px;
    margin-right: 10px;
`;

function AnnouncementArticle({ article, articles }: any) {
    return (
        <>
            {router.isFallback ? (
                <Loader isLoading={true} />
            ) : article ? (
                <>
                    <BuilderComponent name="blogs" content={article} />
                    <RecentPostContainer>
                        <RecentPostScrollContainer>
                            {articles &&
                                articles.map((item: any) => (
                                    <TileContainer key={item.data.slug}>
                                        {
                                            <BlogTile
                                                linkUrl={item.data.slug}
                                                mainImage={item.data.mainImage}
                                                title={item.data.title}
                                                excerpt={item.data.excerpt}
                                                date={item.data.date}
                                                isFirstTile={false}
                                                readTime={item.data.readTime}
                                            />
                                        }
                                    </TileContainer>
                                ))}
                        </RecentPostScrollContainer>
                    </RecentPostContainer>
                </>
            ) : (
                <PageRedirect />
            )}
        </>
    );
}

export const getStaticPaths: GetStaticPaths = async () => {
    const results = await builder.getAll('announcements', {
        options: { noTargeting: true },
        apiKey: BUILDER_API_KEY,
        query: {
            'data.footballPools': { $eq: true },
        },
    });
    return {
        paths: results.map(item => ({ params: { article: item.data!.slug || '' } })),
        fallback: true,
    };
};

export const getStaticProps: GetStaticProps = async context => {
    const props = await getContent(context);
    return { props, revalidate: 90 };
};

const getContent = async (context: GetStaticPropsContext) => {
    const [article, articles] = await Promise.all([
        builder
            .get('announcements', {
                key: context.params!.article as string,
                query: {
                    'data.slug': context.params!.article,
                    'data.footballPools': { $eq: true },
                },
                ...{
                    options: {
                        includeRefs: true,
                    } as any,
                },
            })
            .promise(),
        builder.getAll('announcements', {
            key: `announcements:all:_:4`,
            fields: 'data.mainImage,data.slug,data.title,data.excerpt,data.date,data.readTime',
            limit: 4,
            options: {
                noTargeting: true,
            },
            query: {
                'data.hideFromList': { $ne: true },
                'data.footballPools': { $eq: true },
            },
        }),
    ]);
    return {
        article: article || null,
        articles: articles.filter((item: any) => item.data && item.data?.slug !== article?.data.slug).slice(0, 3),
    };
};

export default withFullWidthLayout(AnnouncementArticle);
