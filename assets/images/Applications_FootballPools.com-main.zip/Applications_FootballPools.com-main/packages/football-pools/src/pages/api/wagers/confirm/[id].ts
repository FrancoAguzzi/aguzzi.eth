import { withApiMiddleware, confirmWagersApiRoute } from '@sportech/pools-api';
import { useSubscriptionApiAdaptor } from '@fp/shared/src/api/subscriptionApi/useSubscriptionApiAdaptor';

export default withApiMiddleware(confirmWagersApiRoute, useSubscriptionApiAdaptor());
