import { builder, Builder, BuilderComponent } from '@builder.io/react';
import { GetStaticPropsContext, InferGetStaticPropsType } from 'next';
import getConfig from 'next/config';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { useEffect } from 'react';
import withLayout from '@fp/shared/src/components/Layouts/Layout/Layout';
import { PageRedirect } from '@fp/shared/src/components/PageNotFound/PageNotFound';
import { HeadComponent } from '@fp/shared/src/settings/HeadComponent';
import '@builder.io/widgets/dist/lib/builder-widgets-async';
import getPoolSizesProps from '@fp/shared/src/features/poolSizes/poolSizesApiCall';
import { GetPoolSizes } from '@fp/shared/src/features/poolSizes/poolSizesTypes';

import '@fp/shared/src/components/TileList/TileList';
import '@fp/shared/src/components/Lottery/QuickPlay';
import '@fp/shared/src/components/FlipCard/FlipCard';

const { publicRuntimeConfig } = getConfig();

const BUILDER_API_KEY = process.env.BUILDER_API_KEY || publicRuntimeConfig.BUILDER_API_KEY;

builder.init(BUILDER_API_KEY);

export async function getStaticProps({ params }: GetStaticPropsContext) {
    const poolSizes: GetPoolSizes = await getPoolSizesProps();
    const urlPath = '/' + (params?.path instanceof Array ? params.path.join('/') : params?.path || '');
    const page = await builder
        .get('page', {
            key: `page:${urlPath}`,
            userAttributes: {
                urlPath,
            },
            query: {
                'data.website.footballpools': true,
            },
        })
        .toPromise();

    if (page?.data?.url && page.data.url !== urlPath) {
        console.error(`Requested ${urlPath}, received ${page?.data?.url}`, page, params);
    }

    return {
        props: {
            page: page || null,
            poolSizes: poolSizes,
        },
        revalidate: 60,
    };
}

export async function getStaticPaths() {
    const pages = await builder.getAll('page', {
        key: 'content-pages:all',
        fields: 'data.url',
        options: { noTargeting: true },
        query: {
            'data.website.footballpools': true,
        },
    });

    return {
        paths: pages.map(page => `${page.data?.url}`),
        fallback: true,
    };
}

const Path = ({ page, poolSizes }: InferGetStaticPropsType<typeof getStaticProps>) => {
    const router = useRouter();
    const { title, description, ...data } = page?.data || {};

    useEffect(() => {
        if (router.asPath === '/' && typeof window !== 'undefined') {
            router.push('/', '/home');
        }
    }, [router, router.asPath]);

    return (
        <>
            {!page && (
                <Head>
                    <meta key="robots" name="robots" content="noindex" />
                </Head>
            )}
            <HeadComponent description={description} title={title} keywords={page?.data?.keywords} />
            {page || Builder.isEditing || Builder.isPreviewing ? (
                <BuilderComponent model="page" content={{ ...page, data }} context={{ poolSizes: poolSizes }} />
            ) : (
                <PageRedirect />
            )}
        </>
    );
};

export default withLayout(Path);
