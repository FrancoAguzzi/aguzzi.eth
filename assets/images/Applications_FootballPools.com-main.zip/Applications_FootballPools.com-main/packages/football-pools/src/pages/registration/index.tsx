import Head from 'next/head';
import { RegistrationForm } from '@containers/registration/registrationForm';
import styled from 'styled-components';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import withFullWidthLayout from '@fp/shared/src/components/Layouts/FullWidthLayout/FullWidthLayout';

const Container = styled.div`
    background: #000d68;
    height: 100%;
    display: flex;
    justify-content: center;
    > form {
        margin: 0 50px;
        padding-top: 90px;
        max-width: 320px;
        min-height: 750px;

        ${breakpoints.below('md')} {
            min-height: auto;
        }
    }

    ${breakpoints.below('md')} {
        padding: 0;

        > form {
            padding-top: 0;
            margin: 0 20px;
            max-width: 100%;
        }
    }
`;

const Page = () => (
    <>
        <Head>
            <title>The Football Pools | Registration</title>
        </Head>
        <Container>
            <RegistrationForm />
        </Container>
    </>
);

const ImageBackground = styled.div`
    height: 100%;
    background: #000d68;
`;

const Image = styled.img`
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: right;
    max-height: 80vh;
`;

export default withFullWidthLayout(Page);
