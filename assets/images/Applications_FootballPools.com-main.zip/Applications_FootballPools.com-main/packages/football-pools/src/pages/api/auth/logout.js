import { NextApiRequest, NextApiResponse } from 'next';

export default async (req, res) => {
    const redirect = req.query['postLogoutUrl'] || process.env.SITE_URL;
    try {
        res.writeHead(302, {
            Location:
                process.env.SSO_URL +
                '/connect/endsession?post_logout_redirect_uri=' +
                encodeURI(redirect) +
                '&clientId=' +
                process.env.SSO_CLIENT,
        });
        res.end();
    } catch (e) {
        res.writeHead(302, {
            Location: redirect,
        });
        res.end();
    }
};
