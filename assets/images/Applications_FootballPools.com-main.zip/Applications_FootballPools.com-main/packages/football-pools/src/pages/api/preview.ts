import { NextApiRequest, NextApiResponse } from 'next';

export default async (req: NextApiRequest, res: NextApiResponse) => {
    const slug = req.query.slug as string | undefined;

    if (req.query.secret !== process.env.PREVIEW_SECRET || !slug) {
        return res.status(401).json({ message: 'Invalid token' });
    }

    res.setPreviewData({}, { maxAge: 60 * 60 });

    res.setHeader('location', slug);
    res.statusCode = 302;
    res.end();
};
