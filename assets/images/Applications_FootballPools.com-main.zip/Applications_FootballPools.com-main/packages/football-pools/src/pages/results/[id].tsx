import { GetStaticPaths, GetStaticProps } from 'next';
// eslint-disable-next-line import/named
import { CompetitionResult, useApi } from '@sportech/pools-api';
import { useSubscriptionApiAdaptor } from '@fp/shared/src/api/subscriptionApi/useSubscriptionApiAdaptor';
import results, { ResultsProps } from '@containers/results/results';
import { getGameTitle, getGameFromPath } from '@fp/shared/src/lib/utils';

export const getStaticProps: GetStaticProps = async context => {
    const path = context.params && context.params['id'] ? context.params['id'] : 'classic-pools';
    const pageProps = await getResultsPageProps(path as string);

    return {
        props: pageProps,
        revalidate: 30,
    };
};

export const getStaticPaths: GetStaticPaths = async () => {
    return {
        paths: [
            { params: { id: 'classic-pools' } },
            { params: { id: 'goal-rush' } },
            { params: { id: 'lucky-clover' } },
            { params: { id: 'premier-6' } },
            { params: { id: 'premier-10' } },
            { params: { id: 'premier-12' } },
        ],
        fallback: false,
    };
};

const getResultsPageProps = async (path: string): Promise<ResultsProps> => {
    const activeGame = getGameFromPath(path);
    const gameTitle = getGameTitle(activeGame);
    const isClover = activeGame === 'lucky-clover';
    const isHda = activeGame.includes('premier') || activeGame === 'jackpot-12';

    const {
        getCompetitionResultsAsync,
        getDividendsAsync,
        getOpenCompetitionsAsync,
        getFilteredOfferingsAsync,
        initialise,
    } = useApi();
    initialise(useSubscriptionApiAdaptor());

    const response = await Promise.all([
        getCompetitionResultsAsync(activeGame),
        getDividendsAsync(activeGame),
        getOpenCompetitionsAsync(activeGame),
        getFilteredOfferingsAsync(activeGame),
    ]);
    const compResults = response[0].data?.reverse();
    const competitionDividends = response[1].data;
    const competitions = response[2].data;
    const offerings = response[3].data;

    const nextGameDate = competitions && competitions?.length > 0 ? competitions[0].datumDateWithBuffer : '';

    const dateNow = new Date();
    const luckyCloverCompNumbers: number[] = [];
    const competitionResults: CompetitionResult[] | undefined = compResults
        ? compResults.filter(c => {
              if (isClover) {
                  if (!luckyCloverCompNumbers.includes(c.number)) {
                      luckyCloverCompNumbers.push(c.number);
                      const date = new Date(c.datumDate);
                      if (date <= dateNow) {
                          return c;
                      }
                  }
              } else {
                  const date = new Date(c.datumDate);
                  if (date <= dateNow) {
                      return c;
                  }
              }
          })
        : undefined;

    return {
        competitionResults: competitionResults ? competitionResults : [],
        competitionDividends: competitionDividends ? competitionDividends : [],
        offerings: offerings ? offerings : [],
        activeGame,
        gameTitle,
        isClover,
        isHda,
        nextGameDate,
    };
};

export default results;
