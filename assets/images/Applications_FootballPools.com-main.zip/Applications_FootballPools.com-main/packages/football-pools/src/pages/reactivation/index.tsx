import { ReactivationForm } from '@fp/shared/src/containers/account/ReactivationForm';
import withLayout from '@fp/shared/src/components/Layouts/Layout/Layout';
import styled from 'styled-components';
import getConfig from 'next/config';
import { PageRedirect } from '@fp/shared/src/components/PageNotFound/PageNotFound';
import { HeadComponent } from '@fp/shared/src/settings/HeadComponent';

const { publicRuntimeConfig } = getConfig();

const ReactivationPage = () => {
    const reactivation = publicRuntimeConfig.TOGGLE_REACTIVATION === 'true';
    return reactivation ? (
        <>
            <HeadComponent
                title="Reactivation"
                description="Reactivate your Football Pools Account"
                keywords="Reactivate, Football, Pools"
            />
            <div>
                <TextBox>
                    <PageTitle>Welcome to The Football Pools!</PageTitle>
                    There are just a few simple steps required to complete your registration and get you in the game.
                    <StyledSpan>Please complete the following details:</StyledSpan>
                </TextBox>
                <ReactivationForm />
            </div>
        </>
    ) : (
        <>
            <PageRedirect />
        </>
    );
};

const PageTitle = styled.h1`
    font-size: 20px;
    font-weight: 900;
`;

const TextBox = styled.div`
    display: flex;
    flex-direction: column;
    width: 90%;
    margin: 10px 0 0 10px;
`;

const StyledSpan = styled.span`
    font-weight: 900;
    margin: 20px 0;
`;

export default withLayout(ReactivationPage);
