import { NextPage, GetServerSideProps } from 'next';
import styled from 'styled-components';
import { requiredAuthPage } from '@fp/shared/src/lib/requiredAuthPage';
import withLayout from '@fp/shared/src/components/Layouts/Layout/Layout';
import { HeadComponent } from '@fp/shared/src/settings/HeadComponent';
import { AccountLayout } from '@fp/shared/src/components/Layouts/AccountLayout/AccountLayout';
import { AccountHistory } from '@fp/shared/src/containers/account/history/history';
import getConfig from 'next/config';

const { publicRuntimeConfig } = getConfig();

const url = `${publicRuntimeConfig.LEGACY_FP_URL}/account/history?iframe=true`;

const IframeAccountHistory = styled.iframe`
    border: none;
    height: 500px;
    width: 100%;
`;

const Page: NextPage = () => {
    const isIframe = publicRuntimeConfig.ACCOUNT_HISTORY_IFRAME;
    return (
        <>
            <HeadComponent title={'Account | History'} />
            <AccountLayout operator="footballpools">
                {isIframe && isIframe === 'true' ? (
                    <IframeAccountHistory src={url}></IframeAccountHistory>
                ) : (
                    <AccountHistory />
                )}
            </AccountLayout>
        </>
    );
};

export default withLayout(Page);

export const getServerSideProps: GetServerSideProps = async ({ req, res }) => {
    requiredAuthPage(req, res, 'footballPools');

    return { props: {} };
};
