import { withApiMiddleware, getDividendsApiRoute } from '@sportech/pools-api';
import { useSubscriptionApiAdaptor } from '@fp/shared/src/api/subscriptionApi/useSubscriptionApiAdaptor';

export default withApiMiddleware(getDividendsApiRoute, useSubscriptionApiAdaptor());
