import { getCookieFromDocument } from '@services/cookies';

const CallBackPage = () => {
    const cookie = getCookieFromDocument('_clubFpToken');
    parent.postMessage({ event: 'LoginDone', cookie }, '*');
    return <></>;
};

export default CallBackPage;
