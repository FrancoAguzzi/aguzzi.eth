import { builder, BuilderComponent, BuilderContent, Image } from '@builder.io/react';
import { GetStaticProps, GetStaticPropsContext } from 'next';
import getConfig from 'next/config';
import styled from 'styled-components';
import withFullWidthLayout from '@fp/shared/src/components/Layouts/FullWidthLayout/FullWidthLayout';
import BlogTile from '@fp/shared/src/components/Blog/BlogTile';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import { useEffect, useState } from 'react';

const { publicRuntimeConfig } = getConfig();

const BUILDER_API_KEY = process.env.BUILDER_API_KEY || publicRuntimeConfig.BUILDER_API_KEY;

builder.init(BUILDER_API_KEY);

const AnnouncementsHeader = styled.div`
    width: 100vw;
    background-color: rgb(170, 0, 0);
    margin-bottom: 20px;
`;
const AnnouncementsHeaderText = styled.p`
    color: #fff;
    padding: 10px 20px;
    font-size: 40px;
    font-weight: bolder;
    margin: 0 auto;
    max-width: 1200px;
`;

const FirstArticleContainer = styled.div`
    display: grid;
    grid-template-columns: 1fr;
    margin: 0 auto;
    width: 100vw;
    max-width: 1200px;
    margin-bottom: 20px;
`;

const AnnouncementsGrid = styled.div`
    display: grid;
    column-gap: 8px;
    grid-template-columns: 1fr 1fr 1fr;
    position: relative;
    row-gap: 12px;
    margin: 0 auto 20px auto;
    max-width: 1200px;

    ${breakpoints.below('md')} {
        grid-template-columns: 1fr;
        width: 100%;
    }
`;

const MoreAnnouncementsButton = styled.button`
    color: #fff;
    background-color: rgb(170, 0, 0);
    margin: 0 auto 20px auto;
    border-radius: 33px;
    font-size: 18px;
    font-weight: 700;
    font-style: italic;
    max-width: 300px;
    min-height: 65px;
    border: 2px solid #fff;
    padding: 15px 25px;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    transition: all 0.5s ease;

    :hover {
        color: rgb(170, 0, 0);
        background-color: #fff;
        border: 2px solid rgb(170, 0, 0);
    }
`;

type Props = { articles: BuilderContent[] };

function Announcements({ articles }: Props) {
    const [articlesToDisplayCount, setArticlesToDisplayCount] = useState(6);
    const articlesToDisplay = articles.slice(0, articlesToDisplayCount);
    const [displayMoreBlogsButton, setDisplayMoreBlogsButton] = useState(false);

    useEffect(() => {
        articlesToDisplayCount < articles.length - 1
            ? setDisplayMoreBlogsButton(true)
            : setDisplayMoreBlogsButton(false);
    }, [articlesToDisplayCount]);

    return (
        <>
            <AnnouncementsHeader>
                <AnnouncementsHeaderText>Announcements</AnnouncementsHeaderText>
            </AnnouncementsHeader>
            <AnnouncementsGrid>
                {articlesToDisplay &&
                    articlesToDisplay.map((item: any) => (
                        <BlogTile
                            key={item.data.slug}
                            isFirstTile={false}
                            linkUrl={`/announcements/${item.data.slug}`}
                            mainImage={item.data.mainImage}
                            title={item.data.title}
                            excerpt={item.data.excerpt}
                            date={item.data.date}
                            readTime={item.data.readTime}
                        />
                    ))}
            </AnnouncementsGrid>
            {displayMoreBlogsButton && (
                <MoreAnnouncementsButton
                    onClick={() => {
                        setArticlesToDisplayCount(articlesToDisplayCount + 6);
                    }}
                >
                    More Announcements
                </MoreAnnouncementsButton>
            )}
        </>
    );
}

export const getStaticProps: GetStaticProps = async context => {
    const props = await getContent();
    return { props, revalidate: 90 };
};

const getContent = async () => {
    const articles = await builder.getAll('announcements', {
        apiKey: BUILDER_API_KEY,
        fields: 'data.mainImage,data.slug,data.title,data.excerpt,data.date,data.readTime',
        options: {
            noTargeting: true,
        },
        query: {
            'data.hideFromList': { $ne: true },
            'data.footballPools': { $eq: true },
        },
    });
    return {
        articles: articles,
    };
};

export default withFullWidthLayout(Announcements);
