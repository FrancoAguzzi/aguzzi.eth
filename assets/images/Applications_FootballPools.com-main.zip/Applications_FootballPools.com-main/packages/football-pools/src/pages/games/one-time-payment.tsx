import { NextPage, GetStaticProps, GetServerSideProps } from 'next';
import Head from 'next/head';
import styled from 'styled-components';
import { Payment } from '@containers/game/payment';
import { PaymentV2 } from '@containers/game/paymentv2';
import { Button } from '@fp/shared/src/components/Button/Button';
// eslint-disable-next-line import/named
import { getWagersSelector, PaymentMethod, resetWagers } from '@sportech/pools-api';
import { useSelector, useDispatch } from 'react-redux';
import { useRouter } from 'next/router';
import { AppDispatch } from '@fp/shared/src/store';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import { BuilderPaymentPageData, getPaymentPage } from '@fp/shared/src/core/paymentPage.builder';
import { isEnabled } from '@fp/shared/src/core/toggle.builder';
import { getGameTitle } from '@fp/shared/src/lib/utils';
import withSideBannerLayout, {
    SideBannerProps,
} from '@fp/shared/src/components/Layouts/SideBannerLayout/SideBannerLayout';
import { OneTimePayment, Background } from '@containers/game/oneTimePayment';
import { HeadComponent } from '@fp/shared/src/settings/HeadComponent';

const Container = styled.div`
    max-width: 70vw;
    min-height: 100vh;
    background: '#fff';
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 800px;
    ${breakpoints.below('overlay')} {
        max-width: 100%;
    }
    z-index: 0;
`;
const TopRowContainer = styled.div`
    display: flex;
    flex-direction: row-reverse;
    width: 100%;
    margin: 1.2rem 0;
`;

const CloseButton = styled(Button)`
    background-color: transparent;
    color: black;
    z-index: 1;
    &:hover {
        background: none;
    }
`;

const PaymentContainer = styled.div`
    margin: -3.5rem auto auto auto;
    max-width: 100%;
`;

export interface PaymentPageProps {
    paymentDetailsContent?: BuilderPaymentPageData;
    isNewDesign?: boolean;
    oneTimePayment?: boolean;
    defaultToPaymentMethod?: PaymentMethod;
}

const OneOffPaymentPage: NextPage<PaymentPageProps> = props => {
    const wagers = useSelector(getWagersSelector);
    const router = useRouter();
    const dispatch = useDispatch<AppDispatch>();
    const closePaymentWindow = (): void => {
        router.push(`/games/${wagers.gameVariant || wagers.game}/game`);
        dispatch(resetWagers({ game: wagers.game }));
    };
    return (
        <>
            <HeadComponent
                title={`Football Pools | Play ${getGameTitle(wagers.game)}`}
                description={props.paymentDetailsContent?.description}
                keywords={props.paymentDetailsContent?.keywords}
            />
            <Background />
            <Container>
                <OneTimePayment oneTimePayment={true} defaultToPaymentMethod="card" {...props} />
            </Container>
        </>
    );
};

const getPaymentPageProps = async (): Promise<PaymentPageProps & SideBannerProps> => {
    const paymentDetailsContent = await getPaymentPage('lucky-clover-minigame');
    const isNewDesign = await isEnabled('new-payment-design');
    return {
        paymentDetailsContent,
        isNewDesign,
        leftBannerImg: paymentDetailsContent?.background.leftBackgroundImg ?? '',
        rightBannerImg: paymentDetailsContent?.background.rightBackgroundImg ?? '',
        backgroundColour: paymentDetailsContent?.background.backgroundColour, // isNewDesign ? '#000d68' : '#fff',
    };
};

// export const getStaticProps: GetStaticProps = async () => {
//     const props = await getPaymentPageProps();
//     return {
//         props: props,
//         revalidate: 60,
//     };
// };

export const getServerSideProps: GetServerSideProps = async () => {
    const props = await getPaymentPageProps();
    return {
        props: props,
    };
};

export default withSideBannerLayout(OneOffPaymentPage);
