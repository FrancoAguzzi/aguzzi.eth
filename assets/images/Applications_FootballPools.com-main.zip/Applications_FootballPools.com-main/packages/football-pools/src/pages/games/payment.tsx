import { useEffect } from 'react';
import { NextPage, /* GetStaticProps, */ GetServerSideProps } from 'next';
import styled from 'styled-components';
import { Payment } from '@containers/game/payment';
import { PaymentV2 } from '@containers/game/paymentv2';
// eslint-disable-next-line import/named
import { Competition, getWagersSelector, PaymentMethod } from '@sportech/pools-api';
import { useSelector, useDispatch } from 'react-redux';
import { useRouter } from 'next/router';
import { AppDispatch } from '@fp/shared/src/store';
import { breakpoints } from '@fp/shared/src/settings/breakpoints';
import { BuilderPaymentPageData, getPaymentPage } from '@fp/shared/src/core/paymentPage.builder';
import { isEnabled } from '@fp/shared/src/core/toggle.builder';
import { getGameTitle } from '@fp/shared/src/lib/utils';
import withSideBannerLayout, {
    SideBannerProps,
} from '@fp/shared/src/components/Layouts/SideBannerLayout/SideBannerLayout';
import { OneTimePayment } from '@containers/game/oneTimePayment';
import { HeadComponent } from '@fp/shared/src/settings/HeadComponent';
import { getAuthenticationSelector } from '@fp/shared/src/features/authentication/authenticationSelectors';
import { clearRedirectUrl } from '@fp/shared/src/features/registration/registrationSlice';

const Container = styled.div`
    max-width: 70vw;
    min-height: 100vh;
    background: '#fff';
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 800px;
    ${breakpoints.below('overlay')} {
        max-width: 100%;
    }
`;
const TopRowContainer = styled.div`
    display: flex;
    flex-direction: row-reverse;
    width: 100%;
    margin: 1.2rem 0;
`;

const PaymentContainer = styled.div`
    margin: -3.5rem auto auto auto;
    max-width: 100%;
`;

export interface PaymentPageProps {
    paymentDetailsContent?: BuilderPaymentPageData;
    isNewDesign?: boolean;
    oneTimePayment?: boolean;
    defaultToPaymentMethod?: PaymentMethod;
    competitions?: Competition[];
    headerRef?: HTMLDivElement;
}

const PaymentPage: NextPage<PaymentPageProps> = props => {
    const wagers = useSelector(getWagersSelector);
    const oneTimePayment = wagers.numberOfGames && wagers.numberOfGames < 10;

    return (
        <>
            <HeadComponent title={`Play ${getGameTitle(wagers.game)}`} />
            <Container>
                {!props.isNewDesign && <TopRowContainer></TopRowContainer>}

                {oneTimePayment ? (
                    <OneTimePayment oneTimePayment={oneTimePayment} defaultToPaymentMethod="card" {...props} />
                ) : props.isNewDesign ? (
                    <PaymentV2 {...props} />
                ) : (
                    <PaymentContainer>
                        <Payment {...props} defaultToPaymentMethod="card" />
                    </PaymentContainer>
                )}
            </Container>
        </>
    );
};

const getPaymentPageProps = async (): Promise<PaymentPageProps & SideBannerProps> => {
    const paymentDetailsContent = await getPaymentPage('paymentpagetest');
    const isNewDesign = await isEnabled('new-payment-design');
    return {
        paymentDetailsContent,
        isNewDesign: false,
        backgroundColour: isNewDesign ? '#000d68' : paymentDetailsContent?.background.backgroundColour,
    };
};

// export const getStaticProps: GetStaticProps = async () => {
//     const props = await getPaymentPageProps();
//     return {
//         props: props,
//         revalidate: 60,
//     };
// };

export const getServerSideProps: GetServerSideProps = async () => {
    const props = await getPaymentPageProps();
    return {
        props: props,
    };
};

export default withSideBannerLayout(PaymentPage);
