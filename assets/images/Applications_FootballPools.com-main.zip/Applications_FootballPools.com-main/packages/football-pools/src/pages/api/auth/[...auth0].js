/* eslint-disable @typescript-eslint/camelcase */
import auth0 from '../../../../authConfig';

export default auth0.handleAuth({
    async callback(req, res) {
        try {
            await auth0.handleCallback(req, res);
        } catch (error) {
            res.writeHead(302, {
                Location: process.env.SITE_URL + '/account/auth/callback',
            });
            res.end();
        }
    },
    async login(req, res) {
        const { returnurl, cross_return_url: customCrossReturnUrl } = req.query;
        let isIos = false;
        if (req.headers['user-agent'] !== undefined) {
            isIos =
                req.headers['user-agent'].toUpperCase().match(/IPAD|IOS|IPHONE|IPOD|SAFARI/i) !== null &&
                req.headers['user-agent'].toUpperCase().match(/CHROME/i) == null;
        }
        try {
            await auth0.handleLogin(req, res, {
                returnTo:
                    returnurl != '' && returnurl != undefined && isIos
                        ? returnurl
                        : process.env.SITE_URL + '/account/auth/callback',
                authorizationParams: {
                    prompt: 'login',
                    // eslint-disable-next-line @typescript-eslint/camelcase
                    urltest_param:
                        returnurl != '' && returnurl != undefined && isIos ? returnurl : process.env.SITE_URL,
                    // eslint-disable-next-line @typescript-eslint/camelcase
                    urltest_param2: customCrossReturnUrl,
                },
            });
        } catch (error) {
            res.status(500).end(error.message);
        }
    },
});
