import { withApiMiddleware, getOfferingsApiRoute } from '@sportech/pools-api';
import { useSubscriptionApiAdaptor } from '@fp/shared/src/api/subscriptionApi/useSubscriptionApiAdaptor';

export default withApiMiddleware(getOfferingsApiRoute, useSubscriptionApiAdaptor());
