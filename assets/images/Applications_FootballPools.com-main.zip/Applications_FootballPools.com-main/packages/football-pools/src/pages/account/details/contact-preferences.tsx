import { NextPage, GetServerSideProps } from 'next';

import Container from '@containers/account/contactPreferences';
import { AccountDetailsLayout } from '@fp/shared/src/components/Layouts/AccountDetailsLayout/AccountDetailsLayout';
import withLayout from '@fp/shared/src/components/Layouts/Layout/Layout';
import { requiredAuthPage } from '@fp/shared/src/lib/requiredAuthPage';
import { HeadComponent } from '@fp/shared/src/settings/HeadComponent';

const Page: NextPage = () => (
    <>
        <HeadComponent title={'Account | Contact Preferences'} />
        <AccountDetailsLayout operator="footballpools">
            <Container />
        </AccountDetailsLayout>
    </>
);

export default withLayout(Page);

export const getServerSideProps: GetServerSideProps = async ({ req, res }) => {
    requiredAuthPage(req, res, 'footballPools');

    return { props: {} };
};
