/* eslint-disable @typescript-eslint/no-var-requires */
const applicationInsights = require('applicationinsights');

const express = require('express');
const next = require('next');
const { parse } = require('url');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const helmetConfig = require('./helmetConfig');

const dev = process.env.NODE_ENV !== 'production';
const app = next({ dev });
const handle = app.getRequestHandler();

try {
    const key = process.env.APPINSIGHTS_INSTRUMENTATIONKEY;
    console.info(`starting app insights with key ${key}`);
    applicationInsights.setup(key).start();
    applicationInsights.defaultClient.commonProperties = {
        stagingEnvironment: process.env.STAGING_ENVIRONMENT,
    };
    applicationInsights.defaultClient.setAutoPopulateAzureProperties(true);
} catch (err) {
    if (process.env.NODE_ENV !== 'development') {
        console.error('error starting app insights', err, process.env.APPINSIGHTS_INSTRUMENTATIONKEY);
    }
}

const port = process.env.PORT || 3000;

const DEFAULT_TIMEOUT = 90 * 1000;

(async () => {
    await app.prepare();
    const server = express();

    server.use(cookieParser());

    // While the app is using a custom server.js file I think it makes sense to use helmet over next-secure-headers.
    // helmet offers more options and if we move to vercel in future, changing to use next-secure-headers is trivial.
    server.use(helmet(helmetConfig()));

    server.use((req, res, next) => {
        res.setHeader('x-powered-by', '');
        res.setHeader('server', '');
        next();
    });

    // handle nextjs routing
    server.all('*', (req, res) => {
        req.setTimeout(DEFAULT_TIMEOUT);
        res.setTimeout(DEFAULT_TIMEOUT);

        // Be sure to pass `true` as the second argument to `url.parse`.
        // This tells it to parse the query portion of the URL.
        const parsedUrl = parse(req.url, true);
        handle(req, res, parsedUrl);
    });

    try {
        await server.listen(port);
    } catch (err) {
        throw err;
    }

    console.log(`🚀 Ready on http://localhost:${port}`);

    applicationInsights.defaultClient.trackEvent({
        name: 'server_started',
        properties: {
            instanceName: process.env.INSTANCE_NAME || 'local_development',
        },
    });
})();
