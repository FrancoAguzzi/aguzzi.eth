// eslint-disable-next-line @typescript-eslint/no-var-requires
const path = require('path');

console.log('webpack output path:', path.resolve(__dirname, 'dist'));

module.exports = {
    module: {
        rules: [
            {
                test: /\.tsx?$/,
                use: 'ts-loader',
                exclude: /node_modules/,
            },
        ],
    },
    resolve: {
        extensions: ['.ts', '.tsx', '.js'],
    },
    output: {
        filename: 'bundle.js',
        path: path.resolve(__dirname, 'dist'),
    },
};
