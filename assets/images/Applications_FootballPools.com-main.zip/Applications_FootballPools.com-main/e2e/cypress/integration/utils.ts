export const generateRandomString = (length: number, removeNumbers = false) => {
    let ret = Array(length)
        .join((Math.random().toString(36) + '00000000000000000').slice(2, 18))
        .slice(0, length);
    if (removeNumbers) {
        ret = ret.replace(/[0-9]/g, '');
    }
    return ret;
};

export const generateRandomDate = (minDate: Date, maxDate: Date) => {
    return new Date(minDate.getTime() + Math.random() * (maxDate.getTime() - minDate.getTime()));
};
