describe('Login Popup', () => {
    beforeEach(() => {
        cy.visit('/home');
    });

    it('logs user in', () => {
        cy.dataTestId('Header_LoginButton').should('exist'); //.click();
        // cy.dataTestId('LoginForm_EmailInput').should('exist').type('testerpayment03@test.com');
        // cy.dataTestId('LoginForm_PasswordInput').should('exist').type('Plums1234');
        // cy.dataTestId('LoginForm_SubmitButton').should('exist').click();
    });
});
