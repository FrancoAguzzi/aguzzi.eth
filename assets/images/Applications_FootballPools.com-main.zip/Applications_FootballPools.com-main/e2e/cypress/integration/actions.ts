import { generateRandomDate, generateRandomString } from './utils';

export const dismissCookieConsent = () => {
    cy.findByText('Accept').click();
};

const MIN_DATE = new Date(1970, 1);
const MAX_DATE = new Date(2002, 7);

export const registerUserAction = () => {
    cy.intercept('/api/account/create').as('create');
    cy.intercept('/api/account/update').as('update');

    // step 1:

    cy.getById('emailAddress')
        .should('exist')
        .type(`${generateRandomString(8)}@test-subscriptions.footballpools.com`);
    cy.getById('password').should('exist').type('P@5Sw0r41234');
    cy.getById('confirmPassword').should('exist').type('P@5Sw0r41234');
    cy.dataTestId('registration_submit-button').should('exist').click();

    cy.wait('@create').its('response.statusCode').should('eq', 201);
    cy.url({ timeout: 60 * 1000 }).should('include', '/details');

    // step 2:

    const date = generateRandomDate(MIN_DATE, MAX_DATE);
    cy.dataTestId('header_account-button').should('exist').should('be.visible');
    cy.getById('firstName').should('exist').type(generateRandomString(5, true));
    cy.getById('lastName').should('exist').type(generateRandomString(5, true));

    cy.fixture('postcodes.json').then(data => {
        if (data && data.postcodes && data.postcodes.length) {
            const postcodeIndex = Math.round(Math.random() * (data.postcodes.length - 1));
            cy.getById('"address.postcode"').should('exist').type(data.postcodes[postcodeIndex]);
        }
    });

    cy.dataTestId('registration-details_address-picker').should('exist').should('be.enabled').click();
    cy.get('[data-testid*=address-picker_option]')
        .its('length')
        .should('be.gt', 0)
        .then($length => {
            const addressIndex = Math.round(Math.random() * ($length - 1));
            cy.get('[data-testid*=address-picker_option]').eq(addressIndex).click();
        });
    cy.getById('"mobile.number"').should('exist').type('07987654321');
    cy.getById('dobDay').should('exist').click().type(`${date.getDate()}{enter}`);
    cy.getById('dobMonth')
        .should('exist')
        .click()
        .type(`${new Intl.DateTimeFormat('en-GB', { month: 'long' }).format(date).slice(0, 3)}{enter}`);
    cy.getById('dobYear').should('exist').click().type(`${date.getFullYear()}{enter}`);
    cy.dataTestId('registration-details_submit-button').should('exist').should('be.enabled').click();

    cy.wait('@update').its('response.statusCode').should('eq', 200);
};
