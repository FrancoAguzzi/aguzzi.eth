import { dismissCookieConsent, registerUserAction } from '../actions';

describe('Registration Flow', () => {
    beforeEach(() => {
        cy.visit('/registration');
        // dismissCookieConsent();
    });

    it('registers new user with address picker', () => {
        // registerUserAction();
        // cy.url({ timeout: 60 * 1000 }).should('include', '/home');
        cy.url({ timeout: 60 * 1000 }).should('include', '/registration');
    });
});
