import { dismissCookieConsent, registerUserAction } from '../actions';

describe('Game Page', () => {
    beforeEach(() => {
        cy.visit('/games/classic-pools/game');
    });

    // it('displays required elements', () => {
    //     cy.dataTestId('Game_LuckyDipButton').should('exist').should('be.enabled');
    //     cy.dataTestId('Game_HowToPlayButton').should('exist').should('be.enabled');
    //     cy.dataTestId('Game_BuyNewLinesButton').should('exist').should('be.enabled');
    //     cy.dataTestId('Game_PlayButton').should('exist').should('not.be.enabled');
    //     cy.dataTestId('Game_BetslipItem0').should('exist');
    //     cy.dataTestId('Game_BetslipClearButton0').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_0').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_1').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_2').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_3').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_4').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_5').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_6').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_7').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_8').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_9').should('exist');
    // });

    it('completes purchase flow successfully', () => {
        dismissCookieConsent();

        // lucky dip:
        // cy.findByRole('button', { name: 'LUCKY DIP' }).click();
        // cy.findByRole('button', { name: 'PLAY NOW' }).click();

        // // register:
        // cy.url({ timeout: 60 * 1000 }).should('include', '/registration');
        // registerUserAction();

        // // payment:
        // cy.intercept('**/api/wagers/payment-methods/*').as('paymentMethods');
        // cy.intercept('**/api/wagers/create/*').as('createWagers');
        // cy.intercept('**/api/wagers/confirm/*').as('confirmWagers');

        // cy.url({ timeout: 60 * 1000 }).should('include', '/payment');
        // cy.findByRole('button', { name: 'Direct Debit' }).click();
        // cy.wait('@createWagers').its('response.statusCode').should('eq', 201);

        // cy.findByLabelText('ACCOUNT NUMBER').type('12345678');
        // cy.findByRole('textbox', { name: 'SORT CODE' }).type('01');
        // cy.findByRole('textbox', { name: 'sortCode2' }).type('01');
        // cy.findByRole('textbox', { name: 'sortCode3' }).type('01');

        // cy.findByRole('button', { name: 'Submit' }).click();
        // cy.wait('@confirmWagers').its('response.statusCode').should('eq', 200);
    });
});
