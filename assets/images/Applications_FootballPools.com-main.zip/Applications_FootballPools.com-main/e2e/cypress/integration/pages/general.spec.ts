describe('General Page Health', () => {
    beforeEach(() => {
        cy.visit('/home');
    });

    // it('displays required elements', () => {
    //     cy.dataTestId('Game_LuckyDipButton').should('exist').should('be.enabled');
    //     cy.dataTestId('Game_HowToPlayButton').should('exist').should('be.enabled');
    //     cy.dataTestId('Game_BuyNewLinesButton').should('exist').should('be.enabled');
    //     cy.dataTestId('Game_PlayButton').should('exist').should('not.be.enabled');
    //     cy.dataTestId('Game_BetslipItem0').should('exist');
    //     cy.dataTestId('Game_BetslipClearButton0').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_0').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_1').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_2').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_3').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_4').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_5').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_6').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_7').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_8').should('exist');
    //     cy.dataTestId('Game_BetslipCircle0_9').should('exist');
    // });

    it('navigates to basic pages', () => {
        cy.visit('/games/classic-pools');
        cy.visit('/games/classic-pools/game');
        cy.visit('/games/goal-rush');
        cy.visit('/games/goal-rush/game');
        cy.visit('/games/lucky-clover');
        cy.visit('/games/lucky-clover/game');
        cy.visit('/leaderboards/classic-pools');
        cy.visit('/leaderboards/goal-rush');
        cy.visit('/leaderboards/premier-6');
        cy.visit('/leaderboards/premier-10');
        cy.visit('/leaderboards/jackpot-12');
        cy.visit('/promotions');
        cy.visit('/winners');
    });
});
