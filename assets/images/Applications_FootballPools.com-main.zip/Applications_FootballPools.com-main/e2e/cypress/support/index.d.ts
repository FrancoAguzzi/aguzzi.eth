// in cypress/support/index.d.ts
// load type definitions that come with Cypress module
/// <reference types="cypress" />

declare namespace Cypress {
    interface Chainable {
        /**
         * Custom command to select DOM element by data-test attribute.
         * @example cy.dataTestId('greeting')
         */
        dataTestId(value: string): Chainable<Element>;
        containsDataTestId(value: string): Chainable<Element>;
        getById(value: string): Chainable<Element>;
    }
}
