import { Normalize } from 'styled-normalize';

const BrowserResetDecorator = storyFn => (
    <>
        <Normalize />
        {storyFn()}
    </>
);

export default BrowserResetDecorator;
