module.exports = {
    stories: ['../stories/**/*.stories.js'],
    addons: [
        '@storybook/addon-actions/register',
        '@storybook/addon-docs',
        '@storybook/addon-jest',
        '@storybook/addon-knobs/register',
        '@storybook/addon-links',
        '@storybook/addon-storysource',
        '@storybook/addon-viewport/register',
        '@storybook/addon-controls',
    ],
};
