/* eslint-disable import/no-named-as-default-member */
import { group, check, sleep } from 'k6';
import { Options } from 'k6/options';
import http from 'k6/http';
import { Counter } from 'k6/metrics';

export function setSleep(min = 1, max = 2) {
    sleep(Math.floor(Math.random() * (max - min) + min));
}

export const options: Partial<Options> = {
    stages: [
        { duration: '15m', target: 60 },
        { duration: '10m', target: 60 },
        { duration: '3m', target: 100 },
        { duration: '2m', target: 100 },
        { duration: '3m', target: 60 },
        { duration: '10m', target: 60 },
        { duration: '15m', target: 0 },
    ],
};

const numberOfPagesVisited = new Counter('GamePagesVisited');
const numberOfBuilderPagesVisited = new Counter('BuilderPagesVisited');

export function getGamePage(game: string, count: Counter): void {
    const res = http.get(`${BASE_URL}/games/${game}/game`);
    // console.log(res.body);

    if (check(res, { 'success response': r => r.status === 200 })) {
        // let stringToSearch = (res.body as string);
        // const scripts: string[] = [];
        // while (typeof stringToSearch !== undefined && stringToSearch.length > 0) {
        //     const scriptIndex = stringToSearch.search(`<script`);
        //     if (scriptIndex > -1) {
        //         const endScriptIndex =
        //     }
        // }

        count.add(1);
    } else {
        fail(`Game page error ${res.status}`);
    }
}

const BASE_URL = `https://fp-uat-subs-linux.azurewebsites.net`;

const pages = ['classic-pools', 'goal-rush', 'lucky-clover', 'lucky-clover-minigame'];
const builderPages = [
    'about-us',
    'home',
    'news',
    'newsletter',
    'promotions',
    'tfptv',
    'games/classic-pools',
    'games/goal-rush',
    'games/lucky-clover',
];

export default () => {
    group('Visit game page', () => {
        const game = pages[Math.floor(Math.random() * (pages.length - 1))];
        getGamePage(game, numberOfPagesVisited);
    });
    setSleep();

    group('Visit builder page', () => {
        const page = builderPages[Math.floor(Math.random() * (builderPages.length - 1))];
        const res = http.get(`${BASE_URL}/${page}`);

        if (check(res, { 'success response': r => r.status === 200 })) {
            // let stringToSearch = (res.body as string);
            // const scripts: string[] = [];
            // while (typeof stringToSearch !== undefined && stringToSearch.length > 0) {
            //     const scriptIndex = stringToSearch.search(`<script`);
            //     if (scriptIndex > -1) {
            //         const endScriptIndex =
            //     }
            // }

            numberOfBuilderPagesVisited.add(1);
        } else {
            fail(`Builder page error ${res.status}`);
        }
    });
    setSleep(3, 10);
};
